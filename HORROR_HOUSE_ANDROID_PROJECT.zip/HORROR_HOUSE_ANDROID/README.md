# HORROR HOUSE Android project

This Android WebView project packages the supplied Arabic HTML game as an Android app.

- App name: HORROR HOUSE
- Developer branding in the HTML: ASOMA OKAZI GAMES
- Main game file: `app/src/main/assets/index.html`
- Build: GitHub Actions workflow `Build HORROR HOUSE APK`

The game loads Three.js r128 from a CDN, so an internet connection is needed when launching it unless that library is bundled locally.
