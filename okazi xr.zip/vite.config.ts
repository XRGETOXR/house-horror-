import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import * as esbuild from 'esbuild';
import fs from 'fs';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      // Copies src/assets into dist/ so root-relative URLs like
      // "/src/assets/images/..." (e.g. generate_image output) still resolve
      // in production builds. Do not remove.
      {
        name: 'copy-unbundled-src-assets',
        apply: 'build',
        async closeBundle(error?: Error): Promise<void> {
          if (error) {
            return;
          }
          const distDir = path.resolve(__dirname, 'dist');
          const srcAssets = path.resolve(__dirname, 'src/assets');
          const distAssets = path.resolve(distDir, 'src/assets');
          if (fs.existsSync(distDir) && fs.existsSync(srcAssets)) {
            fs.cpSync(srcAssets, distAssets, {recursive: true, force: true});
          }

          // Also emit a self-contained single-file offline HTML game (works via file:// on Android & PC)
          try {
            const assetsDir = path.join(distDir, 'assets');
            let cssText = '';
            if (fs.existsSync(assetsDir)) {
              for (const f of fs.readdirSync(assetsDir)) {
                if (f.endsWith('.css')) {
                  cssText += fs.readFileSync(path.join(assetsDir, f), 'utf8') + '\n';
                }
              }
            }

            const result = await esbuild.build({
              entryPoints: [path.resolve(__dirname, 'src/main.tsx')],
              bundle: true,
              minify: true,
              format: 'iife',
              platform: 'browser',
              target: ['es2020'],
              write: false,
              tsconfig: path.resolve(__dirname, 'tsconfig.json'),
              define: {
                'process.env.NODE_ENV': '"production"',
              },
              loader: {
                '.jpg': 'dataurl',
                '.png': 'dataurl',
                '.webp': 'dataurl',
              },
              plugins: [
                {
                  name: 'ignore-css-imports',
                  setup(build) {
                    build.onLoad({filter: /\.css$/}, () => ({
                      contents: '',
                      loader: 'js',
                    }));
                  },
                },
              ],
            });

            const jsText = result.outputFiles?.[0]?.text || '';
            if (jsText) {
              const safeCss = cssText.replace(/<\/(style)/gi, '<\\/$1');
              const safeJs = jsText.replace(/<\/(script)/gi, '<\\/$1');
              const offlineHtml = `<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <title>بيت المطرقة — نسخة اللعب بدون إنترنت</title>
    <style>${safeCss}</style>
  </head>
  <body class="bg-[#050404] text-[#ebe3d6] antialiased overflow-hidden select-none">
    <div id="root"></div>
    <script>${safeJs}</script>
  </body>
</html>`;
              fs.writeFileSync(path.join(distDir, 'HammerHouse-Game.html'), offlineHtml, 'utf8');
            }
          } catch (offlineErr) {
            console.warn('Could not emit offline single-file HTML:', offlineErr);
          }
        },
      },
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
