interface PauseModalProps {
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onResume: () => void;
  onSettings: () => void;
  onMenu: () => void;
}

export function PauseModal({
  isFullscreen,
  onToggleFullscreen,
  onResume,
  onSettings,
  onMenu,
}: PauseModalProps) {
  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-[rgba(2,1,1,0.82)]"
      dir="rtl"
    >
      <div className="w-full max-w-[440px] text-center space-y-5">
        <h2 className="font-display text-5xl text-[#b3201a]">متوقف مؤقتًا</h2>
        <p className="text-sm text-[#a09384]">رجل المطرقة ينتظرك في الظلام…</p>
        <div className="flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={onResume}
            className="font-display text-2xl px-8 py-1.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[#ebe3d6] cursor-pointer"
          >
            متابعة
          </button>
          <button
            type="button"
            onClick={onToggleFullscreen}
            className="font-display text-2xl px-6 py-1.5 rounded-md border border-[#e2b34a]/45 text-[#e2b34a] hover:bg-white/5 cursor-pointer"
          >
            {isFullscreen ? 'إنهاء ملء الشاشة' : 'ملء الشاشة ⛶'}
          </button>
          <button
            type="button"
            onClick={onSettings}
            className="font-display text-2xl px-6 py-1.5 rounded-md border border-[rgba(235,227,214,0.22)] text-[#ebe3d6] hover:bg-white/5 cursor-pointer"
          >
            الإعدادات
          </button>
          <button
            type="button"
            onClick={onMenu}
            className="font-display text-2xl px-6 py-1.5 rounded-md border border-[rgba(235,227,214,0.22)] text-[#ebe3d6] hover:bg-white/5 cursor-pointer"
          >
            القائمة
          </button>
        </div>
      </div>
    </div>
  );
}
