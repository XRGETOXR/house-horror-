import { useState } from 'react';
import gameCoverImg from '../assets/images/hammer_house_cover_1794939975336.jpg';
import gameIconImg from '../assets/images/hammer_house_icon_1794939976192.jpg';
import { DIFFICULTIES, HOUSE_PRESETS, toArabicDigits } from '../game/constants';
import { DifficultyKey, HouseTheme } from '../game/types';

interface TitleOverlayProps {
  difficulty: DifficultyKey;
  houseTheme: HouseTheme;
  mpRoomCode: string | null;
  mpPeersCount: number;
  onSelectDifficulty: (diff: DifficultyKey) => void;
  onSelectHouseTheme: (theme: HouseTheme) => void;
  onStart: () => void;
  onOpenMultiplayer: () => void;
  onOpenSettings: () => void;
}

const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];
const HOUSE_KEYS: HouseTheme[] = ['manor', 'classic'];

export function TitleOverlay({
  difficulty,
  houseTheme,
  mpRoomCode,
  mpPeersCount,
  onSelectDifficulty,
  onSelectHouseTheme,
  onStart,
  onOpenMultiplayer,
  onOpenSettings,
}: TitleOverlayProps) {
  const [showGuide, setShowGuide] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadNote, setDownloadNote] = useState<string | null>(null);
  const isOfflineFile = typeof window !== 'undefined' && window.location.protocol === 'file:';

  const handleDownloadGame = async () => {
    if (downloading) return;
    setDownloading(true);
    setDownloadNote(null);
    try {
      const res = await fetch('/api/download-offline');
      if (!res.ok) throw new Error('failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HammerHouse-Game.html';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);
      setDownloadNote('تم تنزيل HammerHouse-Game.html! افتحه بالمتصفح للعب بدون إنترنت.');
    } catch {
      setDownloadNote('تعذر التنزيل من المعاينة الحالية.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-20 flex items-center justify-center p-3 sm:p-4 bg-[rgba(2,1,1,0.74)] overflow-y-auto"
      dir="rtl"
    >
      <div className="w-full max-w-[430px] bg-[rgba(12,8,7,0.92)] border border-[rgba(235,227,214,0.16)] rounded-2xl overflow-hidden text-center shadow-2xl">
        {/* Game Cover Artwork Banner & Emblem */}
        <div className="relative h-[132px] sm:h-[152px] w-full overflow-hidden bg-[#0a0606]">
          <img
            src={gameCoverImg}
            alt="غلاف لعبة بيت المطرقة"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center opacity-85"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                'linear-gradient(180deg, rgba(12,8,7,0.15) 0%, rgba(12,8,7,0.58) 58%, rgba(12,8,7,0.98) 100%)',
            }}
          />
          <div className="absolute inset-x-4 bottom-2.5 flex items-center gap-3 text-start">
            <img
              src={gameIconImg}
              alt="شعار بيت المطرقة"
              referrerPolicy="no-referrer"
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover border border-[#e2b34a]/45 shadow-[0_4px_16px_rgba(0,0,0,0.85)] shrink-0"
            />
            <div className="min-w-0">
              <h1 className="font-display text-[clamp(30px,7vw,44px)] leading-none text-[#d3261d] [text-shadow:0_2px_18px_rgba(0,0,0,0.95)]">
                بيت المطرقة
              </h1>
              <p className="text-[11px] sm:text-xs text-[#cfc3b4] mt-0.5 truncate">
                ٥ أيام للنجاة · يدعم الجوال والكمبيوتر
              </p>
            </div>
          </div>
        </div>

        <div className="px-4 pb-4 pt-2 sm:px-5 sm:pb-5 space-y-3">
          {/* House Switcher */}
          <div className="grid grid-cols-2 gap-2">
            {HOUSE_KEYS.map((key) => {
              const hp = HOUSE_PRESETS[key];
              const active = houseTheme === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => onSelectHouseTheme(key)}
                  className={`py-2 px-2.5 rounded-lg border text-start transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#2c1512] border-[#e2b34a] text-[#ebe3d6]'
                      : 'bg-black/45 border-white/12 text-[#a09384] hover:border-white/30'
                  }`}
                >
                  <span className="block text-xs sm:text-sm font-bold truncate">{hp.name}</span>
                  <span className="block text-[10px] text-[#a09384] truncate mt-0.5">
                    {key === 'manor' ? 'جديد · قصر حجري ومدفأة' : 'التصميم الخشبي الأصلي'}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Compact Difficulty Strip */}
          <div className="space-y-1.5">
            <div className="grid grid-cols-5 gap-1.5">
              {DIFF_KEYS.map((key) => {
                const d = DIFFICULTIES[key];
                const active = difficulty === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onSelectDifficulty(key)}
                    className={`py-1.5 px-1 rounded-lg border text-center transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#5e0d0a] border-[#b3201a] text-[#ebe3d6]'
                        : 'bg-black/45 border-white/12 text-[#c2b5a6] hover:border-white/30'
                    }`}
                  >
                    <span className="block text-xs font-bold">{d.name}</span>
                    <span className="block text-[10px] text-[#a09384]">
                      {toArabicDigits(d.keys)}
                    </span>
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-[#b2a596] leading-snug">
              {DIFFICULTIES[difficulty].info}
            </p>
          </div>

          {/* Primary Play Button (triggers Fullscreen) */}
          <button
            type="button"
            onClick={onStart}
            className="w-full min-h-[48px] font-display text-2xl sm:text-3xl py-2 rounded-xl bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[#ebe3d6] cursor-pointer transition-colors shadow-[0_6px_22px_rgba(179,32,26,0.35)]"
          >
            ابدأ الليلة (شاشة كاملة)
          </button>

          {/* Secondary Actions */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={onOpenMultiplayer}
              className="min-h-[42px] px-2 py-1.5 rounded-lg bg-[#241b16] hover:bg-[#33261f] border border-[#e2b34a]/45 text-xs sm:text-sm font-bold text-[#e2b34a] cursor-pointer transition-colors"
            >
              {mpRoomCode
                ? mpRoomCode === 'LAN'
                  ? `LAN (${toArabicDigits(mpPeersCount)})`
                  : `${mpRoomCode} (${toArabicDigits(mpPeersCount)})`
                : 'جماعي LAN'}
            </button>
            <button
              type="button"
              onClick={onOpenSettings}
              className="min-h-[42px] px-2 py-1.5 rounded-lg bg-black/40 hover:bg-white/10 border border-white/18 text-xs sm:text-sm font-bold text-[#ebe3d6] cursor-pointer transition-colors"
            >
              الإعدادات
            </button>
            <button
              type="button"
              onClick={() => setShowGuide((v) => !v)}
              className={`min-h-[42px] px-2 py-1.5 rounded-lg border text-xs sm:text-sm font-bold cursor-pointer transition-colors ${
                showGuide
                  ? 'bg-white/15 border-[#e2b34a] text-[#e2b34a]'
                  : 'bg-black/40 hover:bg-white/10 border-white/18 text-[#ebe3d6]'
              }`}
            >
              دليل اللعب
            </button>
          </div>

          {/* Collapsible Clear Guide */}
          {showGuide && (
            <div className="text-start bg-black/65 border border-white/15 rounded-lg p-3 text-[11px] sm:text-xs text-[#ebe3d6] space-y-2">
              <div className="font-bold text-[#e2b34a]">كيف تفوز؟</div>
              <p className="text-[#c5b9aa] leading-relaxed">
                اجمع المفاتيح، وافتح أقفال باب الخروج بالمطرقة (غرفة الغلايات) ثم قاطع الأسلاك
                (الطابق ٢) ثم المفك (خزنة المكتبة — رمزها بالمطبخ).
              </p>
              <div className="font-bold text-[#e2b34a]">التحكم</div>
              <p className="text-[#c5b9aa] leading-relaxed">
                على الجوال: حرّك بالدائرة يسار الشاشة واسحب يمين الشاشة للالتفات. على الكمبيوتر: W A
                S D للحركة، E للتفاعل، C للانحناء، F للكشاف، M للخريطة.
              </p>
            </div>
          )}

          {/* Offline File Download */}
          {!isOfflineFile && (
            <div className="pt-0.5 space-y-1.5">
              <button
                type="button"
                disabled={downloading}
                onClick={handleDownloadGame}
                className="w-full py-1.5 px-3 rounded-lg bg-black/45 hover:bg-white/10 disabled:opacity-50 border border-[#e2b34a]/30 text-[11px] sm:text-xs font-bold text-[#e2b34a] cursor-pointer transition-colors"
              >
                {downloading ? 'جاري تجهيز الملف...' : 'تحميل أوفلاين (ملف واحد)'}
              </button>
              {downloadNote && (
                <p className="text-[11px] text-[#ebe3d6] bg-[#1c2b1e] border border-[#45b877]/45 rounded-md px-2.5 py-1">
                  {downloadNote}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
