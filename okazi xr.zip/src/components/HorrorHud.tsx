import { useEffect, useRef, useState } from 'react';
import { getHousePreset, toArabicDigits } from '../game/constants';
import { ChatMessage, HudState } from '../game/types';

interface HorrorHudProps {
  hud: HudState;
  isTouch: boolean;
  isFullscreen: boolean;
  chatMessages: ChatMessage[];
  chatOpen: boolean;
  unreadChat: number;
  onToggleChat: (open: boolean) => void;
  onSendChat: (text: string) => void;
  onInteract: () => void;
  onDrop: () => void;
  onFire: () => void;
  onToggleCrouch: () => void;
  onToggleTorch: () => void;
  onToggleMap: () => void;
  onOpenJournal: () => void;
  onPause: () => void;
  onToggleFullscreen: () => void;
  onCycleSpectate: () => void;
  onExitSpectate: () => void;
  onTouchMove: (mx: number, mz: number) => void;
  onTouchRun: (running: boolean) => void;
  onTouchLook: (dx: number, dy: number) => void;
  onSkipCinema: () => void;
}

const PEER_COLORS = ['#5de2ff', '#ffd584', '#8effb8', '#ffa6c4'];

const SWEAT_DROPS = [
  { side: 'left', offset: '1.8%', w: 6, h: 11, delay: '0s', baseDur: 3.1, threshold: 0.12 },
  { side: 'right', offset: '2.1%', w: 7, h: 13, delay: '0.6s', baseDur: 2.8, threshold: 0.12 },
  { side: 'left', offset: '4.6%', w: 5, h: 10, delay: '1.3s', baseDur: 3.4, threshold: 0.28 },
  { side: 'right', offset: '5.2%', w: 6, h: 12, delay: '1.9s', baseDur: 3.0, threshold: 0.28 },
  { side: 'left', offset: '2.9%', w: 8, h: 15, delay: '0.9s', baseDur: 2.5, threshold: 0.46 },
  { side: 'right', offset: '3.4%', w: 8, h: 14, delay: '2.2s', baseDur: 2.6, threshold: 0.46 },
  { side: 'left', offset: '6.8%', w: 5, h: 9, delay: '1.6s', baseDur: 3.2, threshold: 0.65 },
  { side: 'right', offset: '6.9%', w: 5, h: 10, delay: '0.3s', baseDur: 3.1, threshold: 0.65 },
  { side: 'left', offset: '1.2%', w: 7, h: 14, delay: '2.4s', baseDur: 2.3, threshold: 0.8 },
  { side: 'right', offset: '1.4%', w: 7, h: 14, delay: '1.1s', baseDur: 2.4, threshold: 0.8 },
] as const;

export function HorrorHud({
  hud,
  isTouch,
  isFullscreen,
  chatMessages,
  chatOpen,
  unreadChat,
  onToggleChat,
  onSendChat,
  onInteract,
  onDrop,
  onFire,
  onToggleCrouch,
  onToggleTorch,
  onToggleMap,
  onOpenJournal,
  onPause,
  onToggleFullscreen,
  onCycleSpectate,
  onExitSpectate,
  onTouchMove,
  onTouchRun,
  onTouchLook,
  onSkipCinema,
}: HorrorHudProps) {
  const mapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const stickRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);
  const lookZoneRef = useRef<HTMLDivElement | null>(null);
  const chatInputRef = useRef<HTMLInputElement | null>(null);
  const chatListRef = useRef<HTMLDivElement | null>(null);
  const [chatDraft, setChatDraft] = useState('');
  const [touchSprint, setTouchSprint] = useState(false);

  const showPlayHud = hud.state === 'play';

  useEffect(() => {
    if (!showPlayHud || hud.crouch) {
      setTouchSprint(false);
      onTouchRun(false);
    }
  }, [showPlayHud, hud.crouch, onTouchRun]);

  useEffect(() => {
    if (chatOpen) {
      const id = window.setTimeout(() => chatInputRef.current?.focus(), 20);
      return () => window.clearTimeout(id);
    }
    return undefined;
  }, [chatOpen]);

  useEffect(() => {
    if (chatListRef.current) {
      chatListRef.current.scrollTop = chatListRef.current.scrollHeight;
    }
  }, [chatMessages.length, chatOpen]);

  // Draw mini-map when open
  useEffect(() => {
    if (!hud.mapOpen || !mapCanvasRef.current) return;
    const c = mapCanvasRef.current;
    const g = c.getContext('2d');
    if (!g) return;
    const Z = 5;
    const preset = getHousePreset(hud.houseTheme);
    const list = hud.floor ? preset.rooms1 : preset.rooms0;
    const st = preset.stairBounds;

    g.clearRect(0, 0, 300, 290);
    g.fillStyle = 'rgba(0,0,0,0.65)';
    g.fillRect(0, 0, 300, 290);
    g.lineWidth = 1;
    g.strokeStyle = 'rgba(235,227,214,0.55)';
    g.fillStyle = 'rgba(235,227,214,0.72)';
    g.font = '9px Tajawal, sans-serif';
    g.textAlign = 'center';

    list.forEach((r) => {
      g.strokeRect(r.x1 * Z + 0.5, r.z1 * Z + 0.5, (r.x2 - r.x1) * Z, (r.z2 - r.z1) * Z);
      g.fillText(r.name, r.cx * Z, r.cz * Z);
    });

    g.strokeRect(0.5, 16 * Z + 0.5, 60 * Z, 8 * Z);
    g.fillText(hud.floor ? 'الصالة العليا' : 'الممر الطويل', 40 * Z, 19 * Z);

    g.fillStyle = 'rgba(226,179,74,0.45)';
    g.fillRect(st.x1 * Z, st.z1 * Z, (st.x2 - st.x1) * Z, (st.z2 - st.z1) * Z);
    g.fillStyle = 'rgba(235,227,214,0.85)';
    g.fillText('الدرج', ((st.x1 + st.x2) / 2) * Z, st.z1 * Z - 3);

    if (!hud.floor) {
      g.fillStyle = '#46ff82';
      g.fillRect(59 * Z, (32 - 1.4) * Z, 4, 2.8 * Z);
    }

    g.fillStyle = 'rgba(235,227,214,0.85)';
    g.textAlign = 'start';
    g.fillText(hud.floor ? 'الطابق الثاني' : 'الطابق الأرضي', 6, 12);

    g.save();
    g.translate(hud.playerX * Z, hud.playerZ * Z);
    g.rotate(-hud.playerYaw + Math.PI);
    g.fillStyle = '#ff6a4a';
    g.beginPath();
    g.moveTo(0, -7);
    g.lineTo(5, 5);
    g.lineTo(-5, 5);
    g.closePath();
    g.fill();
    g.restore();

    // Draw live multiplayer teammates & fallen corpses on same floor
    hud.mpPeers.forEach((p) => {
      if (p.escaped || p.fl !== hud.floor) return;
      const col = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
      if (!p.alive) {
        g.strokeStyle = '#ff5a4d';
        g.lineWidth = 2.2;
        g.beginPath();
        g.moveTo(p.x * Z - 5, p.z * Z - 5);
        g.lineTo(p.x * Z + 5, p.z * Z + 5);
        g.moveTo(p.x * Z + 5, p.z * Z - 5);
        g.lineTo(p.x * Z - 5, p.z * Z + 5);
        g.stroke();

        g.fillStyle = '#ff7b6e';
        g.font = 'bold 9px Tajawal, sans-serif';
        g.textAlign = 'center';
        g.fillText(`${p.name} (جثة)`, p.x * Z, p.z * Z - 8);
        return;
      }

      g.save();
      g.translate(p.x * Z, p.z * Z);
      g.rotate(-p.yaw + Math.PI);
      g.fillStyle = col;
      g.beginPath();
      g.moveTo(0, -6.5);
      g.lineTo(4.5, 4.5);
      g.lineTo(-4.5, 4.5);
      g.closePath();
      g.fill();
      g.restore();

      g.fillStyle = col;
      g.font = 'bold 9px Tajawal, sans-serif';
      g.textAlign = 'center';
      g.fillText(p.name, p.x * Z, p.z * Z - 9);
    });
  }, [hud.mapOpen, hud.houseTheme, hud.floor, hud.playerX, hud.playerZ, hud.playerYaw, hud.mpPeers]);

  // Bind virtual joystick & touch look reliably whenever Play HUD mounts
  useEffect(() => {
    if (!showPlayHud || !isTouch) {
      onTouchMove(0, 0);
      return;
    }
    const stick = stickRef.current;
    const knob = knobRef.current;
    const lookZone = lookZoneRef.current;
    if (!stick || !knob || !lookZone) return;

    let sid: number | null = null;
    let cx = 0;
    let cy = 0;
    let lid: number | null = null;
    let lx = 0;
    let ly = 0;

    const mv = (clientX: number, clientY: number) => {
      let dx = clientX - cx;
      let dy = clientY - cy;
      const l = Math.hypot(dx, dy);
      const m = 52;
      if (l > m) {
        dx *= m / l;
        dy *= m / l;
      }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      onTouchMove(dx / m, -dy / m);
    };

    const resetStick = () => {
      sid = null;
      onTouchMove(0, 0);
      knob.style.transform = 'none';
    };

    const onStickStart = (e: TouchEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (sid !== null) return;
      const t = e.changedTouches[0];
      sid = t.identifier;
      const r = stick.getBoundingClientRect();
      cx = r.left + r.width / 2;
      cy = r.top + r.height / 2;
      mv(t.clientX, t.clientY);
    };

    const onLookStart = (e: TouchEvent) => {
      e.preventDefault();
      if (lid !== null) return;
      const t = e.changedTouches[0];
      lid = t.identifier;
      lx = t.clientX;
      ly = t.clientY;
    };

    const onWindowTouchMove = (e: TouchEvent) => {
      let handled = false;
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (sid !== null && t.identifier === sid) {
          mv(t.clientX, t.clientY);
          handled = true;
        } else if (lid !== null && t.identifier === lid) {
          onTouchLook(t.clientX - lx, t.clientY - ly);
          lx = t.clientX;
          ly = t.clientY;
          handled = true;
        }
      }
      if (handled) e.preventDefault();
    };

    const onWindowTouchEnd = (e: TouchEvent) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (sid !== null && t.identifier === sid) {
          resetStick();
        }
        if (lid !== null && t.identifier === lid) {
          lid = null;
        }
      }
    };

    // Mouse-drag fallback if user forces Touch Mode on desktop
    let mouseStickDown = false;
    const onStickMouseDown = (e: MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      mouseStickDown = true;
      const r = stick.getBoundingClientRect();
      cx = r.left + r.width / 2;
      cy = r.top + r.height / 2;
      mv(e.clientX, e.clientY);
    };
    const onWindowMouseMove = (e: MouseEvent) => {
      if (!mouseStickDown) return;
      mv(e.clientX, e.clientY);
    };
    const onWindowMouseUp = () => {
      if (!mouseStickDown) return;
      mouseStickDown = false;
      resetStick();
    };

    stick.addEventListener('touchstart', onStickStart, { passive: false });
    stick.addEventListener('mousedown', onStickMouseDown);
    lookZone.addEventListener('touchstart', onLookStart, { passive: false });
    window.addEventListener('touchmove', onWindowTouchMove, { passive: false });
    window.addEventListener('touchend', onWindowTouchEnd);
    window.addEventListener('touchcancel', onWindowTouchEnd);
    window.addEventListener('mousemove', onWindowMouseMove);
    window.addEventListener('mouseup', onWindowMouseUp);

    return () => {
      resetStick();
      stick.removeEventListener('touchstart', onStickStart);
      stick.removeEventListener('mousedown', onStickMouseDown);
      lookZone.removeEventListener('touchstart', onLookStart);
      window.removeEventListener('touchmove', onWindowTouchMove);
      window.removeEventListener('touchend', onWindowTouchEnd);
      window.removeEventListener('touchcancel', onWindowTouchEnd);
      window.removeEventListener('mousemove', onWindowMouseMove);
      window.removeEventListener('mouseup', onWindowMouseUp);
    };
  }, [showPlayHud, isTouch, onTouchLook, onTouchMove]);

  const fatigueLevel = hud.exhausted ? 1 : Math.max(0, (0.44 - hud.stamina) / 0.44);
  const panicLevel =
    hud.stalkerState === 'chase'
      ? Math.max(0.65, hud.threat)
      : Math.max(0, (hud.threat - 0.5) / 0.5);
  const sweatLevel =
    hud.state === 'play' || hud.state === 'pad'
      ? Math.max(fatigueLevel, panicLevel)
      : 0;

  return (
    <>
      {/* Visual Atmosphere Layers */}
      <div
        className="fixed inset-0 pointer-events-none z-5"
        style={{
          background:
            'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.72) 100%)',
        }}
      />
      <div
        className="fixed inset-0 pointer-events-none z-6"
        style={{
          background:
            'radial-gradient(ellipse at center, transparent 35%, rgba(150,0,0,0.85) 100%)',
          opacity: hud.dangerOpacity,
        }}
      />
      {sweatLevel > 0.1 && (
        <div
          className="fixed inset-0 pointer-events-none z-7 overflow-hidden"
          style={{ opacity: Math.min(0.85, 0.25 + sweatLevel * 0.6) }}
        >
          {SWEAT_DROPS.map((d, idx) => {
            if (sweatLevel < d.threshold) return null;
            const dur = Math.max(1.25, d.baseDur - sweatLevel * 1.15);
            return (
              <div
                key={idx}
                className="sweat-drop fixed top-0"
                style={{
                  [d.side]: d.offset,
                  width: `${d.w}px`,
                  height: `${d.h}px`,
                  animationDuration: `${dur.toFixed(2)}s`,
                  animationDelay: d.delay,
                }}
              />
            );
          })}
        </div>
      )}
      {hud.hidden && hud.hiddenKind !== 'bed' && (
        <div
          className="fixed inset-0 pointer-events-none z-7"
          style={{
            background:
              'repeating-linear-gradient(180deg, #020101 0 20px, rgba(0,0,0,0) 20px 27px)',
            boxShadow: 'inset 0 0 140px 60px #000',
          }}
        />
      )}
      {hud.hitFlash > 0 && (
        <div
          className="fixed inset-0 pointer-events-none z-8 bg-[#7a0000]"
          style={{ opacity: hud.hitFlash }}
        />
      )}
      {hud.lidOpacity > 0 && (
        <div
          className="fixed inset-0 pointer-events-none z-9 bg-black"
          style={{ opacity: hud.lidOpacity }}
        />
      )}

      {/* Cinema Bars & Captions */}
      {hud.cinemaBars && (
        <>
          <div className="fixed inset-x-0 top-0 h-[11vh] bg-black z-15 pointer-events-none transition-all duration-700" />
          <div className="fixed inset-x-0 bottom-0 h-[11vh] bg-black z-15 pointer-events-none transition-all duration-700" />
          {hud.cinemaFlash > 0 && (
            <div
              className="fixed inset-0 bg-white z-16 pointer-events-none"
              style={{ opacity: hud.cinemaFlash }}
            />
          )}
          {hud.cinemaCaption && (
            <div
              className={`fixed inset-x-0 text-center font-display z-17 pointer-events-none px-4 ${
                hud.cinemaBig
                  ? 'top-[36%] text-[clamp(56px,13vw,130px)] text-[#d3261d] [text-shadow:0_0_40px_rgba(211,38,29,0.7)]'
                  : 'bottom-[15vh] text-[clamp(28px,6vw,58px)] text-[#ebe3d6] [text-shadow:0_4px_24px_#000]'
              }`}
            >
              {hud.cinemaCaption}
            </div>
          )}
          {hud.state === 'cinema' && (
            <button
              type="button"
              onClick={onSkipCinema}
              className="fixed right-4 bottom-4 z-20 px-4 py-1.5 rounded-md bg-[rgba(14,10,9,0.9)] border border-[rgba(235,227,214,0.2)] text-sm text-[#ebe3d6] cursor-pointer hover:bg-white/10"
            >
              تخطي ⏭
            </button>
          )}
        </>
      )}

      {/* Spectating Overlay (LAN / Multiplayer after falling — corpse waits to be revived) */}
      {hud.state === 'spec' && (
        <div className="fixed inset-x-0 top-4 z-20 flex flex-col items-center gap-1.5 px-4 pointer-events-none" dir="rtl">
          <div className="pointer-events-auto bg-[rgba(14,10,9,0.92)] border border-[#e2b34a]/45 rounded-lg px-4 py-2.5 flex items-center gap-3 text-sm text-[#ebe3d6] flex-wrap justify-center">
            <span>
              تتابع الآن:{' '}
              <strong className="text-[#e2b34a]">{hud.mpSpectatingName || 'اللاعب الأول'}</strong>
            </span>
            {hud.mpPeers.filter((p) => p.alive && !p.escaped).length > 1 && (
              <button
                type="button"
                onClick={onCycleSpectate}
                className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 border border-white/20 text-xs cursor-pointer"
              >
                تبديل (E)
              </button>
            )}
            <button
              type="button"
              onClick={onExitSpectate}
              className="px-2.5 py-1 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-xs cursor-pointer"
            >
              القائمة
            </button>
          </div>
          <div className="bg-[rgba(40,10,8,0.88)] border border-[#b3201a]/50 rounded-md px-3 py-1 text-xs text-[#ffd2cc]">
            جثتك في مكانها — يمكن لزميلك الاقتراب وإنعاشك خلال ٥ ثوانٍ
          </div>
        </div>
      )}

      {/* Active Play HUD */}
      {showPlayHud && (
        <div className="fixed inset-0 pointer-events-none z-10 flex flex-col justify-between p-2.5 sm:p-4">
          {/* Top Row */}
          <div className="flex items-start justify-between gap-2 flex-wrap">
            {/* Top-Right in RTL: Horror Remaining Days Counter, Room & Locks */}
            <div
              className={`bg-[rgba(12,6,6,0.92)] rounded-md px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs sm:text-sm space-y-1 border ${
                hud.livesLeft <= 2
                  ? 'border-[#b3201a] shadow-[0_0_18px_rgba(179,32,26,0.4)]'
                  : 'border-[rgba(235,227,214,0.18)]'
              }`}
            >
              <div className="flex items-center justify-between gap-2.5">
                <div className="flex items-center gap-1.5">
                  <svg
                    viewBox="0 0 24 24"
                    className={`w-4 h-4 shrink-0 ${
                      hud.livesLeft <= 2 ? 'text-[#ff3b30]' : 'text-[#b3201a]'
                    }`}
                    fill="currentColor"
                    aria-hidden="true"
                  >
                    <path d="M12 2C7.03 2 3 5.82 3 10.5c0 2.74 1.38 5.17 3.54 6.7V20a1 1 0 0 0 1 1h1.5v-2h1.5v2h3v-2H15v2h1.5a1 1 0 0 0 1-1v-2.8C19.62 15.67 21 13.24 21 10.5 21 5.82 16.97 2 12 2zm-3 10a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm6 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" />
                  </svg>
                  <span
                    className={`font-display text-sm sm:text-lg leading-none ${
                      hud.livesLeft <= 2 ? 'text-[#ff4d43]' : 'text-[#e2b34a]'
                    }`}
                  >
                    الأيام: {toArabicDigits(hud.livesLeft)}
                  </span>
                </div>
                <span className="text-[11px] text-[#c5b9aa] max-w-[130px] truncate">
                  {hud.roomName}
                </span>
              </div>

              <div className="flex items-center gap-1" aria-label={`الأيام المتبقية ${hud.livesLeft} من ${hud.maxDays}`}>
                {Array.from({ length: hud.maxDays }).map((_, idx) => {
                  const lostCount = Math.max(0, hud.maxDays - hud.livesLeft);
                  const isLost = idx < lostCount;
                  const isCurrent = idx === lostCount && hud.livesLeft > 0;
                  return (
                    <div
                      key={idx}
                      className={`relative w-5 h-5 sm:w-6 sm:h-6 rounded border flex items-center justify-center font-mono-num text-[11px] sm:text-xs font-bold select-none ${
                        isLost
                          ? 'bg-[#1a0505] border-[#6e110d] text-[#6b3939]'
                          : isCurrent
                            ? hud.livesLeft === 1
                              ? 'bg-[#4f0b09] border-[#ff4d43] text-[#ffdad6]'
                              : 'bg-[#2a170e] border-[#e2b34a] text-[#e2b34a]'
                            : 'bg-[#130e0d] border-white/20 text-[#ebe3d6]'
                      }`}
                    >
                      <span>{toArabicDigits(idx + 1)}</span>
                      {isLost && (
                        <svg
                          viewBox="0 0 24 24"
                          className="absolute inset-0 w-full h-full text-[#d9231a]"
                          stroke="currentColor"
                          strokeWidth="2.8"
                          strokeLinecap="round"
                        >
                          <line x1="4" y1="4" x2="20" y2="20" />
                          <line x1="20" y1="4" x2="4" y2="20" />
                        </svg>
                      )}
                    </div>
                  );
                })}
                {hud.livesLeft === 1 && (
                  <span className="text-[10px] font-bold text-[#ff4d43] ms-1">
                    أخير!
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs text-[#a09384]">
                <span className={hud.locks.plankBroken ? 'text-[#6fbf73]' : ''}>
                  {hud.locks.plankBroken ? '✓ لوح' : '— لوح'}
                </span>
                <span aria-hidden="true">·</span>
                <span className={hud.locks.wireCut ? 'text-[#6fbf73]' : ''}>
                  {hud.locks.wireCut ? '✓ سلك' : '— سلك'}
                </span>
                <span aria-hidden="true">·</span>
                <span className={hud.locks.panelOpened ? 'text-[#6fbf73]' : ''}>
                  {hud.locks.panelOpened ? '✓ غطاء' : '— غطاء'}
                </span>
              </div>

              {hud.mpRoomCode && (
                <div className="pt-1 border-t border-white/10 flex items-center gap-2 flex-wrap text-[11px]">
                  <span className="text-[#e2b34a] font-mono-num font-bold">
                    غرفة {hud.mpRoomCode}
                  </span>
                  {hud.mpPeers.map((p) => {
                    const col = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
                    const st = !p.alive
                      ? 'سقط'
                      : p.escaped
                        ? 'هرب'
                        : p.hiddenIdx >= 0
                          ? 'مختبئ'
                          : p.fl
                            ? 'ط٢'
                            : 'ط١';
                    return (
                      <span
                        key={p.id}
                        className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-black/50 border border-white/15 text-[#ebe3d6]"
                      >
                        <span
                          className="w-2 h-2 rounded-sm shrink-0"
                          style={{ backgroundColor: col }}
                        />
                        <span>{p.name}</span>
                        <span className="text-[#a09384]">({st})</span>
                      </span>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Center Alerts: Exit Arrow / Stun Timer / Chase Warning */}
            <div className="flex flex-col items-center gap-1.5">
              {hud.exitArrowAngle !== null && (
                <div className="bg-[rgba(14,10,9,0.88)] border border-[rgba(70,255,130,0.4)] rounded-md px-3 py-1 text-xs sm:text-sm text-[#46ff82] flex items-center gap-2">
                  <span
                    className="inline-block font-bold text-lg leading-none"
                    style={{ transform: `rotate(${hud.exitArrowAngle.toFixed(3)}rad)` }}
                  >
                    ↑
                  </span>
                  <span>{hud.exitArrowText}</span>
                </div>
              )}

              {hud.stalkerStunLeft > 0 && (
                <div className="bg-[rgba(14,10,9,0.9)] border border-[#e2b34a]/50 rounded-md px-3 py-1 text-xs sm:text-sm text-[#e2b34a] font-bold font-mono-num">
                  الوحش فاقد للوعي: {toArabicDigits(hud.stalkerStunLeft)} ث
                </div>
              )}

              {hud.stalkerState === 'chase' && hud.stalkerStunLeft <= 0 && (
                <div className="font-display text-2xl text-[#ff5a4d] [text-shadow:0_2px_10px_#000]">
                  يطاردك!
                </div>
              )}
            </div>

            {/* Top-Left in RTL: Keys, Diary Notes, Fullscreen & Pause */}
            <div className="flex items-center gap-1.5 pointer-events-auto">
              <div className="bg-[rgba(14,10,9,0.88)] border border-[rgba(235,227,214,0.16)] rounded-md px-2.5 py-1.5 text-xs sm:text-sm flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <span className="text-[#e2b34a] font-bold">مفاتيح</span>
                  <span className="font-mono-num font-bold text-[#ebe3d6]">
                    {toArabicDigits(hud.keys)}/{toArabicDigits(hud.needKeys)}
                  </span>
                </div>
                <span aria-hidden="true" className="text-white/25">
                  ·
                </span>
                <button
                  type="button"
                  onClick={onOpenJournal}
                  className={`flex items-center gap-1 cursor-pointer transition-colors ${
                    hud.notesRead.length > 0 ? 'text-[#e6d7b8] hover:text-[#e2b34a]' : 'text-[#a09384]'
                  }`}
                  title="مذكرات (N)"
                >
                  <span className="font-bold">مذكرات</span>
                  <span className="font-mono-num font-bold">
                    {toArabicDigits(hud.notesRead.length)}/{toArabicDigits(hud.totalNotes)}
                  </span>
                </button>
                {hud.codeKnown && !hud.safeOpen && (
                  <>
                    <span aria-hidden="true" className="text-white/25">
                      ·
                    </span>
                    <span className="text-[#e2b34a] font-mono-num font-bold">
                      {toArabicDigits(hud.safeCode)}
                    </span>
                  </>
                )}
              </div>

              <button
                type="button"
                onClick={onToggleFullscreen}
                aria-label={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
                title={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
                className="min-w-[38px] min-h-[38px] px-2 rounded-md bg-[rgba(14,10,9,0.9)] border border-white/20 text-xs sm:text-sm text-[#ebe3d6] hover:bg-white/10 cursor-pointer flex items-center justify-center"
              >
                ⛶
              </button>
              <button
                type="button"
                onClick={onPause}
                aria-label="إيقاف مؤقت"
                title="إيقاف مؤقت (P)"
                className="min-w-[38px] min-h-[38px] px-2.5 rounded-md bg-[rgba(14,10,9,0.9)] border border-white/20 text-xs sm:text-sm text-[#ebe3d6] hover:bg-white/10 cursor-pointer flex items-center justify-center"
              >
                ⏸
              </button>
            </div>
          </div>

          {/* Bottom Row: Held Item + Stamina (shifted up above joystick on Touch devices) */}
          <div className={`flex items-end justify-between gap-3 ${isTouch ? 'mb-[152px]' : ''}`}>
            <div className="bg-[rgba(14,10,9,0.88)] border border-[rgba(235,227,214,0.16)] rounded-md px-2.5 py-1.5 space-y-1 min-w-[148px] sm:min-w-[170px]">
              <div className="flex items-center justify-between gap-2 text-xs sm:text-sm">
                <span className="text-[#a09384]">في يدك:</span>
                <span className="font-bold text-[#e2b34a]">{hud.heldLabel}</span>
              </div>
              {hud.heldItem && !isTouch && (
                <div className="text-[11px] text-[#a09384]">
                  اضغط <kbd className="px-1 border border-white/20 rounded text-[#ebe3d6]">G</kbd>{' '}
                  لرمي الأداة
                </div>
              )}
              {hud.hasGun && (
                <div className="text-xs text-[#ebe3d6] font-mono-num">
                  الرصاص: {toArabicDigits(hud.ammo)}
                </div>
              )}
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-[#a09384]">
                  {hud.crouch ? 'منحنٍ' : 'طاقة'}
                </span>
                <div className="flex-1 h-2 bg-white/10 rounded overflow-hidden">
                  <div
                    className={`h-full origin-right transition-transform duration-75 ${
                      hud.exhausted ? 'bg-[#c9502f]' : 'bg-[#ebe3d6]'
                    }`}
                    style={{ transform: `scaleX(${hud.stamina.toFixed(3)})` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Center Crosshair, Prompt, Bear Trap Struggle, and Toast */}
      {showPlayHud && (
        <>
          <div className="fixed left-1/2 top-1/2 w-1.5 h-1.5 -ml-[3px] -mt-[3px] rounded-full bg-[rgba(235,227,214,0.6)] pointer-events-none z-11" />

          {hud.trappedTimer > 0 && (
            <div className="fixed left-1/2 bottom-[36%] -translate-x-1/2 z-12 pointer-events-none bg-[rgba(94,13,10,0.92)] border border-[#b3201a] rounded-md px-4 py-2 text-center space-y-1.5 min-w-[230px]">
              <div className="text-sm font-bold text-white">
                {isTouch
                  ? 'عالِق في فخ الدب! اضغط تفاعل باستمرار'
                  : 'عالِق في فخ الدب! اضغط E باستمرار للتحرر'}
              </div>
              <div className="h-2 bg-black/50 rounded overflow-hidden">
                <div
                  className="h-full bg-[#e2b34a]"
                  style={{ width: `${Math.min(100, Math.max(10, (1 - hud.trappedTimer / 3.2) * 100))}%` }}
                />
              </div>
            </div>
          )}

          {hud.revivingTargetName && (
            <div className="fixed left-1/2 bottom-[34%] -translate-x-1/2 z-12 pointer-events-none bg-[rgba(28,12,8,0.94)] border border-[#e2b34a]/70 rounded-md px-4 py-2.5 text-center space-y-1.5 min-w-[250px] shadow-[0_0_24px_rgba(0,0,0,0.65)]">
              <div className="text-sm font-bold text-[#ffe6aa] flex items-center justify-between gap-3">
                <span>جارٍ إنعاش {hud.revivingTargetName}...</span>
                <span className="font-mono-num text-[#e2b34a]">
                  {toArabicDigits(Math.ceil(hud.revivingTimeLeft))} ث
                </span>
              </div>
              <div className="h-2.5 bg-black/60 rounded overflow-hidden border border-white/15">
                <div
                  className="h-full bg-gradient-to-l from-[#e2b34a] to-[#6fbf73] transition-[width] duration-75"
                  style={{ width: `${Math.min(100, Math.max(4, hud.revivingProgress * 100))}%` }}
                />
              </div>
              <div className="text-[11px] font-bold text-[#ff7364]">
                انتبه! الضجيج يجذب رجل المطرقة إليكما الآن
              </div>
            </div>
          )}

          {hud.prompt && (
            <div className="fixed left-1/2 bottom-[25%] -translate-x-1/2 z-12 pointer-events-none bg-[rgba(14,10,9,0.92)] border border-[rgba(235,227,214,0.2)] rounded-md px-3.5 py-1.5 text-xs sm:text-sm text-[#ebe3d6] whitespace-nowrap max-w-[92vw]">
              {!isTouch && (
                <b className="inline-block min-w-[24px] px-1.5 me-2 border border-[#ebe3d6] rounded text-center">
                  E
                </b>
              )}
              <span>{hud.prompt}</span>
            </div>
          )}

          {hud.toast && (
            <div className="fixed left-1/2 top-[17%] -translate-x-1/2 z-12 pointer-events-none font-display text-lg sm:text-2xl text-center text-[#ebe3d6] [text-shadow:0_2px_10px_#000] max-w-[90vw]">
              {hud.toast}
            </div>
          )}
        </>
      )}

      {/* In-Game Multiplayer Live Chat Overlay */}
      {hud.mpRoomCode && (hud.state === 'play' || hud.state === 'spec') && (
        <div
          className={`fixed z-22 w-[min(320px,82vw)] pointer-events-none ${
            isTouch ? 'top-28 left-3' : 'bottom-4 left-4'
          }`}
          dir="rtl"
        >
          <div className="pointer-events-auto bg-[rgba(12,8,7,0.86)] border border-[rgba(235,227,214,0.18)] rounded-lg p-2 space-y-1.5">
            <div className="flex items-center justify-between gap-2 text-[11px]">
              <button
                type="button"
                onClick={() => onToggleChat(!chatOpen)}
                className="flex items-center gap-1.5 font-bold text-[#e2b34a] hover:text-[#f0c766] cursor-pointer"
              >
                <span>الدردشة الجماعية</span>
                {!isTouch && !chatOpen && (
                  <kbd className="px-1 border border-white/20 rounded text-[10px] text-[#c5b9aa]">
                    T
                  </kbd>
                )}
                {unreadChat > 0 && !chatOpen && (
                  <span className="px-1.5 py-0.2 rounded bg-[#b3201a] text-white font-mono-num text-[10px]">
                    {toArabicDigits(unreadChat)}
                  </span>
                )}
              </button>
              {chatOpen && (
                <button
                  type="button"
                  onClick={() => onToggleChat(false)}
                  className="text-[11px] text-[#a09384] hover:text-white cursor-pointer"
                >
                  إغلاق (Esc)
                </button>
              )}
            </div>

            {(chatOpen || chatMessages.length > 0) && (
              <div
                ref={chatListRef}
                className={`overflow-y-auto space-y-1 text-xs pe-1 ${
                  chatOpen ? 'max-h-36' : 'max-h-20'
                }`}
              >
                {(chatOpen ? chatMessages : chatMessages.slice(-3)).map((m) => {
                  const col = PEER_COLORS[Math.abs(m.colorIndex) % PEER_COLORS.length];
                  return (
                    <div key={m.id} className="leading-snug break-words">
                      {m.system ? (
                        <span className="text-[11px] text-[#a09384] italic">{m.text}</span>
                      ) : (
                        <>
                          <span className="font-bold me-1.5" style={{ color: col }}>
                            {m.senderName}:
                          </span>
                          <span className="text-[#ebe3d6]">{m.text}</span>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {chatOpen && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const clean = chatDraft.trim();
                  if (clean) {
                    onSendChat(clean);
                    setChatDraft('');
                  }
                  onToggleChat(false);
                }}
                className="flex gap-1.5 pt-0.5"
              >
                <input
                  ref={chatInputRef}
                  type="text"
                  maxLength={160}
                  value={chatDraft}
                  onChange={(e) => setChatDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') {
                      e.preventDefault();
                      onToggleChat(false);
                    }
                  }}
                  placeholder="اكتب رسالة لزملائك..."
                  className="flex-1 min-w-0 px-2 py-1 rounded bg-black/65 border border-[#e2b34a]/40 text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-xs font-bold text-[#ebe3d6] cursor-pointer"
                >
                  إرسال
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Mini-Map Modal */}
      {showPlayHud && hud.mapOpen && (
        <div className="fixed top-20 start-4 z-14 bg-[rgba(14,10,9,0.92)] border border-[rgba(235,227,214,0.2)] rounded-md p-2 pointer-events-none">
          <canvas ref={mapCanvasRef} width={300} height={290} className="w-[min(300px,70vw)] h-auto block" />
          <small className="block text-[#a09384] mt-1 text-xs">
            {isTouch ? 'اضغط زر خريطة للإغلاق' : 'اضغط M للإغلاق'}
          </small>
        </div>
      )}

      {/* Touch Controls for Mobile/Tablet */}
      {showPlayHud && isTouch && (
        <div className="fixed inset-0 z-13 pointer-events-none">
          {/* Right-side Look Zone */}
          <div
            ref={lookZoneRef}
            className="absolute inset-y-0 left-[42%] right-0 pointer-events-auto touch-none"
          />

          {/* Virtual Stick (Bottom Left - always LTR fixed coordinates) */}
          <div
            ref={stickRef}
            className="absolute left-5 bottom-6 w-[132px] h-[132px] rounded-full bg-white/10 border-2 border-[rgba(235,227,214,0.28)] pointer-events-auto touch-none shadow-[0_0_24px_rgba(0,0,0,0.45)]"
          >
            <span className="absolute top-1.5 left-1/2 -translate-x-1/2 text-[10px] text-white/35 pointer-events-none">
              ▲
            </span>
            <span className="absolute bottom-1.5 left-1/2 -translate-x-1/2 text-[10px] text-white/35 pointer-events-none">
              ▼
            </span>
            <div
              ref={knobRef}
              className="absolute left-1/2 top-1/2 w-[54px] h-[54px] -ml-[27px] -mt-[27px] rounded-full bg-[rgba(235,227,214,0.42)] border border-white/50 shadow-md pointer-events-none"
            />
          </div>

          {/* Action Buttons (Bottom Right) */}
          <div
            className="absolute right-4 bottom-5 grid grid-cols-2 gap-2.5 pointer-events-auto"
            onTouchStart={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                const next = !touchSprint;
                setTouchSprint(next);
                onTouchRun(next);
              }}
              onClick={() => {
                const next = !touchSprint;
                setTouchSprint(next);
                onTouchRun(next);
              }}
              className={`min-w-[54px] min-h-[48px] rounded-full bg-[rgba(14,10,9,0.84)] border text-xs font-bold ${
                touchSprint ? 'border-[#e2b34a] text-[#e2b34a]' : 'border-white/25 text-[#ebe3d6]'
              }`}
            >
              جري
            </button>
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onToggleCrouch();
              }}
              className={`min-w-[54px] min-h-[48px] rounded-full bg-[rgba(14,10,9,0.84)] border text-xs font-bold ${
                hud.crouch ? 'border-[#e2b34a] text-[#e2b34a]' : 'border-white/25 text-[#ebe3d6]'
              }`}
            >
              انحناء
            </button>
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onToggleTorch();
              }}
              className={`min-w-[54px] min-h-[48px] rounded-full bg-[rgba(14,10,9,0.84)] border text-xs font-bold ${
                hud.torch ? 'border-[#e2b34a] text-[#e2b34a]' : 'border-white/25 text-[#ebe3d6]'
              }`}
            >
              كشاف
            </button>
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onToggleMap();
              }}
              className={`min-w-[54px] min-h-[48px] rounded-full bg-[rgba(14,10,9,0.84)] border text-xs font-bold ${
                hud.mapOpen ? 'border-[#e2b34a] text-[#e2b34a]' : 'border-white/25 text-[#ebe3d6]'
              }`}
            >
              خريطة
            </button>
            {hud.heldItem && (
              <button
                type="button"
                onTouchStart={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onDrop();
                }}
                className="min-w-[54px] min-h-[48px] rounded-full bg-[rgba(14,10,9,0.84)] border border-[#e2b34a] text-xs font-bold text-[#e2b34a]"
              >
                رمي
              </button>
            )}
            {hud.heldItem === 'gun' && (
              <button
                type="button"
                onTouchStart={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onFire();
                }}
                className="min-w-[54px] min-h-[48px] rounded-full bg-[#5e0d0a] border border-[#b3201a] text-xs font-bold text-[#ebe3d6]"
              >
                إطلاق
              </button>
            )}
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onInteract();
              }}
              className="col-span-2 w-20 h-20 justify-self-center rounded-full bg-[#5e0d0a] border-2 border-[#b3201a] text-sm font-bold text-[#ebe3d6] shadow-lg active:scale-95"
            >
              تفاعل
            </button>
          </div>
        </div>
      )}
    </>
  );
}
