import { DifficultyKey, HeldItemType, HouseTheme, RoomDef } from './types';

export const WALL_H = 3.3;
export const HALL_H = 7.1;
export const FY = 7.1;
export const WALL_T = 0.3;
export const DOOR_W = 2.8;
export const EYE = 1.65;
export const EYE_C = 1.05;
export const EYE_UNDER_BED = 0.44;
export const PR = 0.38;
export const MAX_DAYS = 5;

export const DIFFICULTIES: Record<
  DifficultyKey,
  {
    name: string;
    keys: number;
    hs: number;
    gs: number;
    see: number;
    hear: number;
    monsters: boolean;
    giant: number;
    traps: number;
    stunDuration: number;
    info: string;
  }
> = {
  practice: {
    name: 'تدريب',
    keys: 3,
    hs: 1,
    gs: 1,
    see: 1,
    hear: 1,
    monsters: false,
    giant: 0,
    traps: 0,
    stunDuration: 45,
    info: 'بلا وحوش · تعرّف على البيت والأقفال والأدوات بهدوء',
  },
  easy: {
    name: 'سهل',
    keys: 3,
    hs: 0.85,
    gs: 0.82,
    see: 0.8,
    hear: 0.8,
    monsters: true,
    giant: 0.35,
    traps: 3,
    stunDuration: 40,
    info: '٣ مفاتيح · وحش أبطأ · إغماء ٤٠ ثانية · ٣ أفخاخ فقط',
  },
  med: {
    name: 'متوسط',
    keys: 4,
    hs: 1.0,
    gs: 1.0,
    see: 1.0,
    hear: 1.0,
    monsters: true,
    giant: 0.65,
    traps: 5,
    stunDuration: 30,
    info: '٤ مفاتيح · التجربة الكاملة · إغماء ٣٠ ثانية · ٥ أفخاخ',
  },
  hard: {
    name: 'صعب',
    keys: 5,
    hs: 1.18,
    gs: 1.12,
    see: 1.2,
    hear: 1.25,
    monsters: true,
    giant: 0.9,
    traps: 7,
    stunDuration: 22,
    info: '٥ مفاتيح · سمع حاد ومطاردة شرسة · ٧ أفخاخ',
  },
  nightmare: {
    name: 'كابوس',
    keys: 6,
    hs: 1.32,
    gs: 1.22,
    see: 1.35,
    hear: 1.4,
    monsters: true,
    giant: 1.0,
    traps: 9,
    stunDuration: 15,
    info: '٦ مفاتيح · أقصى سرعة وذكاء · العملاق موجود دائماً',
  },
};

export const ITEM_LABELS: Record<Exclude<HeldItemType, null>, string> = {
  hammer: 'المطرقة',
  screwdriver: 'المفك',
  cutters: 'قاطع الأسلاك',
  gun: 'المسدس',
  vase: 'مزهرية (تشتيت)',
};

export interface HousePreset {
  id: HouseTheme;
  name: string;
  tagline: string;
  rooms0: RoomDef[];
  rooms1: RoomDef[];
  allRooms: RoomDef[];
  stairBounds: { x1: number; x2: number; z1: number; z2: number };
  startPos: { x: number; z: number; yaw: number };
  bedWake: { x: number; y: number; z: number };
  swPos: { x: number; y: number; z: number };
  safePos: { x: number; z: number };
  notePos: { x: number; y: number; z: number };
  ammoSpots: { x: number; y: number; z: number }[];
  vases: { fl: 0 | 1; x: number; y: number; z: number }[];
  trapCoords: { fl: 0 | 1; x: number; z: number }[];
  creakCoords: { fl: 0 | 1; x: number; z: number; w: number; d: number }[];
  lampX0: number[];
  lampX1: number[];
  southDoors0: number[];
  deepDoors0: number[];
  midDoors1: number[];
  deepDoors1: number[];
  menuCamera: { x: number; y: number; z: number; yaw: number };
}

export const ROOMS_FLOOR_0_CLASSIC: RoomDef[] = [
  { id: 'bed', name: 'غرفة النوم', x1: 0, z1: 0, x2: 14, z2: 16, cx: 7, cz: 8, fl: 0 },
  { id: 'kit', name: 'المطبخ', x1: 14, z1: 0, x2: 28, z2: 16, cx: 21, cz: 8, fl: 0 },
  { id: 'lib', name: 'المكتبة', x1: 28, z1: 0, x2: 42, z2: 16, cx: 35, cz: 8, fl: 0 },
  { id: 'bath', name: 'الحمّام', x1: 42, z1: 0, x2: 52, z2: 16, cx: 47, cz: 8, fl: 0 },
  { id: 'stor', name: 'المخزن', x1: 52, z1: 0, x2: 60, z2: 16, cx: 56, cz: 8, fl: 0 },
  { id: 'liv', name: 'غرفة المعيشة', x1: 0, z1: 24, x2: 18, z2: 40, cx: 9, cz: 32, fl: 0 },
  { id: 'din', name: 'غرفة الطعام', x1: 18, z1: 24, x2: 34, z2: 40, cx: 26, cz: 32, fl: 0 },
  { id: 'nur', name: 'غرفة الأطفال', x1: 34, z1: 24, x2: 46, z2: 40, cx: 40, cz: 32, fl: 0 },
  { id: 'exit', name: 'قاعة الخروج', x1: 46, z1: 24, x2: 60, z2: 40, cx: 53, cz: 32, fl: 0 },
  { id: 'laun', name: 'غرفة الغسيل', x1: 0, z1: 40, x2: 20, z2: 56, cx: 10, cz: 48, fl: 0 },
  { id: 'stu', name: 'المرسم', x1: 20, z1: 40, x2: 40, z2: 56, cx: 30, cz: 48, fl: 0 },
  { id: 'cell', name: 'القبو', x1: 40, z1: 40, x2: 60, z2: 56, cx: 50, cz: 48, fl: 0 },
];

export const ROOMS_FLOOR_0_MANOR: RoomDef[] = [
  { id: 'stor', name: 'قبو المؤن الشمالي', x1: 0, z1: 0, x2: 10, z2: 16, cx: 5, cz: 8, fl: 0 },
  { id: 'kit', name: 'المطبخ الحجري', x1: 10, z1: 0, x2: 24, z2: 16, cx: 17, cz: 8, fl: 0 },
  { id: 'din', name: 'قاعة الطعام الكبرى', x1: 24, z1: 0, x2: 38, z2: 16, cx: 31, cz: 8, fl: 0 },
  { id: 'lib', name: 'مكتبة القصر', x1: 38, z1: 0, x2: 50, z2: 16, cx: 44, cz: 8, fl: 0 },
  { id: 'bath', name: 'الحمّام القديم', x1: 50, z1: 0, x2: 60, z2: 16, cx: 55, cz: 8, fl: 0 },
  { id: 'bed', name: 'غرفة النوم الرئيسية', x1: 0, z1: 24, x2: 16, z2: 40, cx: 8, cz: 32, fl: 0 },
  { id: 'liv', name: 'بهو المدفأة', x1: 16, z1: 24, x2: 34, z2: 40, cx: 25, cz: 32, fl: 0 },
  { id: 'nur', name: 'غرفة الدمى والحضانة', x1: 34, z1: 24, x2: 46, z2: 40, cx: 40, cz: 32, fl: 0 },
  { id: 'exit', name: 'رواق البوابة الحديدية', x1: 46, z1: 24, x2: 60, z2: 40, cx: 53, cz: 32, fl: 0 },
  { id: 'laun', name: 'غرفة الغلايات والغسيل', x1: 0, z1: 40, x2: 18, z2: 56, cx: 9, cz: 48, fl: 0 },
  { id: 'stu', name: 'مرسم اللوحات الملعونة', x1: 18, z1: 40, x2: 38, z2: 56, cx: 28, cz: 48, fl: 0 },
  { id: 'cell', name: 'الزنزانة الحجرية', x1: 38, z1: 40, x2: 60, z2: 56, cx: 49, cz: 48, fl: 0 },
];

export const ROOMS_FLOOR_1: RoomDef[] = (() => {
  const list: RoomDef[] = [];
  ['غرفة الضيوف', 'المكتب', 'غرفة الملابس', 'غرفة الألعاب', 'غرفة الصلاة', 'الشرفة المغلقة'].forEach(
    (name, i) => {
      const x1 = i * 10;
      const x2 = x1 + 10;
      list.push({ id: `n${i}`, name, x1, z1: 0, x2, z2: 16, cx: (x1 + x2) / 2, cz: 8, fl: 1 });
    }
  );
  ['غرفة الخادمة', 'المكتبة العليا', 'غرفة الضيوف الثانية', 'المعمل القديم', 'الغرفة الحمراء'].forEach(
    (name, i) => {
      const x1 = i * 12;
      const x2 = x1 + 12;
      list.push({ id: `a${i}`, name, x1, z1: 24, x2, z2: 40, cx: (x1 + x2) / 2, cz: 32, fl: 1 });
    }
  );
  ['العلّية', 'غرفة الأرشيف', 'غرفة الدمى', 'غرفة المرايا'].forEach((name, i) => {
    const x1 = i * 15;
    const x2 = x1 + 15;
    list.push({ id: `b${i}`, name, x1, z1: 40, x2, z2: 56, cx: (x1 + x2) / 2, cz: 48, fl: 1 });
  });
  return list;
})();

export const HOUSE_PRESETS: Record<HouseTheme, HousePreset> = {
  manor: {
    id: 'manor',
    name: 'القصر الحجري الملعون',
    tagline: 'جديد · جدران حجرية ومدفأة ودرج شرقي وتخطيط غرف مختلف',
    rooms0: ROOMS_FLOOR_0_MANOR,
    rooms1: ROOMS_FLOOR_1,
    allRooms: [...ROOMS_FLOOR_0_MANOR, ...ROOMS_FLOOR_1],
    stairBounds: { x1: 28.0, x2: 41.2, z1: 21.55, z2: 23.65 },
    startPos: { x: 5.4, z: 28.2, yaw: -Math.PI / 2 },
    bedWake: { x: 2.8, y: 0.98, z: 28.0 },
    swPos: { x: 27.0, y: 1.35, z: 16.3 },
    safePos: { x: 44, z: 0.8 },
    notePos: { x: 15.2, y: 1.02, z: 0.8 },
    ammoSpots: [
      { x: 20.5, y: 0.92, z: 4.5 },
      { x: 25.0, y: 0.72, z: 29.0 },
    ],
    vases: [
      { fl: 0, x: 31.0, y: 0.92, z: 4.5 },
      { fl: 0, x: 25.2, y: 0.72, z: 29.8 },
      { fl: 1, x: 22.0, y: 0.0, z: 20.0 },
    ],
    trapCoords: [
      { fl: 0, x: 22, z: 20 },
      { fl: 0, x: 46, z: 20 },
      { fl: 0, x: 51, z: 32 },
      { fl: 0, x: 9, z: 40 },
      { fl: 1, x: 18, z: 20 },
      { fl: 1, x: 48, z: 20 },
      { fl: 0, x: 31, z: 8 },
      { fl: 0, x: 28, z: 40 },
      { fl: 1, x: 30, z: 32 },
    ],
    creakCoords: [
      { fl: 0, x: 12, z: 20, w: 1.8, d: 2.8 },
      { fl: 0, x: 26, z: 20, w: 1.8, d: 2.8 },
      { fl: 0, x: 49, z: 20, w: 1.8, d: 2.8 },
      { fl: 1, x: 16, z: 20, w: 1.8, d: 2.8 },
      { fl: 1, x: 46, z: 20, w: 1.8, d: 2.8 },
    ],
    lampX0: [8, 21, 47, 55],
    lampX1: [10, 23, 49],
    southDoors0: [8, 23, 43.2, 53],
    deepDoors0: [9, 28, 49],
    midDoors1: [6, 18, 45, 54],
    deepDoors1: [7.5, 22.5, 37.5, 52.5],
    menuCamera: { x: 22, y: 1.75, z: 19.6, yaw: -Math.PI / 2 },
  },
  classic: {
    id: 'classic',
    name: 'البيت الخشبي القديم',
    tagline: 'التصميم الكلاسيكي الأصلي للمنزل المهجور',
    rooms0: ROOMS_FLOOR_0_CLASSIC,
    rooms1: ROOMS_FLOOR_1,
    allRooms: [...ROOMS_FLOOR_0_CLASSIC, ...ROOMS_FLOOR_1],
    stairBounds: { x1: 10.8, x2: 24.4, z1: 21.55, z2: 23.65 },
    startPos: { x: 4.8, z: 3.8, yaw: -Math.PI / 2 },
    bedWake: { x: 2.4, y: 0.98, z: 3.6 },
    swPos: { x: 17.5, y: 1.35, z: 16.3 },
    safePos: { x: 35, z: 0.8 },
    notePos: { x: 17, y: 1.02, z: 0.8 },
    ammoSpots: [
      { x: 25.1, y: 0.92, z: 4.35 },
      { x: 27.6, y: 0.92, z: 37.0 },
    ],
    vases: [
      { fl: 0, x: 26, y: 0.9, z: 36.2 },
      { fl: 0, x: 13.5, y: 0.72, z: 27.5 },
      { fl: 1, x: 26, y: 0.0, z: 20.0 },
    ],
    trapCoords: [
      { fl: 0, x: 21, z: 20 },
      { fl: 0, x: 38, z: 20 },
      { fl: 0, x: 51, z: 32 },
      { fl: 0, x: 10, z: 40 },
      { fl: 1, x: 18, z: 20 },
      { fl: 1, x: 36, z: 20 },
      { fl: 0, x: 28, z: 8 },
      { fl: 0, x: 46, z: 28 },
      { fl: 1, x: 30, z: 32 },
    ],
    creakCoords: [
      { fl: 0, x: 14, z: 20, w: 1.8, d: 2.8 },
      { fl: 0, x: 30, z: 20, w: 1.8, d: 2.8 },
      { fl: 0, x: 48, z: 20, w: 1.8, d: 2.8 },
      { fl: 1, x: 25, z: 20, w: 1.8, d: 2.8 },
      { fl: 1, x: 43, z: 20, w: 1.8, d: 2.8 },
    ],
    lampX0: [8, 22, 36, 50],
    lampX1: [10, 28, 46],
    southDoors0: ROOMS_FLOOR_0_CLASSIC.slice(5, 9).map((r) => r.cx),
    deepDoors0: [10, 31, 52],
    midDoors1: [6, 30, 42, 54],
    deepDoors1: [7.5, 22.5, 37.5, 52.5],
    menuCamera: { x: 24, y: 1.75, z: 20, yaw: -Math.PI / 2 },
  },
};

export function getHousePreset(theme: HouseTheme = 'manor'): HousePreset {
  return HOUSE_PRESETS[theme] || HOUSE_PRESETS.manor;
}

export const ROOMS_FLOOR_0 = ROOMS_FLOOR_0_MANOR;
export const ALL_ROOMS: RoomDef[] = [...ROOMS_FLOOR_0, ...ROOMS_FLOOR_1];
export const STAIR_BOUNDS = HOUSE_PRESETS.manor.stairBounds;

export function toArabicDigits(n: number | string): string {
  return String(n).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'.charAt(Number(d)));
}

export function formatTimeAr(t: number): string {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${toArabicDigits(m)}:${s < 10 ? toArabicDigits(0) : ''}${toArabicDigits(s)}`;
}

export const DIARY_NOTES = [
  {
    id: 'diary_1',
    roomId: 'bed',
    number: 1,
    title: 'صفحة ممزقة — اليوم الأول',
    author: 'السجين السابق',
    dateLabel: 'منذ ١٤ عاماً',
    body: [
      'استيقظتُ في هذه الغرفة ورأسي ينزف. الباب الخارجي مُغلق بثلاثة أقفال فوق الأقفال الحديدية… وذلك الشيء الممسك بالمطرقة لا ينام أبداً.',
      'بصرُه ضعيف في الظلام، لكن أذنيه تلتقطان همس الخشب تحت قدميك. لا تركض فوق الألواح المتآكلة في الممر، وإذا سمعتَ وقع خطواته… اندسَّ تحت السرير أو داخل أقرب خزانة فوراً.',
    ],
    hint: 'تلميح: اضغط C للانحناء والمشي بصمت فوق الألواح الصريرية، ويمكنك رمي المزهرية أو أي أداة بـ G لتشتيت الوحش نحو مكان السقوط.',
  },
  {
    id: 'diary_2',
    roomId: 'liv',
    number: 2,
    title: 'دفتر الحارس — طبقات باب الخروج',
    author: 'الحارس القديم',
    dateLabel: 'الليلة الأخيرة',
    body: [
      'أحكمتُ إغلاق البوابة الشرقية حتى لا يخرج أحدٌ قبل الفجر، لكنني كتبتُ خطة الفك هنا إن اضطررتُ للهرب:',
      'أولاً: لوح الخشب المسمّر لا يُكسر إلا بالمطرقة الثقيلة في غرفة الغسيل. ثانياً: السلك الأحمر المكهرب يحتاج قاطع أسلاك في الطابق العلوي. ثالثاً: الغطاء المعدني مثبّت ببراغٍ لا يفكها سوى المفك داخل الخزنة.',
    ],
    hint: 'لغز الباب: المطرقة (غرفة الغسيل) ← قاطع الأسلاك (الطابق الثاني) ← المفك (خزنة المكتبة) ← المفاتيح.',
  },
  {
    id: 'diary_3',
    roomId: 'lib',
    number: 3,
    title: 'الورقة المحروقة — لغز الخزنة',
    author: 'صاحب القصر',
    dateLabel: 'ملاحظة سرية',
    body: [
      'بعد أن كاد أحدهم يسرق المفكّ من الخزنة الفولاذية، غيّرتُ الرمز السرّي ذي الأرقام الثلاثة وأبقيته في مكانٍ لا يجرؤ على الاقتراب منه طويلاً… فوق منضدة المطبخ.',
      'تذكّر أن تحمل معك غرضاً واحداً فقط في يدك؛ فاليد الفارغة تسرع، والمقذوفات المعدنية تُطلق الأفخاخ الفولاذية من بعيد دون أن تلمس قدميك.',
    ],
    hint: 'تلميح: رمز الخزنة مرسوم على ورقة متوهجة في المطبخ، ورمي أداة على فخ الدب يُبطل مفعوله بأمان.',
  },
  {
    id: 'diary_4',
    roomId: 'cell',
    number: 4,
    title: 'اعترافات القبو — فخاخ الصيد',
    author: 'صانع الأفخاخ',
    dateLabel: 'قبو القصر',
    body: [
      'رجل المطرقة لم يكن وحشاً منذ البدء؛ كان حدّاد هذا القصر قبل أن تُغلق الأبواب عليه لسنوات في العتمة. ما زال يزرع أفخاخ الدبّ عند المنعطفات كلما سمع ضجيجاً.',
      'إن أطبق فخٌ على كاحلك، سيتضاعف ألمك ويسمع صراخك من الطابق الآخر. لكن إن رأيتَ الفخَّ قبل أن تطأه، انحنِ ببطء لتفكيك أسنانه… أو أفرغ رصاص المسدس في صدره لتُسقطه أرضاً لبضع ثوانٍ.',
    ],
    hint: 'تلميح: المسدس موجود في الصندوق الحديدي بغرفة الأطفال، وإصابة رجل المطرقة تُفقده الوعي وتمنحك وقتاً ثميناً للبحث.',
  },
  {
    id: 'diary_5',
    roomId: 'a3',
    number: 5,
    title: 'مذكرة المعمل — همس الطابق العلوي',
    author: 'الباحث المفقود',
    dateLabel: 'الطابق الثاني',
    body: [
      'الريح هنا في الطابق العلوي تعوي كأن البيت يتنفس. أحياناً أسمع خطوات فوق رأسي أو خلف الجدار الخشبي حتى عندما يكون رجل المطرقة في القبو… ولا أعلم إن كان هو أم صدى من سبقونا.',
      'خبأتُ قاطع الأسلاك داخل صندوق الصيانة في إحدى غرف الضيوف القريبة من هنا. راقب الدرج جيداً قبل النزول؛ فالعملاق الطويل لا يزال يتجول في الممر الرئيسي بالأسفل.',
    ],
    hint: 'تلميح: عملاق الممر لا يصعد إلى الطابق الثاني ولا يدخل الغرف الجانبية، استعمل الغرف كملجأ آمن.',
  },
  {
    id: 'diary_6',
    roomId: 'b2',
    number: 6,
    title: 'الوصية الأخيرة — نحو ضوء الفجر',
    author: 'مجهول',
    dateLabel: 'اليوم الخامس',
    body: [
      'الدمى تحدّق بي من الزوايا بينما أكتب سطوري الأخيرة. لم يتبقَّ لي سوى مفتاح واحد لكنني سمعتُ خطواته تصعد الدرج.',
      'إن وصلتَ إلى هنا حيّاً، فاعلم أنك إذا فعلتَ مصباح الممر الرئيسي في الطابق الأرضي فسيغمر الضوء الرواق لعشر ثوانٍ كاملة، وبعد فتح القفل الأخير بالخروج اركض مباشرة خارج البوابة نحو الغابة ولا تلتفت.',
    ],
    hint: 'تلميح: إذا ضللت الطريق بعد جمع المفاتيح، اتبع السهم الأخضر في أعلى الشاشة نحو باب الخروج.',
  },
] as const;
