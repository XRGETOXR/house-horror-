import * as THREE from 'three';

export interface GameTextures {
  wall: THREE.CanvasTexture;
  stoneWall: THREE.CanvasTexture;
  floor: THREE.CanvasTexture;
  manorFloor: THREE.CanvasTexture;
  ceil: THREE.CanvasTexture;
  blood: THREE.CanvasTexture;
  cloth: THREE.CanvasTexture;
  face: THREE.CanvasTexture;
  closet: THREE.CanvasTexture;
  crate: THREE.CanvasTexture;
  glow: THREE.CanvasTexture;
  burlap: THREE.CanvasTexture;
  apron: THREE.CanvasTexture;
  giantSkin: THREE.CanvasTexture;
  skin: THREE.CanvasTexture;
  cobweb: THREE.CanvasTexture;
  clockFace: THREE.CanvasTexture;
  windowNight: THREE.CanvasTexture;
  stairs: THREE.CanvasTexture;
}

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return c;
}

export function rand(a: number, b: number): number {
  return a + Math.random() * (b - a);
}

export function speckle(
  g: CanvasRenderingContext2D,
  w: number,
  h: number,
  n: number,
  tpl: string,
  smax = 3
): void {
  for (let i = 0; i < n; i++) {
    g.fillStyle = tpl.replace('A', (Math.random() * 0.5).toFixed(2));
    const s = rand(1, smax);
    g.fillRect(Math.random() * w, Math.random() * h, s, s);
  }
}

export function makeTexture(
  c: HTMLCanvasElement,
  rx = 1,
  ry = 1,
  maxAniso = 4
): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.anisotropy = maxAniso;
  return t;
}

function wallCanvas(): HTMLCanvasElement {
  const c = makeCanvas(256, 256);
  const g = c.getContext('2d')!;
  g.fillStyle = '#6b5a4c';
  g.fillRect(0, 0, 256, 256);
  for (let x = 0; x < 256; x += 32) {
    g.fillStyle = 'rgba(255,235,210,0.06)';
    g.fillRect(x, 0, 16, 256);
  }
  for (let y = 12; y < 256; y += 40) {
    for (let x2 = 16; x2 < 256; x2 += 32) {
      g.fillStyle = 'rgba(0,0,0,0.12)';
      g.beginPath();
      g.arc(x2, y + (((x2 / 32) | 0) % 2 ? 10 : 0), 3, 0, 6.3);
      g.fill();
    }
  }
  // Peeling damp patches
  for (let i = 0; i < 7; i++) {
    const gx = rand(0, 256);
    const gy = rand(0, 200);
    const gr = g.createRadialGradient(gx, gy, 2, gx, gy, rand(20, 55));
    gr.addColorStop(0, 'rgba(35,20,8,0.45)');
    gr.addColorStop(1, 'rgba(35,20,8,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 256, 256);
  }
  const mold = g.createLinearGradient(0, 150, 0, 256);
  mold.addColorStop(0, 'rgba(0,0,0,0)');
  mold.addColorStop(1, 'rgba(0,0,0,0.52)');
  g.fillStyle = mold;
  g.fillRect(0, 150, 256, 106);
  speckle(g, 256, 256, 900, 'rgba(0,0,0,A)', 2);
  return c;
}

function floorCanvas(): HTMLCanvasElement {
  const c = makeCanvas(256, 256);
  const g = c.getContext('2d')!;
  const cols = ['#5a3d27', '#4d3321', '#63452d', '#563a25'];
  for (let r = 0; r < 8; r++) {
    g.fillStyle = cols[r % 4];
    g.fillRect(0, r * 32, 256, 32);
    g.fillStyle = 'rgba(0,0,0,0.55)';
    g.fillRect(0, r * 32, 256, 2);
    const j = rand(30, 226);
    g.fillRect(j, r * 32, 2, 32);
    for (let k = 0; k < 5; k++) {
      g.strokeStyle = 'rgba(0,0,0,0.18)';
      g.beginPath();
      g.moveTo(0, r * 32 + rand(4, 28));
      g.lineTo(256, r * 32 + rand(4, 28));
      g.stroke();
    }
  }
  speckle(g, 256, 256, 700, 'rgba(0,0,0,A)', 2);
  return c;
}

function ceilCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#3b3430';
  g.fillRect(0, 0, 128, 128);
  speckle(g, 128, 128, 400, 'rgba(0,0,0,A)', 2);
  const gr = g.createRadialGradient(64, 64, 2, 64, 64, 50);
  gr.addColorStop(0, 'rgba(20,10,0,0.45)');
  gr.addColorStop(1, 'rgba(20,10,0,0)');
  g.fillStyle = gr;
  g.fillRect(0, 0, 128, 128);
  return c;
}

function bloodCanvas(): HTMLCanvasElement {
  const c = makeCanvas(256, 256);
  const g = c.getContext('2d')!;
  g.fillStyle = 'rgba(105,8,8,0.92)';
  for (let i = 0; i < 14; i++) {
    g.beginPath();
    g.ellipse(
      128 + rand(-60, 60),
      128 + rand(-60, 60),
      rand(6, 26),
      rand(5, 22),
      rand(0, 3),
      0,
      6.3
    );
    g.fill();
  }
  for (let i = 0; i < 40; i++) {
    const a = rand(0, 6.28);
    const d = rand(40, 120);
    g.beginPath();
    g.arc(128 + Math.cos(a) * d, 128 + Math.sin(a) * d, rand(1.5, 6), 0, 6.3);
    g.fill();
  }
  g.strokeStyle = 'rgba(90,6,6,0.85)';
  g.lineWidth = rand(6, 14);
  g.lineCap = 'round';
  g.beginPath();
  g.moveTo(128, 128);
  g.quadraticCurveTo(rand(60, 200), rand(60, 200), rand(20, 236), rand(20, 236));
  g.stroke();
  return c;
}

function clothCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#3a312c';
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 16; i++) {
    g.fillStyle = `rgba(135,16,14,${rand(0.5, 0.9).toFixed(2)})`;
    g.beginPath();
    g.arc(rand(0, 128), rand(0, 128), rand(4, 20), 0, 6.3);
    g.fill();
  }
  g.strokeStyle = 'rgba(120,12,10,0.8)';
  g.lineWidth = 3;
  for (let i = 0; i < 8; i++) {
    const x = rand(0, 128);
    g.beginPath();
    g.moveTo(x, rand(0, 30));
    g.lineTo(x + rand(-4, 4), rand(70, 128));
    g.stroke();
  }
  speckle(g, 128, 128, 200, 'rgba(0,0,0,A)', 2);
  return c;
}

function faceCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#b3a99b';
  g.fillRect(0, 0, 128, 128);
  g.strokeStyle = 'rgba(140,14,12,0.9)';
  g.lineCap = 'round';
  for (let i = 0; i < 9; i++) {
    g.lineWidth = rand(3, 9);
    const x = rand(0, 128);
    g.beginPath();
    g.moveTo(x, rand(0, 40));
    g.lineTo(x + rand(-8, 8), rand(60, 128));
    g.stroke();
  }
  for (let i = 0; i < 12; i++) {
    g.fillStyle = 'rgba(120,10,10,0.8)';
    g.beginPath();
    g.arc(rand(0, 128), rand(0, 128), rand(2, 9), 0, 6.3);
    g.fill();
  }
  return c;
}

function closetCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 256);
  const g = c.getContext('2d')!;
  g.fillStyle = '#4a3322';
  g.fillRect(0, 0, 128, 256);
  g.strokeStyle = 'rgba(0,0,0,0.6)';
  g.lineWidth = 3;
  g.strokeRect(8, 10, 52, 236);
  g.strokeRect(68, 10, 52, 236);
  g.fillStyle = 'rgba(0,0,0,0.75)';
  for (let i = 0; i < 5; i++) {
    g.fillRect(16, 26 + i * 9, 36, 3);
    g.fillRect(76, 26 + i * 9, 36, 3);
  }
  g.fillStyle = '#8a7a55';
  g.fillRect(54, 120, 4, 16);
  g.fillRect(70, 120, 4, 16);
  speckle(g, 128, 256, 300, 'rgba(0,0,0,A)', 2);
  return c;
}

function crateCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#6b4e2e';
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 8; i++) {
    g.fillStyle = i % 2 ? 'rgba(0,0,0,0.12)' : 'rgba(255,220,160,0.06)';
    g.fillRect(0, i * 16, 128, 16);
    g.fillStyle = 'rgba(0,0,0,0.5)';
    g.fillRect(0, i * 16, 128, 2);
  }
  g.strokeStyle = 'rgba(30,18,8,0.9)';
  g.lineWidth = 10;
  g.strokeRect(5, 5, 118, 118);
  g.lineWidth = 8;
  g.beginPath();
  g.moveTo(8, 8);
  g.lineTo(120, 120);
  g.moveTo(120, 8);
  g.lineTo(8, 120);
  g.stroke();
  speckle(g, 128, 128, 300, 'rgba(0,0,0,A)', 2);
  return c;
}

function glowCanvas(): HTMLCanvasElement {
  const c = makeCanvas(64, 64);
  const g = c.getContext('2d')!;
  const gr = g.createRadialGradient(32, 32, 1, 32, 32, 31);
  gr.addColorStop(0, 'rgba(255,220,120,0.9)');
  gr.addColorStop(1, 'rgba(255,200,80,0)');
  g.fillStyle = gr;
  g.fillRect(0, 0, 64, 64);
  return c;
}

function burlapCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#a8905c';
  g.fillRect(0, 0, 128, 128);
  g.strokeStyle = 'rgba(60,40,15,0.35)';
  g.lineWidth = 1;
  for (let i = 0; i < 128; i += 3) {
    g.beginPath();
    g.moveTo(i, 0);
    g.lineTo(i + rand(-1, 1), 128);
    g.stroke();
    g.beginPath();
    g.moveTo(0, i);
    g.lineTo(128, i + rand(-1, 1));
    g.stroke();
  }
  for (let i = 0; i < 22; i++) {
    g.fillStyle = `rgba(110,10,8,${rand(0.2, 0.6).toFixed(2)})`;
    g.beginPath();
    g.arc(rand(0, 128), rand(0, 128), rand(3, 12), 0, 6.28);
    g.fill();
  }
  speckle(g, 128, 128, 200, 'rgba(30,20,5,A)', 3);
  return c;
}

function apronCanvas(): HTMLCanvasElement {
  const c = makeCanvas(64, 96);
  const g = c.getContext('2d')!;
  g.fillStyle = '#3a2a1e';
  g.fillRect(0, 0, 64, 96);
  speckle(g, 64, 96, 260, 'rgba(0,0,0,A)', 3);
  for (let i = 0; i < 9; i++) {
    const x = rand(2, 62);
    const y = rand(0, 50);
    const h = rand(18, 60);
    g.fillStyle = `rgba(${110 + ((Math.random() * 40) | 0)},10,8,0.8)`;
    g.fillRect(x, y, rand(3, 8), h);
    g.beginPath();
    g.arc(x + 2, y + h, rand(2, 4), 0, 6.28);
    g.fill();
  }
  g.fillStyle = 'rgba(90,6,6,0.7)';
  g.beginPath();
  g.arc(32, 60, 22, 0, 6.28);
  g.fill();
  return c;
}

function giantSkinCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#7a7868';
  g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 90; i++) {
    g.fillStyle = `rgba(${60 + ((Math.random() * 50) | 0)},${
      70 + ((Math.random() * 40) | 0)
    },55,0.18)`;
    g.beginPath();
    g.arc(rand(0, 128), rand(0, 128), rand(4, 16), 0, 6.28);
    g.fill();
  }
  g.strokeStyle = 'rgba(120,40,40,0.45)';
  g.lineWidth = 1;
  for (let i = 0; i < 14; i++) {
    g.beginPath();
    g.moveTo(rand(0, 128), rand(0, 128));
    g.bezierCurveTo(
      rand(0, 128),
      rand(0, 128),
      rand(0, 128),
      rand(0, 128),
      rand(0, 128),
      rand(0, 128)
    );
    g.stroke();
  }
  g.strokeStyle = 'rgba(40,10,10,0.7)';
  g.lineWidth = 2;
  for (let i = 0; i < 5; i++) {
    const x = rand(10, 118);
    const y = rand(10, 118);
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + rand(-26, 26), y + rand(8, 30));
    g.stroke();
  }
  speckle(g, 128, 128, 400, 'rgba(20,20,10,A)', 2);
  return c;
}

function skinCanvas(): HTMLCanvasElement {
  const c = makeCanvas(64, 64);
  const g = c.getContext('2d')!;
  g.fillStyle = '#d6a07a';
  g.fillRect(0, 0, 64, 64);
  for (let i = 0; i < 46; i++) {
    g.fillStyle = `rgba(${150 + ((Math.random() * 40) | 0)},92,70,0.10)`;
    g.fillRect(rand(0, 64), rand(0, 64), rand(2, 12), rand(1, 3));
  }
  g.strokeStyle = 'rgba(90,110,150,0.16)';
  g.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    g.beginPath();
    g.moveTo(rand(0, 64), 0);
    g.bezierCurveTo(rand(0, 64), 20, rand(0, 64), 40, rand(0, 64), 64);
    g.stroke();
  }
  speckle(g, 64, 64, 70, 'rgba(80,40,30,A)', 2);
  return c;
}

function cobwebCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.strokeStyle = 'rgba(215,210,200,0.45)';
  g.lineWidth = 1.2;
  for (let i = 0; i <= 6; i++) {
    const ang = (i / 6) * (Math.PI / 2);
    g.beginPath();
    g.moveTo(0, 0);
    g.lineTo(Math.cos(ang) * 126, Math.sin(ang) * 126);
    g.stroke();
  }
  for (let r = 24; r <= 116; r += 22) {
    g.beginPath();
    for (let i = 0; i <= 6; i++) {
      const ang = (i / 6) * (Math.PI / 2);
      const px = Math.cos(ang) * r;
      const py = Math.sin(ang) * r;
      if (i === 0) g.moveTo(px, py);
      else g.quadraticCurveTo(px * 0.85, py * 0.85, px, py);
    }
    g.stroke();
  }
  return c;
}

function clockFaceCanvas(): HTMLCanvasElement {
  const c = makeCanvas(128, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = '#ddd0b2';
  g.beginPath();
  g.arc(64, 64, 58, 0, Math.PI * 2);
  g.fill();
  g.strokeStyle = '#2b1c10';
  g.lineWidth = 4;
  g.stroke();
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    g.beginPath();
    g.moveTo(64 + Math.cos(a) * 44, 64 + Math.sin(a) * 44);
    g.lineTo(64 + Math.cos(a) * 53, 64 + Math.sin(a) * 53);
    g.stroke();
  }
  g.lineWidth = 3;
  g.beginPath();
  g.moveTo(64, 64);
  g.lineTo(64, 28);
  g.moveTo(64, 64);
  g.lineTo(90, 74);
  g.stroke();
  return c;
}

function windowCanvas(): HTMLCanvasElement {
  const c = makeCanvas(64, 96);
  const g = c.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 0, 96);
  gr.addColorStop(0, '#1a2848');
  gr.addColorStop(1, '#0c1220');
  g.fillStyle = gr;
  g.fillRect(0, 0, 64, 96);
  g.fillStyle = 'rgba(220,230,255,0.9)';
  g.beginPath();
  g.arc(44, 22, 6, 0, 6.28);
  g.fill();
  g.fillStyle = 'rgba(0,0,0,0.6)';
  for (let i = 0; i < 4; i++) {
    g.beginPath();
    g.moveTo(i * 18, 96);
    g.lineTo(i * 18 + 8, 60 + rand(0, 10));
    g.lineTo(i * 18 + 16, 96);
    g.fill();
  }
  g.strokeStyle = '#2a1c12';
  g.lineWidth = 4;
  g.strokeRect(2, 2, 60, 92);
  g.beginPath();
  g.moveTo(32, 0);
  g.lineTo(32, 96);
  g.moveTo(0, 48);
  g.lineTo(64, 48);
  g.stroke();
  return c;
}

function stairsCanvas(): HTMLCanvasElement {
  const c = makeCanvas(64, 64);
  const g = c.getContext('2d')!;
  g.fillStyle = '#5a3d27';
  g.fillRect(0, 0, 64, 64);
  g.fillStyle = '#7a5636';
  g.fillRect(0, 0, 50, 64);
  g.fillStyle = 'rgba(0,0,0,0.5)';
  g.fillRect(58, 0, 6, 64);
  speckle(g, 64, 64, 60, 'rgba(0,0,0,A)', 2);
  return c;
}

export function rugTexture(base: string, trim: string, maxAniso: number): THREE.CanvasTexture {
  const c = makeCanvas(128, 96);
  const g = c.getContext('2d')!;
  g.fillStyle = base;
  g.fillRect(0, 0, 128, 96);
  g.strokeStyle = trim;
  g.lineWidth = 4;
  g.strokeRect(6, 6, 116, 84);
  g.lineWidth = 2;
  g.strokeRect(14, 14, 100, 68);
  g.fillStyle = trim;
  for (let i = 0; i < 5; i++) {
    g.beginPath();
    g.moveTo(24 + i * 20, 48);
    g.lineTo(34 + i * 20, 36);
    g.lineTo(44 + i * 20, 48);
    g.lineTo(34 + i * 20, 60);
    g.closePath();
    g.fill();
  }
  speckle(g, 128, 96, 500, 'rgba(0,0,0,A)', 2);
  return makeTexture(c, 1, 1, maxAniso);
}

export function paintingTexture(seed: number, maxAniso: number): THREE.CanvasTexture {
  const c = makeCanvas(96, 128);
  const g = c.getContext('2d')!;
  g.fillStyle = ['#2a2a22', '#22262c', '#2c2420'][seed % 3];
  g.fillRect(0, 0, 96, 128);
  speckle(g, 96, 128, 300, 'rgba(255,255,255,A)', 2);
  g.fillStyle = '#0c0a09';
  g.beginPath();
  g.ellipse(48, 56, 22, 30, 0, 0, 6.28);
  g.fill();
  g.fillRect(24, 86, 48, 42);
  g.fillStyle = 'rgba(200,190,160,0.85)';
  g.beginPath();
  g.arc(40, 52, 3.5, 0, 6.28);
  g.fill();
  g.beginPath();
  g.arc(56, 52, 3.5, 0, 6.28);
  g.fill();
  g.fillStyle = 'rgba(120,10,10,0.7)';
  for (let i = 0; i < 4; i++) {
    g.fillRect(30 + i * 10, 76, 3, rand(8, 24));
  }
  return makeTexture(c, 1, 1, maxAniso);
}

export function createTextTexture(txt: string, font: string, col: string): THREE.CanvasTexture {
  const c = makeCanvas(512, 160);
  const g = c.getContext('2d')!;
  g.font = font;
  g.fillStyle = col;
  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.shadowColor = col;
  g.shadowBlur = 10;
  try {
    g.direction = 'rtl';
  } catch {
    // ignore
  }
  g.fillText(txt, 256, 84);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function stoneWallCanvas(): HTMLCanvasElement {
  const c = makeCanvas(256, 256);
  const g = c.getContext('2d')!;
  g.fillStyle = '#3c4048';
  g.fillRect(0, 0, 256, 256);

  // Masonry stone blocks
  const tones = ['#454a54', '#383d46', '#4d5058', '#31353d'];
  for (let row = 0; row < 5; row++) {
    const y = row * 34;
    const offset = row % 2 ? 32 : 0;
    for (let x = -32; x < 256; x += 64) {
      g.fillStyle = tones[(row + Math.abs(x / 64 | 0)) % tones.length];
      g.fillRect(x + offset + 2, y + 2, 60, 30);
    }
  }

  // Dark carved oak wainscoting on lower third
  g.fillStyle = '#251a13';
  g.fillRect(0, 170, 256, 86);
  g.fillStyle = '#38271b';
  g.fillRect(0, 166, 256, 7);
  for (let x = 8; x < 256; x += 42) {
    g.strokeStyle = 'rgba(0,0,0,0.6)';
    g.lineWidth = 2;
    g.strokeRect(x, 182, 34, 64);
  }

  // Damp moss & soot grime
  const grime = g.createLinearGradient(0, 0, 0, 170);
  grime.addColorStop(0, 'rgba(0,0,0,0.48)');
  grime.addColorStop(0.6, 'rgba(18,28,22,0.12)');
  grime.addColorStop(1, 'rgba(0,0,0,0.42)');
  g.fillStyle = grime;
  g.fillRect(0, 0, 256, 170);
  speckle(g, 256, 256, 1100, 'rgba(0,0,0,A)', 2);
  return c;
}

function manorFloorCanvas(): HTMLCanvasElement {
  const c = makeCanvas(256, 256);
  const g = c.getContext('2d')!;
  g.fillStyle = '#262426';
  g.fillRect(0, 0, 256, 256);
  for (let y = 0; y < 256; y += 64) {
    for (let x = 0; x < 256; x += 64) {
      const dark = ((x / 64 + y / 64) | 0) % 2 === 0;
      g.fillStyle = dark ? '#2a2b30' : '#3a3430';
      g.fillRect(x + 2, y + 2, 60, 60);
      g.strokeStyle = 'rgba(0,0,0,0.55)';
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(x + rand(10, 50), y + 2);
      g.lineTo(x + rand(10, 50), y + 62);
      g.stroke();
    }
  }
  speckle(g, 256, 256, 950, 'rgba(0,0,0,A)', 2.2);
  return c;
}

export function buildAllTextures(maxAniso: number): GameTextures {
  const glow = new THREE.CanvasTexture(glowCanvas());
  glow.colorSpace = THREE.SRGBColorSpace;
  return {
    wall: makeTexture(wallCanvas(), 1, 1, maxAniso),
    stoneWall: makeTexture(stoneWallCanvas(), 1, 1, maxAniso),
    floor: makeTexture(floorCanvas(), 30, 28, maxAniso),
    manorFloor: makeTexture(manorFloorCanvas(), 24, 22, maxAniso),
    ceil: makeTexture(ceilCanvas(), 1, 1, maxAniso),
    blood: makeTexture(bloodCanvas(), 1, 1, maxAniso),
    cloth: makeTexture(clothCanvas(), 1, 1, maxAniso),
    face: makeTexture(faceCanvas(), 1, 1, maxAniso),
    closet: makeTexture(closetCanvas(), 1, 1, maxAniso),
    crate: makeTexture(crateCanvas(), 1, 1, maxAniso),
    glow,
    burlap: makeTexture(burlapCanvas(), 1, 1, maxAniso),
    apron: makeTexture(apronCanvas(), 1, 1, maxAniso),
    giantSkin: makeTexture(giantSkinCanvas(), 2, 2, maxAniso),
    skin: makeTexture(skinCanvas(), 1, 1, maxAniso),
    cobweb: makeTexture(cobwebCanvas(), 1, 1, maxAniso),
    clockFace: makeTexture(clockFaceCanvas(), 1, 1, maxAniso),
    windowNight: makeTexture(windowCanvas(), 1, 1, maxAniso),
    stairs: makeTexture(stairsCanvas(), 1, 1, maxAniso),
  };
}
