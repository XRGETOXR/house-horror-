export function isGameFullscreen(): boolean {
  if (typeof document === 'undefined') return false;
  const doc = document as Document & {
    webkitFullscreenElement?: Element | null;
    mozFullScreenElement?: Element | null;
  };
  return Boolean(
    doc.fullscreenElement || doc.webkitFullscreenElement || doc.mozFullScreenElement
  );
}

export async function requestGameFullscreen(): Promise<boolean> {
  if (typeof document === 'undefined') return false;
  if (isGameFullscreen()) return true;

  const el = document.documentElement as HTMLElement & {
    webkitRequestFullscreen?: (options?: FullscreenOptions) => Promise<void> | void;
    mozRequestFullScreen?: () => Promise<void> | void;
  };

  try {
    if (typeof el.requestFullscreen === 'function') {
      await el.requestFullscreen({ navigationUI: 'hide' } as FullscreenOptions);
      return true;
    }
    if (typeof el.webkitRequestFullscreen === 'function') {
      await el.webkitRequestFullscreen();
      return true;
    }
    if (typeof el.mozRequestFullScreen === 'function') {
      await el.mozRequestFullScreen();
      return true;
    }
  } catch {
    // Fullscreen can be blocked in certain embedded iframes or iOS Safari
  }
  return false;
}

export async function exitGameFullscreen(): Promise<void> {
  if (typeof document === 'undefined' || !isGameFullscreen()) return;
  const doc = document as Document & {
    webkitExitFullscreen?: () => Promise<void> | void;
    mozCancelFullScreen?: () => Promise<void> | void;
  };
  try {
    if (typeof doc.exitFullscreen === 'function') {
      await doc.exitFullscreen();
    } else if (typeof doc.webkitExitFullscreen === 'function') {
      await doc.webkitExitFullscreen();
    } else if (typeof doc.mozCancelFullScreen === 'function') {
      await doc.mozCancelFullScreen();
    }
  } catch {
    // ignore
  }
}

export function toggleGameFullscreen(): void {
  if (isGameFullscreen()) {
    void exitGameFullscreen();
  } else {
    void requestGameFullscreen();
  }
}
