HORROR HOUSE - Android App Project

تم تحديث اسم التطبيق إلى Horror House وإضافة صورة أيقونة جديدة لرجل مخيف يحمل مطرقة شوكية أمام منزل مرعب.

المشروع يحوّل نسخة HTML المرفقة إلى تطبيق Android باستخدام WebView، مع وضع ملء الشاشة واتجاه أفقي ودعم JavaScript والتحكم باللمس.

مهم: ملف اللعبة يستدعي Three.js والخطوط العربية من الإنترنت عبر CDN/Google Fonts؛ لذلك يحتاج التطبيق إلى اتصال بالإنترنت عند التشغيل.

لبناء APK:
1) افتح مجلد hammer_house_android في Android Studio حديث.
2) اسمح بمزامنة Gradle وتنزيل Android Gradle Plugin وAndroid SDK 35 عند الطلب.
3) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4) ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk.

معرّف التطبيق: com.okazi.hammerhouse
اسم التطبيق: Horror House
