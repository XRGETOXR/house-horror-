import { formatTimeAr, toArabicDigits } from '../game/constants';
import { HudState } from '../game/types';

interface EndScreenModalProps {
  hud: HudState;
  onRestart: () => void;
  onSpectate: () => void;
  onMenu: () => void;
}

export function EndScreenModal({ hud, onRestart, onSpectate, onMenu }: EndScreenModalProps) {
  const won = hud.state === 'win';
  const hasAliveTeammate =
    Boolean(hud.mpRoomCode) && hud.mpPeers.some((p) => p.alive && !p.escaped);
  const deathTitle =
    {
      hammer: 'حطّمتك المطرقة',
      giant: 'سحقك العملاق',
      closet: 'اكتشف مخبأك',
      trap: 'انتهيت في الفخ',
    }[hud.killer || 'hammer'] || 'انتهت اللعبة';

  return (
    <div
      className={`fixed inset-0 z-30 flex justify-center p-4 ${
        won
          ? 'items-end bg-gradient-to-t from-[rgba(2,1,1,0.9)] via-[rgba(2,1,1,0.4)] to-transparent pb-10'
          : 'items-center bg-[rgba(2,1,1,0.86)]'
      }`}
      dir="rtl"
    >
      <div className="w-full max-w-[460px] text-center space-y-3">
        <h2
          className={`font-display text-[clamp(28px,6.5vw,44px)] leading-tight ${
            won ? 'text-[#6fbf73]' : 'text-[#b3201a]'
          }`}
        >
          {won ? 'هربت من البيت!' : deathTitle}
        </h2>

        <p className="text-xs sm:text-sm text-[#ebe3d6] leading-relaxed">
          الوقت{' '}
          <span className="font-mono-num font-bold">{formatTimeAr(hud.timeSeconds)}</span> ·
          المفاتيح{' '}
          <span className="font-mono-num font-bold">
            {toArabicDigits(hud.keys)}/{toArabicDigits(hud.needKeys)}
          </span>{' '}
          · الاختباء{' '}
          <span className="font-mono-num font-bold">{toArabicDigits(hud.hidesCount)}</span> مرة
        </p>

        <div className="flex flex-wrap justify-center gap-2 pt-1">
          {!won && hasAliveTeammate && (
            <button
              type="button"
              onClick={onSpectate}
              className="font-display text-lg sm:text-xl px-5 py-1.5 rounded-md bg-[#2a221d] hover:bg-[#3a2f28] border border-[#e2b34a] text-[#e2b34a] cursor-pointer"
            >
              متابعة زميلك
            </button>
          )}
          {(!hud.mpRoomCode || hud.mpIsHost) && (
            <button
              type="button"
              onClick={onRestart}
              className="font-display text-lg sm:text-xl px-6 py-1.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[#ebe3d6] cursor-pointer"
            >
              {won ? 'العب مجددًا' : 'حاول مرة أخرى'}
            </button>
          )}
          <button
            type="button"
            onClick={onMenu}
            className="font-display text-lg sm:text-xl px-5 py-1.5 rounded-md border border-[rgba(235,227,214,0.22)] text-[#ebe3d6] hover:bg-white/5 cursor-pointer"
          >
            القائمة
          </button>
        </div>
      </div>
    </div>
  );
}
