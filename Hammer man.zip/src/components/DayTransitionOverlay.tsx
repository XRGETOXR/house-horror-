import { toArabicDigits } from '../game/constants';

interface DayTransitionOverlayProps {
  day: number;
  maxDays: number;
  phase: 'start' | 'death' | 'final';
  cross: boolean;
  sub: string;
}

export function DayTransitionOverlay({
  day,
  maxDays,
  phase,
  cross,
  sub,
}: DayTransitionOverlayProps) {
  const goneCount = phase === 'start' ? day - 1 : day - 1;
  const title =
    phase === 'start'
      ? `اليوم ${toArabicDigits(day)} من ${toArabicDigits(maxDays)}`
      : `سقطتَ في اليوم ${toArabicDigits(day)}`;

  return (
    <div
      className="fixed inset-0 z-25 grid place-items-center content-center gap-5 bg-[#030202] text-center p-4"
      dir="rtl"
    >
      <div className="font-display text-[clamp(42px,10vw,92px)] text-[#ebe3d6] [text-shadow:0_0_30px_rgba(179,32,26,0.4)]">
        {title}
      </div>

      <div className="flex gap-2.5 justify-center">
        {Array.from({ length: maxDays }, (_, idx) => {
          const i = idx + 1;
          const isGone = i <= goneCount;
          const isCur = i === day;
          const showAnimX = cross && isCur;

          return (
            <div
              key={i}
              className={`relative w-[clamp(38px,9vw,58px)] aspect-square border-2 grid place-items-center font-display text-[clamp(20px,5vw,32px)] ${
                isGone
                  ? 'border-[rgba(235,227,214,0.16)] text-[#6a1410]'
                  : isCur
                    ? 'border-[#ebe3d6] text-[#ebe3d6] shadow-[0_0_18px_rgba(179,32,26,0.5)]'
                    : 'border-[rgba(235,227,214,0.16)] text-[#a09384]'
              }`}
            >
              <span>{toArabicDigits(i)}</span>
              {(isGone || showAnimX) && (
                <>
                  <span
                    className={`absolute left-[6%] right-[6%] top-1/2 h-1 -mt-0.5 bg-[#b3201a] rotate-45 ${
                      showAnimX ? 'day-cross-1' : ''
                    }`}
                  />
                  <span
                    className={`absolute left-[6%] right-[6%] top-1/2 h-1 -mt-0.5 bg-[#b3201a] -rotate-45 ${
                      showAnimX ? 'day-cross-2' : ''
                    }`}
                  />
                </>
              )}
            </div>
          );
        })}
      </div>

      {sub && <div className="text-lg sm:text-xl text-[#a09384]">{sub}</div>}
    </div>
  );
}
