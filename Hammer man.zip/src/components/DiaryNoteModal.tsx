import { useEffect } from 'react';
import { DIARY_NOTES, toArabicDigits } from '../game/constants';

interface DiaryNoteModalProps {
  activeNoteId: string;
  notesRead: string[];
  totalNotes: number;
  onSelectNote: (id: string) => void;
  onClose: () => void;
}

export function DiaryNoteModal({
  activeNoteId,
  notesRead,
  totalNotes,
  onSelectNote,
  onClose,
}: DiaryNoteModalProps) {
  const note = DIARY_NOTES.find((n) => n.id === activeNoteId) ?? DIARY_NOTES[0];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape' || e.code === 'Enter' || e.code === 'KeyN' || e.code === 'KeyE') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-[rgba(4,2,2,0.88)] overflow-y-auto"
      dir="rtl"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="w-full max-w-[540px] rounded-lg bg-[#e6d7b8] text-[#241911] border-2 border-[#6e5638] p-5 sm:p-7 space-y-4 relative"
        style={{
          boxShadow: 'inset 0 0 42px rgba(72,44,18,0.34), 0 20px 55px rgba(0,0,0,0.85)',
        }}
      >
        {/* Top Meta Bar */}
        <div className="flex items-center justify-between gap-2 text-xs text-[#634b35] border-b border-[#5b432b]/25 pb-2">
          <span className="font-bold">
            مذكرة {toArabicDigits(note.number)} من {toArabicDigits(totalNotes)}
          </span>
          <span>{note.dateLabel}</span>
        </div>

        {/* Note Title & Author */}
        <div className="space-y-1">
          <h2 className="font-display text-2xl sm:text-3xl text-[#6e120f] leading-snug">
            {note.title}
          </h2>
          <p className="text-xs text-[#6a4e37] font-bold">بقلم: {note.author}</p>
        </div>

        {/* Story / Lore Body */}
        <div className="space-y-3 text-sm sm:text-base leading-relaxed text-[#261a12]">
          {note.body.map((paragraph, idx) => (
            <p key={idx}>{paragraph}</p>
          ))}
        </div>

        {/* Puzzle Clue Highlight */}
        <div className="bg-[rgba(110,18,15,0.08)] border border-[#7c1b16]/35 rounded-md px-3.5 py-2.5 text-xs sm:text-sm font-bold text-[#52120e] leading-relaxed">
          {note.hint}
        </div>

        {/* Collected Notes Switcher (when 2+ found) */}
        {notesRead.length > 1 && (
          <div className="pt-1 border-t border-[#5b432b]/20 flex items-center justify-between gap-2 flex-wrap">
            <span className="text-xs text-[#5d4732] font-bold">المذكرات التي عثرت عليها:</span>
            <div className="flex items-center gap-1.5 flex-wrap">
              {DIARY_NOTES.filter((n) => notesRead.includes(n.id)).map((item) => {
                const active = item.id === note.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectNote(item.id)}
                    className={`px-2.5 py-1 rounded text-xs font-bold cursor-pointer transition-colors border ${
                      active
                        ? 'bg-[#6e120f] text-[#f4ead5] border-[#6e120f]'
                        : 'bg-[#d6c29d] text-[#3a2a1c] border-[#8b704f]/50 hover:bg-[#cbb387]'
                    }`}
                  >
                    #{toArabicDigits(item.number)}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Close Button */}
        <div className="pt-1 flex items-center justify-between gap-3">
          <span className="text-[11px] text-[#634b35]">
            تم إيقاف الوحوش مؤقتاً أثناء القراءة
          </span>
          <button
            type="button"
            onClick={onClose}
            className="font-display text-lg px-6 py-1.5 rounded-md bg-[#261a12] hover:bg-[#3a261a] text-[#f2e7d0] cursor-pointer transition-colors"
          >
            متابعة اللعب
          </button>
        </div>
      </div>
    </div>
  );
}
