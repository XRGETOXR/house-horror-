import { GameSettings, GfxQuality, HouseTheme, TouchMode } from '../game/types';

interface SettingsModalProps {
  settings: GameSettings;
  onChange: (next: GameSettings) => void;
  onBack: () => void;
}

export function SettingsModal({ settings, onChange, onBack }: SettingsModalProps) {
  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-3 sm:p-4 bg-[rgba(2,1,1,0.86)]"
      dir="rtl"
    >
      <div className="w-full max-w-[440px] max-h-[92dvh] overflow-y-auto bg-[rgba(14,10,9,0.95)] border border-[rgba(235,227,214,0.18)] rounded-xl p-5 sm:p-6 space-y-4">
        <h2 className="font-display text-3xl sm:text-4xl text-[#b3201a] text-center">الإعدادات</h2>

        <div className="space-y-3.5 text-sm text-[#ebe3d6]">
          <label className="block space-y-1">
            <span className="block font-bold">تصميم المنزل</span>
            <select
              value={settings.houseTheme}
              onChange={(e) => onChange({ ...settings, houseTheme: e.target.value as HouseTheme })}
              className="w-full bg-[#151110] border border-[rgba(235,227,214,0.2)] rounded-md px-3 py-2 text-[#ebe3d6]"
            >
              <option value="manor">القصر الحجري الملعون (جديد)</option>
              <option value="classic">البيت الخشبي القديم</option>
            </select>
          </label>

          <label className="block space-y-1">
            <span className="block font-bold">أزرار التحكم باللمس (للجوال)</span>
            <select
              value={settings.touchMode}
              onChange={(e) => onChange({ ...settings, touchMode: e.target.value as TouchMode })}
              className="w-full bg-[#151110] border border-[rgba(235,227,214,0.2)] rounded-md px-3 py-2 text-[#ebe3d6]"
            >
              <option value="auto">تلقائي (حسب الجهاز)</option>
              <option value="on">مفعّلة دائماً (جوال / تابلت)</option>
              <option value="off">مخفية (كمبيوتر)</option>
            </select>
          </label>

          <label className="block space-y-1">
            <span className="block font-bold">جودة الرسوم</span>
            <select
              value={settings.gfx}
              onChange={(e) => onChange({ ...settings, gfx: e.target.value as GfxQuality })}
              className="w-full bg-[#151110] border border-[rgba(235,227,214,0.2)] rounded-md px-3 py-2 text-[#ebe3d6]"
            >
              <option value="low">منخفضة (أسرع)</option>
              <option value="med">متوسطة</option>
              <option value="high">عالية (أوضح)</option>
            </select>
          </label>

          <label className="block space-y-1">
            <div className="flex justify-between">
              <span className="font-bold">حساسية النظر</span>
              <span className="font-mono-num text-[#a09384]">{settings.sens.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="0.4"
              max="2"
              step="0.1"
              value={settings.sens}
              onChange={(e) => onChange({ ...settings, sens: Number(e.target.value) })}
              className="w-full accent-[#b3201a]"
            />
          </label>

          <label className="block space-y-1">
            <div className="flex justify-between">
              <span className="font-bold">مستوى الصوت</span>
              <span className="font-mono-num text-[#a09384]">
                {Math.round(settings.vol * 100)}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.vol}
              onChange={(e) => onChange({ ...settings, vol: Number(e.target.value) })}
              className="w-full accent-[#b3201a]"
            />
          </label>

          <label className="block space-y-1">
            <div className="flex justify-between">
              <span className="font-bold">السطوع</span>
              <span className="font-mono-num text-[#a09384]">{settings.bright.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="0.6"
              max="1.8"
              step="0.1"
              value={settings.bright}
              onChange={(e) => onChange({ ...settings, bright: Number(e.target.value) })}
              className="w-full accent-[#b3201a]"
            />
          </label>
        </div>

        <div className="text-center pt-1">
          <button
            type="button"
            onClick={onBack}
            className="font-display text-2xl px-8 py-1.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[#ebe3d6] cursor-pointer"
          >
            رجوع
          </button>
        </div>
      </div>
    </div>
  );
}
