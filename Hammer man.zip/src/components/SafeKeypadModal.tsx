import { useEffect, useState } from 'react';
import { Snd } from '../game/sound';

interface SafeKeypadModalProps {
  safeCode: number;
  onComplete: (opened: boolean) => void;
}

export function SafeKeypadModal({ safeCode, onComplete }: SafeKeypadModalProps) {
  const [buf, setBuf] = useState('');
  const [status, setStatus] = useState<'idle' | 'ok' | 'bad'>('idle');

  const pressKey = (k: string) => {
    if (status !== 'idle') return;
    if (k === '⌫') {
      setBuf((prev) => prev.slice(0, -1));
      return;
    }
    if (k === '✓') {
      if (buf.length < 3) return;
    }
    const next = k === '✓' ? buf : buf.length < 3 ? buf + k : buf;
    setBuf(next);
    Snd.tone('square', 700 + next.length * 80, 700, 0.06, 0.05);

    if (next.length === 3) {
      const good = next === String(safeCode);
      window.setTimeout(() => {
        if (good) {
          setStatus('ok');
          Snd.chime();
          window.setTimeout(() => onComplete(true), 600);
        } else {
          setStatus('bad');
          Snd.bang();
          window.setTimeout(() => {
            setStatus('idle');
            setBuf('');
          }, 480);
        }
      }, 180);
    }
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        e.preventDefault();
        onComplete(false);
        return;
      }
      if (/^[0-9]$/.test(e.key)) pressKey(e.key);
      else if (e.code === 'Backspace') pressKey('⌫');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const displayStr = [0, 1, 2].map((i) => (i < buf.length ? buf[i] : '-')).join(' ');

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-[rgba(2,1,1,0.85)]"
      dir="rtl"
    >
      <div className="w-full max-w-[360px] text-center space-y-4">
        <h2 className="font-display text-4xl text-[#b3201a]">الخزنة</h2>
        <div
          dir="ltr"
          className={`font-display text-5xl tracking-[0.28em] py-2 font-mono-num ${
            status === 'ok'
              ? 'text-[#46ff82]'
              : status === 'bad'
                ? 'text-[#b3201a]'
                : 'text-[#ebe3d6]'
          }`}
        >
          {displayStr}
        </div>

        <div className="grid grid-cols-3 gap-2.5 max-w-[220px] mx-auto" dir="ltr">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', '✓'].map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => pressKey(k)}
              className="h-14 text-2xl text-[#ebe3d6] bg-[rgba(14,10,9,0.92)] hover:bg-white/10 border border-[rgba(235,227,214,0.2)] rounded-lg cursor-pointer transition-colors"
            >
              {k}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => onComplete(false)}
          className="font-display text-xl px-7 py-1.5 rounded-md border border-[rgba(235,227,214,0.22)] text-[#ebe3d6] hover:bg-white/5 cursor-pointer"
        >
          إغلاق
        </button>
      </div>
    </div>
  );
}
