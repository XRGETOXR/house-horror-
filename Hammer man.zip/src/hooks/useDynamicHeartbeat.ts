import { useEffect, useRef } from 'react';
import { Snd } from '../game/sound';

/**
 * Dynamically schedules player heartbeat speed, lub-dub cadence, rhythmic horror
 * stabs, and multi-layered tension music based on Stalker proximity (`hud.threat` 0..1).
 */
export function useDynamicHeartbeat(threat: number, active: boolean): void {
  const threatRef = useRef(threat);
  const activeRef = useRef(active);
  const nextBeatAtRef = useRef<number>(0);
  const beatCountRef = useRef<number>(0);

  threatRef.current = threat;
  activeRef.current = active;

  useEffect(() => {
    if (!active) {
      Snd.setThreatTension(0);
      nextBeatAtRef.current = 0;
      beatCountRef.current = 0;
      return;
    }

    const intervalId = window.setInterval(() => {
      if (!activeRef.current) return;
      const t = Math.max(0, Math.min(1, threatRef.current));
      Snd.setThreatTension(t);

      if (t <= 0.05) {
        nextBeatAtRef.current = 0;
        return;
      }

      // Smoothly ramp BPM from 54 (distant Stalker) up to 184 BPM (panic chase)
      const bpm = 54 + Math.pow(t, 1.05) * 130;
      const beatMs = Math.max(326, Math.round(60000 / bpm));
      const now = performance.now();

      // If threat spikes suddenly, pull the next beat closer right away
      if (nextBeatAtRef.current > now + beatMs) {
        nextBeatAtRef.current = now + beatMs;
      }

      if (nextBeatAtRef.current === 0 || now >= nextBeatAtRef.current) {
        const vol = 0.14 + Math.pow(t, 0.85) * 0.8;
        Snd.beat(vol, t);
        beatCountRef.current += 1;

        // Trigger horror musical ostinato pulse in sync with heartbeat at higher proximity
        if (t > 0.34 && (t > 0.76 || beatCountRef.current % 2 === 0)) {
          Snd.tensionStab(t);
        }

        nextBeatAtRef.current = now + beatMs;
      }
    }, 60);

    return () => {
      window.clearInterval(intervalId);
      Snd.setThreatTension(0);
    };
  }, [active]);
}
