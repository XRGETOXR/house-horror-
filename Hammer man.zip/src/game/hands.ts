import * as THREE from 'three';
import { HeldItemType } from './types';

function pivot(x: number, y: number, z: number): THREE.Group {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  return g;
}

function mk(
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x: number,
  y: number,
  z: number
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  return m;
}

export class FirstPersonHands {
  public readonly scene = new THREE.Scene();
  public readonly camera = new THREE.PerspectiveCamera(58, 1, 0.02, 6);
  private leftRoot: THREE.Group;
  private rightEmpty: THREE.Group;
  private rightToolRoot: THREE.Group;
  private lensMesh: THREE.Mesh;
  private toolGroups: Record<Exclude<HeldItemType, null>, THREE.Group>;

  private t = 0;
  private sx = 0;
  private sy = 0;
  private py: number | undefined = undefined;
  private pp: number | undefined = undefined;
  public recoil = 0;
  public swing = 0;

  constructor(skinTexture: THREE.Texture) {
    this.scene.add(new THREE.AmbientLight(0xa39588, 0.85));
    const dl = new THREE.DirectionalLight(0xffeedd, 0.85);
    dl.position.set(-0.4, 1, 1);
    this.scene.add(dl);

    const sk = new THREE.MeshStandardMaterial({
      map: skinTexture,
      roughness: 0.72,
      metalness: 0.05,
    });
    const sleeve = new THREE.MeshStandardMaterial({
      color: 0x282830,
      roughness: 0.9,
      metalness: 0.05,
    });
    const nail = new THREE.MeshStandardMaterial({
      color: 0xecd0be,
      roughness: 0.35,
      metalness: 0.05,
    });

    const cylZ = (r0: number, r1: number, len: number, mat: THREE.Material) => {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(r0, r1, len, 10), mat);
      m.rotation.x = Math.PI / 2;
      m.position.z = -len / 2;
      return m;
    };

    const finger = (
      g: THREE.Group,
      x: number,
      z0: number,
      c1: number,
      c2: number,
      c3: number,
      sc: number,
      ry = 0
    ) => {
      const p1 = pivot(x, 0.004, z0);
      p1.rotation.x = -c1;
      if (ry) p1.rotation.y = ry;
      p1.add(cylZ(0.0115, 0.0105, 0.046 * sc, sk));

      const p2 = pivot(0, 0, -0.046 * sc);
      p2.rotation.x = -c2;
      p2.add(new THREE.Mesh(new THREE.SphereGeometry(0.0108, 8, 6), sk));
      p2.add(cylZ(0.0105, 0.0095, 0.033 * sc, sk));

      const p3 = pivot(0, 0, -0.033 * sc);
      p3.rotation.x = -c3;
      p3.add(new THREE.Mesh(new THREE.SphereGeometry(0.0096, 8, 6), sk));
      p3.add(cylZ(0.0095, 0.0085, 0.026 * sc, sk));
      p3.add(mk(new THREE.BoxGeometry(0.011, 0.003, 0.014), nail, 0, 0.0078, -0.016 * sc));

      p2.add(p3);
      p1.add(p2);
      g.add(p1);
    };

    const buildHand = (sign: number, pose: 'grip' | 'relaxed' | 'gun') => {
      const g = new THREE.Group();
      const fore = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.047, 0.5, 14), sk);
      fore.rotation.x = Math.PI / 2;
      fore.position.z = 0.27;
      g.add(fore);

      const sl = new THREE.Mesh(
        new THREE.CylinderGeometry(0.05, 0.058, 0.3, 14, 1, true),
        sleeve
      );
      sl.rotation.x = Math.PI / 2;
      sl.position.z = 0.4;
      g.add(sl);

      const cuff = new THREE.Mesh(
        new THREE.TorusGeometry(0.052, 0.008, 6, 16),
        new THREE.MeshStandardMaterial({ color: 0x1a1a20, roughness: 0.9 })
      );
      cuff.position.z = 0.25;
      g.add(cuff);

      g.add(mk(new THREE.BoxGeometry(0.098, 0.034, 0.1), sk, 0, 0, -0.05));
      g.add(mk(new THREE.SphereGeometry(0.047, 10, 8), sk, 0, 0, 0));

      const xs = [-0.036, -0.012, 0.012, 0.036];
      const sc = [0.92, 1.05, 1.0, 0.82];
      const cv =
        pose === 'grip' || pose === 'gun'
          ? [1.15, 1.2, 1.2, 1.1]
          : [0.35, 0.45, 0.5, 0.55];
      for (let i = 0; i < 4; i++) {
        if (pose === 'gun' && i === 0) {
          finger(g, xs[i] * sign * -1, -0.1, 0.08, 0.05, 0.02, sc[i]);
          continue;
        }
        finger(g, xs[i] * sign * -1, -0.1, cv[i], cv[i] * 1.05, cv[i] * 0.7, sc[i]);
      }
      finger(g, sign * 0.052, -0.045, 0.2, 0.25, 0.15, 1.0, sign * 0.7);
      return g;
    };

    // Left hand + flashlight
    this.leftRoot = new THREE.Group();
    const lh = buildHand(-1, 'grip');
    this.leftRoot.add(lh);
    const fl = new THREE.Group();
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.026, 0.03, 0.2, 14),
      new THREE.MeshStandardMaterial({ color: 0x2a2a30, roughness: 0.45, metalness: 0.7 })
    );
    body.rotation.x = Math.PI / 2;
    fl.add(body);
    const head = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.028, 0.06, 14),
      new THREE.MeshStandardMaterial({ color: 0x44444c, roughness: 0.3, metalness: 0.85 })
    );
    head.rotation.x = Math.PI / 2;
    head.position.z = -0.12;
    fl.add(head);
    this.lensMesh = new THREE.Mesh(
      new THREE.CircleGeometry(0.036, 14),
      new THREE.MeshBasicMaterial({ color: 0xfff0c0 })
    );
    this.lensMesh.position.z = -0.151;
    this.lensMesh.rotation.y = Math.PI;
    fl.add(this.lensMesh);
    fl.position.set(0, -0.03, -0.1);
    lh.add(fl);
    this.leftRoot.rotation.set(-0.1, 0.25, 0.5);
    this.leftRoot.position.set(-0.2, -0.2, -0.42);
    this.scene.add(this.leftRoot);

    // Right hand empty
    this.rightEmpty = new THREE.Group();
    this.rightEmpty.add(buildHand(1, 'relaxed'));
    this.rightEmpty.rotation.set(-0.1, -0.25, -0.3);
    this.rightEmpty.position.set(0.2, -0.2, -0.42);
    this.scene.add(this.rightEmpty);

    // Right hand holding tools
    this.rightToolRoot = new THREE.Group();
    const rhGrip = buildHand(1, 'gun');
    this.rightToolRoot.add(rhGrip);
    this.rightToolRoot.rotation.set(-0.12, -0.12, -0.1);
    this.rightToolRoot.position.set(0.2, -0.2, -0.42);
    this.scene.add(this.rightToolRoot);

    const metalDark = new THREE.MeshStandardMaterial({
      color: 0x202228,
      roughness: 0.35,
      metalness: 0.85,
    });
    const metalBright = new THREE.MeshStandardMaterial({
      color: 0xaab0ba,
      roughness: 0.25,
      metalness: 0.9,
    });
    const wood = new THREE.MeshStandardMaterial({
      color: 0x5c3c22,
      roughness: 0.82,
      metalness: 0.05,
    });
    const redPlastic = new THREE.MeshStandardMaterial({
      color: 0xb22820,
      roughness: 0.55,
      metalness: 0.1,
    });
    const ceramic = new THREE.MeshStandardMaterial({
      color: 0xc2b29b,
      roughness: 0.35,
      metalness: 0.05,
    });

    // 1. Gun
    const gunG = new THREE.Group();
    gunG.add(mk(new THREE.BoxGeometry(0.034, 0.042, 0.2), metalDark, 0, -0.044, -0.12));
    gunG.add(mk(new THREE.BoxGeometry(0.03, 0.036, 0.07), wood, 0, -0.052, 0));
    const grip = mk(new THREE.BoxGeometry(0.032, 0.095, 0.046), wood, 0, -0.1, -0.045);
    grip.rotation.x = -0.25;
    gunG.add(grip);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.06, 8), metalDark);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, -0.04, -0.24);
    gunG.add(barrel);
    gunG.add(mk(new THREE.BoxGeometry(0.01, 0.012, 0.012), metalBright, 0, -0.02, -0.205));
    rhGrip.add(gunG);

    // 2. Hammer
    const hamG = new THREE.Group();
    const hHandle = mk(new THREE.CylinderGeometry(0.013, 0.015, 0.28, 10), wood, 0, 0.04, -0.07);
    hHandle.rotation.x = 0.25;
    hamG.add(hHandle);
    const hHead = mk(new THREE.BoxGeometry(0.042, 0.042, 0.13), metalDark, 0, 0.17, -0.11);
    hHead.rotation.x = 0.25;
    hamG.add(hHead);
    rhGrip.add(hamG);

    // 3. Screwdriver
    const sdG = new THREE.Group();
    const sdHandle = mk(
      new THREE.CylinderGeometry(0.018, 0.015, 0.11, 10),
      redPlastic,
      0,
      -0.01,
      -0.07
    );
    sdHandle.rotation.x = Math.PI / 2;
    sdG.add(sdHandle);
    const sdShaft = mk(
      new THREE.CylinderGeometry(0.004, 0.004, 0.16, 8),
      metalBright,
      0,
      -0.01,
      -0.19
    );
    sdShaft.rotation.x = Math.PI / 2;
    sdG.add(sdShaft);
    rhGrip.add(sdG);

    // 4. Wire Cutters / Pliers
    const cutG = new THREE.Group();
    const leg1 = mk(new THREE.BoxGeometry(0.014, 0.014, 0.14), redPlastic, -0.014, -0.01, -0.08);
    leg1.rotation.y = 0.14;
    const leg2 = mk(new THREE.BoxGeometry(0.014, 0.014, 0.14), redPlastic, 0.014, -0.01, -0.08);
    leg2.rotation.y = -0.14;
    const jaw1 = mk(new THREE.BoxGeometry(0.012, 0.016, 0.07), metalBright, -0.007, -0.01, -0.17);
    jaw1.rotation.y = -0.15;
    const jaw2 = mk(new THREE.BoxGeometry(0.012, 0.016, 0.07), metalBright, 0.007, -0.01, -0.17);
    jaw2.rotation.y = 0.15;
    cutG.add(leg1, leg2, jaw1, jaw2);
    rhGrip.add(cutG);

    // 5. Ceramic Vase (Throwable distraction)
    const vaseG = new THREE.Group();
    const vBody = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.036, 0.15, 14),
      ceramic
    );
    vBody.position.set(0, 0.01, -0.12);
    const vNeck = new THREE.Mesh(
      new THREE.CylinderGeometry(0.032, 0.025, 0.05, 14),
      ceramic
    );
    vNeck.position.set(0, 0.095, -0.12);
    const vBand = new THREE.Mesh(
      new THREE.CylinderGeometry(0.047, 0.047, 0.02, 14),
      new THREE.MeshStandardMaterial({ color: 0x7a2420, roughness: 0.5 })
    );
    vBand.position.set(0, 0.02, -0.12);
    vaseG.add(vBody, vNeck, vBand);
    rhGrip.add(vaseG);

    this.toolGroups = {
      gun: gunG,
      hammer: hamG,
      screwdriver: sdG,
      cutters: cutG,
      vase: vaseG,
    };
  }

  public resize(aspect: number): void {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }

  public update(
    dt: number,
    yaw: number,
    pitch: number,
    moving: boolean,
    bob: number,
    crouch: boolean,
    torchOn: boolean,
    heldItem: HeldItemType,
    hasTorch = true
  ): void {
    this.t += dt;
    let dy = yaw - (this.py === undefined ? yaw : this.py);
    const dp = pitch - (this.pp === undefined ? pitch : this.pp);
    this.py = yaw;
    this.pp = pitch;
    while (dy > Math.PI) dy -= Math.PI * 2;
    while (dy < -Math.PI) dy += Math.PI * 2;

    const k = Math.min(1, dt * 8);
    this.sx += (Math.max(-0.07, Math.min(0.07, -dy * 1.2)) - this.sx) * k;
    this.sy += (Math.max(-0.05, Math.min(0.05, dp * 0.9)) - this.sy) * k;

    const mv = moving ? 1 : 0;
    const bx = mv * Math.sin(bob * 0.5) * 0.012;
    const by = mv * Math.abs(Math.sin(bob)) * 0.015 + Math.sin(this.t * 1.7) * 0.003;

    this.recoil = Math.max(0, this.recoil - dt * 7);
    this.swing = Math.max(0, this.swing - dt * 5);
    const cd = crouch ? 0.015 : 0;

    this.leftRoot.visible = hasTorch;
    this.leftRoot.position.set(-0.2 + bx + this.sx, -0.2 - by + this.sy - cd, -0.42);
    const rz = -0.42 + this.recoil * 0.06 - this.swing * 0.05;
    this.rightEmpty.position.set(0.2 + bx + this.sx, -0.2 - by + this.sy - cd, -0.42);
    this.rightToolRoot.position.set(0.2 + bx + this.sx, -0.2 - by + this.sy - cd, rz);
    this.rightToolRoot.rotation.x = -0.12 + this.recoil * 0.45 - Math.sin(this.swing * Math.PI) * 0.65;

    this.rightEmpty.visible = heldItem === null;
    this.rightToolRoot.visible = heldItem !== null;

    (Object.keys(this.toolGroups) as Exclude<HeldItemType, null>[]).forEach((key) => {
      this.toolGroups[key].visible = heldItem === key;
    });

    (this.lensMesh.material as THREE.MeshBasicMaterial).color.setHex(
      hasTorch && torchOn ? 0xfff0c0 : 0x303030
    );
  }
}
