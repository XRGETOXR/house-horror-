import { ChatMessage, DifficultyKey, MultiplayerPeer, MultiplayerRoomSnapshot, RoomWorldSnapshot } from './types';

function createInitialWorld(diff: DifficultyKey): RoomWorldSnapshot {
  return {
    roundId: Date.now() + ((Math.random() * 1000) | 0),
    diff,
    safeCode: 100 + ((Math.random() * 900) | 0),
    keySeed: (Math.random() * 0xffffffff) >>> 0,
    giantRoll: Math.random(),
    searchedSpots: [],
    plankBroken: false,
    wireCut: false,
    panelOpened: false,
    safeOpen: false,
    doorOpen: false,
  };
}

function cleanName(raw: unknown): string {
  const s = String(raw || '')
    .replace(/[^\p{L}\p{N} _-]/gu, '')
    .trim()
    .slice(0, 14);
  return s || 'لاعب';
}

function cleanChat(raw: unknown): string {
  return String(raw || '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .trim()
    .slice(0, 160);
}

function bytesToBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64ToBytes(b64: string): Uint8Array {
  const norm = b64.replace(/-/g, '+').replace(/_/g, '/');
  const pad = norm.length % 4 === 0 ? '' : '='.repeat(4 - (norm.length % 4));
  const bin = atob(norm + pad);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

async function encodeSignalToken(payload: unknown): Promise<string> {
  const rawBytes = new TextEncoder().encode(JSON.stringify(payload));
  if (typeof CompressionStream !== 'undefined') {
    try {
      const cs = new CompressionStream('deflate-raw');
      const writer = cs.writable.getWriter();
      await writer.write(rawBytes);
      await writer.close();
      const compressed = new Uint8Array(await new Response(cs.readable).arrayBuffer());
      return `LANZ:${bytesToBase64(compressed)}`;
    } catch {
      // fall through
    }
  }
  return `LAN1:${bytesToBase64(rawBytes)}`;
}

async function decodeSignalToken(token: string): Promise<Record<string, unknown>> {
  const clean = token.trim();
  if (clean.startsWith('LANZ:') && typeof DecompressionStream !== 'undefined') {
    const bytes = base64ToBytes(clean.slice(5));
    const ds = new DecompressionStream('deflate-raw');
    const writer = ds.writable.getWriter();
    await writer.write(bytes as unknown as BufferSource);
    await writer.close();
    const text = await new Response(ds.readable).text();
    return JSON.parse(text) as Record<string, unknown>;
  }
  const rawB64 = clean.startsWith('LAN1:') ? clean.slice(5) : clean;
  const text = new TextDecoder().decode(base64ToBytes(rawB64));
  return JSON.parse(text) as Record<string, unknown>;
}

function waitForIceComplete(pc: RTCPeerConnection, timeoutMs = 1800): Promise<void> {
  if (pc.iceGatheringState === 'complete') return Promise.resolve();
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      pc.removeEventListener('icegatheringstatechange', onChange);
      window.clearTimeout(timer);
      resolve();
    };
    const onChange = () => {
      if (pc.iceGatheringState === 'complete') finish();
    };
    const timer = window.setTimeout(finish, timeoutMs);
    pc.addEventListener('icegatheringstatechange', onChange);
  });
}

export interface LanTransportHandlers {
  onOpen: () => void;
  onPacket: (packet: Record<string, unknown>) => void;
  onError: (msg: string) => void;
  onClose: () => void;
}

/**
 * Direct Wi-Fi / Mobile Hotspot LAN WebRTC transport (no internet or relay server required).
 * The Host browser/device acts as the authoritative room coordinator for up to 3 LAN guests.
 */
export class LanRtcManager {
  private handlers: LanTransportHandlers;
  private role: 'host' | 'guest' | null = null;
  private hostId = 'lan_host';
  private guestSeq = 1;
  private msgSeq = 1;
  private pendingHostPc: RTCPeerConnection | null = null;
  private pendingHostChannel: RTCDataChannel | null = null;
  private pendingGuestId: string | null = null;

  private hostPeers = new Map<
    string,
    { pc: RTCPeerConnection; dc: RTCDataChannel; state: MultiplayerPeer }
  >();
  private room: MultiplayerRoomSnapshot | null = null;

  private guestPc: RTCPeerConnection | null = null;
  private guestDc: RTCDataChannel | null = null;

  constructor(handlers: LanTransportHandlers) {
    this.handlers = handlers;
  }

  public get active(): boolean {
    return this.role !== null;
  }

  public async createHostOffer(hostName: string, diff: DifficultyKey): Promise<string> {
    if (typeof RTCPeerConnection === 'undefined') {
      throw new Error('هذا المتصفح لا يدعم اتصال LAN المباشر');
    }

    // Initialize room if first time hosting on LAN
    if (!this.room || this.role !== 'host') {
      this.close();
      this.role = 'host';
      const cleanHost = cleanName(hostName);
      const hostPeer: MultiplayerPeer = {
        id: this.hostId,
        name: cleanHost,
        colorIndex: 0,
        x: 4.8,
        y: 0,
        z: 3.8,
        yaw: -Math.PI / 2,
        fl: 0,
        crouch: false,
        torch: true,
        hiddenIdx: -1,
        heldItem: null,
        alive: true,
        escaped: false,
        day: 1,
        speed: 0,
      };
      this.room = {
        code: 'LAN',
        hostId: this.hostId,
        phase: 'lobby',
        diff,
        world: createInitialWorld(diff),
        peers: [hostPeer],
        messages: [],
      };
      this.handlers.onOpen();
      this.handlers.onPacket({
        type: 'room:joined',
        selfId: this.hostId,
        room: this.snapshotRoom(),
      });
    }

    // Close any unconfirmed pending offer before making a fresh one
    if (this.pendingHostPc) {
      try {
        this.pendingHostPc.close();
      } catch {
        // ignore
      }
      this.pendingHostPc = null;
      this.pendingHostChannel = null;
    }

    const pc = new RTCPeerConnection({ iceServers: [] });
    const gid = `lan_g${this.guestSeq++}`;
    const dc = pc.createDataChannel('granny-lan', { ordered: true });
    this.pendingHostPc = pc;
    this.pendingHostChannel = dc;
    this.pendingGuestId = gid;

    this.attachHostDataChannel(gid, pc, dc);

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIceComplete(pc);

    return encodeSignalToken({
      t: 'o',
      s: pc.localDescription?.sdp || '',
      n: cleanName(hostName),
      d: this.room.diff,
      g: gid,
    });
  }

  public async acceptGuestAnswer(answerToken: string): Promise<void> {
    if (this.role !== 'host' || !this.pendingHostPc || !this.pendingGuestId) {
      throw new Error('أنشئ دعوة نقطة الاتصال أولاً');
    }
    const data = await decodeSignalToken(answerToken);
    if (data.t !== 'a' || typeof data.s !== 'string') {
      throw new Error('رمز الرد غير صالح');
    }
    const guestName = cleanName(data.n);
    const gid = this.pendingGuestId;
    const pc = this.pendingHostPc;
    const dc = this.pendingHostChannel!;
    this.pendingHostPc = null;
    this.pendingHostChannel = null;
    this.pendingGuestId = null;

    const usedColors = new Set(this.room?.peers.map((p) => p.colorIndex) || [0]);
    let colorIndex = 1;
    while (usedColors.has(colorIndex) && colorIndex < 4) colorIndex++;

    const peerState: MultiplayerPeer = {
      id: gid,
      name: guestName,
      colorIndex: colorIndex % 4,
      x: 4.8,
      y: 0,
      z: 3.8,
      yaw: -Math.PI / 2,
      fl: 0,
      crouch: false,
      torch: true,
      hiddenIdx: -1,
      heldItem: null,
      alive: this.room?.phase !== 'playing',
      escaped: false,
      day: 1,
      speed: 0,
    };

    this.hostPeers.set(gid, { pc, dc, state: peerState });
    await pc.setRemoteDescription({ type: 'answer', sdp: data.s });
  }

  public async joinWithHostOffer(offerToken: string, guestName: string): Promise<string> {
    if (typeof RTCPeerConnection === 'undefined') {
      throw new Error('هذا المتصفح لا يدعم اتصال LAN المباشر');
    }
    const data = await decodeSignalToken(offerToken);
    if (data.t !== 'o' || typeof data.s !== 'string') {
      throw new Error('رمز دعوة نقطة الاتصال غير صالح');
    }

    this.close();
    this.role = 'guest';
    const pc = new RTCPeerConnection({ iceServers: [] });
    this.guestPc = pc;

    pc.ondatachannel = (ev) => {
      const dc = ev.channel;
      this.guestDc = dc;
      dc.onopen = () => {
        this.handlers.onOpen();
      };
      dc.onmessage = (mEv) => {
        try {
          const pkt = JSON.parse(String(mEv.data)) as Record<string, unknown>;
          this.handlers.onPacket(pkt);
        } catch {
          // ignore
        }
      };
      dc.onclose = () => {
        this.handlers.onError('انقطع اتصال نقطة الاتصال بالمضيف');
        this.close();
      };
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'disconnected') {
        this.handlers.onError('تعذر إبقاء الاتصال المباشر على نقطة الاتصال');
      }
    };

    await pc.setRemoteDescription({ type: 'offer', sdp: data.s });
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await waitForIceComplete(pc);

    return encodeSignalToken({
      t: 'a',
      s: pc.localDescription?.sdp || '',
      n: cleanName(guestName),
    });
  }

  private attachHostDataChannel(
    gid: string,
    pc: RTCPeerConnection,
    dc: RTCDataChannel
  ): void {
    dc.onopen = () => {
      if (!this.room) return;
      const peerRec = this.hostPeers.get(gid);
      if (!peerRec) return;

      if (!this.room.peers.some((p) => p.id === gid)) {
        this.room.peers.push(peerRec.state);
      }

      const joinMsg: ChatMessage = {
        id: `lansys_${this.msgSeq++}_${Date.now()}`,
        senderId: 'system',
        senderName: 'النظام',
        colorIndex: peerRec.state.colorIndex,
        text: `اتصل ${peerRec.state.name} عبر نقطة الاتصال (LAN)`,
        ts: Date.now(),
        system: true,
      };
      this.pushHostMessage(joinMsg);

      this.sendToPeer(gid, {
        type: 'room:joined',
        selfId: gid,
        room: this.snapshotRoom(),
      });
      this.handlers.onPacket({ type: 'chat:message', message: joinMsg });
      this.handlers.onPacket({ type: 'room:update', room: this.snapshotRoom() });
      this.broadcastFromHost({ type: 'chat:message', message: joinMsg }, gid);
      this.broadcastFromHost({ type: 'room:update', room: this.snapshotRoom() }, gid);
    };

    dc.onmessage = (ev) => {
      try {
        const pkt = JSON.parse(String(ev.data)) as Record<string, unknown>;
        this.handleHostIncoming(gid, pkt);
      } catch {
        // ignore
      }
    };

    const removeGuest = () => {
      const rec = this.hostPeers.get(gid);
      if (!rec) return;
      this.hostPeers.delete(gid);
      if (this.room) {
        this.room.peers = this.room.peers.filter((p) => p.id !== gid);
        const leaveMsg: ChatMessage = {
          id: `lansys_${this.msgSeq++}_${Date.now()}`,
          senderId: 'system',
          senderName: 'النظام',
          colorIndex: 0,
          text: `انفصل ${rec.state.name} من نقطة الاتصال`,
          ts: Date.now(),
          system: true,
        };
        this.pushHostMessage(leaveMsg);
        this.handlers.onPacket({ type: 'chat:message', message: leaveMsg });
        this.handlers.onPacket({ type: 'room:update', room: this.snapshotRoom() });
        this.broadcastFromHost({ type: 'chat:message', message: leaveMsg });
        this.broadcastFromHost({ type: 'room:update', room: this.snapshotRoom() });
      }
    };

    dc.onclose = removeGuest;
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
        removeGuest();
      }
    };
  }

  private pushHostMessage(msg: ChatMessage): void {
    if (!this.room) return;
    if (!this.room.messages) this.room.messages = [];
    this.room.messages.push(msg);
    if (this.room.messages.length > 60) {
      this.room.messages.splice(0, this.room.messages.length - 60);
    }
  }

  private snapshotRoom(): MultiplayerRoomSnapshot | null {
    if (!this.room) return null;
    return {
      ...this.room,
      world: { ...this.room.world, searchedSpots: [...this.room.world.searchedSpots] },
      peers: this.room.peers.map((p) => ({ ...p })),
      messages: [...(this.room.messages || [])],
    };
  }

  private sendToPeer(gid: string, payload: unknown): void {
    const rec = this.hostPeers.get(gid);
    if (rec && rec.dc.readyState === 'open') {
      rec.dc.send(JSON.stringify(payload));
    }
  }

  private broadcastFromHost(payload: unknown, exceptId?: string): void {
    const raw = JSON.stringify(payload);
    this.hostPeers.forEach((rec, gid) => {
      if (gid !== exceptId && rec.dc.readyState === 'open') {
        rec.dc.send(raw);
      }
    });
  }

  public sendClientMessage(msg: Record<string, unknown>): void {
    if (this.role === 'host') {
      this.handleHostIncoming(this.hostId, msg);
    } else if (this.role === 'guest' && this.guestDc?.readyState === 'open') {
      this.guestDc.send(JSON.stringify(msg));
    }
  }

  private handleHostIncoming(fromId: string, msg: Record<string, unknown>): void {
    if (!this.room) return;
    const type = String(msg.type || '');

    if (type === 'room:diff' && fromId === this.hostId) {
      this.room.diff = (msg.diff || this.room.diff) as DifficultyKey;
      const pkt = { type: 'room:update', room: this.snapshotRoom() };
      this.handlers.onPacket(pkt);
      this.broadcastFromHost(pkt);
      return;
    }

    if (type === 'game:start' && fromId === this.hostId) {
      const diff = (msg.diff || this.room.diff) as DifficultyKey;
      this.room.diff = diff;
      this.room.phase = 'playing';
      this.room.world = createInitialWorld(diff);
      this.room.peers.forEach((p) => {
        p.alive = true;
        p.escaped = false;
        p.day = 1;
        p.hiddenIdx = -1;
        p.heldItem = null;
        p.x = 4.8;
        p.z = 3.8;
        p.fl = 0;
      });
      const pkt = { type: 'game:started', room: this.snapshotRoom() };
      this.handlers.onPacket(pkt);
      this.broadcastFromHost(pkt);
      return;
    }

    if (type === 'player:state') {
      const peer = this.room.peers.find((p) => p.id === fromId);
      if (!peer) return;
      if (typeof msg.x === 'number') peer.x = msg.x;
      if (typeof msg.y === 'number') peer.y = msg.y;
      if (typeof msg.z === 'number') peer.z = msg.z;
      if (typeof msg.yaw === 'number') peer.yaw = msg.yaw;
      if (msg.fl === 0 || msg.fl === 1) peer.fl = msg.fl;
      if (typeof msg.crouch === 'boolean') peer.crouch = msg.crouch;
      if (typeof msg.torch === 'boolean') peer.torch = msg.torch;
      if (typeof msg.hiddenIdx === 'number') peer.hiddenIdx = msg.hiddenIdx;
      if (msg.heldItem === null || typeof msg.heldItem === 'string') {
        peer.heldItem = msg.heldItem as MultiplayerPeer['heldItem'];
      }
      if (typeof msg.alive === 'boolean') peer.alive = msg.alive;
      if (typeof msg.escaped === 'boolean') peer.escaped = msg.escaped;
      if (typeof msg.day === 'number') peer.day = msg.day;
      if (typeof msg.speed === 'number') peer.speed = msg.speed;

      const pkt = { type: 'peer:state', peer: { ...peer } };
      if (fromId !== this.hostId) this.handlers.onPacket(pkt);
      this.broadcastFromHost(pkt, fromId);
      return;
    }

    if (type === 'monsters:state' && fromId === this.hostId) {
      this.broadcastFromHost({ type: 'monsters:state', data: msg.data });
      return;
    }

    if (type === 'world:event') {
      const ev = msg.event as Record<string, unknown> | undefined;
      if (!ev) return;
      const kind = String(ev.kind || '');
      if (kind === 'spot' && typeof ev.index === 'number') {
        if (!this.room.world.searchedSpots.includes(ev.index)) {
          this.room.world.searchedSpots.push(ev.index);
        }
      } else if (kind === 'lock') {
        if (ev.lock === 'plankBroken') this.room.world.plankBroken = true;
        if (ev.lock === 'wireCut') this.room.world.wireCut = true;
        if (ev.lock === 'panelOpened') this.room.world.panelOpened = true;
      } else if (kind === 'safe') {
        this.room.world.safeOpen = true;
      } else if (kind === 'door') {
        this.room.world.doorOpen = true;
      } else if (kind === 'revive' && typeof ev.targetId === 'string') {
        const revived = this.room.peers.find((p) => p.id === ev.targetId);
        if (revived) revived.alive = true;
      }
      const pkt = {
        type: 'world:event',
        fromId,
        event: ev,
        world: { ...this.room.world },
      };
      if (fromId !== this.hostId) this.handlers.onPacket(pkt);
      this.broadcastFromHost(pkt, fromId);
      return;
    }

    if (type === 'chat:send') {
      const peer = this.room.peers.find((p) => p.id === fromId);
      if (!peer) return;
      const text = cleanChat(msg.text);
      if (!text) return;
      const chatMsg: ChatMessage = {
        id: `lanm_${this.msgSeq++}_${Date.now()}`,
        senderId: fromId,
        senderName: peer.name,
        colorIndex: peer.colorIndex,
        text,
        ts: Date.now(),
      };
      this.pushHostMessage(chatMsg);
      const pkt = { type: 'chat:message', message: chatMsg };
      this.handlers.onPacket(pkt);
      this.broadcastFromHost(pkt);
    }
  }

  public close(): void {
    this.role = null;
    this.room = null;
    if (this.pendingHostPc) {
      try {
        this.pendingHostPc.close();
      } catch {
        // ignore
      }
      this.pendingHostPc = null;
      this.pendingHostChannel = null;
    }
    this.hostPeers.forEach((rec) => {
      try {
        rec.dc.close();
        rec.pc.close();
      } catch {
        // ignore
      }
    });
    this.hostPeers.clear();
    if (this.guestPc) {
      try {
        this.guestDc?.close();
        this.guestPc.close();
      } catch {
        // ignore
      }
      this.guestPc = null;
      this.guestDc = null;
    }
    this.handlers.onClose();
  }
}
