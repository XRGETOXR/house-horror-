import * as THREE from 'three';
import { GameTextures, rand } from './textures';

function mk(
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x: number,
  y: number,
  z: number
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  return m;
}

function pivot(x: number, y: number, z: number): THREE.Group {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  return g;
}

export interface HammerManRig {
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  head: THREE.Group;
}

export interface GiantRig {
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  body: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
}

export function createHammerManRig(tex: GameTextures): HammerManRig {
  const g = new THREE.Group();
  const coatMat = new THREE.MeshStandardMaterial({ map: tex.cloth, color: 0x3b2c28, roughness: 0.92, metalness: 0.08 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e1916, roughness: 0.95 });
  const skinMat = new THREE.MeshStandardMaterial({ map: tex.face, roughness: 0.72 });
  const maskLeather = new THREE.MeshStandardMaterial({ map: tex.burlap, color: 0x4c3a2d, roughness: 0.88 });
  const darkIron = new THREE.MeshStandardMaterial({ color: 0x3a3e46, roughness: 0.42, metalness: 0.85 });
  const forgedSteel = new THREE.MeshStandardMaterial({ color: 0x7e838c, roughness: 0.28, metalness: 0.92 });
  const bloodMetal = new THREE.MeshStandardMaterial({ color: 0x6e1310, roughness: 0.58, metalness: 0.5 });
  const emberGlow = new THREE.MeshBasicMaterial({ color: 0xff4514 });
  const darkSocket = new THREE.MeshBasicMaterial({ color: 0x040202 });
  const eyeCrimson = new THREE.MeshBasicMaterial({ color: 0xff1e10 });
  const woodHaft = new THREE.MeshStandardMaterial({ color: 0x362214, roughness: 0.86 });

  // Heavy articulated legs with iron shin guards & buckled boots
  const buildLeg = (sx: number): THREE.Group => {
    const leg = pivot(sx * 0.18, 0.96, 0);
    leg.add(mk(new THREE.CylinderGeometry(0.145, 0.125, 0.92, 10), pantsMat, 0, -0.46, 0));
    const shinPlate = mk(new THREE.BoxGeometry(0.22, 0.38, 0.18), darkIron, 0, -0.62, 0.05);
    leg.add(shinPlate);
    leg.add(mk(new THREE.BoxGeometry(0.25, 0.04, 0.2), forgedSteel, 0, -0.45, 0.05));
    const boot = mk(new THREE.BoxGeometry(0.28, 0.2, 0.44), new THREE.MeshStandardMaterial({ color: 0x120e0b, roughness: 0.82 }), 0, -0.88, 0.07);
    leg.add(boot);
    leg.add(mk(new THREE.BoxGeometry(0.26, 0.1, 0.14), darkIron, 0, -0.87, 0.24));
    return leg;
  };
  const legL = buildLeg(-1);
  const legR = buildLeg(1);
  g.add(legL, legR);

  // Muscular hunched torso wrapped in tattered executioner coat + bloody leather apron
  const torso = new THREE.Group();
  torso.position.set(0, 1.38, 0.03);
  torso.rotation.x = 0.11;
  torso.add(mk(new THREE.BoxGeometry(0.76, 0.9, 0.42), coatMat, 0, 0, 0));
  // Tattered coat tails hanging past waist
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    const flap = mk(new THREE.BoxGeometry(0.22, 0.48, 0.04), coatMat, Math.sin(angle) * 0.34, -0.58, Math.cos(angle) * 0.2);
    flap.rotation.y = angle;
    flap.rotation.x = -0.14;
    torso.add(flap);
  }
  // Blood-drenched apron
  torso.add(
    mk(
      new THREE.BoxGeometry(0.62, 0.92, 0.03),
      new THREE.MeshStandardMaterial({ map: tex.apron, roughness: 0.68 }),
      0,
      -0.06,
      0.22
    )
  );
  // Broad hunched mantle + spiked iron shoulder pauldrons
  const mantle = mk(new THREE.CylinderGeometry(0.42, 0.5, 0.26, 12), coatMat, 0, 0.36, 0);
  torso.add(mantle);
  [-1, 1].forEach((sx) => {
    const pauldron = mk(new THREE.SphereGeometry(0.22, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.6), darkIron, sx * 0.46, 0.42, 0);
    pauldron.rotation.z = -sx * 0.35;
    torso.add(pauldron);
    const pSpike = mk(new THREE.ConeGeometry(0.035, 0.18, 6), forgedSteel, sx * 0.56, 0.55, 0);
    pSpike.rotation.z = -sx * 0.55;
    torso.add(pSpike);
  });

  // Heavy belt + dangling meat hook + iron chain harness
  torso.add(mk(new THREE.BoxGeometry(0.8, 0.11, 0.46), woodHaft, 0, -0.34, 0));
  torso.add(mk(new THREE.BoxGeometry(0.16, 0.13, 0.06), forgedSteel, 0, -0.34, 0.23));
  for (let k = 0; k < 14; k++) {
    const u = k / 13;
    const link = mk(
      new THREE.TorusGeometry(0.034, 0.01, 5, 8),
      forgedSteel,
      -0.31 + 0.62 * u,
      0.4 - 0.72 * u,
      0.245
    );
    link.rotation.y = k % 2 ? 0 : 1.57;
    link.rotation.z = -0.88;
    torso.add(link);
  }
  // Spiked iron executioner collar
  const collar = mk(new THREE.TorusGeometry(0.21, 0.04, 8, 16), darkIron, 0, 0.48, 0);
  collar.rotation.x = Math.PI / 2;
  torso.add(collar);
  g.add(torso);

  // Terrifying Hooded Executioner Skull + Riveted Iron Half-Mask + Crimson Eyes
  const head = pivot(0, 1.9, 0.09);
  const cranium = mk(new THREE.SphereGeometry(0.245, 18, 14), skinMat, 0, 0.13, 0);
  cranium.scale.set(0.95, 1.2, 1.05);
  head.add(cranium);

  // Tattered pointed executioner cowl/hood draped over crown & back
  const hoodBack = mk(new THREE.CylinderGeometry(0.22, 0.29, 0.38, 12, 1, false, Math.PI * 0.18, Math.PI * 1.64), maskLeather, 0, 0.15, -0.04);
  hoodBack.rotation.y = Math.PI;
  head.add(hoodBack);
  const hoodPeak = mk(new THREE.ConeGeometry(0.18, 0.34, 8), maskLeather, 0, 0.38, -0.1);
  hoodPeak.rotation.x = -0.68;
  head.add(hoodPeak);

  // Forged iron brow-guard & riveted jaw cage
  const browBar = mk(new THREE.BoxGeometry(0.38, 0.065, 0.12), darkIron, 0, 0.22, 0.19);
  browBar.rotation.x = 0.15;
  head.add(browBar);
  const jawPlate = mk(new THREE.CylinderGeometry(0.19, 0.16, 0.19, 10, 1, false, -0.9, 1.8), darkIron, 0, 0.0, 0.06);
  head.add(jawPlate);

  // Vertical iron grille teeth bars across lower mask
  for (let i = -3; i <= 3; i++) {
    const bar = mk(new THREE.BoxGeometry(0.018, 0.14, 0.025), forgedSteel, i * 0.042, 0.02, 0.235);
    head.add(bar);
  }
  // Sunken dark eye sockets + piercing glowing crimson eyes
  [-1, 1].forEach((s) => {
    const socket = mk(new THREE.SphereGeometry(0.056, 10, 8), darkSocket, s * 0.088, 0.145, 0.215);
    socket.scale.set(1.15, 0.88, 0.55);
    head.add(socket);
    head.add(mk(new THREE.SphereGeometry(0.018, 8, 8), eyeCrimson, s * 0.088, 0.145, 0.242));
  });
  // Forehead iron crown spikes
  [-0.09, 0, 0.09].forEach((ox) => {
    const n = mk(new THREE.ConeGeometry(0.016, 0.075, 5), forgedSteel, ox, 0.28, 0.21);
    n.rotation.x = 0.5;
    head.add(n);
  });
  g.add(head);

  // Heavy Butcher Arms + Leather Bracers
  const buildArm = (sx: number): THREE.Group => {
    const arm = pivot(sx * 0.49, 1.78, 0.04);
    arm.add(mk(new THREE.CylinderGeometry(0.11, 0.095, 0.78, 10), coatMat, 0, -0.38, 0));
    arm.add(mk(new THREE.CylinderGeometry(0.105, 0.1, 0.28, 10), darkIron, 0, -0.62, 0));
    arm.add(mk(new THREE.SphereGeometry(0.105, 8, 8), skinMat, 0, -0.84, 0));
    return arm;
  };
  const armL = buildArm(-1);
  const armR = buildArm(1);
  g.add(armL);

  // Forged Ember-Cracked War Sledgehammer
  const hm = pivot(0, -0.84, 0.04);
  hm.rotation.x = 2.2;
  hm.add(mk(new THREE.CylinderGeometry(0.044, 0.038, 1.78, 10), woodHaft, 0, 0.68, 0));
  for (let r = 0; r < 6; r++) {
    const rg = mk(new THREE.TorusGeometry(0.048, 0.009, 5, 10), darkIron, 0, 0.08 + r * 0.13, 0);
    rg.rotation.x = Math.PI / 2;
    hm.add(rg);
  }
  // Core sledge block + bevelled strike faces + ember forge seams + blood
  hm.add(mk(new THREE.BoxGeometry(0.68, 0.42, 0.42), darkIron, 0, 1.58, 0));
  hm.add(mk(new THREE.BoxGeometry(0.76, 0.34, 0.34), forgedSteel, 0, 1.58, 0));
  hm.add(mk(new THREE.BoxGeometry(0.54, 0.44, 0.45), bloodMetal, 0, 1.48, 0));
  // Glowing hot forge fissure strips
  hm.add(mk(new THREE.BoxGeometry(0.7, 0.035, 0.44), emberGlow, 0, 1.62, 0));
  hm.add(mk(new THREE.BoxGeometry(0.04, 0.36, 0.44), emberGlow, 0.14, 1.58, 0));

  for (let d = 0; d < 6; d++) {
    hm.add(mk(new THREE.BoxGeometry(0.032, rand(0.14, 0.32), 0.025), bloodMetal, rand(-0.26, 0.26), 1.34, 0.22));
  }
  const sg = new THREE.ConeGeometry(0.058, 0.25, 6);
  const sp = (x: number, y: number, z: number, rx: number, rz: number, m: THREE.Material) => {
    const s = mk(sg, m, x, y, z);
    s.rotation.x = rx;
    s.rotation.z = rz;
    hm.add(s);
  };
  [-1, 1].forEach((sx) => {
    [-1, 1].forEach((sy) => {
      [-1, 1].forEach((sz) => {
        sp(sx * 0.46, 1.58 + sy * 0.1, sz * 0.1, 0, sx > 0 ? -Math.PI / 2 : Math.PI / 2, sy + sz > 0 ? forgedSteel : bloodMetal);
        sp(sz * 0.18, 1.58 + sy * 0.1, sx * 0.33, sx > 0 ? Math.PI / 2 : -Math.PI / 2, 0, sy + sz > 0 ? bloodMetal : forgedSteel);
      });
    });
  });
  sp(0, 1.9, 0, 0, 0, forgedSteel);
  sp(0, 1.24, 0, 0, Math.PI, bloodMetal);
  // Dangling chain from hammer pommel
  for (let c = 0; c < 4; c++) {
    const cl = mk(new THREE.TorusGeometry(0.035, 0.009, 5, 8), forgedSteel, 0, -0.22 - c * 0.055, 0);
    cl.rotation.y = c % 2 ? 0 : 1.57;
    hm.add(cl);
  }
  armR.add(hm);
  g.add(armR);

  return { group: g, legL, legR, armL, armR, head };
}

export function createGiantRig(tex: GameTextures): GiantRig {
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ map: tex.giantSkin, roughness: 0.86 });
  const boneMat = new THREE.MeshStandardMaterial({ color: 0xc9bfa0, roughness: 0.55 });
  const armorIron = new THREE.MeshStandardMaterial({ color: 0x34363c, roughness: 0.48, metalness: 0.82 });
  const cloth = new THREE.MeshStandardMaterial({ map: tex.cloth, roughness: 0.92 });
  const eye = new THREE.MeshBasicMaterial({ color: 0xffd83a });
  const socketDark = new THREE.MeshBasicMaterial({ color: 0x050202 });
  const chainMat = new THREE.MeshStandardMaterial({
    color: 0x6f737d,
    roughness: 0.32,
    metalness: 0.88,
  });

  // Pillar legs with ankle shackles
  const legL = pivot(-0.68, 2.4, 0);
  legL.add(mk(new THREE.CylinderGeometry(0.5, 0.44, 2.38, 10), skin, 0, -1.2, 0));
  const ankleL = mk(new THREE.TorusGeometry(0.52, 0.09, 6, 14), armorIron, 0, -2.05, 0);
  ankleL.rotation.x = Math.PI / 2;
  legL.add(ankleL);
  g.add(legL);

  const legR = pivot(0.68, 2.4, 0);
  legR.add(mk(new THREE.CylinderGeometry(0.5, 0.44, 2.38, 10), skin, 0, -1.2, 0));
  const ankleR = mk(new THREE.TorusGeometry(0.52, 0.09, 6, 14), armorIron, 0, -2.05, 0);
  ankleR.rotation.x = Math.PI / 2;
  legR.add(ankleR);
  g.add(legR);

  // Massive hunched crypt brute torso with protruding spine & rib scars
  const body = pivot(0, 2.4, 0);
  body.rotation.x = 0.16;
  body.add(mk(new THREE.BoxGeometry(2.52, 2.38, 1.54), skin, 0, 1.2, 0));
  body.add(mk(new THREE.BoxGeometry(2.62, 0.95, 1.62), cloth, 0, 0.12, 0));
  // Protruding jagged bone-armored shoulder hump
  body.add(mk(new THREE.BoxGeometry(3.0, 0.72, 1.58), armorIron, 0, 2.38, -0.05));
  [-1, 1].forEach((sx) => {
    const humpSpike = mk(new THREE.ConeGeometry(0.18, 0.65, 6), boneMat, sx * 1.15, 2.88, -0.08);
    humpSpike.rotation.z = -sx * 0.32;
    body.add(humpSpike);
  });
  // Protruding dorsal spine vertebrae along back
  for (let v = 0; v < 6; v++) {
    const sp = mk(new THREE.ConeGeometry(0.12, 0.36, 5), boneMat, 0, 0.4 + v * 0.42, -0.84);
    sp.rotation.x = -Math.PI / 2;
    body.add(sp);
  }
  // Ribcage scars across chest
  const scar = new THREE.MeshBasicMaterial({ color: 0x3b0707 });
  for (let w = 0; w < 5; w++) {
    const sc = mk(new THREE.BoxGeometry(0.98, 0.048, 0.03), scar, rand(-0.45, 0.45), 0.55 + w * 0.36, 0.79);
    sc.rotation.z = rand(-0.35, 0.35);
    body.add(sc);
  }
  // Iron neck shackle
  const neckShackle = mk(new THREE.TorusGeometry(0.85, 0.1, 8, 16), armorIron, 0, 2.74, 0.15);
  neckShackle.rotation.x = Math.PI / 2;
  body.add(neckShackle);

  // Horned Skull Head with Iron Jaw Vise & Amber Eyes
  const head = pivot(0, 2.94, 0.48);
  const skull = mk(new THREE.SphereGeometry(0.8, 16, 12), skin, 0, 0.25, 0.05);
  skull.scale.set(0.95, 1.08, 1.05);
  head.add(skull);
  [-1, 1].forEach((s) => {
    // Deep socket + blazing sulfur eye
    head.add(mk(new THREE.SphereGeometry(0.17, 10, 8), socketDark, s * 0.3, 0.4, 0.68));
    head.add(mk(new THREE.SphereGeometry(0.1, 8, 8), eye, s * 0.3, 0.4, 0.77));
    // Curved upward demon-skull horns
    const horn = mk(new THREE.ConeGeometry(0.16, 0.88, 7), boneMat, s * 0.52, 0.92, 0.02);
    horn.rotation.z = -s * 0.48;
    horn.rotation.x = 0.22;
    head.add(horn);
    // Heavy brow ridge
    const br = mk(new THREE.BoxGeometry(0.52, 0.15, 0.32), armorIron, s * 0.3, 0.58, 0.62);
    br.rotation.z = -s * 0.22;
    head.add(br);
    // Lower tusks
    const t = mk(new THREE.ConeGeometry(0.1, 0.52, 8), boneMat, s * 0.32, -0.18, 0.8);
    t.rotation.x = Math.PI + 0.48;
    head.add(t);
  });
  // Iron jaw muzzle & fangs
  head.add(mk(new THREE.BoxGeometry(0.76, 0.16, 0.14), new THREE.MeshBasicMaterial({ color: 0x200404 }), 0, -0.1, 0.78));
  for (let q = 0; q < 8; q++) {
    head.add(mk(new THREE.BoxGeometry(0.06, 0.12, 0.05), boneMat, -0.26 + q * 0.075, -0.1, 0.82));
  }
  body.add(head);

  // Massive Chained Brute Arms
  const buildGiantArm = (sx: number): THREE.Group => {
    const arm = pivot(sx * 1.68, 2.1, 0);
    arm.add(mk(new THREE.CylinderGeometry(0.4, 0.36, 3.35, 10), skin, 0, -1.68, 0));
    arm.add(mk(new THREE.SphereGeometry(0.6, 10, 8), armorIron, 0, -3.48, 0));
    for (let s = 0; s < 4; s++) {
      const sp = mk(new THREE.ConeGeometry(0.09, 0.32, 5), boneMat, sx * 0.44, -1.2 - s * 0.55, 0.15);
      sp.rotation.z = -sx * Math.PI / 2;
      arm.add(sp);
    }
    const sh = mk(new THREE.TorusGeometry(0.48, 0.075, 6, 14), chainMat, 0, -2.95, 0);
    sh.rotation.x = Math.PI / 2;
    arm.add(sh);
    return arm;
  };
  const armL = buildGiantArm(-1);
  const armR = buildGiantArm(1);
  body.add(armL, armR);

  g.add(body);
  return { group: g, legL, legR, body, head, armL, armR };
}

export function createBearTrapMesh(): {
  mesh: THREE.Group;
  jawL: THREE.Mesh;
  jawR: THREE.Mesh;
} {
  const g = new THREE.Group();
  const iron = new THREE.MeshStandardMaterial({
    color: 0x3b3532,
    roughness: 0.55,
    metalness: 0.75,
  });
  const rust = new THREE.MeshStandardMaterial({
    color: 0x612218,
    roughness: 0.75,
    metalness: 0.45,
  });
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.03, 12), rust);
  plate.position.y = 0.015;
  g.add(plate);

  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.025, 6, 18), iron);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.02;
  g.add(ring);

  const jawGeo = new THREE.TorusGeometry(0.3, 0.03, 6, 14, Math.PI);
  const jawL = new THREE.Mesh(jawGeo, iron);
  jawL.rotation.x = Math.PI / 2;
  jawL.position.y = 0.035;
  g.add(jawL);

  const jawR = new THREE.Mesh(jawGeo, iron);
  jawR.rotation.x = Math.PI / 2;
  jawR.rotation.z = Math.PI;
  jawR.position.y = 0.035;
  g.add(jawR);

  // Subtle metallic glint teeth
  const toothGeo = new THREE.ConeGeometry(0.016, 0.05, 4);
  for (let i = 0; i < 6; i++) {
    const a = (i / 5) * Math.PI;
    const t = new THREE.Mesh(toothGeo, rust);
    t.position.set(Math.cos(a) * 0.28, 0.055, Math.sin(a) * 0.28);
    g.add(t);
  }

  return { mesh: g, jawL, jawR };
}
