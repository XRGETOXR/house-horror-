import express from 'express';
import fs from 'fs';
import http from 'http';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocket, WebSocketServer } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type DifficultyKey = 'practice' | 'easy' | 'med' | 'hard' | 'nightmare';

interface PeerState {
  id: string;
  name: string;
  colorIndex: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  fl: 0 | 1;
  crouch: boolean;
  torch: boolean;
  hiddenIdx: number;
  heldItem: string | null;
  alive: boolean;
  escaped: boolean;
  day: number;
  speed: number;
}

interface RoomWorldState {
  roundId: number;
  diff: DifficultyKey;
  safeCode: number;
  keySeed: number;
  giantRoll: number;
  searchedSpots: number[];
  plankBroken: boolean;
  wireCut: boolean;
  panelOpened: boolean;
  safeOpen: boolean;
  doorOpen: boolean;
  takenTorches: number[];
}

interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  colorIndex: number;
  text: string;
  ts: number;
  system?: boolean;
}

interface RoomRecord {
  code: string;
  serverName: string;
  hostId: string;
  phase: 'lobby' | 'playing';
  diff: DifficultyKey;
  world: RoomWorldState;
  peers: Map<string, { ws: WebSocket; state: PeerState }>;
  messages: ChatMessage[];
  createdAt: number;
}

const rooms = new Map<string, RoomRecord>();
let idCounter = 1;
let msgCounter = 1;

function makeRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 4; i++) {
    out += chars[(Math.random() * chars.length) | 0];
  }
  return rooms.has(out) ? makeRoomCode() : out;
}

function cleanName(raw: unknown): string {
  const s = String(raw || '')
    .replace(/[^\p{L}\p{N} _-]/gu, '')
    .trim()
    .slice(0, 14);
  return s || 'لاعب';
}

function cleanServerName(raw: unknown, hostName: string): string {
  const s = String(raw || '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .trim()
    .slice(0, 26);
  return s || `سيرفر ${hostName}`;
}

function createInitialWorld(diff: DifficultyKey): RoomWorldState {
  return {
    roundId: Date.now() + ((Math.random() * 1000) | 0),
    diff,
    safeCode: 100 + ((Math.random() * 900) | 0),
    keySeed: (Math.random() * 0xffffffff) >>> 0,
    giantRoll: Math.random(),
    searchedSpots: [],
    plankBroken: false,
    wireCut: false,
    panelOpened: false,
    safeOpen: false,
    doorOpen: false,
    takenTorches: [],
  };
}

function cleanChatText(raw: unknown): string {
  return String(raw || '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .trim()
    .slice(0, 160);
}

function pushRoomMessage(room: RoomRecord, msg: ChatMessage): void {
  room.messages.push(msg);
  if (room.messages.length > 60) {
    room.messages.splice(0, room.messages.length - 60);
  }
}

function roomHostName(room: RoomRecord): string {
  return room.peers.get(room.hostId)?.state.name || 'المضيف';
}

function roomSnapshot(room: RoomRecord) {
  return {
    code: room.code,
    serverName: room.serverName,
    hostName: roomHostName(room),
    hostId: room.hostId,
    phase: room.phase,
    diff: room.diff,
    world: room.world,
    peers: Array.from(room.peers.values()).map((p) => p.state),
    messages: room.messages,
  };
}

function publicRoomSummaries() {
  return Array.from(rooms.values())
    .filter((r) => r.peers.size > 0)
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((r) => ({
      code: r.code,
      serverName: r.serverName,
      hostName: roomHostName(r),
      diff: r.diff,
      phase: r.phase,
      playerCount: r.peers.size,
      maxPlayers: 4,
      createdAt: r.createdAt,
    }));
}

function sendJson(ws: WebSocket, payload: unknown): void {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcast(room: RoomRecord, payload: unknown, exceptId?: string): void {
  const raw = JSON.stringify(payload);
  room.peers.forEach((p, pid) => {
    if (pid !== exceptId && p.ws.readyState === WebSocket.OPEN) {
      p.ws.send(raw);
    }
  });
}

async function startServer(): Promise<void> {
  const app = express();
  const server = http.createServer(app);

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, rooms: rooms.size });
  });

  app.get('/api/rooms', (_req, res) => {
    res.json({ rooms: publicRoomSummaries() });
  });

  app.get('/api/lan-info', (_req, res) => {
    const nets = os.networkInterfaces();
    const addresses: string[] = [];
    for (const name of Object.keys(nets)) {
      const list = nets[name] || [];
      for (const iface of list) {
        if (iface.family === 'IPv4' && !iface.internal) {
          addresses.push(iface.address);
        }
      }
    }
    const port = Number(process.env.PORT || 3000);
    res.json({
      port,
      addresses,
      urls: addresses.map((ip) => `http://${ip}:${port}`),
    });
  });

  app.get('/api/download-offline', async (_req, res) => {
    try {
      const offlineFile = path.resolve(__dirname, 'dist', 'HammerHouse-Game.html');
      if (process.env.NODE_ENV !== 'production' || !fs.existsSync(offlineFile)) {
        const { build } = await import('vite');
        await build({ logLevel: 'silent' });
      }
      if (!fs.existsSync(offlineFile)) {
        res.status(500).json({ error: 'Offline bundle not generated' });
        return;
      }
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="HammerHouse-Game.html"');
      res.sendFile(offlineFile);
    } catch (err) {
      console.error('Failed to build offline HTML:', err);
      res.status(500).json({ error: 'تعذر تجهيز ملف اللعبة' });
    }
  });

  const wss = new WebSocketServer({ server, path: '/ws' });

  const broadcastRoomsList = () => {
    const payload = JSON.stringify({ type: 'rooms:list', rooms: publicRoomSummaries() });
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(payload);
      }
    });
  };

  wss.on('connection', (ws) => {
    const clientId = `p_${idCounter++}_${((Math.random() * 9999) | 0).toString(36)}`;
    let currentRoomCode: string | null = null;

    sendJson(ws, { type: 'rooms:list', rooms: publicRoomSummaries() });

    const leaveCurrentRoom = () => {
      if (!currentRoomCode) return;
      const room = rooms.get(currentRoomCode);
      currentRoomCode = null;
      if (!room) return;
      const leavingPeer = room.peers.get(clientId);
      room.peers.delete(clientId);
      if (room.peers.size === 0) {
        rooms.delete(room.code);
        broadcastRoomsList();
        return;
      }
      if (room.hostId === clientId) {
        const nextHost = room.peers.keys().next().value;
        if (nextHost) room.hostId = nextHost;
      }
      if (leavingPeer) {
        const sysMsg: ChatMessage = {
          id: `sys_${msgCounter++}_${Date.now()}`,
          senderId: 'system',
          senderName: 'النظام',
          colorIndex: 0,
          text: `غادر ${leavingPeer.state.name} السيرفر`,
          ts: Date.now(),
          system: true,
        };
        pushRoomMessage(room, sysMsg);
        broadcast(room, { type: 'chat:message', message: sysMsg });
      }
      broadcast(room, { type: 'room:update', room: roomSnapshot(room) });
      broadcastRoomsList();
    };

    ws.on('message', (buf) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(buf.toString()) as Record<string, unknown>;
      } catch {
        return;
      }

      const type = String(msg.type || '');

      if (type === 'rooms:list') {
        sendJson(ws, { type: 'rooms:list', rooms: publicRoomSummaries() });
        return;
      }

      if (type === 'room:create') {
        leaveCurrentRoom();
        const code = makeRoomCode();
        const diff = (['practice', 'easy', 'med', 'hard', 'nightmare'].includes(String(msg.diff))
          ? String(msg.diff)
          : 'med') as DifficultyKey;
        const hostName = cleanName(msg.name);
        const room: RoomRecord = {
          code,
          serverName: cleanServerName(msg.serverName, hostName),
          hostId: clientId,
          phase: 'lobby',
          diff,
          world: createInitialWorld(diff),
          peers: new Map(),
          messages: [],
          createdAt: Date.now(),
        };
        const peerState: PeerState = {
          id: clientId,
          name: hostName,
          colorIndex: 0,
          x: 4.8,
          y: 0,
          z: 3.8,
          yaw: -Math.PI / 2,
          fl: 0,
          crouch: false,
          torch: false,
          hiddenIdx: -1,
          heldItem: null,
          alive: true,
          escaped: false,
          day: 1,
          speed: 0,
        };
        room.peers.set(clientId, { ws, state: peerState });
        rooms.set(code, room);
        currentRoomCode = code;
        sendJson(ws, { type: 'room:joined', selfId: clientId, room: roomSnapshot(room) });
        broadcastRoomsList();
        return;
      }

      if (type === 'room:join') {
        const code = String(msg.code || '')
          .trim()
          .toUpperCase();
        const room = rooms.get(code);
        if (!room) {
          sendJson(ws, { type: 'room:error', message: 'السيرفر لم يعد متاحاً' });
          broadcastRoomsList();
          return;
        }
        if (room.peers.size >= 4) {
          sendJson(ws, { type: 'room:error', message: 'السيرفر ممتلئ (الحد الأقصى ٤ لاعبين)' });
          return;
        }
        leaveCurrentRoom();
        const usedColors = new Set(Array.from(room.peers.values()).map((p) => p.state.colorIndex));
        let colorIndex = 0;
        while (usedColors.has(colorIndex) && colorIndex < 4) colorIndex++;

        const peerState: PeerState = {
          id: clientId,
          name: cleanName(msg.name),
          colorIndex: colorIndex % 4,
          x: 4.8,
          y: 0,
          z: 3.8,
          yaw: -Math.PI / 2,
          fl: 0,
          crouch: false,
          torch: false,
          hiddenIdx: -1,
          heldItem: null,
          alive: true,
          escaped: false,
          day: 1,
          speed: 0,
        };
        room.peers.set(clientId, { ws, state: peerState });
        currentRoomCode = code;
        const joinMsg: ChatMessage = {
          id: `sys_${msgCounter++}_${Date.now()}`,
          senderId: 'system',
          senderName: 'النظام',
          colorIndex: peerState.colorIndex,
          text: `انضم ${peerState.name} إلى السيرفر`,
          ts: Date.now(),
          system: true,
        };
        pushRoomMessage(room, joinMsg);
        sendJson(ws, { type: 'room:joined', selfId: clientId, room: roomSnapshot(room) });
        broadcast(room, { type: 'chat:message', message: joinMsg }, clientId);
        broadcast(room, { type: 'room:update', room: roomSnapshot(room) }, clientId);
        broadcastRoomsList();
        return;
      }

      if (type === 'room:leave') {
        leaveCurrentRoom();
        sendJson(ws, { type: 'room:left' });
        return;
      }

      if (!currentRoomCode) return;
      const room = rooms.get(currentRoomCode);
      if (!room) return;

      if (type === 'room:diff' && room.hostId === clientId) {
        const diff = (['practice', 'easy', 'med', 'hard', 'nightmare'].includes(String(msg.diff))
          ? String(msg.diff)
          : room.diff) as DifficultyKey;
        room.diff = diff;
        broadcast(room, { type: 'room:update', room: roomSnapshot(room) });
        broadcastRoomsList();
        return;
      }

      if (type === 'game:start' && room.hostId === clientId) {
        const diff = (['practice', 'easy', 'med', 'hard', 'nightmare'].includes(String(msg.diff))
          ? String(msg.diff)
          : room.diff) as DifficultyKey;
        room.diff = diff;
        room.phase = 'playing';
        room.world = createInitialWorld(diff);
        room.peers.forEach((p) => {
          p.state.alive = true;
          p.state.escaped = false;
          p.state.day = 1;
          p.state.hiddenIdx = -1;
          p.state.heldItem = null;
          p.state.torch = false;
          p.state.x = 4.8;
          p.state.z = 3.8;
          p.state.fl = 0;
        });
        broadcast(room, { type: 'game:started', room: roomSnapshot(room) });
        broadcastRoomsList();
        return;
      }

      if (type === 'player:state') {
        const peer = room.peers.get(clientId);
        if (!peer) return;
        const st = peer.state;
        if (typeof msg.x === 'number') st.x = msg.x;
        if (typeof msg.y === 'number') st.y = msg.y;
        if (typeof msg.z === 'number') st.z = msg.z;
        if (typeof msg.yaw === 'number') st.yaw = msg.yaw;
        if (msg.fl === 0 || msg.fl === 1) st.fl = msg.fl;
        if (typeof msg.crouch === 'boolean') st.crouch = msg.crouch;
        if (typeof msg.torch === 'boolean') st.torch = msg.torch;
        if (typeof msg.hiddenIdx === 'number') st.hiddenIdx = msg.hiddenIdx;
        if (msg.heldItem === null || typeof msg.heldItem === 'string') st.heldItem = msg.heldItem;
        if (typeof msg.alive === 'boolean') st.alive = msg.alive;
        if (typeof msg.escaped === 'boolean') st.escaped = msg.escaped;
        if (typeof msg.day === 'number') st.day = msg.day;
        if (typeof msg.speed === 'number') st.speed = msg.speed;

        broadcast(room, { type: 'peer:state', peer: st }, clientId);
        return;
      }

      if (type === 'monsters:state' && room.hostId === clientId) {
        broadcast(room, { type: 'monsters:state', data: msg.data }, clientId);
        return;
      }

      if (type === 'world:event') {
        const ev = msg.event as Record<string, unknown> | undefined;
        if (!ev) return;
        const kind = String(ev.kind || '');
        if (kind === 'spot' && typeof ev.index === 'number') {
          if (!room.world.searchedSpots.includes(ev.index)) {
            room.world.searchedSpots.push(ev.index);
          }
        } else if (kind === 'lock') {
          if (ev.lock === 'plankBroken') room.world.plankBroken = true;
          if (ev.lock === 'wireCut') room.world.wireCut = true;
          if (ev.lock === 'panelOpened') room.world.panelOpened = true;
        } else if (kind === 'safe') {
          room.world.safeOpen = true;
        } else if (kind === 'door') {
          room.world.doorOpen = true;
        } else if (kind === 'torchPickup' && typeof ev.index === 'number') {
          if (!room.world.takenTorches.includes(ev.index)) {
            room.world.takenTorches.push(ev.index);
          }
        } else if (kind === 'revive' && typeof ev.targetId === 'string') {
          const revived = room.peers.get(ev.targetId);
          if (revived) revived.state.alive = true;
        }
        broadcast(room, { type: 'world:event', fromId: clientId, event: ev, world: room.world }, clientId);
        return;
      }

      if (type === 'chat:send') {
        const peer = room.peers.get(clientId);
        if (!peer) return;
        const text = cleanChatText(msg.text);
        if (!text) return;
        const chatMsg: ChatMessage = {
          id: `m_${msgCounter++}_${Date.now()}`,
          senderId: clientId,
          senderName: peer.state.name,
          colorIndex: peer.state.colorIndex,
          text,
          ts: Date.now(),
        };
        pushRoomMessage(room, chatMsg);
        broadcast(room, { type: 'chat:message', message: chatMsg });
      }
    });

    ws.on('close', () => {
      leaveCurrentRoom();
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  server.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

void startServer();
