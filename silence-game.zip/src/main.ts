import { Game } from './game/game';

const app = document.getElementById('app');
if (app) {
  const game = new Game(app);
  void game.boot();
}
