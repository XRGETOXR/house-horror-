import type { LanNet } from '../game/net';

// LAN panel (plain DOM). Host: makes one invite code per guest and accepts each reply code.
// Guest: pastes the invite code and returns a reply code to the host.

function el<K extends keyof HTMLElementTagNameMap>(tag: K, cls?: string, text?: string): HTMLElementTagNameMap[K] {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text) e.textContent = text;
  return e;
}

function copyBox(box: HTMLTextAreaElement): void {
  box.select();
  try {
    void navigator.clipboard?.writeText(box.value);
  } catch {
    // The text stays selected for a manual copy.
  }
}

export function mountLanPanel(root: HTMLElement, net: LanNet, getName: () => string): void {
  root.innerHTML = '';
  const title = el('h2', 'lan-title', 'الشبكة المحلية (LAN)');
  const hint = el(
    'p',
    'lan-hint',
    'المضيف يفعّل نقطة الاتصال من الهاتف، والضيوف يتصلون بها دون إنترنت. انسخ الرمز وأرسله للطرف الآخر.'
  );
  const status = el('p', 'lan-status', '');
  const previousStatus = net.onStatus;
  const setStatus = (m: string) => {
    status.textContent = m;
    previousStatus?.(m);
  };
  net.onStatus = setStatus;

  // Host side
  const hostBox = el('div', 'lan-box');
  const hostBtn = el('button', 'btn', 'استضافة (دعوة لاعب)');
  const inviteOut = el('textarea', 'lan-code') as HTMLTextAreaElement;
  inviteOut.readOnly = true;
  inviteOut.placeholder = 'رمز الدعوة سيظهر هنا';
  const copyInvite = el('button', 'btn small', 'نسخ الدعوة');
  copyInvite.onclick = () => copyBox(inviteOut);
  const replyIn = el('textarea', 'lan-code') as HTMLTextAreaElement;
  replyIn.placeholder = 'الصق رمز الرد من الضيف هنا';
  const acceptBtn = el('button', 'btn small', 'قبول الضيف');
  acceptBtn.onclick = async () => {
    try {
      await net.acceptAnswer(replyIn.value.trim());
      replyIn.value = '';
      setStatus('تم قبول الضيف. يمكنك دعوة لاعب آخر.');
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'تعذر قبول الرد');
    }
  };
  hostBtn.onclick = async () => {
    try {
      setStatus('جارٍ تجهيز الدعوة...');
      inviteOut.value = await net.host(getName());
      setStatus('أرسل رمز الدعوة للضيف، ثم الصق رده هنا.');
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'تعذر إنشاء الدعوة');
    }
  };
  hostBox.append(hostBtn, inviteOut, copyInvite, replyIn, acceptBtn);

  // Guest side
  const joinBox = el('div', 'lan-box');
  const joinTitle = el('h3', 'lan-sub', 'الانضمام إلى مضيف');
  const inviteIn = el('textarea', 'lan-code') as HTMLTextAreaElement;
  inviteIn.placeholder = 'الصق رمز الدعوة من المضيف';
  const joinBtn = el('button', 'btn small', 'انضمام');
  const replyOut = el('textarea', 'lan-code') as HTMLTextAreaElement;
  replyOut.readOnly = true;
  replyOut.placeholder = 'رمز الرد يظهر هنا';
  const copyReply = el('button', 'btn small', 'نسخ الرد');
  copyReply.onclick = () => copyBox(replyOut);
  joinBtn.onclick = async () => {
    try {
      setStatus('جارٍ الاتصال...');
      replyOut.value = await net.join(inviteIn.value.trim(), getName());
      setStatus('أرسل رمز الرد للمضيف ليكتمل الاتصال.');
    } catch (e) {
      setStatus(e instanceof Error ? e.message : 'تعذر الانضمام');
    }
  };
  joinBox.append(joinTitle, inviteIn, joinBtn, replyOut, copyReply);

  root.append(title, hint, hostBox, joinBox, status);
}
