import * as THREE from 'three';
import { Creature, KILL_DIST, type CreatureNet } from './creature';
import { loadGLTF } from './models';
import { LanNet } from './net';
import { buildWorld, findSpot, type BuiltWorld } from './world';
import { mountLanPanel } from '../ui/lanPanel';

// Game loop, player, torch, creature authority and LAN sync.

const HOST_ID = 'lan_host'; // the LAN transport gives the host this id
const EYE = 1.6;
const WALK = 2.0;
const RUN = 3.3;
const BATTERY_USE = 1 / 90; // a full battery lasts about 90 seconds of torch
const BATTERY_CHARGE = 1 / 60;
const SEND_EVERY = 0.1;
const PEER_TIMEOUT = 4;
const RESPAWN_DELAY = 3;

type RelayMsg =
  | { k: 'p'; n: string; x: number; y: number; z: number; yaw: number }
  | { k: 'c'; x: number; z: number; yaw: number; chase: boolean };

interface Peer {
  root: THREE.Group;
  tx: number;
  ty: number;
  tz: number;
  tyaw: number;
  seen: number;
}

function nameSprite(text: string): THREE.Sprite {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 64;
  const g = c.getContext('2d');
  if (g) {
    g.fillStyle = 'rgba(0,0,0,0.55)';
    g.fillRect(0, 0, 256, 64);
    g.fillStyle = '#e8e8e8';
    g.font = '30px sans-serif';
    g.textAlign = 'center';
    g.fillText(text.slice(0, 14), 128, 43);
  }
  const mat = new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true });
  const s = new THREE.Sprite(mat);
  s.scale.set(0.9, 0.22, 1);
  s.position.y = 2.0;
  return s;
}

function avatarFor(name: string): THREE.Group {
  const g = new THREE.Group();
  let h = 0;
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const color = new THREE.Color().setHSL((h % 360) / 360, 0.5, 0.45);
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.25, 1.0, 4, 10),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.15, roughness: 0.8 })
  );
  body.position.y = 0.95;
  g.add(body);
  g.add(nameSprite(name));
  return g;
}

export class Game {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(70, 1, 0.05, 200);
  private clock = new THREE.Clock();
  private torch: THREE.SpotLight;
  private world: BuiltWorld | null = null;
  private creature: Creature | null = null;
  private torchOn = true;
  private battery = 1;
  private px = 0;
  private py = 0;
  private pz = 0;
  private yaw = 0;
  private pitch = 0;
  private keys = new Set<string>();
  private locked = false;
  private started = false;
  private alive = true;
  private respawnT = 0;
  private deaths = 0;
  private time = 0;
  private sendT = 0;
  private creatureTarget: CreatureNet | null = null;
  private peers = new Map<string, Peer>();
  readonly net = new LanNet();
  name = 'لاعب';

  private menuEl = document.getElementById('menu') as HTMLElement;
  private startBtn = document.getElementById('startBtn') as HTMLButtonElement;
  private nameIn = document.getElementById('nameIn') as HTMLInputElement;
  private lanEl = document.getElementById('lan') as HTMLElement;
  private loadingEl = document.getElementById('loading') as HTMLElement;
  private hudText = document.getElementById('hudText') as HTMLElement;
  private deadEl = document.getElementById('dead') as HTMLElement;
  private netNote = document.getElementById('netNote') as HTMLElement;

  constructor(host: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    host.appendChild(this.renderer.domElement);

    this.scene.background = new THREE.Color(0x030405);
    this.scene.fog = new THREE.FogExp2(0x030405, 0.06);
    this.scene.add(new THREE.HemisphereLight(0x3a4a66, 0x000000, 0.25));
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(400, 400),
      new THREE.MeshStandardMaterial({ color: 0x101112, roughness: 1 })
    );
    ground.rotation.x = -Math.PI / 2;
    this.scene.add(ground);

    // The torch: a spot light fixed to the camera, pointing where the player looks.
    this.torch = new THREE.SpotLight(0xffe7b0, 3, 18, Math.PI / 6, 0.45, 1.5);
    const target = new THREE.Object3D();
    target.position.set(0, 0, -5);
    this.camera.add(target);
    this.torch.target = target;
    this.camera.add(this.torch);
    this.scene.add(this.camera);

    this.bindInput();
    this.net.onRelay = (from, data) => this.onRelay(from, data);
    this.net.onStatus = (m) => {
      this.netNote.textContent = m;
    };
    this.net.onLost = () => {
      this.creatureTarget = null;
      this.clearPeers();
      this.netNote.textContent = 'انقطع اتصال المضيف، اللعب مستمر بشكل فردي';
    };
    mountLanPanel(this.lanEl, this.net, () => this.name);
    this.renderer.setAnimationLoop(() => this.frame());
  }

  async boot(): Promise<void> {
    try {
      this.loadingEl.textContent = 'جارٍ بناء المنزل من النماذج...';
      this.world = await buildWorld(this.scene);
      this.creature = await Creature.create(this.scene);
      await this.addHeldFlashlight();
      this.resetPlayer();
      this.loadingEl.textContent = '';
      this.startBtn.disabled = false;
      this.startBtn.textContent = 'ابدأ اللعب';
    } catch (e) {
      this.loadingEl.textContent = 'تعذر تحميل اللعبة: ' + (e instanceof Error ? e.message : String(e));
    }
  }

  private async addHeldFlashlight(): Promise<void> {
    const gltf = await loadGLTF('flashlight');
    if (!gltf) return;
    const model = gltf.scene.clone(true);
    // The model is about 1 m long along Z. Scaled to about 0.28 m and turned so its +Z end faces forward.
    // Orientation is unverified until it is seen on a device (see FLASHLIGHT_FLIP below).
    model.scale.setScalar(0.28);
    model.rotation.set(0.05, Math.PI * FLASHLIGHT_FLIP, 0);
    model.position.set(0.24, -0.22, -0.42);
    this.camera.add(model);
  }

  private bindInput(): void {
    window.addEventListener('keydown', (e) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      this.keys.add(e.code);
      if (e.code === 'KeyF' && this.alive && this.started) {
        if (this.torchOn) this.torchOn = false;
        else if (this.battery > 0.02) this.torchOn = true;
      }
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());
    const canvas = this.renderer.domElement;
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === canvas;
      if (!this.locked && this.started) this.showPause();
    });
    document.addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      this.yaw -= e.movementX * 0.0022;
      this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch - e.movementY * 0.0022));
    });
    this.startBtn.addEventListener('click', () => this.start());
    this.nameIn.addEventListener('input', () => {
      this.name = this.nameIn.value.trim().slice(0, 14) || 'لاعب';
    });
    window.addEventListener('resize', () => {
      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
    });
  }

  private start(): void {
    if (!this.world) return;
    this.name = this.nameIn.value.trim().slice(0, 14) || 'لاعب';
    this.started = true;
    this.menuEl.hidden = true;
    const hud = document.getElementById('hud');
    if (hud) hud.hidden = false;
    this.renderer.domElement.requestPointerLock();
  }

  private showPause(): void {
    this.menuEl.hidden = false;
    this.startBtn.textContent = 'متابعة';
    this.startBtn.onclick = () => this.renderer.domElement.requestPointerLock();
  }

  private resetPlayer(): void {
    if (!this.world) return;
    const sp = this.world.spawn;
    this.px = sp.x;
    this.py = sp.y;
    this.pz = sp.z;
    this.alive = true;
    this.deadEl.hidden = true;
    if (this.creature && this.authority()) {
      const far = findSpot(this.world.collision, 0, sp, 7);
      if (far) this.creature.place(far);
    }
  }

  private authority(): boolean {
    return !this.net.active || this.net.isHost;
  }

  private die(): void {
    this.alive = false;
    this.deaths++;
    this.respawnT = RESPAWN_DELAY;
    this.deadEl.hidden = false;
  }

  private frame(): void {
    const dt = Math.min(0.05, this.clock.getDelta());
    if (this.world && this.started && this.locked) this.update(dt);
    this.renderer.render(this.scene, this.camera);
  }

  private update(dt: number): void {
    if (!this.world) return;
    this.time += dt;
    if (this.alive) {
      this.movePlayer(dt);
      this.updateTorch(dt);
    } else {
      this.respawnT -= dt;
      if (this.respawnT <= 0) this.resetPlayer();
    }
    this.updateCreature(dt);
    this.checkKill();
    this.camera.position.set(this.px, this.py + EYE, this.pz);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.set(this.pitch, this.yaw, 0);
    this.updatePeers(dt);
    this.sendState(dt);
    this.updateHud();
  }

  private movePlayer(dt: number): void {
    if (!this.world) return;
    let ix = 0;
    let iz = 0;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) ix += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) ix -= 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) iz += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) iz -= 1;
    if (ix === 0 && iz === 0) return;
    const l = Math.hypot(ix, iz);
    ix /= l;
    iz /= l;
    const running = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight');
    const speed = running ? RUN : WALK;
    // Forward is (-sin yaw, -cos yaw) and right is (cos yaw, -sin yaw), matching the camera.
    const dx = ix * Math.cos(this.yaw) + iz * -Math.sin(this.yaw);
    const dz = ix * -Math.sin(this.yaw) + iz * -Math.cos(this.yaw);
    const moved = this.world.collision.move(this.px, this.py, this.pz, dx * speed * dt, dz * speed * dt);
    this.px = moved.x;
    this.py = moved.y;
    this.pz = moved.z;
  }

  private updateTorch(dt: number): void {
    if (this.torchOn) {
      this.battery -= dt * BATTERY_USE;
      if (this.battery <= 0) {
        this.battery = 0;
        this.torchOn = false;
      }
    } else {
      this.battery = Math.min(1, this.battery + dt * BATTERY_CHARGE);
    }
    const flicker = this.battery < 0.15 ? 0.5 + 0.5 * Math.sin(this.time * 37) : 1;
    this.torch.intensity = this.torchOn ? 3 * flicker : 0;
  }

  private updateCreature(dt: number): void {
    if (!this.world || !this.creature) return;
    const cw = this.world.collision;
    const auth = this.authority();
    this.creature.root.visible = auth || this.creatureTarget !== null;
    if (auth) this.creature.update(dt, cw, this.px, this.pz);
    else if (this.creatureTarget) this.creature.follow(dt, cw, this.creatureTarget);
  }

  private checkKill(): void {
    if (!this.creature || !this.alive || !this.creature.root.visible) return;
    const d = Math.hypot(this.creature.x - this.px, this.creature.z - this.pz);
    if (d < KILL_DIST && Math.abs(this.creature.y - this.py) < 1.2) this.die();
  }

  private creatureChasing(): boolean {
    if (this.authority()) return this.creature?.chase ?? false;
    return this.creatureTarget?.chase ?? false;
  }

  private updatePeers(dt: number): void {
    const k = Math.min(1, dt * 10);
    for (const [id, p] of this.peers) {
      if (this.time - p.seen > PEER_TIMEOUT) {
        this.scene.remove(p.root);
        this.peers.delete(id);
        continue;
      }
      p.root.position.x += (p.tx - p.root.position.x) * k;
      p.root.position.y += (p.ty - p.root.position.y) * k;
      p.root.position.z += (p.tz - p.root.position.z) * k;
      let dyaw = p.tyaw - p.root.rotation.y;
      while (dyaw > Math.PI) dyaw -= Math.PI * 2;
      while (dyaw < -Math.PI) dyaw += Math.PI * 2;
      p.root.rotation.y += dyaw * k;
    }
  }

  private clearPeers(): void {
    for (const p of this.peers.values()) this.scene.remove(p.root);
    this.peers.clear();
  }

  private sendState(dt: number): void {
    if (!this.net.active) return;
    this.sendT += dt;
    if (this.sendT < SEND_EVERY) return;
    this.sendT = 0;
    const me: RelayMsg = { k: 'p', n: this.name, x: this.px, y: this.py, z: this.pz, yaw: this.yaw };
    this.net.send(me);
    if (this.net.isHost && this.creature) {
      const c = this.creature.net();
      const msg: RelayMsg = { k: 'c', x: c.x, z: c.z, yaw: c.yaw, chase: c.chase };
      this.net.send(msg);
    }
  }

  private onRelay(from: string, data: unknown): void {
    if (!data || typeof data !== 'object') return;
    const d = data as RelayMsg;
    if (this.net.isHost && from === HOST_ID) return; // our own echo
    if (d.k === 'p') {
      let p = this.peers.get(from);
      if (!p) {
        const root = avatarFor(d.n);
        this.scene.add(root);
        p = { root, tx: d.x, ty: d.y, tz: d.z, tyaw: d.yaw, seen: this.time };
        root.position.set(d.x, d.y, d.z);
        this.peers.set(from, p);
      }
      p.tx = d.x;
      p.ty = d.y;
      p.tz = d.z;
      p.tyaw = d.yaw;
      p.seen = this.time;
    } else if (d.k === 'c' && from === HOST_ID) {
      this.creatureTarget = { x: d.x, z: d.z, yaw: d.yaw, chase: d.chase };
    }
  }

  private updateHud(): void {
    const state = this.creatureChasing() ? 'مطاردة!' : 'هادئ';
    const mode = this.net.active ? `متصلون: ${this.peers.size + 1}` : 'لعب فردي';
    this.hudText.textContent =
      `${state}  |  البطارية ${Math.round(this.battery * 100)}%  |  ${mode}  |  الوفيات ${this.deaths}  |  ${Math.floor(this.time)} ث`;
  }
}

// 1 flips the flashlight so its +Z end points forward; set to 0 if the lens faces the wrong way.
const FLASHLIGHT_FLIP = 1;
