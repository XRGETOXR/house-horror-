import * as THREE from 'three';
import { boundsOf, cloneModel } from './models';
import type { ModelKey } from './modelKeys';
import { CollisionWorld, LEVEL_BASE, type MeshTris } from './collision';

// Builds the playable level: the house itself, its collision, and the props.

export interface Spot {
  x: number;
  y: number;
  z: number;
}

export interface BuiltWorld {
  collision: CollisionWorld;
  house: THREE.Group;
  spawn: Spot;
  props: THREE.Object3D[];
}

const INDOOR_PROPS: ModelKey[] = [
  'chair_on_side',
  'folding_chair',
  'crt_tv',
  'monitor_wall',
  'drawers',
  'side_table',
  'mirror_cracked',
  'tool_rack',
  'bloody_sink',
  'machete',
  'flashlight',
];

const OUTDOOR_PROPS: ModelKey[] = [
  'porch_door',
  'porch_steps',
  'boarded_window',
  'upper_window',
  'mailbox',
  'street_light',
  'dead_tree',
  'gate',
  'van_panel',
  'van_investigation',
  'shed_door',
];

// World-space triangles of every mesh under root, with a path name for classification.
export function extractTris(root: THREE.Object3D): MeshTris[] {
  root.updateMatrixWorld(true);
  const out: MeshTris[] = [];
  const v = new THREE.Vector3();
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh) return;
    const geo = mesh.geometry as THREE.BufferGeometry;
    const posAttr = geo.getAttribute('position');
    if (!posAttr) return;
    const n = posAttr.count;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      v.fromBufferAttribute(posAttr, i).applyMatrix4(mesh.matrixWorld);
      pos[i * 3] = v.x;
      pos[i * 3 + 1] = v.y;
      pos[i * 3 + 2] = v.z;
    }
    let idx: Uint32Array;
    if (geo.index) {
      const ia = geo.index;
      idx = new Uint32Array(ia.count);
      for (let i = 0; i < ia.count; i++) idx[i] = ia.getX(i);
    } else {
      idx = new Uint32Array(n);
      for (let i = 0; i < n; i++) idx[i] = i;
    }
    out.push({ name: pathOf(mesh), pos, idx });
  });
  return out;
}

function pathOf(o: THREE.Object3D): string {
  const parts: string[] = [];
  let cur: THREE.Object3D | null = o;
  while (cur) {
    if (cur.name) parts.unshift(cur.name);
    cur = cur.parent;
  }
  return parts.join('/');
}

export function mergeTris(list: MeshTris[]): MeshTris {
  let vc = 0, ic = 0;
  for (const m of list) {
    vc += m.pos.length;
    ic += m.idx.length;
  }
  const pos = new Float32Array(vc);
  const idx = new Uint32Array(ic);
  let po = 0, io = 0, base = 0;
  for (const m of list) {
    pos.set(m.pos, po);
    for (let i = 0; i < m.idx.length; i++) idx[io + i] = m.idx[i] + base;
    base += m.pos.length / 3;
    po += m.pos.length;
    io += m.idx.length;
  }
  return { name: 'merged', pos, idx };
}

// Places an object so its footprint centre is (x,z) and its lowest point sits at y.
function placeAt(obj: THREE.Object3D, x: number, y: number, z: number, yaw: number): void {
  obj.position.set(0, 0, 0);
  obj.rotation.set(0, yaw, 0);
  obj.updateMatrixWorld(true);
  const b = boundsOf(obj);
  obj.position.set(x - (b.min.x + b.max.x) / 2, y - b.min.y, z - (b.min.z + b.max.z) / 2);
  obj.updateMatrixWorld(true);
}

export async function buildWorld(scene: THREE.Scene): Promise<BuiltWorld> {
  const collision = new CollisionWorld();
  const houseInst = await cloneModel('house');
  if (!houseInst) throw new Error('نموذج المنزل غير موجود');
  scene.add(houseInst.root);
  for (const m of extractTris(houseInst.root)) collision.addMesh(m);

  const props: THREE.Object3D[] = [];
  for (const key of INDOOR_PROPS) {
    const inst = await cloneModel(key);
    if (!inst) continue;
    let placed = false;
    for (let t = 0; t < 400 && !placed; t++) {
      const L = Math.random() < 0.5 ? 0 : 1;
      const base = LEVEL_BASE[L];
      const x = (Math.random() * 2 - 1) * 2.6;
      const z = (Math.random() * 2 - 1) * 2.6;
      if (Math.hypot(x, z) < 1.5) continue;
      const yaw = Math.floor(Math.random() * 4) * (Math.PI / 2);
      placeAt(inst.root, x, base, z, yaw);
      const g = collision.groundAt(x, z, base + 0.5);
      if (g === null || Math.abs(g - base) > 0.05) continue;
      if (!collision.placeProp(mergeTris(extractTris(inst.root)), L)) continue;
      scene.add(inst.root);
      props.push(inst.root);
      placed = true;
    }
  }

  for (const key of OUTDOOR_PROPS) {
    const inst = await cloneModel(key);
    if (!inst) continue;
    const a = Math.random() * Math.PI * 2;
    const r = 7 + Math.random() * 6;
    placeAt(inst.root, Math.cos(a) * r, 0, Math.sin(a) * r, Math.random() * Math.PI * 2);
    scene.add(inst.root);
    props.push(inst.root);
  }

  // The street scene is a backdrop far from the house, not part of the playable area.
  const street = await cloneModel('street');
  if (street) {
    placeAt(street.root, -140, 0, 0, 0);
    scene.add(street.root);
    props.push(street.root);
  }

  const spawnY = collision.groundAt(0, 0, LEVEL_BASE[0]) ?? LEVEL_BASE[0];
  return { collision, house: houseInst.root, spawn: { x: 0, y: spawnY, z: 0 }, props };
}

// A random walkable spot on a storey, at least minDist away from from.
export function findSpot(cw: CollisionWorld, L: number, from: Spot, minDist: number): Spot | null {
  const base = LEVEL_BASE[L];
  for (let t = 0; t < 600; t++) {
    const x = (Math.random() * 2 - 1) * 2.7;
    const z = (Math.random() * 2 - 1) * 2.7;
    if (Math.hypot(x - from.x, z - from.z) < minDist) continue;
    const g = cw.groundAt(x, z, base + 0.5);
    if (g === null || Math.abs(g - base) > 0.05) continue;
    if (cw.blocked(x, z, g)) continue;
    return { x, y: g, z };
  }
  return null;
}
