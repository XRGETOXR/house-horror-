import * as THREE from 'three';
import { cloneModel } from './models';
import { CollisionWorld, LEVEL_BASE } from './collision';
import type { Spot } from './world';

// The creature: the uploaded "creature-infected-bloated" model.
// Its forward is +Z (the eyes sit on the +Z side), which matches the yaw convention used here.

const ROAM_SPEED = 0.8;
const CHASE_SPEED = 1.9;
const SIGHT = 9; // starts chasing inside this distance
const LOSE = 14; // gives up beyond this distance
export const KILL_DIST = 0.85;

export interface CreatureNet {
  x: number;
  z: number;
  yaw: number;
  chase: boolean;
}

export class Creature {
  readonly root: THREE.Group;
  private mixer: THREE.AnimationMixer | null = null;
  private action: THREE.AnimationAction | null = null;
  x = 0;
  y = LEVEL_BASE[0];
  z = 0;
  yaw = 0;
  chase = false;
  private wanderX = 0;
  private wanderZ = 0;
  private wanderT = 0;
  private stuckT = 0;
  private lostT = 0;

  private constructor(root: THREE.Group) {
    this.root = root;
  }

  static async create(scene: THREE.Scene): Promise<Creature | null> {
    const inst = await cloneModel('monster_bloated');
    if (!inst) return null;
    const c = new Creature(inst.root);
    if (inst.animations.length > 0) {
      c.mixer = new THREE.AnimationMixer(inst.root);
      c.action = c.mixer.clipAction(inst.animations[0]);
      c.action.play();
    }
    scene.add(inst.root);
    return c;
  }

  place(s: Spot): void {
    this.x = s.x;
    this.y = s.y;
    this.z = s.z;
    this.chase = false;
    this.lostT = 0;
  }

  // Authority side: runs the AI against the collision grid.
  update(dt: number, cw: CollisionWorld, playerX: number, playerZ: number): void {
    const dP = Math.hypot(playerX - this.x, playerZ - this.z);
    if (!this.chase && dP < SIGHT) this.chase = true;
    if (this.chase) {
      if (dP > LOSE) {
        this.lostT += dt;
        if (this.lostT > 3) {
          this.chase = false;
          this.lostT = 0;
        }
      } else {
        this.lostT = 0;
      }
    }

    let tx: number, tz: number, speed: number;
    if (this.chase) {
      tx = playerX;
      tz = playerZ;
      speed = CHASE_SPEED;
    } else {
      this.wanderT -= dt;
      if (this.wanderT <= 0 || Math.hypot(this.wanderX - this.x, this.wanderZ - this.z) < 0.3) {
        this.pickWander(cw);
      }
      tx = this.wanderX;
      tz = this.wanderZ;
      speed = ROAM_SPEED;
    }

    const dx = tx - this.x;
    const dz = tz - this.z;
    const d = Math.hypot(dx, dz);
    if (d > 1e-4) {
      const step = Math.min(d, speed * dt);
      const bx = this.x, bz = this.z;
      const moved = cw.move(this.x, this.y, this.z, (dx / d) * step, (dz / d) * step);
      this.x = moved.x;
      this.z = moved.z;
      this.y = moved.y;
      this.yaw = Math.atan2(dx, dz);
      if (Math.abs(this.x - bx) + Math.abs(this.z - bz) < 1e-5) {
        this.stuckT += dt;
        if (this.stuckT > 0.8 && !this.chase) {
          this.pickWander(cw);
          this.stuckT = 0;
        }
      } else {
        this.stuckT = 0;
      }
    }
    this.animate(dt, d > 0.05);
  }

  // Guests: follows the host's state with smoothing and keeps the feet on the floor.
  follow(dt: number, cw: CollisionWorld, n: CreatureNet): void {
    const k = Math.min(1, dt * 8);
    this.x += (n.x - this.x) * k;
    this.z += (n.z - this.z) * k;
    const g = cw.groundAt(this.x, this.z, this.y);
    if (g !== null) this.y = g;
    this.yaw = n.yaw;
    this.chase = n.chase;
    this.animate(dt, Math.hypot(n.x - this.x, n.z - this.z) > 0.02);
  }

  private pickWander(cw: CollisionWorld): void {
    this.wanderT = 2 + Math.random() * 3;
    for (let t = 0; t < 40; t++) {
      const x = this.x + (Math.random() * 2 - 1) * 2.5;
      const z = this.z + (Math.random() * 2 - 1) * 2.5;
      if (Math.abs(x) > 2.7 || Math.abs(z) > 2.7) continue;
      const g = cw.groundAt(x, z, this.y);
      if (g === null || cw.blocked(x, z, g)) continue;
      this.wanderX = x;
      this.wanderZ = z;
      return;
    }
    this.wanderX = this.x;
    this.wanderZ = this.z;
  }

  private animate(dt: number, moving: boolean): void {
    this.root.position.set(this.x, this.y, this.z);
    this.root.rotation.set(0, this.yaw, 0);
    if (this.action) this.action.paused = !moving;
    if (this.mixer) this.mixer.update(dt);
  }

  net(): CreatureNet {
    return { x: this.x, z: this.z, yaw: this.yaw, chase: this.chase };
  }
}
