import { LanRtcManager } from './lanRtc';

// Thin wrapper over the kept LAN transport (Wi-Fi / hotspot WebRTC, manual codes, no server).
// The host relays every message to the other guests; the game protocol rides on 'relay'.

export type RelayHandler = (from: string, data: unknown) => void;

export class LanNet {
  private mgr: LanRtcManager;
  role: 'host' | 'guest' | null = null;
  onRelay: RelayHandler | null = null;
  onStatus: ((msg: string) => void) | null = null;
  onLost: (() => void) | null = null;

  constructor() {
    this.mgr = new LanRtcManager({
      onOpen: () => this.status('تم الاتصال بالشبكة المحلية'),
      onPacket: (pkt) => {
        if (String(pkt.type) !== 'relay') return;
        this.onRelay?.(String(pkt.from || ''), pkt.data);
      },
      onError: (m) => this.status(m),
      onClose: () => {
        const wasGuest = this.role === 'guest';
        this.role = null;
        this.status('انقطع الاتصال');
        if (wasGuest) this.onLost?.();
      },
    });
  }

  get active(): boolean {
    return this.role !== null;
  }

  get isHost(): boolean {
    return this.role === 'host';
  }

  private status(msg: string): void {
    this.onStatus?.(msg);
  }

  // Host: returns an invite code for one guest.
  async host(name: string): Promise<string> {
    const token = await this.mgr.createHostOffer(name, 'med');
    this.role = 'host';
    return token;
  }

  // Host: pastes a guest's reply code.
  async acceptAnswer(token: string): Promise<void> {
    await this.mgr.acceptGuestAnswer(token);
  }

  // Guest: pastes the invite code and gets a reply code to send back.
  async join(invite: string, name: string): Promise<string> {
    const reply = await this.mgr.joinWithHostOffer(invite, name);
    this.role = 'guest';
    return reply;
  }

  send(data: unknown): void {
    this.mgr.sendClientMessage({ type: 'relay', data });
  }

  close(): void {
    this.mgr.close();
    this.role = null;
  }
}
