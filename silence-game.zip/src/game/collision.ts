// Collision and ground logic built from the house's real triangles.
// Pure TypeScript with no three.js import, so it can be tested directly in node.

export const CELL = 0.05;
export const GRID_MIN = -3.5;
export const GRID_SIZE = 7.0;
export const N = Math.round(GRID_SIZE / CELL);

// Floor top heights of the four storeys (ground, first, second, attic), read from the house file.
export const LEVEL_BASE = [0.16, 2.92, 5.67, 8.43];
export const STEP_UP = 0.45; // highest step the body can climb in one move
export const BODY_R = 0.22; // horizontal body radius
const BODY_LO = 0.2; // solid band relative to a level base (feet clearance)
const BODY_HI = 1.8; // solid band top (head clearance)

export interface MeshTris {
  name: string;
  pos: Float32Array; // world-space xyz, 3 floats per vertex
  idx: Uint32Array; // triangle list
}

export type MeshClass = 'solid' | 'surface' | 'skip';

// Which meshes block the body, which give walkable ground, and which are ignored.
// Works per path segment, so material labels such as "oakFloor" do not count as floors.
const SURFACE_SEG = /(^|-)(floor|stair|staircase)(-|$)/;
const SKIP_SEG = /rug|roof|door|ladder|hatch|lamp/;

export function classify(name: string): MeshClass {
  const segs = name.toLowerCase().split('/');
  if (segs.some((s) => SURFACE_SEG.test(s) && !s.includes('lamp'))) return 'surface';
  if (segs.some((s) => SKIP_SEG.test(s))) return 'skip';
  return 'solid';
}

export function levelOf(y: number): number {
  let best = 0;
  for (let i = 1; i < LEVEL_BASE.length; i++) {
    if (Math.abs(y - LEVEL_BASE[i]) < Math.abs(y - LEVEL_BASE[best])) best = i;
  }
  return best;
}

export function cellOf(x: number, z: number): number {
  const i = Math.floor((x - GRID_MIN) / CELL);
  const j = Math.floor((z - GRID_MIN) / CELL);
  if (i < 0 || j < 0 || i >= N || j >= N) return -1;
  return j * N + i;
}

export function cellCenter(c: number): [number, number] {
  const i = c % N;
  const j = (c - i) / N;
  return [GRID_MIN + (i + 0.5) * CELL, GRID_MIN + (j + 0.5) * CELL];
}

function distToSeg(px: number, pz: number, ax: number, az: number, bx: number, bz: number): number {
  const dx = bx - ax;
  const dz = bz - az;
  const len2 = dx * dx + dz * dz;
  let t = len2 > 0 ? ((px - ax) * dx + (pz - az) * dz) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  const ex = ax + dx * t - px;
  const ez = az + dz * t - pz;
  return Math.sqrt(ex * ex + ez * ez);
}

// Barycentric weights of (px,pz) in the 2D triangle, or null if outside.
function bary(
  px: number, pz: number,
  ax: number, az: number, bx: number, bz: number, cx: number, cz: number
): [number, number, number] | null {
  const den = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz);
  if (Math.abs(den) < 1e-12) return null;
  const u = ((bz - cz) * (px - cx) + (cx - bx) * (pz - cz)) / den;
  const v = ((cz - az) * (px - cx) + (ax - cx) * (pz - cz)) / den;
  const w = 1 - u - v;
  if (u < -1e-6 || v < -1e-6 || w < -1e-6) return null;
  return [u, v, w];
}

export class CollisionWorld {
  // One solid grid per storey.
  readonly solid: Uint8Array[] = LEVEL_BASE.map(() => new Uint8Array(N * N));
  // Walkable heights per cell (floor tops and stair treads).
  readonly surf: (number[] | undefined)[] = new Array(N * N);

  // Marks cells touched by triangles whose y-range overlaps [lo, hi].
  // Degenerate (vertical) triangles are handled by distance to their edges.
  rasterInto(m: MeshTris, lo: number, hi: number, out: Uint8Array): number {
    let marked = 0;
    const p = m.pos;
    const ix = m.idx;
    const half = CELL * 0.6;
    for (let t = 0; t + 2 < ix.length; t += 3) {
      const a = ix[t] * 3, b = ix[t + 1] * 3, c = ix[t + 2] * 3;
      const ay = p[a + 1], by = p[b + 1], cy = p[c + 1];
      const minY = Math.min(ay, by, cy), maxY = Math.max(ay, by, cy);
      if (maxY < lo || minY > hi) continue;
      const ax = p[a], az = p[a + 2], bx = p[b], bz = p[b + 2], cx = p[c], cz = p[c + 2];
      const i0 = Math.max(0, Math.floor((Math.min(ax, bx, cx) - GRID_MIN) / CELL));
      const i1 = Math.min(N - 1, Math.floor((Math.max(ax, bx, cx) - GRID_MIN) / CELL));
      const j0 = Math.max(0, Math.floor((Math.min(az, bz, cz) - GRID_MIN) / CELL));
      const j1 = Math.min(N - 1, Math.floor((Math.max(az, bz, cz) - GRID_MIN) / CELL));
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const cIdx = j * N + i;
          if (out[cIdx]) continue;
          const px = GRID_MIN + (i + 0.5) * CELL;
          const pz = GRID_MIN + (j + 0.5) * CELL;
          const inside = bary(px, pz, ax, az, bx, bz, cx, cz) !== null;
          if (
            inside ||
            distToSeg(px, pz, ax, az, bx, bz) <= half ||
            distToSeg(px, pz, bx, bz, cx, cz) <= half ||
            distToSeg(px, pz, cx, cz, ax, az) <= half
          ) {
            out[cIdx] = 1;
            marked++;
          }
        }
      }
    }
    return marked;
  }

  // Adds the mesh to every storey it overlaps (solid meshes) or as walkable ground (surfaces).
  addMesh(m: MeshTris): void {
    const cls = classify(m.name);
    if (cls === 'solid') {
      for (let L = 0; L < LEVEL_BASE.length; L++) {
        this.rasterInto(m, LEVEL_BASE[L] + BODY_LO, LEVEL_BASE[L] + BODY_HI, this.solid[L]);
      }
    } else if (cls === 'surface') {
      this.addSurfaces(m);
    }
  }

  private addSurfaces(m: MeshTris): void {
    const p = m.pos;
    const ix = m.idx;
    for (let t = 0; t + 2 < ix.length; t += 3) {
      const a = ix[t] * 3, b = ix[t + 1] * 3, c = ix[t + 2] * 3;
      const ux = p[b] - p[a], uy = p[b + 1] - p[a + 1], uz = p[b + 2] - p[a + 2];
      const vx = p[c] - p[a], vy = p[c + 1] - p[a + 1], vz = p[c + 2] - p[a + 2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      const nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
      if (nl < 1e-9 || Math.abs(ny) / nl < 0.7) continue; // only upward-facing triangles
      const ax = p[a], az = p[a + 2], bx = p[b], bz = p[b + 2], cx = p[c], cz = p[c + 2];
      const i0 = Math.max(0, Math.floor((Math.min(ax, bx, cx) - GRID_MIN) / CELL));
      const i1 = Math.min(N - 1, Math.floor((Math.max(ax, bx, cx) - GRID_MIN) / CELL));
      const j0 = Math.max(0, Math.floor((Math.min(az, bz, cz) - GRID_MIN) / CELL));
      const j1 = Math.min(N - 1, Math.floor((Math.max(az, bz, cz) - GRID_MIN) / CELL));
      for (let j = j0; j <= j1; j++) {
        for (let i = i0; i <= i1; i++) {
          const px = GRID_MIN + (i + 0.5) * CELL;
          const pz = GRID_MIN + (j + 0.5) * CELL;
          const w = bary(px, pz, ax, az, bx, bz, cx, cz);
          if (!w) continue;
          const h = w[0] * p[a + 1] + w[1] * p[b + 1] + w[2] * p[c + 1];
          const c2 = j * N + i;
          const list = this.surf[c2] || (this.surf[c2] = []);
          if (!list.some((v) => Math.abs(v - h) < 0.005)) list.push(h);
        }
      }
    }
  }

  // Ground height under (x,z) reachable from height y (step up allowed), or null.
  groundAt(x: number, z: number, y: number): number | null {
    const c = cellOf(x, z);
    if (c < 0) return null;
    const s = this.surf[c];
    if (!s) return null;
    let best: number | null = null;
    for (const h of s) {
      if (h <= y + STEP_UP && (best === null || h > best)) best = h;
    }
    return best;
  }

  // True when the body circle at (x,z) overlaps solid geometry on the storey of height y.
  blocked(x: number, z: number, y: number): boolean {
    const L = levelOf(y);
    const grid = this.solid[L];
    const pts = 9;
    for (let k = 0; k < pts; k++) {
      let px = x, pz = z;
      if (k < 8) {
        const ang = (k * Math.PI) / 4;
        px = x + Math.cos(ang) * BODY_R;
        pz = z + Math.sin(ang) * BODY_R;
      }
      const c = cellOf(px, pz);
      if (c < 0 || grid[c]) return true;
    }
    return false;
  }

  // Moves the body by (dx,dz) with axis sliding. Returns the new feet height, or null if stuck.
  tryStep(x: number, y: number, z: number, dx: number, dz: number): { x: number; z: number; y: number } | null {
    const nx = x + dx, nz = z + dz;
    if (!this.blocked(nx, nz, y)) {
      const g = this.groundAt(nx, nz, y);
      if (g !== null) return { x: nx, z: nz, y: g };
    }
    return null;
  }

  move(x: number, y: number, z: number, dx: number, dz: number): { x: number; z: number; y: number } {
    const full = this.tryStep(x, y, z, dx, dz);
    if (full) return full;
    const onX = Math.abs(dx) > 0 ? this.tryStep(x, y, z, dx, 0) : null;
    const onZ = Math.abs(dz) > 0 ? this.tryStep(x, y, z, 0, dz) : null;
    if (onX && onZ) return Math.abs(dx) >= Math.abs(dz) ? onX : onZ;
    if (onX) return onX;
    if (onZ) return onZ;
    return { x, y, z };
  }

  // Footprint of a prop on the grid, used before committing it.
  footprint(m: MeshTris): Uint8Array {
    const mask = new Uint8Array(N * N);
    this.rasterInto(m, -Infinity, Infinity, mask);
    return mask;
  }

  // Commits a prop footprint to one storey if it does not overlap existing solids.
  placeProp(m: MeshTris, level: number): boolean {
    const mask = this.footprint(m);
    const grid = this.solid[level];
    for (let c = 0; c < mask.length; c++) {
      if (mask[c] && grid[c]) return false;
    }
    for (let c = 0; c < mask.length; c++) {
      if (mask[c]) grid[c] = 1;
    }
    return true;
  }
}
