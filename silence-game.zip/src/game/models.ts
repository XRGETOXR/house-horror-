import * as THREE from 'three';
import { GLTFLoader, type GLTF } from 'three/addons/loaders/GLTFLoader.js';
import { MODEL_KEYS, type ModelKey } from './modelKeys';

// Loads the uploaded GLB models from /models/<key>.glb.
// A failed load resolves to null, so the caller can fall back to something simple.

const loader = new GLTFLoader();
const cache = new Map<ModelKey, Promise<GLTF | null>>();

export function loadGLTF(key: ModelKey): Promise<GLTF | null> {
  let p = cache.get(key);
  if (!p) {
    p = new Promise<GLTF | null>((resolve) => {
      loader.load(
        MODEL_KEYS[key],
        (gltf) => resolve(gltf),
        undefined,
        (err) => {
          console.warn('[models] failed to load', key, err);
          resolve(null);
        }
      );
    });
    cache.set(key, p);
  }
  return p;
}

export interface ModelInstance {
  root: THREE.Group;
  animations: THREE.AnimationClip[];
}

// A fresh instance of a model. Geometry is shared with the cache, which is fine for static props.
export async function cloneModel(key: ModelKey): Promise<ModelInstance | null> {
  const gltf = await loadGLTF(key);
  if (!gltf) return null;
  const root = new THREE.Group();
  root.add(gltf.scene.clone(true));
  root.name = key;
  return { root, animations: gltf.animations };
}

// Bounding box of an object in its own space (metres in these files).
export function boundsOf(obj: THREE.Object3D): THREE.Box3 {
  return new THREE.Box3().setFromObject(obj);
}
