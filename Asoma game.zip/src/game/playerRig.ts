import * as THREE from 'three';
import { HeldItemType } from './types';

export interface PlayerSurvivorRig {
  group: THREE.Group;
  bodyGroup: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  beamMesh: THREE.Mesh;
  torchGlow: THREE.Sprite;
  auraGlow: THREE.Sprite;
  toolMeshes: Record<Exclude<HeldItemType, null>, THREE.Group>;
  nameSprite: THREE.Sprite;
  nameText: string;
  walkPhase: number;
}

const JACKET_PALETTES = [
  { jacket: 0x2b7a9b, trim: 0x8be4ff, pack: 0x46392c }, // Teal survivor
  { jacket: 0xc27a2c, trim: 0xffd584, pack: 0x3b2f26 }, // Amber survivor
  { jacket: 0x388c5d, trim: 0x8effb8, pack: 0x363628 }, // Emerald survivor
  { jacket: 0x9b4260, trim: 0xffa6c4, pack: 0x352930 }, // Crimson-plum survivor
];

function createNameTagTexture(name: string, status = ''): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 384;
  canvas.height = 96;
  const g = canvas.getContext('2d')!;
  g.clearRect(0, 0, 384, 96);

  // Dark readable backing pill for contrast in dark rooms
  g.fillStyle = 'rgba(10, 8, 8, 0.86)';
  g.strokeStyle = 'rgba(139, 228, 255, 0.85)';
  g.lineWidth = 3;
  const rx = 24;
  const ry = 16;
  const rw = 336;
  const rh = 64;
  g.beginPath();
  g.roundRect(rx, ry, rw, rh, 12);
  g.fill();
  g.stroke();

  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillStyle = '#f4efe6';
  g.font = 'bold 30px Tajawal, sans-serif';
  const label = status ? `${name} · ${status}` : name;
  g.fillText(label, 192, 49);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createSurvivorRig(
  name: string,
  colorIndex: number,
  skinTex: THREE.Texture,
  glowTex: THREE.Texture
): PlayerSurvivorRig {
  const palette = JACKET_PALETTES[Math.abs(colorIndex) % JACKET_PALETTES.length];
  const group = new THREE.Group();
  const bodyGroup = new THREE.Group();
  group.add(bodyGroup);

  const mk = (
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number
  ) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    return m;
  };

  const jacketMat = new THREE.MeshStandardMaterial({
    color: palette.jacket,
    roughness: 0.72,
    metalness: 0.08,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: palette.trim,
    emissive: palette.trim,
    emissiveIntensity: 0.28,
    roughness: 0.5,
  });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0x262932, roughness: 0.85 });
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x161311, roughness: 0.9 });
  const packMat = new THREE.MeshStandardMaterial({ color: palette.pack, roughness: 0.85 });
  const skinMat = new THREE.MeshStandardMaterial({ map: skinTex, roughness: 0.68 });
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x1e1612, roughness: 0.9 });

  // Torso / Jacket + Reflective Survivor Collar & Stripes + Backpack
  bodyGroup.add(mk(new THREE.BoxGeometry(0.46, 0.58, 0.28), jacketMat, 0, 1.12, 0));
  // Belt + brass buckle
  bodyGroup.add(mk(new THREE.BoxGeometry(0.48, 0.07, 0.3), bootMat, 0, 0.85, 0));
  bodyGroup.add(mk(new THREE.BoxGeometry(0.1, 0.07, 0.04), trimMat, 0, 0.85, 0.16));
  // High-visibility shoulder & chest trim so teammate stands out clearly
  bodyGroup.add(mk(new THREE.BoxGeometry(0.48, 0.06, 0.3), trimMat, 0, 1.38, 0));
  bodyGroup.add(mk(new THREE.BoxGeometry(0.08, 0.42, 0.3), trimMat, 0, 1.13, 0));
  // Backpack on back (-Z is back, +Z is forward facing)
  bodyGroup.add(mk(new THREE.BoxGeometry(0.34, 0.42, 0.16), packMat, 0, 1.14, -0.2));
  bodyGroup.add(mk(new THREE.BoxGeometry(0.28, 0.04, 0.18), trimMat, 0, 1.24, -0.21));

  // Articulated Head with Eyes, Brows, Nose & Hair Cap (facing +Z)
  const head = new THREE.Group();
  head.position.set(0, 1.56, 0);
  head.add(mk(new THREE.BoxGeometry(0.28, 0.3, 0.28), skinMat, 0, 0, 0));
  // Hair cap / hood top & back
  head.add(mk(new THREE.BoxGeometry(0.3, 0.1, 0.31), hairMat, 0, 0.13, -0.01));
  head.add(mk(new THREE.BoxGeometry(0.3, 0.24, 0.1), hairMat, 0, 0.02, -0.11));
  // Clear expressive eyes & brows
  const eyeWhite = new THREE.MeshBasicMaterial({ color: 0xf4f4f0 });
  const eyePupil = new THREE.MeshBasicMaterial({ color: 0x161a24 });
  [-0.065, 0.065].forEach((ex) => {
    head.add(mk(new THREE.BoxGeometry(0.055, 0.04, 0.02), eyeWhite, ex, 0.025, 0.145));
    head.add(mk(new THREE.BoxGeometry(0.028, 0.032, 0.024), eyePupil, ex, 0.025, 0.148));
    head.add(mk(new THREE.BoxGeometry(0.065, 0.018, 0.02), hairMat, ex, 0.065, 0.145));
  });
  bodyGroup.add(head);

  // Left Arm + Flashlight & Volumetric Light Cone (armL at +X in local +Z forward rig)
  const armL = new THREE.Group();
  armL.position.set(0.3, 1.34, 0);
  armL.add(mk(new THREE.BoxGeometry(0.14, 0.48, 0.14), jacketMat, 0, -0.2, 0));
  armL.add(mk(new THREE.SphereGeometry(0.065, 8, 8), skinMat, 0, -0.47, 0.02));
  // Detailed flashlight in left hand
  const flashBody = new THREE.Group();
  flashBody.position.set(0, -0.46, 0.14);
  const fCyl = mk(
    new THREE.CylinderGeometry(0.036, 0.03, 0.24, 10),
    new THREE.MeshStandardMaterial({ color: 0x333842, metalness: 0.7, roughness: 0.35 }),
    0,
    0,
    0
  );
  fCyl.rotation.x = Math.PI / 2;
  flashBody.add(fCyl);
  const lens = mk(
    new THREE.CylinderGeometry(0.042, 0.036, 0.03, 10),
    new THREE.MeshBasicMaterial({ color: 0xfff2be }),
    0,
    0,
    0.13
  );
  lens.rotation.x = Math.PI / 2;
  flashBody.add(lens);

  // Volumetric visible flashlight beam cone
  const beamGeo = new THREE.ConeGeometry(0.65, 3.2, 14, 1, true);
  beamGeo.translate(0, -1.6, 0);
  beamGeo.rotateX(-Math.PI / 2);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0xffe8b0,
    transparent: true,
    opacity: 0.11,
    side: THREE.DoubleSide,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const beamMesh = new THREE.Mesh(beamGeo, beamMat);
  beamMesh.position.set(0, 0, 0.14);
  flashBody.add(beamMesh);

  const torchGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTex,
      color: 0xffe6a3,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  torchGlow.scale.set(0.55, 0.55, 1);
  torchGlow.position.set(0, 0, 0.16);
  flashBody.add(torchGlow);
  armL.add(flashBody);
  armL.rotation.x = -0.95;
  bodyGroup.add(armL);

  // Right Arm + Held Item Meshes
  const armR = new THREE.Group();
  armR.position.set(-0.3, 1.34, 0);
  armR.add(mk(new THREE.BoxGeometry(0.14, 0.48, 0.14), jacketMat, 0, -0.2, 0));
  armR.add(mk(new THREE.SphereGeometry(0.065, 8, 8), skinMat, 0, -0.47, 0.02));

  const handAnchor = new THREE.Group();
  handAnchor.position.set(0, -0.47, 0.12);
  armR.add(handAnchor);

  const metalM = new THREE.MeshStandardMaterial({ color: 0x383d46, roughness: 0.3, metalness: 0.85 });
  const woodM = new THREE.MeshStandardMaterial({ color: 0x624026, roughness: 0.85 });
  const redM = new THREE.MeshStandardMaterial({ color: 0xb82e24, roughness: 0.5 });
  const ceramicM = new THREE.MeshStandardMaterial({ color: 0xd0bfa8, roughness: 0.35 });

  const hammerG = new THREE.Group();
  const hShaft = mk(new THREE.CylinderGeometry(0.024, 0.024, 0.42, 8), woodM, 0, 0.16, 0.04);
  hShaft.rotation.x = 0.45;
  hammerG.add(hShaft);
  hammerG.add(mk(new THREE.BoxGeometry(0.08, 0.09, 0.2), metalM, 0, 0.34, 0.12));

  const cuttersG = new THREE.Group();
  cuttersG.add(mk(new THREE.BoxGeometry(0.026, 0.03, 0.24), redM, 0.025, 0, 0.08));
  cuttersG.add(mk(new THREE.BoxGeometry(0.026, 0.03, 0.24), redM, -0.025, 0, 0.08));
  cuttersG.add(mk(new THREE.BoxGeometry(0.07, 0.04, 0.12), metalM, 0, 0, 0.22));

  const screwG = new THREE.Group();
  const sh1 = mk(new THREE.CylinderGeometry(0.024, 0.024, 0.16, 8), redM, 0, 0, 0.04);
  sh1.rotation.x = Math.PI / 2;
  const sh2 = mk(new THREE.CylinderGeometry(0.008, 0.008, 0.22, 8), metalM, 0, 0, 0.2);
  sh2.rotation.x = Math.PI / 2;
  screwG.add(sh1, sh2);

  const gunG = new THREE.Group();
  gunG.add(mk(new THREE.BoxGeometry(0.05, 0.06, 0.28), metalM, 0, 0.05, 0.1));
  gunG.add(mk(new THREE.BoxGeometry(0.048, 0.13, 0.06), woodM, 0, -0.02, 0.02));

  const vaseG = new THREE.Group();
  vaseG.add(mk(new THREE.CylinderGeometry(0.095, 0.07, 0.28, 12), ceramicM, 0, 0.08, 0.12));

  const toolMeshes: Record<Exclude<HeldItemType, null>, THREE.Group> = {
    hammer: hammerG,
    cutters: cuttersG,
    screwdriver: screwG,
    gun: gunG,
    vase: vaseG,
  };
  Object.values(toolMeshes).forEach((tm) => {
    tm.visible = false;
    handAnchor.add(tm);
  });
  bodyGroup.add(armR);

  // Articulated Legs + Boots
  const legL = new THREE.Group();
  legL.position.set(0.13, 0.82, 0);
  legL.add(mk(new THREE.BoxGeometry(0.17, 0.66, 0.18), pantsMat, 0, -0.34, 0));
  legL.add(mk(new THREE.BoxGeometry(0.18, 0.16, 0.25), bootMat, 0, -0.74, 0.03));
  bodyGroup.add(legL);

  const legR = new THREE.Group();
  legR.position.set(-0.13, 0.82, 0);
  legR.add(mk(new THREE.BoxGeometry(0.17, 0.66, 0.18), pantsMat, 0, -0.34, 0));
  legR.add(mk(new THREE.BoxGeometry(0.18, 0.16, 0.25), bootMat, 0, -0.74, 0.03));
  bodyGroup.add(legR);

  // Soft teammate silhouette aura so player is visible down dim hallways
  const auraGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTex,
      color: palette.trim,
      transparent: true,
      opacity: 0.26,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  auraGlow.scale.set(1.5, 2.2, 1);
  auraGlow.position.set(0, 1.15, 0);
  group.add(auraGlow);

  // Crisp floating Arabic Nameplate above head
  const nameSprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: createNameTagTexture(name),
      transparent: true,
      depthTest: true,
    })
  );
  nameSprite.scale.set(1.65, 0.42, 1);
  nameSprite.position.set(0, 2.15, 0);
  group.add(nameSprite);

  return {
    group,
    bodyGroup,
    head,
    armL,
    armR,
    legL,
    legR,
    beamMesh,
    torchGlow,
    auraGlow,
    toolMeshes,
    nameSprite,
    nameText: name,
    walkPhase: 0,
  };
}

export function updateSurvivorNameTag(
  rig: PlayerSurvivorRig,
  name: string,
  status = ''
): void {
  const key = `${name}|${status}`;
  if (rig.nameText === key) return;
  rig.nameText = key;
  const mat = rig.nameSprite.material as THREE.SpriteMaterial;
  mat.map?.dispose();
  mat.map = createNameTagTexture(name, status);
  mat.needsUpdate = true;
}

export function animateSurvivorRig(
  rig: PlayerSurvivorRig,
  dt: number,
  speed: number,
  crouch: boolean,
  torchOn: boolean,
  heldItem: HeldItemType,
  alive: boolean
): void {
  rig.beamMesh.visible = torchOn && alive;
  rig.torchGlow.visible = torchOn && alive;

  (Object.keys(rig.toolMeshes) as Exclude<HeldItemType, null>[]).forEach((k) => {
    rig.toolMeshes[k].visible = alive && heldItem === k;
  });

  if (!alive) {
    rig.bodyGroup.rotation.x = -Math.PI / 2;
    rig.bodyGroup.position.y = 0.28;
    rig.nameSprite.position.y = 1.1;
    return;
  }

  rig.bodyGroup.rotation.x = crouch ? 0.24 : 0;
  rig.bodyGroup.position.y += ((crouch ? -0.35 : 0) - rig.bodyGroup.position.y) * Math.min(1, dt * 10);
  rig.nameSprite.position.y = crouch ? 1.78 : 2.15;

  if (speed > 0.15) {
    rig.walkPhase += dt * Math.min(12, speed * 2.5);
  }
  const swing = speed > 0.15 ? Math.sin(rig.walkPhase) * Math.min(0.85, speed * 0.22) : 0;

  rig.legL.rotation.x = swing;
  rig.legR.rotation.x = -swing;
  rig.armL.rotation.x = -0.92 + swing * 0.15;
  rig.armR.rotation.x = heldItem ? -0.65 + swing * 0.2 : -swing * 0.55;
  rig.head.rotation.y = Math.sin(rig.walkPhase * 0.25) * 0.05;
}
