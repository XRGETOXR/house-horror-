class HorrorAudioEngine {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambientBus: GainNode | null = null;
  private draftGain: GainNode | null = null;
  private tensionGain: GainNode | null = null;
  private tensionFilter: BiquadFilterNode | null = null;
  private tensionTremLfo: OscillatorNode | null = null;
  private tensionTremGain: GainNode | null = null;
  private screechGain: GainNode | null = null;
  private screechFilter: BiquadFilterNode | null = null;
  private whisperGain: GainNode | null = null;
  private whisperFilter: BiquadFilterNode | null = null;
  private whisperPanner: StereoPannerNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private longNoiseBuf: AudioBuffer | null = null;
  private volume = 0.75;
  private ambientActive = false;

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.master) {
      this.master.gain.value = this.volume;
    }
  }

  public setAmbientActive(active: boolean, intensity = 1): void {
    this.ambientActive = active;
    if (!this.ac || !this.draftGain || !this.ambientBus) return;
    const now = this.ac.currentTime;
    const targetDraft = active ? 0.045 * Math.max(0.4, Math.min(1.8, intensity)) : 0.005;
    this.draftGain.gain.setTargetAtTime(targetDraft, now, 0.6);
    this.ambientBus.gain.setTargetAtTime(active ? 1.0 : 0.25, now, 0.4);
  }

  public setThreatTension(threat: number): void {
    if (!this.ac || !this.tensionGain || !this.tensionFilter) return;
    const t = Math.max(0, Math.min(1, threat));
    const now = this.ac.currentTime;

    // 1. Dissonant bass strings swell & filter sweep
    const bassGain = t > 0.07 ? 0.01 + Math.pow(t, 1.25) * 0.14 : 0.0001;
    const cutoff = 95 + Math.pow(t, 1.15) * 1120;
    this.tensionGain.gain.setTargetAtTime(bassGain, now, 0.14);
    this.tensionFilter.frequency.setTargetAtTime(cutoff, now, 0.14);

    // 2. Tremolo pulse speeds up with Stalker proximity
    if (this.tensionTremLfo && this.tensionTremGain) {
      this.tensionTremLfo.frequency.setTargetAtTime(0.65 + t * 6.2, now, 0.2);
      this.tensionTremGain.gain.setTargetAtTime(t > 0.12 ? t * 0.045 : 0.0001, now, 0.18);
    }

    // 3. Eerie high-register bowed horror strings enter past medium proximity
    if (this.screechGain && this.screechFilter) {
      const highLvl = t > 0.34 ? Math.pow((t - 0.34) / 0.66, 1.45) : 0;
      this.screechGain.gain.setTargetAtTime(highLvl > 0.01 ? highLvl * 0.055 : 0.0001, now, 0.16);
      this.screechFilter.frequency.setTargetAtTime(920 + highLvl * 1350, now, 0.2);
    }
  }

  public setWhisperProximity(intensity: number, pan = 0): void {
    if (!this.ac || !this.whisperGain || !this.whisperFilter) return;
    const lvl = Math.max(0, Math.min(1, intensity));
    const now = this.ac.currentTime;
    const targetGain = lvl > 0.04 ? Math.pow(lvl, 1.35) * 0.15 : 0.0001;
    const targetFreq = 580 + lvl * 1050;
    this.whisperGain.gain.setTargetAtTime(targetGain, now, 0.18);
    this.whisperFilter.frequency.setTargetAtTime(targetFreq, now, 0.22);
    if (this.whisperPanner) {
      this.whisperPanner.pan.setTargetAtTime(Math.max(-0.92, Math.min(0.92, pan)), now, 0.12);
    }
  }

  private connectPanned(node: AudioNode, pan = 0): void {
    if (!this.ac || !this.ambientBus) return;
    const clampedPan = Math.max(-0.95, Math.min(0.95, pan));
    if (typeof this.ac.createStereoPanner === 'function') {
      const panner = this.ac.createStereoPanner();
      panner.pan.value = clampedPan;
      node.connect(panner);
      panner.connect(this.ambientBus);
    } else {
      node.connect(this.ambientBus);
    }
  }

  public init(): void {
    if (this.ac) {
      if (this.ac.state === 'suspended') {
        void this.ac.resume();
      }
      return;
    }
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctx) return;
      this.ac = new Ctx();
      this.master = this.ac.createGain();
      this.master.gain.value = this.volume;
      this.master.connect(this.ac.destination);

      this.ambientBus = this.ac.createGain();
      this.ambientBus.gain.value = this.ambientActive ? 1.0 : 0.25;
      this.ambientBus.connect(this.master);

      this.noiseBuf = this.ac.createBuffer(1, this.ac.sampleRate, this.ac.sampleRate);
      const data = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      // 3-second seamless noise buffer for ambient wind/drafts
      const longLen = this.ac.sampleRate * 3;
      this.longNoiseBuf = this.ac.createBuffer(1, longLen, this.ac.sampleRate);
      const longData = this.longNoiseBuf.getChannelData(0);
      for (let i = 0; i < longLen; i++) {
        longData[i] = Math.random() * 2 - 1;
      }

      // Eerie dark room ambient drone
      [46, 48.5, 69].forEach((freq, i) => {
        if (!this.ac || !this.master) return;
        const osc = this.ac.createOscillator();
        const gain = this.ac.createGain();
        osc.type = i === 2 ? 'triangle' : 'sine';
        osc.frequency.value = freq;
        gain.gain.value = 0.028;
        osc.connect(gain);
        gain.connect(this.master);
        osc.start();

        const lfo = this.ac.createOscillator();
        const lfoGain = this.ac.createGain();
        lfo.frequency.value = 0.07 + i * 0.03;
        lfoGain.gain.value = 0.015;
        lfo.connect(lfoGain);
        lfoGain.connect(gain.gain);
        lfo.start();
      });

      // Continuous subtle abandoned-house wind draft
      if (this.longNoiseBuf) {
        const draftSrc = this.ac.createBufferSource();
        draftSrc.buffer = this.longNoiseBuf;
        draftSrc.loop = true;

        const draftFilter = this.ac.createBiquadFilter();
        draftFilter.type = 'bandpass';
        draftFilter.frequency.value = 230;
        draftFilter.Q.value = 1.6;

        const filterLfo = this.ac.createOscillator();
        const filterLfoGain = this.ac.createGain();
        filterLfo.frequency.value = 0.11;
        filterLfoGain.gain.value = 85;
        filterLfo.connect(filterLfoGain);
        filterLfoGain.connect(draftFilter.frequency);
        filterLfo.start();

        this.draftGain = this.ac.createGain();
        this.draftGain.gain.value = this.ambientActive ? 0.045 : 0.005;

        draftSrc.connect(draftFilter);
        draftFilter.connect(this.draftGain);
        this.draftGain.connect(this.ambientBus);
        draftSrc.start();
      }

      // Dynamic Stalker-proximity horror music: dissonant low cluster + tremolo
      this.tensionFilter = this.ac.createBiquadFilter();
      this.tensionFilter.type = 'lowpass';
      this.tensionFilter.frequency.value = 95;
      this.tensionFilter.Q.value = 3.8;
      this.tensionGain = this.ac.createGain();
      this.tensionGain.gain.value = 0.0001;

      const bassCluster: Array<[OscillatorType, number]> = [
        ['sawtooth', 55],     // A1
        ['sawtooth', 58.27],  // A#1 (tense minor 2nd clash)
        ['triangle', 77.78],  // D#2 (tritone horror interval)
      ];
      for (const [oscType, freq] of bassCluster) {
        const osc = this.ac.createOscillator();
        osc.type = oscType;
        osc.frequency.value = freq;
        osc.connect(this.tensionFilter);
        osc.start();
      }

      this.tensionTremLfo = this.ac.createOscillator();
      this.tensionTremLfo.frequency.value = 0.7;
      this.tensionTremGain = this.ac.createGain();
      this.tensionTremGain.gain.value = 0.0001;
      this.tensionTremLfo.connect(this.tensionTremGain);
      this.tensionTremGain.connect(this.tensionGain.gain);
      this.tensionTremLfo.start();

      this.tensionFilter.connect(this.tensionGain);
      this.tensionGain.connect(this.master);

      // High-register bowed horror strings screech for close Stalker chases
      this.screechFilter = this.ac.createBiquadFilter();
      this.screechFilter.type = 'bandpass';
      this.screechFilter.frequency.value = 980;
      this.screechFilter.Q.value = 2.6;
      this.screechGain = this.ac.createGain();
      this.screechGain.gain.value = 0.0001;

      const screechVib = this.ac.createOscillator();
      const screechVibGain = this.ac.createGain();
      screechVib.frequency.value = 5.4;
      screechVibGain.gain.value = 14;
      screechVib.connect(screechVibGain);
      screechVib.start();

      for (const freq of [466.16, 493.88, 659.25]) {
        const osc = this.ac.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.value = freq;
        screechVibGain.connect(osc.frequency);
        osc.connect(this.screechFilter);
        osc.start();
      }
      this.screechFilter.connect(this.screechGain);
      this.screechGain.connect(this.master);

      // Continuous spatial whisper-breath layer (early enemy proximity cue)
      if (this.longNoiseBuf) {
        const wSrc = this.ac.createBufferSource();
        wSrc.buffer = this.longNoiseBuf;
        wSrc.loop = true;

        this.whisperFilter = this.ac.createBiquadFilter();
        this.whisperFilter.type = 'bandpass';
        this.whisperFilter.frequency.value = 680;
        this.whisperFilter.Q.value = 4.2;

        const wLfo = this.ac.createOscillator();
        const wLfoGain = this.ac.createGain();
        wLfo.frequency.value = 1.9;
        wLfoGain.gain.value = 220;
        wLfo.connect(wLfoGain);
        wLfoGain.connect(this.whisperFilter.frequency);
        wLfo.start();

        this.whisperGain = this.ac.createGain();
        this.whisperGain.gain.value = 0.0001;

        wSrc.connect(this.whisperFilter);
        this.whisperFilter.connect(this.whisperGain);
        if (typeof this.ac.createStereoPanner === 'function') {
          this.whisperPanner = this.ac.createStereoPanner();
          this.whisperGain.connect(this.whisperPanner);
          this.whisperPanner.connect(this.master);
        } else {
          this.whisperGain.connect(this.master);
        }
        wSrc.start();
      }
    } catch {
      this.ac = null;
    }
  }

  public tone(
    type: OscillatorType,
    f0: number,
    f1: number,
    vol: number,
    dur: number,
    delay = 0
  ): void {
    if (!this.ac || !this.master) return;
    const t = this.ac.currentTime + delay;
    const osc = this.ac.createOscillator();
    const gain = this.ac.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(f0, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gain);
    gain.connect(this.master);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  public noise(vol: number, dur: number, freq: number, delay = 0): void {
    if (!this.ac || !this.master || !this.noiseBuf) return;
    const t = this.ac.currentTime + delay;
    const src = this.ac.createBufferSource();
    const filter = this.ac.createBiquadFilter();
    const gain = this.ac.createGain();
    src.buffer = this.noiseBuf;
    filter.type = 'lowpass';
    filter.frequency.value = freq;
    gain.gain.setValueAtTime(Math.max(0.0002, vol), t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.master);
    src.start(t);
    src.stop(t + dur + 0.05);
  }

  public beat(v: number, tension = 0): void {
    const t = Math.max(0, Math.min(1, tension));
    const dubDelay = 0.2 - t * 0.1;
    const f0 = 60 + t * 22;
    // Lub (S1)
    this.tone('sine', f0, 26, v, 0.17);
    this.tone('triangle', f0 * 0.92, 32, v * 0.44, 0.13);
    // Dub (S2)
    this.tone('sine', f0 * 0.88, 24, v * (0.78 + t * 0.16), 0.15, dubDelay);
    if (t > 0.5) {
      // Adrenaline thump & gasp rush during close Stalker chase
      this.noise(v * 0.18 * (t - 0.35), 0.09, 260 + t * 380);
    }
  }

  public tensionStab(tension: number): void {
    if (!this.ac || !this.master) return;
    const t = Math.max(0, Math.min(1, tension));
    if (t < 0.3) return;
    const lvl = (t - 0.3) / 0.7;
    // Low pizzicato/horror percussion hit + metallic scrape
    this.tone('sawtooth', 98 + lvl * 35, 38, 0.045 + lvl * 0.09, 0.18);
    if (lvl > 0.45) {
      this.tone('triangle', 311.13, 277.18, 0.025 + lvl * 0.04, 0.24, 0.02);
    }
  }

  public chatMsg(isSelf = false): void {
    this.tone('sine', isSelf ? 520 : 660, isSelf ? 640 : 880, 0.06, 0.09);
  }

  public gstep(d: number): void {
    const v = Math.max(0.05, 0.75 * (1 - d / 40));
    this.tone('sine', 52, 22, v, 0.45);
    this.noise(v * 0.5, 0.35, 180);
  }

  public hstep(d: number, pan = 0): void {
    if (!this.ac || !this.noiseBuf || !this.ambientBus) return;
    const v = Math.max(0.015, 0.24 * Math.pow(Math.max(0, 1 - d / 22), 1.15));
    const t = this.ac.currentTime;
    const src = this.ac.createBufferSource();
    src.buffer = this.noiseBuf;
    const filter = this.ac.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = d > 12 ? 480 : 920;
    const gain = this.ac.createGain();
    gain.gain.setValueAtTime(Math.max(0.0002, v), t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
    src.connect(filter);
    filter.connect(gain);
    this.connectPanned(gain, pan);
    src.start(t);
    src.stop(t + 0.14);
  }

  public whisperBurst(intensity: number, pan = 0): void {
    if (!this.ac || !this.noiseBuf || !this.ambientBus) return;
    const lvl = Math.max(0, Math.min(1, intensity));
    if (lvl < 0.06) return;
    const t0 = this.ac.currentTime;
    const syllables = 2 + ((Math.random() * 3) | 0);
    let cursor = 0;

    for (let i = 0; i < syllables; i++) {
      const dur = 0.16 + Math.random() * 0.16;
      const st = t0 + cursor;
      cursor += dur + 0.05 + Math.random() * 0.08;

      // Breathy syllabic sibilant / consonant air
      const nSrc = this.ac.createBufferSource();
      nSrc.buffer = this.noiseBuf;
      const bp = this.ac.createBiquadFilter();
      bp.type = 'bandpass';
      const fStart = 950 + Math.random() * 1100;
      bp.frequency.setValueAtTime(fStart, st);
      bp.frequency.exponentialRampToValueAtTime(Math.max(450, fStart * (0.65 + Math.random() * 0.6)), st + dur);
      bp.Q.value = 5.5;

      const gN = this.ac.createGain();
      const peak = (0.04 + lvl * 0.16) * (0.75 + Math.random() * 0.45);
      gN.gain.setValueAtTime(0.0001, st);
      gN.gain.linearRampToValueAtTime(peak, st + dur * 0.28);
      gN.gain.exponentialRampToValueAtTime(0.0001, st + dur);

      nSrc.connect(bp);
      bp.connect(gN);
      this.connectPanned(gN, pan);
      nSrc.start(st);
      nSrc.stop(st + dur + 0.04);

      // Faint hoarse under-mutter formant
      if (Math.random() < 0.6) {
        const osc = this.ac.createOscillator();
        osc.type = 'triangle';
        const f0 = 155 + Math.random() * 65;
        osc.frequency.setValueAtTime(f0, st);
        osc.frequency.exponentialRampToValueAtTime(f0 * 0.72, st + dur);

        const gO = this.ac.createGain();
        gO.gain.setValueAtTime(0.0001, st);
        gO.gain.linearRampToValueAtTime(peak * 0.25, st + dur * 0.25);
        gO.gain.exponentialRampToValueAtTime(0.0001, st + dur);

        osc.connect(gO);
        this.connectPanned(gO, pan);
        osc.start(st);
        osc.stop(st + dur + 0.04);
      }
    }
  }

  public sting(): void {
    this.tone('sawtooth', 440, 70, 0.24, 0.9);
    this.tone('square', 233, 60, 0.11, 0.9);
  }

  public swing(): void {
    this.noise(0.35, 0.4, 1400);
  }

  public groan(): void {
    this.tone('sawtooth', 90, 45, 0.18, 1.2);
  }

  public chime(): void {
    this.tone('sine', 880, 880, 0.16, 0.5);
    this.tone('sine', 1320, 1320, 0.12, 0.6, 0.12);
  }

  public hit(): void {
    this.noise(0.9, 0.6, 500);
    this.tone('sine', 90, 25, 0.9, 0.7);
  }

  public bang(): void {
    this.noise(0.5, 0.5, 600);
    this.tone('sine', 70, 30, 0.5, 0.4);
  }

  public creak(v: number): void {
    this.tone('sawtooth', 155, 88, v, 0.42);
  }

  public floorCreak(): void {
    this.tone('sawtooth', 190, 125, 0.16, 0.32);
    this.tone('triangle', 260, 180, 0.08, 0.28, 0.04);
  }

  public trapSnap(): void {
    this.noise(0.85, 0.16, 2800);
    this.tone('square', 520, 120, 0.35, 0.15);
    this.tone('sawtooth', 140, 60, 0.3, 0.3, 0.04);
  }

  public dropNoise(isCeramic: boolean): void {
    if (isCeramic) {
      this.noise(0.75, 0.35, 4200);
      this.tone('triangle', 1200, 420, 0.25, 0.18);
      this.tone('triangle', 1650, 680, 0.2, 0.15, 0.05);
    } else {
      this.noise(0.55, 0.2, 2200);
      this.tone('square', 460, 190, 0.22, 0.12);
    }
  }

  public lockBreak(): void {
    this.noise(0.45, 0.22, 1900);
    this.tone('triangle', 320, 160, 0.2, 0.2);
  }

  public door(): void {
    this.tone('sawtooth', 70, 40, 0.2, 1.2);
    this.noise(0.2, 0.8, 300);
  }

  public shot(): void {
    this.noise(0.9, 0.3, 3000);
    this.tone('square', 220, 40, 0.4, 0.22);
    this.noise(0.5, 0.7, 350);
  }

  public clockTick(): void {
    this.tone('triangle', 720, 400, 0.04, 0.03);
  }

  public paperRustle(): void {
    this.noise(0.18, 0.18, 2800);
    this.noise(0.12, 0.14, 3600, 0.09);
  }

  public pad(freqs: number[], dur: number, vol: number): void {
    if (!this.ac || !this.master) return;
    const t = this.ac.currentTime;
    freqs.forEach((f) => {
      if (!this.ac || !this.master) return;
      const o = this.ac.createOscillator();
      const g = this.ac.createGain();
      o.type = 'triangle';
      o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + dur * 0.4);
      g.gain.linearRampToValueAtTime(0.0001, t + dur);
      o.connect(g);
      g.connect(this.master);
      o.start(t);
      o.stop(t + dur + 0.1);
    });
  }

  public kick(v: number): void {
    this.tone('sine', 130, 38, v, 0.24);
  }

  public whoosh(): void {
    this.noise(0.28, 0.45, 2400);
  }

  // ---------- Spatial Abandoned-House Ambient Sounds ----------
  public windGust(vol = 0.14, pan = 0): void {
    if (!this.ac || !this.longNoiseBuf || !this.ambientBus) return;
    const t = this.ac.currentTime;
    const dur = 2.6 + Math.random() * 1.4;

    const src = this.ac.createBufferSource();
    src.buffer = this.longNoiseBuf;
    src.loop = true;

    const filter = this.ac.createBiquadFilter();
    filter.type = 'bandpass';
    filter.Q.value = 3.2;
    const baseF = 180 + Math.random() * 110;
    const peakF = baseF + 190 + Math.random() * 140;
    filter.frequency.setValueAtTime(baseF, t);
    filter.frequency.exponentialRampToValueAtTime(peakF, t + dur * 0.42);
    filter.frequency.exponentialRampToValueAtTime(Math.max(110, baseF * 0.75), t + dur);

    const gain = this.ac.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(Math.max(0.001, vol), t + dur * 0.35);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    src.connect(filter);
    filter.connect(gain);
    this.connectPanned(gain, pan);

    src.start(t);
    src.stop(t + dur + 0.08);
  }

  public ambientFloorCreak(vol = 0.08, pan = 0): void {
    if (!this.ac || !this.ambientBus) return;
    const t = this.ac.currentTime;
    const dur = 0.45 + Math.random() * 0.45;
    const fStart = 125 + Math.random() * 65;
    const fEnd = fStart * (0.62 + Math.random() * 0.18);

    const osc = this.ac.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(fStart, t);
    osc.frequency.exponentialRampToValueAtTime(fEnd, t + dur);

    // Bandpass shapes the wood-groan timbre so it sounds distant & hollow
    const filter = this.ac.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 340 + Math.random() * 160;
    filter.Q.value = 2.8;

    const gain = this.ac.createGain();
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(vol, t + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);

    osc.connect(filter);
    filter.connect(gain);
    this.connectPanned(gain, pan);
    osc.start(t);
    osc.stop(t + dur + 0.05);

    // Subtle secondary wood snap/settling tick
    if (Math.random() < 0.65 && this.noiseBuf) {
      const nSrc = this.ac.createBufferSource();
      nSrc.buffer = this.noiseBuf;
      const nFilter = this.ac.createBiquadFilter();
      nFilter.type = 'lowpass';
      nFilter.frequency.value = 550;
      const nGain = this.ac.createGain();
      const t2 = t + dur * 0.45;
      nGain.gain.setValueAtTime(vol * 0.35, t2);
      nGain.gain.exponentialRampToValueAtTime(0.0001, t2 + 0.12);
      nSrc.connect(nFilter);
      nFilter.connect(nGain);
      this.connectPanned(nGain, pan);
      nSrc.start(t2);
      nSrc.stop(t2 + 0.15);
    }
  }

  public distantFootsteps(steps = 4, vol = 0.11, panStart = 0, floorAbove = false): void {
    if (!this.ac || !this.noiseBuf || !this.ambientBus) return;
    const t0 = this.ac.currentTime;
    const cadence = 0.48 + Math.random() * 0.18;
    const panDrift = (Math.random() - 0.5) * 0.35;

    for (let i = 0; i < steps; i++) {
      const stepT = t0 + i * cadence + (Math.random() - 0.5) * 0.04;
      const stepPan = Math.max(-0.95, Math.min(0.95, panStart + (i / steps) * panDrift));
      const stepVol = vol * (0.75 + 0.25 * Math.sin((i / Math.max(1, steps - 1)) * Math.PI));

      // Muffled thud (foot impact through walls/ceiling)
      const osc = this.ac.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(floorAbove ? 78 : 66, stepT);
      osc.frequency.exponentialRampToValueAtTime(28, stepT + 0.16);

      const gOsc = this.ac.createGain();
      gOsc.gain.setValueAtTime(0.0001, stepT);
      gOsc.gain.linearRampToValueAtTime(stepVol, stepT + 0.015);
      gOsc.gain.exponentialRampToValueAtTime(0.0001, stepT + 0.19);

      osc.connect(gOsc);
      this.connectPanned(gOsc, stepPan);
      osc.start(stepT);
      osc.stop(stepT + 0.22);

      // Faint floorboard scuff
      const nSrc = this.ac.createBufferSource();
      nSrc.buffer = this.noiseBuf;
      const filt = this.ac.createBiquadFilter();
      filt.type = 'lowpass';
      filt.frequency.value = floorAbove ? 420 : 320;
      const gN = this.ac.createGain();
      gN.gain.setValueAtTime(stepVol * 0.4, stepT);
      gN.gain.exponentialRampToValueAtTime(0.0001, stepT + 0.11);
      nSrc.connect(filt);
      filt.connect(gN);
      this.connectPanned(gN, stepPan);
      nSrc.start(stepT);
      nSrc.stop(stepT + 0.14);
    }
  }

  public houseRattle(vol = 0.09, pan = 0): void {
    if (!this.ac || !this.noiseBuf || !this.ambientBus) return;
    const t = this.ac.currentTime;
    const hits = 2 + Math.floor(Math.random() * 2);
    for (let i = 0; i < hits; i++) {
      const ht = t + i * (0.09 + Math.random() * 0.07);
      const osc = this.ac.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(95 + Math.random() * 40, ht);
      osc.frequency.exponentialRampToValueAtTime(42, ht + 0.14);
      const g = this.ac.createGain();
      g.gain.setValueAtTime(vol * (1 - i * 0.2), ht);
      g.gain.exponentialRampToValueAtTime(0.0001, ht + 0.16);
      osc.connect(g);
      this.connectPanned(g, pan);
      osc.start(ht);
      osc.stop(ht + 0.18);
    }
  }
}

export const Snd = new HorrorAudioEngine();
