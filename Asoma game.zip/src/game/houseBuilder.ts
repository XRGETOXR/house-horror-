import * as THREE from 'three';
import {
  ALL_ROOMS,
  DIARY_NOTES,
  DOOR_W,
  EYE_UNDER_BED,
  FY,
  HALL_H,
  ROOMS_FLOOR_0,
  ROOMS_FLOOR_1,
  STAIR_BOUNDS,
  WALL_H,
  WALL_T,
} from './constants';
import {
  createTextTexture,
  GameTextures,
  paintingTexture,
  rand,
  rugTexture,
} from './textures';
import {
  Box2D,
  CreakBoard,
  DiaryNoteWorldItem,
  DoorDef,
  HeldItemType,
  HideSpot,
  RoomDef,
  SearchSpot,
} from './types';

export interface NavNode {
  x: number;
  z: number;
  fl: 0 | 1;
  adj: { n: number; d: number }[];
}

export interface HouseBuildResult {
  floors: [{ co: Box2D[]; bl: Box2D[]; g: THREE.Group }, { co: Box2D[]; bl: Box2D[]; g: THREE.Group }];
  doors: DoorDef[];
  closets: HideSpot[];
  spots: SearchSpot[];
  diaryNotes: DiaryNoteWorldItem[];
  creakBoards: CreakBoard[];
  nodes: NavNode[];
  roomNode: Record<string, number>;
  lampLights: THREE.PointLight[];
  lampBulbs: THREE.Mesh[];
  safeObj: {
    g: THREE.Group;
    piv: THREE.Group;
    sd: THREE.Group;
    led: THREE.Mesh;
  };
  exitDoorPivot: THREE.Group;
  exitBox: Box2D;
  exitPlankMesh: THREE.Mesh;
  exitWireMesh: THREE.Group;
  exitPanelMesh: THREE.Mesh;
  outPane: THREE.Mesh;
  outdoorGroup: THREE.Group;
  sunLight: THREE.DirectionalLight;
  sunSprite: THREE.Sprite;
  pendulum: THREE.Group;
  rockingChair: THREE.Group;
  createPropMesh: (kind: Exclude<HeldItemType, null>) => THREE.Group;
}

export function buildHouseWorld(
  scene: THREE.Scene,
  tex: GameTextures,
  maxAniso: number
): HouseBuildResult {
  const FL: [{ co: Box2D[]; bl: Box2D[]; g: THREE.Group }, { co: Box2D[]; bl: Box2D[]; g: THREE.Group }] = [
    { co: [], bl: [], g: new THREE.Group() },
    { co: [], bl: [], g: new THREE.Group() },
  ];
  FL[1].g.position.y = FY;
  scene.add(FL[0].g);
  scene.add(FL[1].g);

  let CUR: 0 | 1 = 0;
  let colliders = FL[0].co;
  let blockers = FL[0].bl;
  let CURG = FL[0].g;

  const setBuild = (f: 0 | 1) => {
    CUR = f;
    colliders = FL[f].co;
    blockers = FL[f].bl;
    CURG = FL[f].g;
  };

  const wallMatCache: Record<string, THREE.MeshStandardMaterial> = {};
  const wallMat = (len: number, h: number) => {
    const k = `${Math.round(len * 2)}_${Math.round(h * 2)}`;
    if (!wallMatCache[k]) {
      const t = tex.wall.clone();
      t.needsUpdate = true;
      t.colorSpace = THREE.SRGBColorSpace;
      t.wrapS = t.wrapT = THREE.RepeatWrapping;
      t.repeat.set(Math.max(1, len / 3), Math.max(1, h / 3));
      t.anisotropy = maxAniso;
      wallMatCache[k] = new THREE.MeshStandardMaterial({
        map: t,
        roughness: 0.9,
        metalness: 0.04,
      });
    }
    return wallMatCache[k];
  };

  const matP = (col: number, roughness = 0.85, metalness = 0.05) =>
    new THREE.MeshStandardMaterial({ color: col, roughness, metalness });

  const mk = (
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number
  ) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    return m;
  };

  const box1 = (x1: number, x2: number, z1: number, z2: number) => {
    FL[CUR].co.push({ x1, x2, z1, z2 });
  };

  const wallSeg = (ax: 'x' | 'z', fixed: number, a: number, b: number, h: number) => {
    const len = b - a;
    if (len < 0.02) return;
    const cx = ax === 'x' ? (a + b) / 2 : fixed;
    const cz = ax === 'x' ? fixed : (a + b) / 2;
    const w = ax === 'x' ? len : WALL_T;
    const d = ax === 'x' ? WALL_T : len;
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat(len, h));
    m.position.set(cx, h / 2, cz);
    CURG.add(m);
    const box: Box2D = { x1: cx - w / 2, x2: cx + w / 2, z1: cz - d / 2, z2: cz + d / 2 };
    colliders.push(box);
    blockers.push(box);
  };

  const wallDoors = (
    ax: 'x' | 'z',
    fixed: number,
    from: number,
    to: number,
    doorsList: number[],
    h: number
  ) => {
    const pts = doorsList.slice().sort((p, q) => p - q);
    let cur = from - WALL_T / 2;
    pts.forEach((c) => {
      const a = c - DOOR_W / 2;
      const b = c + DOOR_W / 2;
      wallSeg(ax, fixed, cur, a, h);
      if (h > 2.8) {
        const lh = h - 2.8;
        const lm = new THREE.Mesh(
          new THREE.BoxGeometry(ax === 'x' ? DOOR_W : WALL_T, lh, ax === 'x' ? WALL_T : DOOR_W),
          wallMat(DOOR_W, lh)
        );
        lm.position.set(ax === 'x' ? c : fixed, 2.8 + lh / 2, ax === 'x' ? fixed : c);
        CURG.add(lm);
      }
      cur = b;
    });
    wallSeg(ax, fixed, cur, to + WALL_T / 2, h);
  };

  const F = (
    x: number,
    z: number,
    w: number,
    d: number,
    h: number,
    col: number,
    o: { map?: THREE.Texture; y?: number; nocol?: boolean } = {}
  ) => {
    const mat = o.map
      ? new THREE.MeshStandardMaterial({ map: o.map, roughness: 0.85, metalness: 0.05 })
      : matP(col);
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, (o.y || 0) + h / 2, z);
    CURG.add(m);
    const b: Box2D = { x1: x - w / 2, x2: x + w / 2, z1: z - d / 2, z2: z + d / 2 };
    if (!o.nocol) {
      colliders.push(b);
      if (h >= 1.8) blockers.push(b);
    }
    return { mesh: m, box: b };
  };

  const deco = (x: number, y: number, z: number, w: number, h: number, d: number, col: number) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), matP(col));
    m.position.set(x, y + h / 2, z);
    CURG.add(m);
    return m;
  };

  const planeAt = (
    w: number,
    d: number,
    x: number,
    y: number,
    z: number,
    rx: number,
    mat: THREE.Material
  ) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mat);
    m.rotation.x = rx;
    m.position.set(x, y, z);
    CURG.add(m);
    return m;
  };

  const addText = (
    txt: string,
    x: number,
    y: number,
    z: number,
    ry: number,
    w: number,
    h: number,
    col: string,
    basic = false
  ) => {
    const t = createTextTexture(txt, 'bold 96px Lalezar, Tajawal, sans-serif', col);
    const mat = basic
      ? new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false })
      : new THREE.MeshStandardMaterial({
          map: t,
          transparent: true,
          depthWrite: false,
          roughness: 0.9,
        });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    m.position.set(x, y, z);
    m.rotation.y = ry;
    CURG.add(m);
    return m;
  };

  const freeAt = (x: number, z: number, hw: number, hd: number, m: number) => {
    const co = FL[CUR].co;
    for (let i = 0; i < co.length; i++) {
      const b = co[i];
      if (x + hw + m > b.x1 && x - hw - m < b.x2 && z + hd + m > b.z1 && z - hd - m < b.z2) {
        return false;
      }
    }
    return true;
  };

  const closets: HideSpot[] = [];
  const ROOM: Record<string, RoomDef> = {};
  ALL_ROOMS.forEach((r) => {
    ROOM[r.id] = r;
  });

  const C = (x: number, z: number, w: number, d: number, room: string) => {
    const o = F(x, z, w, d, 2.3, 0, { map: tex.closet });
    const r = ROOM[room];
    let ex = x;
    let ez = z;
    const rdx = r.cx - x;
    const rdz = r.cz - z;
    if (Math.abs(rdx) > Math.abs(rdz)) ex = x + (rdx > 0 ? 1 : -1) * (w / 2 + 0.9);
    else ez = z + (rdz > 0 ? 1 : -1) * (d / 2 + 0.9);
    closets.push({
      x,
      z,
      w,
      d,
      box: o.box,
      exit: { x: ex, z: ez },
      room,
      kind: 'closet',
      eye: 1.5,
      fl: CUR,
      peekSlits: true,
    });
  };

  const CR = (x: number, z: number, room: string) => {
    const o = F(x, z, 1.5, 1.5, 1.5, 0, { map: tex.crate });
    const r = ROOM[room];
    let ex = x;
    let ez = z;
    const rdx = r.cx - x;
    const rdz = r.cz - z;
    if (Math.abs(rdx) > Math.abs(rdz)) ex = x + (rdx > 0 ? 1 : -1) * 1.65;
    else ez = z + (rdz > 0 ? 1 : -1) * 1.65;
    closets.push({
      x,
      z,
      w: 1.5,
      d: 1.5,
      box: o.box,
      exit: { x: ex, z: ez },
      room,
      kind: 'crate',
      eye: 0.95,
      fl: CUR,
      peekSlits: true,
    });
  };

  const addHideableBed = (
    x: number,
    z: number,
    w: number,
    d: number,
    room: string,
    exitSide: 'east' | 'west' | 'south' | 'north'
  ) => {
    // Elevated bed frame so player can crawl/hide underneath like Granny!
    const frameMat = matP(0x4a3b38);
    const legMat = matP(0x2d2018);
    const mattressMat = matP(0x6a5a52);
    const blanketMat = matP(0x5a2220);

    // 4 legs
    const lx = w / 2 - 0.14;
    const lz = d / 2 - 0.14;
    [
      [-lx, -lz],
      [lx, -lz],
      [-lx, lz],
      [lx, lz],
    ].forEach(([ox, oz]) => {
      deco(x + ox, 0, z + oz, 0.18, 0.55, 0.18, 0x2d2018);
    });
    // Raised bed base (from y=0.52 to y=0.76)
    const base = new THREE.Mesh(new THREE.BoxGeometry(w, 0.24, d), frameMat);
    base.position.set(x, 0.64, z);
    CURG.add(base);
    // Mattress + pillow + blanket
    const matt = new THREE.Mesh(new THREE.BoxGeometry(w - 0.16, 0.18, d - 0.2), mattressMat);
    matt.position.set(x, 0.85, z);
    CURG.add(matt);
    const blanket = new THREE.Mesh(new THREE.BoxGeometry(w - 0.14, 0.08, d * 0.6), blanketMat);
    blanket.position.set(x, 0.96, z + d * 0.15);
    CURG.add(blanket);
    const pillow = new THREE.Mesh(new THREE.BoxGeometry(w * 0.7, 0.12, 0.55), matP(0xbdb4a6));
    pillow.position.set(x, 0.96, z - d / 2 + 0.45);
    CURG.add(pillow);
    // Headboard
    const headb = new THREE.Mesh(new THREE.BoxGeometry(w, 1.35, 0.14), legMat);
    headb.position.set(x, 0.675, z - d / 2 + 0.07);
    CURG.add(headb);

    const b: Box2D = { x1: x - w / 2, x2: x + w / 2, z1: z - d / 2, z2: z + d / 2 };
    colliders.push(b);

    let ex = x;
    let ez = z;
    if (exitSide === 'east') ex = x + w / 2 + 0.85;
    else if (exitSide === 'west') ex = x - w / 2 - 0.85;
    else if (exitSide === 'south') ez = z + d / 2 + 0.85;
    else ez = z - d / 2 - 0.85;

    closets.push({
      x,
      z,
      w,
      d,
      box: b,
      exit: { x: ex, z: ez },
      room,
      kind: 'bed',
      eye: EYE_UNDER_BED,
      fl: CUR,
      peekSlits: false,
    });
  };

  // ---------- Doors ----------
  const doors: DoorDef[] = [];
  const doorMat = matP(0x4a3322);
  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xb58a3a,
    roughness: 0.28,
    metalness: 0.88,
  });

  const addDoor = (ax: 'x' | 'z', fixed: number, c: number) => {
    const w = DOOR_W - 0.06;
    const piv = new THREE.Group();
    const hinge = c - DOOR_W / 2 + 0.03;
    if (ax === 'x') piv.position.set(hinge, 0, fixed);
    else piv.position.set(fixed, 0, hinge);

    const leaf = new THREE.Mesh(
      new THREE.BoxGeometry(ax === 'x' ? w : 0.12, 2.78, ax === 'x' ? 0.12 : w),
      doorMat
    );
    leaf.position.set(ax === 'x' ? w / 2 : 0, 1.39, ax === 'x' ? 0 : w / 2);
    piv.add(leaf);

    const kn = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), brassMat);
    kn.position.set(ax === 'x' ? w - 0.25 : 0, 1.05, ax === 'x' ? 0 : w - 0.25);
    const kb = kn.clone();
    if (ax === 'x') {
      kn.position.z = 0.09;
      kb.position.z = -0.09;
    } else {
      kn.position.x = 0.09;
      kb.position.x = -0.09;
    }
    piv.add(kn, kb);
    CURG.add(piv);

    const box: Box2D =
      ax === 'x'
        ? { x1: c - DOOR_W / 2, x2: c + DOOR_W / 2, z1: fixed - 0.07, z2: fixed + 0.07 }
        : { x1: fixed - 0.07, x2: fixed + 0.07, z1: c - DOOR_W / 2, z2: c + DOOR_W / 2 };
    colliders.push(box);
    blockers.push(box);
    doors.push({
      fl: CUR,
      ax,
      fixed,
      c,
      piv,
      box,
      ang: 0,
      target: 0,
      side: 1,
      solid: true,
      cx: ax === 'x' ? c : fixed,
      cz: ax === 'x' ? fixed : c,
    });
  };

  // ---------- Ground Floor Shell & Walls ----------
  setBuild(0);
  const fm = new THREE.MeshStandardMaterial({
    map: tex.floor,
    roughness: 0.85,
    metalness: 0.05,
  });
  planeAt(60, 56, 30, 0, 28, -Math.PI / 2, fm);

  ROOMS_FLOOR_0.forEach((r) => {
    const t = tex.ceil.clone();
    t.needsUpdate = true;
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set((r.x2 - r.x1) / 3, (r.z2 - r.z1) / 3);
    planeAt(
      r.x2 - r.x1,
      r.z2 - r.z1,
      r.cx,
      WALL_H,
      r.cz,
      Math.PI / 2,
      new THREE.MeshStandardMaterial({ map: t, roughness: 0.95 })
    );
  });

  // Red runner carpet along main hallway
  planeAt(
    56,
    2.4,
    30,
    0.012,
    20,
    -Math.PI / 2,
    new THREE.MeshStandardMaterial({ color: 0x4a1210, roughness: 0.92 })
  );

  const NEWDOORS = [10, 31, 52];
  const north = ROOMS_FLOOR_0.slice(0, 5).map((r) => r.cx);
  const south = ROOMS_FLOOR_0.slice(5, 9).map((r) => r.cx);
  wallDoors('x', 16, 0, 60, north, HALL_H);
  wallDoors('x', 24, 0, 60, south, HALL_H);
  wallSeg('z', 0, 16 - WALL_T / 2, 24 + WALL_T / 2, HALL_H);
  wallSeg('z', 60, 16 - WALL_T / 2, 24 + WALL_T / 2, HALL_H);
  wallDoors('x', 0, 0, 60, [], WALL_H);
  wallDoors('x', 40, 0, 60, NEWDOORS, WALL_H);
  wallDoors('x', 56, 0, 60, [], WALL_H);
  wallDoors('z', 0, 0, 16, [], WALL_H);
  wallDoors('z', 0, 24, 56, [], WALL_H);
  wallDoors('z', 60, 0, 16, [], WALL_H);
  wallDoors('z', 60, 24, 56, [ROOM.exit.cz], WALL_H);
  [14, 28, 42, 52].forEach((x) => {
    wallDoors('z', x, 0, 16, [8], WALL_H);
    addDoor('z', x, 8);
  });
  [18, 34, 46].forEach((x) => {
    wallDoors('z', x, 24, 40, [32], WALL_H);
    addDoor('z', x, 32);
  });
  [20, 40].forEach((x) => {
    wallDoors('z', x, 40, 56, [48], WALL_H);
    addDoor('z', x, 48);
  });
  north.forEach((c) => addDoor('x', 16, c));
  south.forEach((c) => addDoor('x', 24, c));
  NEWDOORS.forEach((c) => addDoor('x', 40, c));

  // ---------- Ground Floor Furniture ----------
  // Bedroom (hideable bed!)
  addHideableBed(2.4, 3.6, 2.4, 3.4, 'bed', 'east');
  F(5.0, 0.8, 0.9, 0.9, 0.6, 0x3b2a1e);
  F(1.2, 13.4, 1.2, 2.4, 1.0, 0x3b2a1e);
  F(12.2, 13.2, 0.8, 0.8, 0.9, 0x4a3322);
  C(11.5, 0.9, 2.0, 1.1, 'bed');

  // Kitchen
  F(19, 0.7, 6, 1.2, 1.0, 0x555048);
  F(25, 4, 2.2, 1.6, 0.9, 0x4a3a2a);
  F(27.2, 12.5, 1.2, 1.2, 2.0, 0x8a8a84);
  deco(24.2, 0.9, 3.6, 0.4, 0.4, 0.4, 0x606060);
  C(15.2, 13.5, 1.2, 2.0, 'kit');

  // Library
  F(31.5, 0.7, 5, 0.6, 2.6, 0x2e2016);
  F(38.5, 0.7, 5, 0.6, 2.6, 0x2e2016);
  F(40.2, 11.5, 2.4, 1.2, 0.85, 0x4a3322);
  F(30.5, 4, 0.9, 0.9, 0.9, 0x5a2a2a);
  C(29.2, 13.6, 1.2, 2.0, 'lib');

  // Bathroom
  F(44.5, 1.0, 2.2, 1.0, 0.7, 0x9a9a92);
  deco(44.5, 0.7, 1.0, 2.0, 0.1, 0.8, 0x5a0d0d);
  F(50.6, 0.8, 0.7, 0.8, 0.5, 0xa8a8a0);
  F(48.4, 0.5, 1.0, 0.6, 0.9, 0x9a9a92);
  C(43.2, 13.8, 1.0, 1.8, 'bath');

  // Storage
  F(59.2, 3.5, 0.8, 4, 2.2, 0x3a2a1c);
  F(53.4, 13.5, 1.0, 1.0, 1.0, 0x6a5030);
  F(54.6, 13.8, 1.0, 1.0, 1.0, 0x5a4228);
  F(58.5, 13.5, 0.9, 0.9, 1.0, 0x3a3a3a);

  // Living Room (with Grandfather Clock + Rocking Chair!)
  F(1.2, 27, 1.0, 2.6, 0.8, 0x3a2a30);
  F(14, 39.4, 2.4, 0.8, 0.9, 0x2a2a2a);
  F(4, 38.8, 0.8, 0.6, 2.2, 0x3b2a1e);
  F(13.5, 27.5, 2.0, 1.4, 0.7, 0x4a3322);
  C(17.3, 37.5, 1.0, 2.0, 'liv');

  // Grandfather Clock at (4, 38.8) decorative dial & pendulum
  const clockDial = new THREE.Mesh(
    new THREE.CircleGeometry(0.24, 16),
    new THREE.MeshStandardMaterial({ map: tex.clockFace, roughness: 0.4 })
  );
  clockDial.position.set(4, 1.82, 38.49);
  clockDial.rotation.y = Math.PI;
  CURG.add(clockDial);
  const pendulum = new THREE.Group();
  pendulum.position.set(4, 1.45, 38.46);
  const pRod = mk(new THREE.BoxGeometry(0.03, 0.6, 0.02), brassMat, 0, -0.3, 0);
  const pDisc = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.03, 14), brassMat);
  pDisc.rotation.x = Math.PI / 2;
  pDisc.position.set(0, -0.62, 0);
  pendulum.add(pRod, pDisc);
  CURG.add(pendulum);

  // Eerie Rocking Chair in Living Room
  const rockingChair = new THREE.Group();
  rockingChair.position.set(10.5, 0, 35.5);
  rockingChair.rotation.y = -0.6;
  const rcWood = matP(0x3a2416);
  rockingChair.add(mk(new THREE.BoxGeometry(0.65, 0.08, 0.62), rcWood, 0, 0.45, 0));
  rockingChair.add(mk(new THREE.BoxGeometry(0.65, 0.75, 0.08), rcWood, 0, 0.85, 0.27));
  [-0.28, 0.28].forEach((ox) => {
    rockingChair.add(mk(new THREE.BoxGeometry(0.06, 0.42, 0.06), rcWood, ox, 0.24, -0.24));
    rockingChair.add(mk(new THREE.BoxGeometry(0.06, 0.42, 0.06), rcWood, ox, 0.24, 0.24));
    rockingChair.add(mk(new THREE.BoxGeometry(0.06, 0.06, 0.85), rcWood, ox, 0.04, 0));
  });
  CURG.add(rockingChair);
  box1(9.9, 11.1, 34.9, 36.1);

  // Dining Room
  F(26, 37, 5, 1.6, 0.9, 0x4a3322);
  F(32.8, 26, 0.8, 3.0, 2.0, 0x3b2a1e);
  F(23.4, 35.6, 0.5, 0.5, 0.9, 0x3a2a1c);
  F(28.6, 35.6, 0.5, 0.5, 0.9, 0x3a2a1c);
  C(19.3, 37.5, 0.9, 1.8, 'din');

  // Nursery
  F(36.5, 38, 1.2, 2.0, 1.0, 0x7a6a5a);
  F(44.5, 26.5, 1.2, 0.8, 0.6, 0x5a3a2a);
  F(43.5, 37, 0.8, 0.9, 0.9, 0x4a3322);
  C(35.0, 26.5, 1.2, 2.0, 'nur');

  // Exit Hall
  F(55.5, 27, 0.9, 0.9, 3.3, 0x4a4640);
  F(55.5, 37, 0.9, 0.9, 3.3, 0x4a4640);
  F(48, 26.5, 1.2, 1.2, 1.0, 0x4a3a2a);
  C(47.1, 37.8, 1.0, 2.0, 'exit');

  // Hiding Crates
  CR(12.9, 14.6, 'bed');
  CR(16.2, 3.5, 'kit');
  CR(40.6, 3.6, 'lib');
  CR(50.6, 13.6, 'bath');
  CR(55.0, 2.4, 'stor');
  CR(1.6, 35.0, 'liv');
  CR(20.2, 26.5, 'din');
  CR(44.8, 38.6, 'nur');
  CR(58.5, 26.5, 'exit');

  // Laundry
  F(1.8, 42.2, 1.6, 1.4, 1.0, 0xb0b0a8);
  F(4.2, 42.2, 1.6, 1.4, 1.0, 0xa8a8a0);
  F(2.0, 53.8, 2.6, 1.4, 0.9, 0x5a4a3a);
  F(17.6, 54.2, 2.0, 1.2, 0.9, 0x6a6a66);
  C(18.8, 42.5, 1.0, 2.0, 'laun');
  CR(14.5, 52.5, 'laun');
  deco(8.0, 0, 53.6, 0.9, 0.5, 0.9, 0x6a5a40);

  // Studio
  F(23.5, 42, 0.6, 3, 2.0, 0x3a2a1c);
  F(36, 53.5, 3, 1.2, 0.9, 0x4a3a2a);
  F(21.5, 53.8, 1.0, 1.0, 1.0, 0x5a4a3a);
  C(38.8, 42.6, 1.0, 2.0, 'stu');
  CR(25.5, 54, 'stu');
  deco(30, 0, 54.2, 0.12, 1.9, 0.12, 0x2a1c10);
  deco(30, 1.0, 54.2, 1.0, 0.8, 0.08, 0x6a5a4a);

  // Cellar
  F(58.3, 42.2, 1.0, 1.0, 1.1, 0x3a3a3a);
  F(55, 41.8, 0.9, 0.9, 1.1, 0x3a3a3a);
  F(56.8, 53.8, 1.4, 1.4, 1.0, 0x6a5030);
  F(44, 54.2, 2.2, 1.2, 1.0, 0x5a4228);
  C(41.2, 42.6, 1.0, 2.0, 'cell');
  CR(58.6, 50.5, 'cell');

  // ---------- Iron Exit Door with 3 Granny Lock Layers ----------
  const exitDoorPivot = new THREE.Group();
  exitDoorPivot.position.set(60, 0, ROOM.exit.cz - DOOR_W / 2 + 0.02);
  const dm = new THREE.Mesh(
    new THREE.BoxGeometry(0.22, 2.78, DOOR_W - 0.05),
    new THREE.MeshStandardMaterial({ color: 0x2a2c30, roughness: 0.45, metalness: 0.78 })
  );
  dm.position.set(0, 1.39, (DOOR_W - 0.05) / 2);
  exitDoorPivot.add(dm);

  const bar = new THREE.Mesh(
    new THREE.BoxGeometry(0.3, 0.16, DOOR_W - 0.1),
    new THREE.MeshStandardMaterial({ color: 0x5a1010, roughness: 0.65 })
  );
  bar.position.set(-0.05, 1.4, (DOOR_W - 0.05) / 2);
  exitDoorPivot.add(bar);

  // Lock Layer 1: Wooden Barricade Plank (Hammer removes)
  const exitPlankMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.24, DOOR_W - 0.02),
    matP(0x6b4728)
  );
  exitPlankMesh.position.set(-0.15, 1.85, (DOOR_W - 0.05) / 2);
  exitPlankMesh.rotation.x = 0.06;
  exitDoorPivot.add(exitPlankMesh);

  // Lock Layer 2: Red Electric Wire & Padlock (Cutters cut)
  const exitWireMesh = new THREE.Group();
  const wireLine = new THREE.Mesh(
    new THREE.CylinderGeometry(0.022, 0.022, DOOR_W - 0.2, 8),
    new THREE.MeshStandardMaterial({ color: 0xc22020, roughness: 0.5 })
  );
  wireLine.rotation.x = Math.PI / 2;
  wireLine.position.set(-0.14, 1.05, (DOOR_W - 0.05) / 2);
  const lockBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.1, 0.22, 0.16),
    brassMat
  );
  lockBody.position.set(-0.15, 1.02, (DOOR_W - 0.05) / 2);
  exitWireMesh.add(wireLine, lockBody);
  exitDoorPivot.add(exitWireMesh);

  // Lock Layer 3: Screwed Metal Panel covering keyhole (Screwdriver opens)
  const exitPanelMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.44, 0.36),
    new THREE.MeshStandardMaterial({ color: 0x5c606a, roughness: 0.35, metalness: 0.85 })
  );
  exitPanelMesh.position.set(-0.15, 1.4, (DOOR_W - 0.05) / 2 + 0.55);
  exitDoorPivot.add(exitPanelMesh);

  CURG.add(exitDoorPivot);
  const exitBox: Box2D = {
    x1: 59.8,
    x2: 60.2,
    z1: ROOM.exit.cz - DOOR_W / 2,
    z2: ROOM.exit.cz + DOOR_W / 2,
    door: true,
  };
  colliders.push(exitBox);
  blockers.push(exitBox);

  const outPane = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 8),
    new THREE.MeshBasicMaterial({ color: 0x8fa4b8 })
  );
  outPane.position.set(64, 3, ROOM.exit.cz);
  outPane.rotation.y = -Math.PI / 2;
  CURG.add(outPane);
  planeAt(14, 14, 67, 0.01, ROOM.exit.cz, -Math.PI / 2, new THREE.MeshBasicMaterial({ color: 0x56626e }));

  // ---------- Blood Decals & Arabic Graffiti ----------
  const bm = new THREE.MeshStandardMaterial({
    map: tex.blood,
    transparent: true,
    depthWrite: false,
    roughness: 0.4,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const splat = (x: number, z: number, s: number) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(s, s), bm);
    m.rotation.x = -Math.PI / 2;
    m.rotation.z = rand(0, 6.28);
    m.position.set(x, 0.02, z);
    CURG.add(m);
  };
  ROOMS_FLOOR_0.forEach((r) => {
    for (let i = 0; i < 4; i++) splat(rand(r.x1 + 1.5, r.x2 - 1.5), rand(r.z1 + 1.5, r.z2 - 1.5), rand(1.2, 3));
  });
  for (let j = 0; j < 9; j++) splat(rand(4, 56), rand(17.2, 22.8), rand(1.5, 3.4));
  addText('اهرب', 15, 2.4, 16.19, 0, 3.6, 1.12, '#8d0f0c');
  addText('لا تنظر خلفك', 45, 2.4, 23.81, Math.PI, 4.4, 1.38, '#8d0f0c');
  addText('ابقَ هادئًا', 0.19, 1.9, 8, Math.PI / 2, 3.2, 1.0, '#8d0f0c');
  addText('هو يسمع كل شيء', 40, 2.2, 39.81, Math.PI, 3.6, 1.0, '#8d0f0c');
  addText('٥ أيام فقط', 48.4, 2.4, 39.81, Math.PI, 3.2, 1.0, '#8d0f0c');
  addText('مخرج', 59.83, 3.05, ROOM.exit.cz, -Math.PI / 2, 1.5, 0.47, '#46ff82', true);

  // ---------- Stairs ----------
  const s = STAIR_BOUNDS;
  const sdx = s.x2 - s.x1;
  const L = Math.hypot(sdx, FY);
  const ang = Math.atan2(FY, sdx);
  const scx = (s.x1 + s.x2) / 2;
  const scz = (s.z1 + s.z2) / 2;
  const sw = s.z2 - s.z1;

  const stTex = tex.stairs.clone();
  stTex.needsUpdate = true;
  stTex.colorSpace = THREE.SRGBColorSpace;
  stTex.wrapS = stTex.wrapT = THREE.RepeatWrapping;
  stTex.repeat.set(L / 0.85, 1);
  const ramp = new THREE.Mesh(
    new THREE.BoxGeometry(L, 0.22, sw),
    new THREE.MeshStandardMaterial({ map: stTex, roughness: 0.85 })
  );
  ramp.position.set(scx, FY / 2 - 0.12, scz);
  ramp.rotation.z = ang;
  scene.add(ramp);

  const darkWood = matP(0x2a1c10, 0.9);
  const sh = new THREE.Shape();
  sh.moveTo(0, 0);
  sh.lineTo(sdx, 0);
  sh.lineTo(sdx, FY);
  sh.closePath();
  const geo = new THREE.ExtrudeGeometry(sh, { depth: 0.12, bevelEnabled: false });
  const s1 = new THREE.Mesh(geo, darkWood);
  s1.position.set(s.x1, 0, s.z1 - 0.12);
  scene.add(s1);
  const s2 = new THREE.Mesh(geo, darkWood);
  s2.position.set(s.x1, 0, s.z2);
  scene.add(s2);
  const endw = new THREE.Mesh(new THREE.BoxGeometry(0.15, FY, sw + 0.24), darkWood);
  endw.position.set(s.x2 + 0.075, FY / 2, scz);
  scene.add(endw);

  setBuild(0);
  box1(s.x1, s.x2, s.z1 - 0.2, s.z1);
  box1(s.x1, s.x2, s.z2, s.z2 + 0.2);
  box1(s.x2, s.x2 + 0.2, s.z1 - 0.2, s.z2 + 0.2);
  const stairLamp = new THREE.PointLight(0xffb060, 0.75, 10, 2);
  stairLamp.position.set(s.x1 + 1.5, 2.6, scz);
  scene.add(stairLamp);

  // ---------- Second Floor ----------
  setBuild(1);
  const floorPiece = (x1: number, z1: number, x2: number, z2: number) => {
    if (x2 - x1 < 0.05 || z2 - z1 < 0.05) return;
    const t = tex.floor.clone();
    t.needsUpdate = true;
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set((x2 - x1) / 2, (z2 - z1) / 2);
    const m = new THREE.Mesh(
      new THREE.PlaneGeometry(x2 - x1, z2 - z1),
      new THREE.MeshStandardMaterial({ map: t, roughness: 0.85, side: THREE.DoubleSide })
    );
    m.rotation.x = -Math.PI / 2;
    m.position.set((x1 + x2) / 2, 0, (z1 + z2) / 2);
    CURG.add(m);
  };
  floorPiece(0, 0, 60, s.z1);
  floorPiece(0, s.z2, 60, 56);
  floorPiece(0, s.z1, s.x1, s.z2);
  floorPiece(s.x2, s.z1, 60, s.z2);

  ROOMS_FLOOR_1.forEach((r) => {
    const t = tex.ceil.clone();
    t.needsUpdate = true;
    t.colorSpace = THREE.SRGBColorSpace;
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set((r.x2 - r.x1) / 3, (r.z2 - r.z1) / 3);
    planeAt(
      r.x2 - r.x1,
      r.z2 - r.z1,
      r.cx,
      WALL_H,
      r.cz,
      Math.PI / 2,
      new THREE.MeshStandardMaterial({ map: t, roughness: 0.95 })
    );
  });

  const ht = tex.ceil.clone();
  ht.needsUpdate = true;
  ht.colorSpace = THREE.SRGBColorSpace;
  ht.wrapS = ht.wrapT = THREE.RepeatWrapping;
  ht.repeat.set(20, 3);
  planeAt(60, 8, 30, HALL_H, 20, Math.PI / 2, new THREE.MeshStandardMaterial({ map: ht, roughness: 0.95 }));

  const nd = ROOMS_FLOOR_1.slice(0, 6).map((r) => r.cx);
  const ad = [6, 30, 42, 54];
  const bd = [7.5, 22.5, 37.5, 52.5];
  wallDoors('x', 16, 0, 60, nd, HALL_H);
  wallDoors('x', 24, 0, 60, ad, HALL_H);
  wallSeg('z', 0, 16 - WALL_T / 2, 24 + WALL_T / 2, HALL_H);
  wallSeg('z', 60, 16 - WALL_T / 2, 24 + WALL_T / 2, HALL_H);
  wallDoors('x', 0, 0, 60, [], WALL_H);
  wallDoors('x', 40, 0, 60, bd, WALL_H);
  wallDoors('x', 56, 0, 60, [], WALL_H);
  wallDoors('z', 0, 0, 16, [], WALL_H);
  wallDoors('z', 0, 24, 56, [], WALL_H);
  wallDoors('z', 60, 0, 16, [], WALL_H);
  wallDoors('z', 60, 24, 56, [], WALL_H);
  [10, 20, 30, 40, 50].forEach((x) => {
    wallDoors('z', x, 0, 16, [8], WALL_H);
    addDoor('z', x, 8);
  });
  [12, 24, 36, 48].forEach((x) => {
    wallDoors('z', x, 24, 40, [32], WALL_H);
    addDoor('z', x, 32);
  });
  [15, 30, 45].forEach((x) => {
    wallDoors('z', x, 40, 56, [48], WALL_H);
    addDoor('z', x, 48);
  });
  nd.forEach((c) => addDoor('x', 16, c));
  ad.forEach((c) => addDoor('x', 24, c));
  bd.forEach((c) => addDoor('x', 40, c));

  // Stairwell guardrails
  box1(s.x1, s.x2, s.z1 - 0.15, s.z1);
  box1(s.x1, s.x2, s.z2, s.z2 + 0.2);
  box1(s.x1 - 0.15, s.x1, s.z1 - 0.15, s.z2 + 0.2);
  const railMat = matP(0x2e2016);
  [0.5, 1.0].forEach((h) => {
    const a = new THREE.Mesh(new THREE.BoxGeometry(s.x2 - s.x1, 0.07, 0.07), railMat);
    a.position.set((s.x1 + s.x2) / 2, h, s.z1 - 0.07);
    CURG.add(a);
    const b = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, s.z2 - s.z1 + 0.3), railMat);
    b.position.set(s.x1 - 0.07, h, (s.z1 + s.z2) / 2 + 0.07);
    CURG.add(b);
  });
  for (let px = s.x1; px <= s.x2; px += 2.2) {
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.09, 1.0, 0.09), railMat);
    p.position.set(px, 0.5, s.z1 - 0.07);
    CURG.add(p);
  }

  // Second Floor Furniture (including hideable beds!)
  const kinds: ((x: number, z: number, rid: string) => void)[] = [
    (x, z, rid) => addHideableBed(x, z, 2.0, 3.0, rid, 'east'),
    (x, z) => F(x, z, 1.7, 1.1, 0.8, 0x4a3322),
    (x, z) => F(x, z, 2.6, 0.6, 2.2, 0x2e2016),
    (x, z) => F(x, z, 2.2, 0.9, 0.8, 0x3a2a30),
    (x, z) => F(x, z, 1.4, 1.2, 1.1, 0x2a2a2a),
  ];

  ROOMS_FLOOR_1.forEach((r, i) => {
    const wide = r.x2 - r.x1;
    const cc = [
      [r.x1 + 1.3, r.z2 - 0.75],
      [r.x2 - 1.3, r.z2 - 0.75],
      [r.x1 + 1.3, r.z1 + 0.75],
      [r.x2 - 1.3, r.z1 + 0.75],
    ];
    for (let a = 0; a < cc.length; a++) {
      if (freeAt(cc[a][0], cc[a][1], 1.0, 0.55, 0.5)) {
        C(cc[a][0], cc[a][1], 2.0, 1.1, r.id);
        break;
      }
    }
    const cr = [
      [r.x2 - 1.2, r.z1 + 1.2],
      [r.x1 + 1.2, r.z1 + 1.2],
      [r.x2 - 1.2, r.z2 - 1.2],
      [r.x1 + 1.2, r.z2 - 1.2],
    ];
    for (let b = 0; b < cr.length; b++) {
      if (freeAt(cr[b][0], cr[b][1], 0.75, 0.75, 0.7)) {
        CR(cr[b][0], cr[b][1], r.id);
        break;
      }
    }
    const fp = [
      [r.cx - wide * 0.3, r.z1 + 2.0],
      [r.cx + wide * 0.3, r.z1 + 2.0],
      [r.cx - wide * 0.3, r.z2 - 2.4],
      [r.cx + wide * 0.3, r.z2 - 2.4],
    ];
    let placed = 0;
    for (let c = 0; c < fp.length && placed < 2; c++) {
      const k = kinds[(i + c) % kinds.length];
      if (freeAt(fp[c][0], fp[c][1], 1.4, 1.5, 0.9)) {
        k(fp[c][0], fp[c][1], r.id);
        placed++;
      }
    }
  });

  addText('لا تنظر إلى الأسفل', 48, 2.5, 15.81, 0, 3.8, 1.2, '#8d0f0c');
  addText('اهرب', 0.19, 2.0, 5, Math.PI / 2, 2.4, 0.75, '#8d0f0c');
  addText('هو في الأسفل', 30, 2.4, 24.19, Math.PI, 3.2, 1.0, '#8d0f0c');

  // ---------- Dress House (Door frames, Rugs, Paintings, Windows, Cobwebs) ----------
  const woodTrim = matP(0x2e2016);
  doors.forEach((d) => {
    setBuild(d.fl);
    const hw = DOOR_W / 2 + 0.05;
    const ax = d.ax === 'x';
    CURG.add(mk(new THREE.BoxGeometry(ax ? 0.14 : 0.26, 2.9, ax ? 0.26 : 0.14), woodTrim, ax ? d.c - hw : d.fixed, 1.45, ax ? d.fixed : d.c - hw));
    CURG.add(mk(new THREE.BoxGeometry(ax ? 0.14 : 0.26, 2.9, ax ? 0.26 : 0.14), woodTrim, ax ? d.c + hw : d.fixed, 1.45, ax ? d.fixed : d.c + hw));
    CURG.add(mk(new THREE.BoxGeometry(ax ? DOOR_W + 0.34 : 0.26, 0.14, ax ? 0.26 : DOOR_W + 0.34), woodTrim, ax ? d.c : d.fixed, 2.87, ax ? d.fixed : d.c));
  });

  const skipRugs: Record<string, number> = { bath: 1, stor: 1, cell: 1, laun: 1, exit: 1 };
  const cobwebMat = new THREE.MeshBasicMaterial({
    map: tex.cobweb,
    transparent: true,
    side: THREE.DoubleSide,
    depthWrite: false,
  });

  ALL_ROOMS.forEach((r, ri) => {
    setBuild(r.fl);
    const w = r.x2 - r.x1;
    const dp = r.z2 - r.z1;
    if (!skipRugs[r.id]) {
      const rug = new THREE.Mesh(
        new THREE.PlaneGeometry(Math.min(4, w * 0.4), Math.min(3, dp * 0.3)),
        new THREE.MeshStandardMaterial({
          map: rugTexture(['#4a1a1a', '#1f2e3a', '#3a3020', '#2a1f33'][ri % 4], '#b08a4a', maxAniso),
          roughness: 0.92,
        })
      );
      rug.rotation.x = -Math.PI / 2;
      rug.position.set(r.cx, 0.014, r.cz);
      CURG.add(rug);
    }

    const northWall = r.z1 < 16;
    const wz = northWall ? r.z1 + 0.17 : r.z2 - 0.17;
    const ry = northWall ? 0 : Math.PI;
    const pt = new THREE.Mesh(
      new THREE.PlaneGeometry(0.9, 1.2),
      new THREE.MeshStandardMaterial({ map: paintingTexture(ri, maxAniso), roughness: 0.6 })
    );
    pt.position.set(r.x1 + w * 0.3, 2.0, wz);
    pt.rotation.y = ry;
    CURG.add(pt);
    CURG.add(
      mk(
        new THREE.BoxGeometry(1.02, 1.32, 0.05),
        matP(0x5a4020, 0.45),
        r.x1 + w * 0.3,
        2.0,
        wz + (northWall ? -0.02 : 0.02)
      )
    );

    if (northWall && r.fl === 0 && r.id !== 'bath') {
      const wd = new THREE.Mesh(
        new THREE.PlaneGeometry(1.3, 1.8),
        new THREE.MeshBasicMaterial({ map: tex.windowNight })
      );
      wd.position.set(r.x1 + w * 0.72, 1.9, wz);
      CURG.add(wd);
      CURG.add(mk(new THREE.BoxGeometry(1.46, 1.96, 0.05), woodTrim, r.x1 + w * 0.72, 1.9, wz - 0.02));
    }

    // Corner cobweb near ceiling
    if (ri % 2 === 0) {
      const cw = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.1), cobwebMat);
      cw.position.set(r.x1 + 0.55, WALL_H - 0.55, r.z1 + 0.2);
      CURG.add(cw);
    }
  });

  // ---------- Search Spots (Chests + Special Tool Chests + Ammo Boxes) ----------
  setBuild(0);
  const spots: SearchSpot[] = [];
  const addSpot = (
    fl: 0 | 1,
    x: number,
    z: number,
    label: string,
    col = 0xc0b0a0,
    special = false,
    item: SearchSpot['item'] = null
  ) => {
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({
      map: tex.crate,
      color: col,
      roughness: 0.82,
    });
    const bx = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.55, 0.65), mat);
    bx.position.y = 0.275;
    g.add(bx);
    const bn = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.1, 0.68), matP(0x2a2a2a, 0.5, 0.7));
    bn.position.y = 0.38;
    g.add(bn);
    g.position.set(x, 0, z);
    g.rotation.y = rand(0, 6.28);
    FL[fl].g.add(g);
    spots.push({
      fl,
      x,
      z,
      label,
      obj: g,
      mat,
      col,
      searched: false,
      key: false,
      item,
      special,
      hide: false,
      r: 1.75,
    });
  };

  ALL_ROOMS.forEach((r, ri) => {
    setBuild(r.fl);
    const cand = [
      [r.x1 + 1.1, r.z1 + 1.1],
      [r.x2 - 1.1, r.z1 + 1.1],
      [r.x1 + 1.1, r.z2 - 1.1],
      [r.x2 - 1.1, r.z2 - 1.1],
      [r.x1 + 1.1, r.cz],
      [r.x2 - 1.1, r.cz],
    ];
    for (let i = 0; i < cand.length; i++) {
      const p = cand[(i + ri) % cand.length];
      if (freeAt(p[0], p[1], 0.55, 0.4, 0.45)) {
        addSpot(r.fl, p[0], p[1], 'ابحث في الصندوق');
        break;
      }
    }
  });
  setBuild(0);
  addSpot(0, 25.4, 21.9, 'ابحث تحت الدرج', 0x7a6a5a);

  const cornerSpecial = (
    roomId: string,
    label: string,
    item: Exclude<SearchSpot['item'], null | 'ammo'>,
    col: number
  ) => {
    const r = ROOM[roomId];
    if (!r) return;
    setBuild(r.fl);
    const cand = [
      [r.x2 - 1.1, r.z2 - 1.1],
      [r.x1 + 1.1, r.z2 - 1.1],
      [r.x2 - 1.1, r.z1 + 1.1],
      [r.x1 + 1.1, r.z1 + 1.1],
    ];
    const ok = (p: number[], strict: boolean) => {
      if (strict) {
        for (let k = 0; k < spots.length; k++) {
          if (spots[k].fl === r.fl && Math.hypot(spots[k].x - p[0], spots[k].z - p[1]) < 1.8) {
            return false;
          }
        }
      }
      return freeAt(p[0], p[1], 0.55, 0.4, 0.45);
    };
    let chosen: number[] | null = null;
    for (let i = 0; i < cand.length && !chosen; i++) if (ok(cand[i], true)) chosen = cand[i];
    for (let i = 0; i < cand.length && !chosen; i++) if (ok(cand[i], false)) chosen = cand[i];
    if (!chosen) {
      for (let x = r.x1 + 1; x < r.x2 - 1 && !chosen; x += 1) {
        for (let z = r.z1 + 1; z < r.z2 - 1 && !chosen; z += 1) {
          if (ok([x, z], false)) chosen = [x, z];
        }
      }
    }
    if (chosen) addSpot(r.fl, chosen[0], chosen[1], label, col, true, item);
  };

  cornerSpecial('nur', 'افتح الصندوق الحديدي', 'gun', 0x6a6a72);
  cornerSpecial('laun', 'ابحث في صندوق الأدوات', 'ham', 0x7a6a52);
  cornerSpecial('a2', 'ابحث في صندوق الصيانة', 'cutters', 0x5c6872);

  // Table Ammo Packs
  const addTableAmmo = (x: number, y: number, z: number) => {
    setBuild(0);
    const g = new THREE.Group();
    const mat = new THREE.MeshStandardMaterial({ color: 0x4a5a34, roughness: 0.7 });
    g.add(mk(new THREE.BoxGeometry(0.3, 0.12, 0.2), mat, 0, 0.06, 0));
    g.add(mk(new THREE.BoxGeometry(0.32, 0.02, 0.22), matP(0x2a3220), 0, 0.125, 0));
    const bmAmmo = new THREE.MeshStandardMaterial({
      color: 0xc8a040,
      roughness: 0.25,
      metalness: 0.9,
    });
    for (let i = 0; i < 3; i++) {
      const b = mk(new THREE.CylinderGeometry(0.014, 0.014, 0.07, 8), bmAmmo, -0.08 + i * 0.08, 0.016, 0.2);
      b.rotation.z = Math.PI / 2;
      g.add(b);
    }
    const gl = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: tex.glow,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        color: 0xffd070,
      })
    );
    gl.scale.set(0.6, 0.6, 1);
    gl.position.y = 0.15;
    g.add(gl);
    g.position.set(x, y, z);
    CURG.add(g);
    spots.push({
      fl: 0,
      x,
      z,
      label: 'خذ الرصاص من فوق الطاولة',
      obj: g,
      mat,
      col: 0x4a5a34,
      searched: false,
      key: false,
      item: 'ammo',
      n: 3,
      special: true,
      hide: true,
      r: 2.6,
    });
  };
  addTableAmmo(25.1, 0.92, 4.35);
  addTableAmmo(27.6, 0.92, 37.0);

  // ---------- Light Switch, Hallway Lamps, Safe, Note ----------
  setBuild(0);
  const lightSwitch = new THREE.Group();
  lightSwitch.add(mk(new THREE.BoxGeometry(0.17, 0.26, 0.05), matP(0xd8d0bc, 0.5), 0, 0, 0));
  lightSwitch.add(mk(new THREE.BoxGeometry(0.04, 0.1, 0.05), matP(0x2a2a2a), 0, 0.03, 0.04));
  lightSwitch.add(mk(new THREE.SphereGeometry(0.018, 8, 8), new THREE.MeshBasicMaterial({ color: 0x44ff77 }), 0, -0.09, 0.03));
  lightSwitch.position.set(17.5, 1.35, 16.3);
  CURG.add(lightSwitch);
  const swGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: tex.glow,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      color: 0x66ff99,
    })
  );
  swGlow.scale.set(0.5, 0.5, 1);
  swGlow.position.set(17.5, 1.26, 16.25);
  CURG.add(swGlow);

  const lampLights: THREE.PointLight[] = [];
  const lampBulbs: THREE.Mesh[] = [];
  [8, 24, 40, 54].forEach((x) => {
    const lp = new THREE.PointLight(0xffd9a0, 0, 26, 1.6);
    lp.position.set(x, 4.2, 17.4);
    CURG.add(lp);
    lampLights.push(lp);

    CURG.add(mk(new THREE.BoxGeometry(0.1, 0.1, 0.35), matP(0x2a2018), x, 3.55, 16.35));
    const bulb = mk(new THREE.SphereGeometry(0.17, 10, 8), new THREE.MeshBasicMaterial({ color: 0x2a2418 }), x, 3.62, 16.55);
    CURG.add(bulb);
    lampBulbs.push(bulb);
    CURG.add(
      mk(
        new THREE.ConeGeometry(0.3, 0.34, 12, 1, true),
        new THREE.MeshStandardMaterial({ color: 0x6a5238, side: THREE.DoubleSide, roughness: 0.85 }),
        x,
        3.78,
        16.55
      )
    );
  });

  // Safe in Library
  const safeG = new THREE.Group();
  const steel = new THREE.MeshStandardMaterial({ color: 0x3c4048, roughness: 0.38, metalness: 0.8 });
  safeG.add(mk(new THREE.BoxGeometry(1.0, 1.15, 0.6), steel, 0, 0.575, 0));
  safeG.add(mk(new THREE.BoxGeometry(0.84, 0.99, 0.5), matP(0x0e0e10), 0, 0.575, 0.06));
  const safePiv = new THREE.Group();
  safePiv.position.set(-0.42, 0, 0.3);
  safePiv.add(
    mk(
      new THREE.BoxGeometry(0.86, 1.0, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x4a4e58, roughness: 0.32, metalness: 0.85 }),
      0.43,
      0.575,
      0.03
    )
  );
  const dial = mk(new THREE.CylinderGeometry(0.1, 0.1, 0.05, 20), brassMat, 0.43, 0.72, 0.075);
  dial.rotation.x = Math.PI / 2;
  safePiv.add(dial);
  safePiv.add(mk(new THREE.BoxGeometry(0.26, 0.05, 0.05), brassMat, 0.43, 0.42, 0.08));
  const led = mk(new THREE.BoxGeometry(0.07, 0.035, 0.02), new THREE.MeshBasicMaterial({ color: 0xff2a1a }), 0.7, 0.95, 0.065);
  safePiv.add(led);
  safeG.add(safePiv);

  const sd = new THREE.Group();
  const shaft = mk(
    new THREE.CylinderGeometry(0.012, 0.012, 0.22, 8),
    new THREE.MeshStandardMaterial({ color: 0x9a9aa2, roughness: 0.25, metalness: 0.9 }),
    0,
    0,
    0
  );
  shaft.rotation.z = Math.PI / 2;
  sd.add(shaft);
  const hnd = mk(new THREE.CylinderGeometry(0.03, 0.026, 0.13, 10), matP(0xc03020, 0.5), -0.17, 0, 0);
  hnd.rotation.z = Math.PI / 2;
  sd.add(hnd);
  sd.position.set(0.1, 0.12, 0.1);
  safeG.add(sd);

  safeG.position.set(35, 0, 0.8);
  CURG.add(safeG);
  box1(34.4, 35.6, 0, 1.15);
  const safeObj = { g: safeG, piv: safePiv, sd, led };

  // Safe Note in Kitchen
  const note = new THREE.Group();
  note.add(mk(new THREE.BoxGeometry(0.28, 0.006, 0.2), matP(0xd8cfae), 0, 0, 0));
  const ng = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: tex.glow,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      color: 0xffe0a0,
    })
  );
  ng.scale.set(0.5, 0.5, 1);
  ng.position.y = 0.1;
  note.add(ng);
  note.position.set(17, 1.02, 0.8);
  note.rotation.y = 0.4;
  CURG.add(note);

  // ---------- Paper Diary Notes (Story & Puzzle Clues) ----------
  const diaryNotes: DiaryNoteWorldItem[] = [];
  const parchmentMat = matP(0xdac79c, 0.9);
  const inkLineMat = matP(0x3a281a, 0.95);
  const waxMat = matP(0x9b1c18, 0.5);

  DIARY_NOTES.forEach((entry, idx) => {
    const r = ROOM[entry.roomId];
    if (!r) return;
    setBuild(r.fl);
    const w = r.x2 - r.x1;
    const d = r.z2 - r.z1;
    const candidates = [
      [r.cx - w * 0.22, r.cz + d * 0.18],
      [r.cx + w * 0.22, r.cz - d * 0.18],
      [r.x1 + 1.6, r.cz],
      [r.x2 - 1.6, r.cz],
      [r.cx, r.cz],
    ];
    let px = r.cx;
    let pz = r.cz;
    for (const cand of candidates) {
      if (freeAt(cand[0], cand[1], 0.45, 0.45, 0.55)) {
        px = cand[0];
        pz = cand[1];
        break;
      }
    }

    const g = new THREE.Group();
    // Low weathered wooden reading stool / stand
    const standMat = matP(0x3a2618, 0.85);
    g.add(mk(new THREE.BoxGeometry(0.46, 0.04, 0.4), standMat, 0, 0.56, 0));
    [
      [-0.18, -0.15],
      [0.18, -0.15],
      [-0.18, 0.15],
      [0.18, 0.15],
    ].forEach(([lx, lz]) => {
      g.add(mk(new THREE.BoxGeometry(0.05, 0.56, 0.05), standMat, lx, 0.28, lz));
    });

    // Aged parchment paper sheet resting on top
    const paper = new THREE.Group();
    paper.add(mk(new THREE.BoxGeometry(0.32, 0.008, 0.24), parchmentMat, 0, 0, 0));
    for (let li = 0; li < 4; li++) {
      paper.add(mk(new THREE.BoxGeometry(0.22 - (li % 2) * 0.04, 0.003, 0.012), inkLineMat, 0, 0.005, -0.06 + li * 0.036));
    }
    paper.add(mk(new THREE.CylinderGeometry(0.024, 0.026, 0.008, 10), waxMat, -0.1, 0.006, 0.075));
    paper.position.y = 0.585;
    paper.rotation.y = (idx % 2 === 0 ? 1 : -1) * 0.25;
    g.add(paper);

    const glow = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: tex.glow,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        color: 0xffd27a,
      })
    );
    glow.scale.set(0.7, 0.7, 1);
    glow.position.y = 0.72;
    g.add(glow);

    g.position.set(px, 0, pz);
    CURG.add(g);
    box1(px - 0.23, px + 0.23, pz - 0.2, pz + 0.2);

    diaryNotes.push({
      id: entry.id,
      title: entry.title,
      fl: r.fl,
      x: px,
      z: pz,
      mesh: g,
      glow,
      read: false,
    });
  });
  setBuild(0);

  // ---------- Creaky Floorboards (Granny stealth!) ----------
  const creakBoards: CreakBoard[] = [
    { fl: 0, x: 14, z: 20, w: 1.8, d: 2.8, cooldown: 0 },
    { fl: 0, x: 30, z: 20, w: 1.8, d: 2.8, cooldown: 0 },
    { fl: 0, x: 48, z: 20, w: 1.8, d: 2.8, cooldown: 0 },
    { fl: 1, x: 25, z: 20, w: 1.8, d: 2.8, cooldown: 0 },
    { fl: 1, x: 43, z: 20, w: 1.8, d: 2.8, cooldown: 0 },
  ];
  creakBoards.forEach((cb) => {
    setBuild(cb.fl);
    const boardMesh = new THREE.Mesh(
      new THREE.BoxGeometry(cb.w, 0.025, cb.d),
      matP(0x472d1b, 0.92)
    );
    boardMesh.position.set(cb.x, 0.015, cb.z);
    CURG.add(boardMesh);
  });
  setBuild(0);

  // ---------- Navigation Graph ----------
  const nodes: NavNode[] = [];
  const roomNode: Record<string, number> = {};
  const addNode = (x: number, z: number, fl: 0 | 1) => {
    nodes.push({ x, z, fl, adj: [] });
    return nodes.length - 1;
  };
  const link = (a: number, b: number) => {
    const d = Math.hypot(nodes[a].x - nodes[b].x, nodes[a].z - nodes[b].z);
    nodes[a].adj.push({ n: b, d });
    nodes[b].adj.push({ n: a, d });
  };
  const hallChain = (xs: number[], fl: 0 | 1) => {
    const sorted = xs.slice().sort((a, b) => a - b);
    const map: Record<number, number> = {};
    let prev = -1;
    sorted.forEach((x) => {
      const n = addNode(x, 20, fl);
      map[x] = n;
      if (prev >= 0) link(prev, n);
      prev = n;
    });
    return map;
  };
  const seqLink = (ids: string[]) => {
    for (let i = 0; i < ids.length - 1; i++) link(roomNode[ids[i]], roomNode[ids[i + 1]]);
  };

  ALL_ROOMS.forEach((r) => {
    roomNode[r.id] = addNode(r.cx, r.cz, r.fl);
  });
  const main0 = ROOMS_FLOOR_0.slice(0, 9);
  const m0 = hallChain(
    main0.map((r) => r.cx),
    0
  );
  main0.forEach((r) => link(roomNode[r.id], m0[r.cx]));
  seqLink(['bed', 'kit', 'lib', 'bath', 'stor']);
  seqLink(['liv', 'din', 'nur', 'exit']);
  seqLink(['laun', 'stu', 'cell']);
  (
    [
      ['liv', 'laun', 10],
      ['din', 'stu', 31],
      ['exit', 'cell', 52],
    ] as [string, string, number][]
  ).forEach(([a, b, x]) => {
    const d = addNode(x, 40, 0);
    link(roomNode[a], d);
    link(d, roomNode[b]);
  });

  const nx = ROOMS_FLOOR_1.slice(0, 6).map((r) => r.cx);
  const m1 = hallChain([...nx, 6, 30, 42, 54], 1);
  ROOMS_FLOOR_1.slice(0, 6).forEach((r) => link(roomNode[r.id], m1[r.cx]));
  (
    [
      ['a0', 6],
      ['a2', 30],
      ['a3', 42],
      ['a4', 54],
    ] as [string, number][]
  ).forEach(([id, x]) => link(roomNode[id], m1[x]));
  seqLink(['n0', 'n1', 'n2', 'n3', 'n4', 'n5']);
  seqLink(['a0', 'a1', 'a2', 'a3', 'a4']);
  seqLink(['b0', 'b1', 'b2', 'b3']);
  (
    [
      ['a0', 'b0', 7.5],
      ['a1', 'b1', 22.5],
      ['a3', 'b2', 37.5],
      ['a4', 'b3', 52.5],
    ] as [string, string, number][]
  ).forEach(([a, b, x]) => {
    const d = addNode(x, 40, 1);
    link(roomNode[a], d);
    link(d, roomNode[b]);
  });
  const sb = addNode(9.6, 22.6, 0);
  const st = addNode(25.6, 22.6, 1);
  link(sb, m0[9]);
  link(st, m1[30]);
  link(st, m1[25]);
  link(sb, st);

  // ---------- Outdoor Escape Forest & Dawn ----------
  const outdoorGroup = new THREE.Group();
  outdoorGroup.visible = false;
  scene.add(outdoorGroup);

  const gc = document.createElement('canvas');
  gc.width = 128;
  gc.height = 128;
  const gg = gc.getContext('2d')!;
  gg.fillStyle = '#34522d';
  gg.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 900; i++) {
    gg.fillStyle = `rgba(0,25,0,${(Math.random() * 0.45).toFixed(2)})`;
    gg.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
  }
  const grassTex = new THREE.CanvasTexture(gc);
  grassTex.colorSpace = THREE.SRGBColorSpace;
  grassTex.wrapS = grassTex.wrapT = THREE.RepeatWrapping;
  grassTex.repeat.set(90, 90);

  const gm = new THREE.Mesh(
    new THREE.PlaneGeometry(420, 420),
    new THREE.MeshStandardMaterial({ map: grassTex, roughness: 0.95 })
  );
  gm.rotation.x = -Math.PI / 2;
  gm.position.set(30, -0.03, 28);
  outdoorGroup.add(gm);

  const pm = new THREE.Mesh(new THREE.PlaneGeometry(70, 3.4), matP(0x7a6a52));
  pm.rotation.x = -Math.PI / 2;
  pm.position.set(95, 0.02, ROOM.exit.cz);
  outdoorGroup.add(pm);

  const tg = new THREE.CylinderGeometry(0.25, 0.32, 2.6, 6);
  const cg = new THREE.ConeGeometry(1.7, 3.4, 7);
  const tm = matP(0x3a2a1c);
  const c1 = matP(0x1f3a22);
  const c2 = matP(0x2a4a2a);
  for (let i = 0; i < 90; i++) {
    let x = 0;
    let z = 0;
    let tries = 0;
    do {
      x = rand(-110, 150);
      z = rand(-110, 140);
      tries++;
    } while (
      tries < 20 &&
      ((x > -9 && x < 71 && z > -9 && z < 65) ||
        (x > 58 && Math.abs(z - ROOM.exit.cz) < 5))
    );
    const sc = rand(0.8, 1.7);
    const tr = new THREE.Group();
    const tk = new THREE.Mesh(tg, tm);
    tk.position.y = 1.3;
    tr.add(tk);
    const a = new THREE.Mesh(cg, c1);
    a.position.y = 3.6;
    tr.add(a);
    const b = new THREE.Mesh(cg, c2);
    b.position.y = 5.0;
    b.scale.set(0.75, 0.75, 0.75);
    tr.add(b);
    tr.position.set(x, 0, z);
    tr.scale.set(sc, sc, sc);
    outdoorGroup.add(tr);
  }

  const wm = matP(0x7d6c5a, 0.9);
  const extPanel = (w: number, h: number, d: number, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wm);
    m.position.set(x, y, z);
    outdoorGroup.add(m);
  };
  const H2 = FY * 2;
  extPanel(61, H2, 0.1, 30, H2 / 2, -0.25);
  extPanel(61, H2, 0.1, 30, H2 / 2, 56.25);
  extPanel(0.1, H2, 57, -0.25, H2 / 2, 28);
  const dz = ROOM.exit.cz;
  const hw = DOOR_W / 2;
  extPanel(0.1, H2, dz - hw + 0.25, 60.3, H2 / 2, (dz - hw - 0.25) / 2);
  extPanel(0.1, H2, 56.25 - (dz + hw), 60.3, H2 / 2, (dz + hw + 56.25) / 2);
  extPanel(0.1, H2 - 2.8, DOOR_W, 60.3, 2.8 + (H2 - 2.8) / 2, dz);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(62, 0.5, 58), matP(0x2a2220));
  roof.position.set(30, H2 + 0.1, 28);
  outdoorGroup.add(roof);

  const sunSprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: tex.glow,
      color: 0xffd29a,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false,
    })
  );
  sunSprite.scale.set(110, 110, 1);
  sunSprite.position.set(260, -10, ROOM.exit.cz);
  outdoorGroup.add(sunSprite);

  const sunLight = new THREE.DirectionalLight(0xffc890, 0);
  sunLight.position.set(200, 40, 32);
  scene.add(sunLight);

  // ---------- Helper for creating physical pickable/droppable 3D prop meshes ----------
  const createPropMesh = (kind: Exclude<HeldItemType, null>) => {
    const g = new THREE.Group();
    const metal = new THREE.MeshStandardMaterial({ color: 0x30343d, roughness: 0.35, metalness: 0.85 });
    const bright = new THREE.MeshStandardMaterial({ color: 0xb2b8c2, roughness: 0.25, metalness: 0.9 });
    const woodM = matP(0x5c3c22);
    const redM = matP(0xb52b22, 0.5);
    const ceramicM = matP(0xc9b9a3, 0.35);

    if (kind === 'hammer') {
      const h = mk(new THREE.CylinderGeometry(0.03, 0.03, 0.45, 8), woodM, 0, 0.05, 0);
      h.rotation.z = Math.PI / 2;
      g.add(h);
      g.add(mk(new THREE.BoxGeometry(0.09, 0.1, 0.22), metal, 0.2, 0.06, 0));
    } else if (kind === 'screwdriver') {
      const h = mk(new THREE.CylinderGeometry(0.025, 0.025, 0.18, 8), redM, -0.09, 0.04, 0);
      h.rotation.z = Math.PI / 2;
      const s = mk(new THREE.CylinderGeometry(0.008, 0.008, 0.24, 8), bright, 0.12, 0.04, 0);
      s.rotation.z = Math.PI / 2;
      g.add(h, s);
    } else if (kind === 'cutters') {
      const l1 = mk(new THREE.BoxGeometry(0.24, 0.03, 0.03), redM, -0.04, 0.04, 0.03);
      l1.rotation.y = 0.2;
      const l2 = mk(new THREE.BoxGeometry(0.24, 0.03, 0.03), redM, -0.04, 0.04, -0.03);
      l2.rotation.y = -0.2;
      const j = mk(new THREE.BoxGeometry(0.12, 0.04, 0.06), bright, 0.12, 0.04, 0);
      g.add(l1, l2, j);
    } else if (kind === 'gun') {
      g.add(mk(new THREE.BoxGeometry(0.28, 0.06, 0.05), metal, 0.02, 0.09, 0));
      g.add(mk(new THREE.BoxGeometry(0.07, 0.13, 0.05), woodM, -0.08, 0.04, 0));
    } else {
      g.add(mk(new THREE.CylinderGeometry(0.11, 0.08, 0.32, 12), ceramicM, 0, 0.16, 0));
      g.add(mk(new THREE.CylinderGeometry(0.07, 0.055, 0.09, 12), ceramicM, 0, 0.35, 0));
    }

    const gl = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: tex.glow,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        color: 0xffd27a,
      })
    );
    gl.scale.set(0.55, 0.55, 1);
    gl.position.y = 0.22;
    g.add(gl);
    return g;
  };

  return {
    floors: FL,
    doors,
    closets,
    spots,
    diaryNotes,
    creakBoards,
    nodes,
    roomNode,
    lampLights,
    lampBulbs,
    safeObj,
    exitDoorPivot,
    exitBox,
    exitPlankMesh,
    exitWireMesh,
    exitPanelMesh,
    outPane,
    outdoorGroup,
    sunLight,
    sunSprite,
    pendulum,
    rockingChair,
    createPropMesh,
  };
}
