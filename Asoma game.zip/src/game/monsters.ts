import * as THREE from 'three';
import { GameTextures, rand } from './textures';

function mk(
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x: number,
  y: number,
  z: number
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  return m;
}

function pivot(x: number, y: number, z: number): THREE.Group {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  return g;
}

export interface HammerManRig {
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  head: THREE.Group;
}

export interface GiantRig {
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  body: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
}

export function createHammerManRig(tex: GameTextures): HammerManRig {
  const g = new THREE.Group();
  const cloth = new THREE.MeshStandardMaterial({ map: tex.cloth, roughness: 0.9, metalness: 0.05 });
  const pants = new THREE.MeshStandardMaterial({ color: 0x2b2622, roughness: 0.95 });
  const skin = new THREE.MeshStandardMaterial({ map: tex.face, roughness: 0.7 });
  const metal = new THREE.MeshStandardMaterial({
    color: 0x7a7a82,
    roughness: 0.35,
    metalness: 0.85,
  });
  const rust = new THREE.MeshStandardMaterial({
    color: 0x7a1612,
    roughness: 0.65,
    metalness: 0.45,
  });
  const wood = new THREE.MeshStandardMaterial({ color: 0x4a3320, roughness: 0.85 });
  const burlap = new THREE.MeshStandardMaterial({ map: tex.burlap, roughness: 0.95 });
  const dark = new THREE.MeshBasicMaterial({ color: 0x050303 });
  const glow = new THREE.MeshBasicMaterial({ color: 0xff5a2a });

  const legL = pivot(-0.17, 0.95, 0);
  legL.add(mk(new THREE.BoxGeometry(0.28, 0.95, 0.3), pants, 0, -0.475, 0));
  legL.add(
    mk(
      new THREE.BoxGeometry(0.31, 0.2, 0.46),
      new THREE.MeshStandardMaterial({ color: 0x15110e, roughness: 0.8 }),
      0,
      -0.9,
      0.07
    )
  );
  g.add(legL);

  const legR = pivot(0.17, 0.95, 0);
  legR.add(mk(new THREE.BoxGeometry(0.28, 0.95, 0.3), pants, 0, -0.475, 0));
  legR.add(
    mk(
      new THREE.BoxGeometry(0.31, 0.2, 0.46),
      new THREE.MeshStandardMaterial({ color: 0x15110e, roughness: 0.8 }),
      0,
      -0.9,
      0.07
    )
  );
  g.add(legR);

  // Torso + bloody apron + chains
  g.add(mk(new THREE.BoxGeometry(0.74, 0.92, 0.38), cloth, 0, 1.4, 0));
  const apron = mk(
    new THREE.BoxGeometry(0.64, 0.86, 0.025),
    new THREE.MeshStandardMaterial({ map: tex.apron, roughness: 0.65 }),
    0,
    1.38,
    0.205
  );
  g.add(apron);
  const strap = mk(new THREE.BoxGeometry(0.08, 0.5, 0.02), wood, -0.16, 1.74, 0.19);
  strap.rotation.z = -0.2;
  g.add(strap);
  const strap2 = strap.clone();
  strap2.position.x = 0.16;
  strap2.rotation.z = 0.2;
  g.add(strap2);

  const chainMat = new THREE.MeshStandardMaterial({
    color: 0x6a6a72,
    roughness: 0.3,
    metalness: 0.9,
  });
  for (let k = 0; k < 14; k++) {
    const u = k / 13;
    const l = mk(
      new THREE.TorusGeometry(0.035, 0.01, 5, 8),
      chainMat,
      -0.3 + 0.6 * u,
      1.8 - 0.72 * u,
      0.235
    );
    l.rotation.y = k % 2 ? 0 : 1.57;
    l.rotation.z = -0.9;
    g.add(l);
  }

  // Head with burlap sack & stitched mouth & glowing eyes
  const head = pivot(0, 1.88, 0.02);
  const sack = mk(new THREE.SphereGeometry(0.255, 18, 14), burlap, 0, 0.12, 0);
  sack.scale.set(1, 1.18, 1.02);
  head.add(sack);
  const top = mk(new THREE.ConeGeometry(0.1, 0.16, 8), burlap, 0, 0.42, -0.02);
  top.rotation.z = 0.25;
  head.add(top);
  [-1, 1].forEach((s) => {
    const h = mk(new THREE.SphereGeometry(0.052, 10, 8), dark, s * 0.09, 0.17, 0.225);
    h.scale.set(1, 1.2, 0.5);
    head.add(h);
    head.add(mk(new THREE.SphereGeometry(0.016, 8, 8), glow, s * 0.09, 0.165, 0.245));
  });
  for (let i = 0; i < 7; i++) {
    const st = mk(new THREE.BoxGeometry(0.012, 0.05, 0.01), dark, -0.09 + i * 0.03, 0.04, 0.248);
    st.rotation.z = i % 2 ? 0.35 : -0.35;
    head.add(st);
  }
  const rope = mk(new THREE.TorusGeometry(0.2, 0.022, 6, 16), wood, 0, -0.02, 0);
  rope.rotation.x = Math.PI / 2;
  head.add(rope);
  g.add(head);

  // Arms + Spiked Hammer
  const armL = pivot(-0.47, 1.8, 0);
  armL.add(mk(new THREE.BoxGeometry(0.17, 0.8, 0.17), cloth, 0, -0.4, 0));
  armL.add(mk(new THREE.SphereGeometry(0.1, 8, 8), skin, 0, -0.85, 0));
  g.add(armL);

  const armR = pivot(0.47, 1.8, 0);
  armR.add(mk(new THREE.BoxGeometry(0.17, 0.8, 0.17), cloth, 0, -0.4, 0));
  armR.add(mk(new THREE.SphereGeometry(0.1, 8, 8), skin, 0, -0.85, 0));

  const hm = pivot(0, -0.85, 0.04);
  hm.rotation.x = 2.2;
  hm.add(mk(new THREE.CylinderGeometry(0.04, 0.04, 1.7, 8), wood, 0, 0.65, 0));
  hm.add(mk(new THREE.BoxGeometry(0.62, 0.4, 0.4), metal, 0, 1.55, 0));
  hm.add(mk(new THREE.BoxGeometry(0.66, 0.14, 0.44), rust, 0, 1.46, 0));

  for (let r = 0; r < 6; r++) {
    const rg = mk(new THREE.TorusGeometry(0.046, 0.008, 5, 10), pants, 0, 0.1 + r * 0.12, 0);
    rg.rotation.x = Math.PI / 2;
    hm.add(rg);
  }
  for (let d = 0; d < 5; d++) {
    hm.add(mk(new THREE.BoxGeometry(0.03, rand(0.14, 0.3), 0.02), rust, rand(-0.25, 0.25), 1.35, 0.21));
  }
  const sg = new THREE.ConeGeometry(0.06, 0.24, 6);
  const sp = (x: number, y: number, z: number, rx: number, rz: number, m: THREE.Material) => {
    const s = mk(sg, m, x, y, z);
    s.rotation.x = rx;
    s.rotation.z = rz;
    hm.add(s);
  };
  [-1, 1].forEach((sx) => {
    [-1, 1].forEach((sy) => {
      [-1, 1].forEach((sz) => {
        sp(sx * 0.43, 1.55 + sy * 0.1, sz * 0.1, 0, sx > 0 ? -Math.PI / 2 : Math.PI / 2, sy + sz > 0 ? metal : rust);
        sp(sz * 0.18, 1.55 + sy * 0.1, sx * 0.32, sx > 0 ? Math.PI / 2 : -Math.PI / 2, 0, sy + sz > 0 ? rust : metal);
      });
    });
  });
  sp(0, 1.86, 0, 0, 0, metal);
  sp(0, 1.24, 0, 0, Math.PI, rust);
  armR.add(hm);
  g.add(armR);

  return { group: g, legL, legR, armL, armR, head };
}

export function createGiantRig(tex: GameTextures): GiantRig {
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ map: tex.giantSkin, roughness: 0.85 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x4a463c, roughness: 0.9 });
  const cloth = new THREE.MeshStandardMaterial({ map: tex.cloth, roughness: 0.92 });
  const eye = new THREE.MeshBasicMaterial({ color: 0xffe14a });
  const tusk = new THREE.MeshStandardMaterial({ color: 0xe8e0c0, roughness: 0.45 });
  const chainMat = new THREE.MeshStandardMaterial({
    color: 0x6a6a72,
    roughness: 0.35,
    metalness: 0.85,
  });

  const legL = pivot(-0.65, 2.4, 0);
  legL.add(mk(new THREE.BoxGeometry(0.95, 2.4, 1.0), skin, 0, -1.2, 0));
  g.add(legL);

  const legR = pivot(0.65, 2.4, 0);
  legR.add(mk(new THREE.BoxGeometry(0.95, 2.4, 1.0), skin, 0, -1.2, 0));
  g.add(legR);

  const body = pivot(0, 2.4, 0);
  body.rotation.x = 0.14;
  body.add(mk(new THREE.BoxGeometry(2.5, 2.4, 1.5), skin, 0, 1.2, 0));
  body.add(mk(new THREE.BoxGeometry(2.56, 0.9, 1.56), cloth, 0, 0.1, 0));
  body.add(mk(new THREE.BoxGeometry(2.9, 0.7, 1.5), dark, 0, 2.35, 0));

  const scar = new THREE.MeshBasicMaterial({ color: 0x3a0a0a });
  for (let w = 0; w < 5; w++) {
    const sc = mk(new THREE.BoxGeometry(0.9, 0.04, 0.02), scar, rand(-0.5, 0.5), 0.5 + w * 0.4, 0.77);
    sc.rotation.z = rand(-0.4, 0.4);
    body.add(sc);
  }

  const head = pivot(0, 2.9, 0.45);
  head.add(mk(new THREE.SphereGeometry(0.8, 16, 12), skin, 0, 0.25, 0.05));
  head.add(mk(new THREE.SphereGeometry(0.11, 8, 8), eye, -0.3, 0.4, 0.72));
  head.add(mk(new THREE.SphereGeometry(0.11, 8, 8), eye, 0.3, 0.4, 0.72));
  head.add(mk(new THREE.BoxGeometry(0.7, 0.12, 0.1), new THREE.MeshBasicMaterial({ color: 0x2a0505 }), 0, -0.1, 0.78));
  [-1, 1].forEach((s) => {
    const t = mk(new THREE.ConeGeometry(0.1, 0.5, 8), tusk, s * 0.3, -0.2, 0.8);
    t.rotation.x = Math.PI + 0.5;
    head.add(t);
    const br = mk(new THREE.BoxGeometry(0.5, 0.13, 0.3), dark, s * 0.3, 0.58, 0.62);
    br.rotation.z = -s * 0.22;
    head.add(br);
  });
  for (let q = 0; q < 8; q++) {
    head.add(mk(new THREE.BoxGeometry(0.06, 0.1, 0.04), tusk, -0.26 + q * 0.075, -0.1, 0.8));
  }
  body.add(head);

  const armL = pivot(-1.65, 2.1, 0);
  armL.add(mk(new THREE.BoxGeometry(0.75, 3.4, 0.75), skin, 0, -1.7, 0));
  armL.add(mk(new THREE.SphereGeometry(0.58, 10, 8), dark, 0, -3.5, 0));
  const shL = mk(new THREE.TorusGeometry(0.46, 0.07, 6, 14), chainMat, 0, -3.0, 0);
  shL.rotation.x = Math.PI / 2;
  armL.add(shL);
  body.add(armL);

  const armR = pivot(1.65, 2.1, 0);
  armR.add(mk(new THREE.BoxGeometry(0.75, 3.4, 0.75), skin, 0, -1.7, 0));
  armR.add(mk(new THREE.SphereGeometry(0.58, 10, 8), dark, 0, -3.5, 0));
  const shR = mk(new THREE.TorusGeometry(0.46, 0.07, 6, 14), chainMat, 0, -3.0, 0);
  shR.rotation.x = Math.PI / 2;
  armR.add(shR);
  body.add(armR);

  g.add(body);
  return { group: g, legL, legR, body, head, armL, armR };
}

export function createBearTrapMesh(): {
  mesh: THREE.Group;
  jawL: THREE.Mesh;
  jawR: THREE.Mesh;
} {
  const g = new THREE.Group();
  const iron = new THREE.MeshStandardMaterial({
    color: 0x3b3532,
    roughness: 0.55,
    metalness: 0.75,
  });
  const rust = new THREE.MeshStandardMaterial({
    color: 0x612218,
    roughness: 0.75,
    metalness: 0.45,
  });
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.03, 12), rust);
  plate.position.y = 0.015;
  g.add(plate);

  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.025, 6, 18), iron);
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.02;
  g.add(ring);

  const jawGeo = new THREE.TorusGeometry(0.3, 0.03, 6, 14, Math.PI);
  const jawL = new THREE.Mesh(jawGeo, iron);
  jawL.rotation.x = Math.PI / 2;
  jawL.position.y = 0.035;
  g.add(jawL);

  const jawR = new THREE.Mesh(jawGeo, iron);
  jawR.rotation.x = Math.PI / 2;
  jawR.rotation.z = Math.PI;
  jawR.position.y = 0.035;
  g.add(jawR);

  // Subtle metallic glint teeth
  const toothGeo = new THREE.ConeGeometry(0.016, 0.05, 4);
  for (let i = 0; i < 6; i++) {
    const a = (i / 5) * Math.PI;
    const t = new THREE.Mesh(toothGeo, rust);
    t.position.set(Math.cos(a) * 0.28, 0.055, Math.sin(a) * 0.28);
    g.add(t);
  }

  return { mesh: g, jawL, jawR };
}
