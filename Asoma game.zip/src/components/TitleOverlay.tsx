import { useState } from 'react';
import { DIFFICULTIES, toArabicDigits } from '../game/constants';
import { DifficultyKey } from '../game/types';

interface TitleOverlayProps {
  difficulty: DifficultyKey;
  mpRoomCode: string | null;
  mpPeersCount: number;
  onSelectDifficulty: (diff: DifficultyKey) => void;
  onStart: () => void;
  onOpenMultiplayer: () => void;
  onOpenSettings: () => void;
}

const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];

export function TitleOverlay({
  difficulty,
  mpRoomCode,
  mpPeersCount,
  onSelectDifficulty,
  onStart,
  onOpenMultiplayer,
  onOpenSettings,
}: TitleOverlayProps) {
  const [downloading, setDownloading] = useState(false);
  const [downloadNote, setDownloadNote] = useState<string | null>(null);
  const isOfflineFile = typeof window !== 'undefined' && window.location.protocol === 'file:';

  const handleDownloadGame = async () => {
    if (downloading) return;
    setDownloading(true);
    setDownloadNote(null);
    try {
      const res = await fetch('/api/download-offline');
      if (!res.ok) throw new Error('failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HammerHouse-Game.html';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);
      setDownloadNote(
        'تم تنزيل ملف HammerHouse-Game.html في مجلد التنزيلات! افتحه بمتصفح Chrome للعب بدون إنترنت.'
      );
    } catch {
      setDownloadNote('تعذر تنزيل الملف من المعاينة الحالية؛ استخدم زر التحميل المباشر أعلى المحرر.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-20 flex items-center justify-center p-4 bg-[rgba(2,1,1,0.82)] overflow-y-auto"
      dir="rtl"
    >
      <div className="w-full max-w-[600px] text-center space-y-4">
        <div className="space-y-2">
          <h1 className="font-display text-[clamp(48px,10vw,84px)] leading-none text-[#b3201a] [text-shadow:0_0_28px_rgba(179,32,26,0.55)]">
            بيت المطرقة
          </h1>
          <p className="text-sm sm:text-base text-[#a09384] max-w-[48ch] mx-auto leading-relaxed">
            أنت محتجز لخمسة أيام داخل بيت مهجور من طابقين. رجل المطرقة يسمع كل حركة، يزرع
            أفخاخ الدب، ويطاردك بين الغرف.
          </p>
        </div>

        {/* Difficulty Selector */}
        <div className="space-y-2">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {DIFF_KEYS.map((key) => {
              const d = DIFFICULTIES[key];
              const active = difficulty === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => onSelectDifficulty(key)}
                  className={`py-2 px-2 rounded-lg border text-center transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#e2b34a] ${
                    active
                      ? 'bg-[#5e0d0a] border-[#b3201a] text-[#ebe3d6]'
                      : 'bg-[rgba(14,10,9,0.9)] border-[rgba(235,227,214,0.16)] text-[#ebe3d6] hover:border-[rgba(235,227,214,0.35)]'
                  }`}
                >
                  <span className="block text-sm font-bold">{d.name}</span>
                  <span className="block text-[11px] text-[#a09384] mt-0.5">
                    {toArabicDigits(d.keys)} مفاتيح
                  </span>
                </button>
              );
            })}
          </div>
          <p className="text-xs sm:text-sm text-[#c2b5a6] min-h-[1.4em]">
            {DIFFICULTIES[difficulty].info}
          </p>
        </div>

        {/* Survival Guide */}
        <div className="text-start bg-[rgba(14,10,9,0.9)] border border-[rgba(235,227,214,0.16)] rounded-lg px-4 py-3 text-xs sm:text-sm text-[#ebe3d6] space-y-1.5">
          <ol className="list-decimal list-inside space-y-1 leading-relaxed">
            <li>
              <strong className="text-[#e2b34a]">أقفال الباب الثلاثة:</strong> انزع اللوح الخشبي
              بالمطرقة، اقطع السلك بقاطع الأسلاك، وفك الغطاء بالمفك (داخل خزنة المكتبة ورمزها
              بالمطبخ) ثم افتح بالمفاتيح.
            </li>
            <li>
              <strong className="text-[#e2b34a]">أداة واحدة في يدك:</strong> اضغط{' '}
              <kbd className="px-1.5 py-0.5 border border-[rgba(235,227,214,0.2)] rounded text-[11px] bg-white/5">
                G
              </kbd>{' '}
              لرمي الأداة أو تحطيم مزهرية لتشتيت الوحش أو تفجير فخ الدب من بعيد.
            </li>
            <li>
              <strong className="text-[#e2b34a]">التخفي والصمت:</strong> انحنِ{' '}
              <kbd className="px-1.5 py-0.5 border border-[rgba(235,227,214,0.2)] rounded text-[11px] bg-white/5">
                C
              </kbd>{' '}
              للمرور فوق ألواح الصرير وتفكيك الأفخاخ، واختبئ تحت الأسرّة أو داخل الخزائن قبل أن
              يراك.
            </li>
          </ol>
        </div>

        {/* Desktop Controls */}
        <div className="hidden sm:grid grid-cols-3 gap-x-4 gap-y-1.5 text-start text-xs text-[#a09384] px-1">
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              W A S D
            </kbd>
            حركة
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              Shift
            </kbd>
            جري
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              C
            </kbd>
            انحناء / تفكيك
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              E
            </kbd>
            تفاعل / اختباء
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              G
            </kbd>
            رمي / إسقاط
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              Q / نقر
            </kbd>
            إطلاق المسدس
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              F
            </kbd>
            الكشاف
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              M
            </kbd>
            الخريطة
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              N
            </kbd>
            المذكرات
          </span>
          <span>
            <kbd className="px-1.5 py-0.5 border border-white/15 rounded text-[#ebe3d6] me-1">
              P
            </kbd>
            إيقاف مؤقت
          </span>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
          <button
            type="button"
            onClick={onStart}
            className="font-display text-2xl px-8 py-2 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[#ebe3d6] cursor-pointer transition-colors focus-visible:outline-2 focus-visible:outline-[#e2b34a]"
          >
            ابدأ الليلة
          </button>
          <button
            type="button"
            onClick={onOpenMultiplayer}
            className="font-display text-2xl px-6 py-2 rounded-md bg-[#241b16] hover:bg-[#33261f] border border-[#e2b34a]/55 text-[#e2b34a] cursor-pointer transition-colors focus-visible:outline-2 focus-visible:outline-[#e2b34a]"
          >
            {mpRoomCode
              ? mpRoomCode === 'LAN'
                ? `نقطة اتصال (${toArabicDigits(mpPeersCount)})`
                : `غرفة ${mpRoomCode} (${toArabicDigits(mpPeersCount)})`
              : 'اللعب الجماعي (LAN)'}
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            className="font-display text-2xl px-6 py-2 rounded-md bg-transparent hover:bg-white/5 border border-[rgba(235,227,214,0.22)] text-[#ebe3d6] cursor-pointer transition-colors focus-visible:outline-2 focus-visible:outline-[#e2b34a]"
          >
            الإعدادات
          </button>
        </div>

        {!isOfflineFile && (
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              disabled={downloading}
              onClick={handleDownloadGame}
              className="px-5 py-2 rounded-md bg-black/55 hover:bg-white/10 disabled:opacity-50 border border-[#e2b34a]/40 text-xs sm:text-sm font-bold text-[#e2b34a] cursor-pointer transition-colors"
            >
              {downloading ? 'جاري تجهيز ملف اللعبة...' : 'تحميل اللعبة كملف واحد (بدون إنترنت)'}
            </button>
            {downloadNote && (
              <p className="text-xs text-[#ebe3d6] bg-[#1c2b1e] border border-[#45b877]/50 rounded-md px-3 py-1.5 max-w-md">
                {downloadNote}
              </p>
            )}
          </div>
        )}

        <p className="text-xs text-[#a09384]">
          لعبة رعب وبقاء · ٥ أيام متاحة · يُفضّل استخدام سماعات الرأس
        </p>
      </div>
    </div>
  );
}
