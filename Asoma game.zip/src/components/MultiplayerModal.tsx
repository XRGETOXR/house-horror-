import { useEffect, useRef, useState } from 'react';
import { DIFFICULTIES, toArabicDigits } from '../game/constants';
import { ChatMessage, DifficultyKey, MultiplayerRoomSnapshot } from '../game/types';

interface LanInfoResponse {
  port: number;
  addresses: string[];
  urls: string[];
}

interface MultiplayerModalProps {
  room: MultiplayerRoomSnapshot | null;
  selfId: string | null;
  errorMsg: string | null;
  difficulty: DifficultyKey;
  chatMessages: ChatMessage[];
  onSendChat: (text: string) => void;
  onCreateRoom: (name: string, diff: DifficultyKey) => void;
  onJoinRoom: (code: string, name: string) => void;
  onSetServerUrl: (url: string | null) => void;
  onCreateLanInvite: (name: string, diff: DifficultyKey) => Promise<string>;
  onAcceptLanReply: (replyCode: string) => Promise<void>;
  onJoinLanInvite: (inviteCode: string, name: string) => Promise<string>;
  onChangeDiff: (diff: DifficultyKey) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
  onClose: () => void;
}

const PEER_COLORS = ['#38a3cc', '#e09132', '#45b877', '#d15a82'];
const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];

function loadSavedName(): string {
  try {
    return localStorage.getItem('hh_name_v2') || '';
  } catch {
    return '';
  }
}

function loadSavedServerUrl(): string {
  try {
    return localStorage.getItem('hh_lan_url_v1') || '';
  } catch {
    return '';
  }
}

export function MultiplayerModal({
  room,
  selfId,
  errorMsg,
  difficulty,
  chatMessages,
  onSendChat,
  onCreateRoom,
  onJoinRoom,
  onSetServerUrl,
  onCreateLanInvite,
  onAcceptLanReply,
  onJoinLanInvite,
  onChangeDiff,
  onStartGame,
  onLeaveRoom,
  onClose,
}: MultiplayerModalProps) {
  const [name, setName] = useState<string>(loadSavedName);
  const [mode, setMode] = useState<'hotspot' | 'server'>('hotspot');
  const [hotspotRole, setHotspotRole] = useState<'host' | 'guest'>('host');

  // Server room state
  const [joinCode, setJoinCode] = useState('');
  const [serverIp, setServerIp] = useState<string>(loadSavedServerUrl);
  const [showCustomIp, setShowCustomIp] = useState(false);
  const [lanUrls, setLanUrls] = useState<string[]>([]);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Hotspot P2P WebRTC state
  const [hostInviteCode, setHostInviteCode] = useState('');
  const [hostReplyInput, setHostReplyInput] = useState('');
  const [guestInviteInput, setGuestInviteInput] = useState('');
  const [guestReplyCode, setGuestReplyCode] = useState('');
  const [lanBusy, setLanBusy] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [showExtraInvite, setShowExtraInvite] = useState(false);

  // Chat state
  const [chatText, setChatText] = useState('');
  const chatScrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages.length]);

  useEffect(() => {
    if (serverIp.trim()) {
      onSetServerUrl(serverIp.trim());
    }
    // Only apply saved LAN server IP on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.protocol === 'file:') {
      return;
    }
    let active = true;
    fetch('/api/lan-info')
      .then((res) => (res.ok ? res.json() : null))
      .then((data: LanInfoResponse | null) => {
        if (active && data && Array.isArray(data.urls)) {
          setLanUrls(data.urls);
        }
      })
      .catch(() => {
        // Offline / bundled APK without local Node server — direct Hotspot P2P still works
      });
    return () => {
      active = false;
    };
  }, []);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = chatText.trim();
    if (!clean) return;
    onSendChat(clean);
    setChatText('');
  };

  const isHost = Boolean(room && selfId && room.hostId === selfId);
  const isLanRoom = room?.code === 'LAN';

  const saveName = (val: string) => {
    setName(val);
    try {
      localStorage.setItem('hh_name_v2', val);
    } catch {
      // ignore
    }
  };

  const applyCustomIp = (val: string) => {
    setServerIp(val);
    try {
      localStorage.setItem('hh_lan_url_v1', val);
    } catch {
      // ignore
    }
    onSetServerUrl(val.trim() || null);
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey((prev) => (prev === key ? null : prev)), 1800);
  };

  const shareText = (title: string, text: string, key: string) => {
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      navigator.share({ title, text }).catch(() => copyText(text, key));
    } else {
      copyText(text, key);
    }
  };

  const handleGenerateInvite = async () => {
    setLocalError(null);
    setLanBusy(true);
    try {
      const code = await onCreateLanInvite(name.trim() || 'لاعب ١', difficulty);
      setHostInviteCode(code);
      setHostReplyInput('');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'تعذر إنشاء دعوة نقطة الاتصال');
    } finally {
      setLanBusy(false);
    }
  };

  const handleAcceptReply = async () => {
    const clean = hostReplyInput.trim();
    if (!clean) return;
    setLocalError(null);
    setLanBusy(true);
    try {
      await onAcceptLanReply(clean);
      setHostReplyInput('');
      setHostInviteCode('');
      setShowExtraInvite(false);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'رمز الرد غير صالح');
    } finally {
      setLanBusy(false);
    }
  };

  const handleGuestGenerateReply = async () => {
    const clean = guestInviteInput.trim();
    if (!clean) return;
    setLocalError(null);
    setLanBusy(true);
    try {
      const reply = await onJoinLanInvite(clean, name.trim() || 'لاعب ٢');
      setGuestReplyCode(reply);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'رمز الدعوة غير صالح');
    } finally {
      setLanBusy(false);
    }
  };

  const activeError = localError || errorMsg;

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-4 bg-[rgba(2,1,1,0.88)] overflow-y-auto"
      dir="rtl"
    >
      <div className="w-full max-w-[490px] bg-[rgba(14,10,9,0.96)] border border-[rgba(235,227,214,0.2)] rounded-xl p-5 space-y-4 text-[#ebe3d6]">
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div>
            <h2 className="font-display text-3xl text-[#e2b34a] leading-none">
              اللعب الجماعي (LAN)
            </h2>
            <p className="text-xs text-[#a09384] mt-1">
              العب مع أصدقائك عبر نقطة الاتصال (Hotspot) أو الشبكة المحلية
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 rounded border border-white/20 text-xs text-[#c5b9aa] hover:bg-white/10 cursor-pointer whitespace-nowrap shrink-0"
          >
            إغلاق
          </button>
        </div>

        {activeError && (
          <div className="bg-[#4b0e0b] border border-[#b3201a] text-[#ffdad6] text-xs rounded-md px-3 py-2 text-center">
            {activeError}
          </div>
        )}

        {!room ? (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs text-[#c5b9aa]" htmlFor="mp-name-input">
                اسمك في الغرفة
              </label>
              <input
                id="mp-name-input"
                type="text"
                maxLength={14}
                value={name}
                onChange={(e) => saveName(e.target.value)}
                placeholder="مثال: أحمد"
                className="w-full px-3 py-2 rounded-md bg-black/50 border border-white/20 text-sm text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
              />
            </div>

            {/* Connection Mode Tabs */}
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-lg bg-black/55 border border-white/10">
              <button
                type="button"
                onClick={() => {
                  setLocalError(null);
                  setMode('hotspot');
                }}
                className={`py-2 px-2 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'hotspot'
                    ? 'bg-[#5e0d0a] text-[#ebe3d6] border border-[#b3201a]'
                    : 'text-[#a09384] hover:text-[#ebe3d6]'
                }`}
              >
                نقطة اتصال مباشرة (بدون نت)
              </button>
              <button
                type="button"
                onClick={() => {
                  setLocalError(null);
                  setMode('server');
                }}
                className={`py-2 px-2 rounded-md text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'server'
                    ? 'bg-[#5e0d0a] text-[#ebe3d6] border border-[#b3201a]'
                    : 'text-[#a09384] hover:text-[#ebe3d6]'
                }`}
              >
                خادم الشبكة المحلية / الرمز
              </button>
            </div>

            {mode === 'hotspot' ? (
              <div className="space-y-3 bg-black/40 border border-white/10 rounded-lg p-3.5">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setLocalError(null);
                      setHotspotRole('host');
                    }}
                    className={`py-1.5 px-3 rounded text-xs font-bold border cursor-pointer ${
                      hotspotRole === 'host'
                        ? 'bg-[#2a221d] border-[#e2b34a] text-[#e2b34a]'
                        : 'bg-black/40 border-white/15 text-[#c5b9aa]'
                    }`}
                  >
                    أنا المضيف (أنشئ الاتصال)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLocalError(null);
                      setHotspotRole('guest');
                    }}
                    className={`py-1.5 px-3 rounded text-xs font-bold border cursor-pointer ${
                      hotspotRole === 'guest'
                        ? 'bg-[#2a221d] border-[#e2b34a] text-[#e2b34a]'
                        : 'bg-black/40 border-white/15 text-[#c5b9aa]'
                    }`}
                  >
                    أنا الضيف (لدي دعوة)
                  </button>
                </div>

                {hotspotRole === 'host' ? (
                  <div className="space-y-3">
                    <p className="text-[11px] text-[#c5b9aa] leading-relaxed">
                      ١. اتصلا بنفس نقطة الاتصال (Hotspot) بدون إنترنت. ٢. أنشئ رمز الدعوة وأرسله
                      لصديقك. ٣. ألصق رمز الرد منه لبدء اللعب مباشرة.
                    </p>

                    <button
                      type="button"
                      disabled={lanBusy}
                      onClick={handleGenerateInvite}
                      className="w-full py-2.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] disabled:opacity-50 border border-[#b3201a] font-display text-2xl text-[#ebe3d6] cursor-pointer"
                    >
                      {lanBusy ? 'جاري تجهيز رمز نقطة الاتصال...' : '١. توليد رمز الدعوة'}
                    </button>

                    {hostInviteCode && (
                      <div className="space-y-2 bg-black/55 border border-[#e2b34a]/35 rounded-md p-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] text-[#e2b34a] font-bold">
                            أرسل هذا الرمز لصديقك:
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => copyText(hostInviteCode, 'invite')}
                              className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 text-[11px] text-[#ebe3d6] cursor-pointer whitespace-nowrap"
                            >
                              {copiedKey === 'invite' ? 'تم النسخ ✓' : 'نسخ'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                shareText('دعوة لعبة بيت المطرقة LAN', hostInviteCode, 'invite')
                              }
                              className="px-2.5 py-1 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[11px] text-[#e2b34a] cursor-pointer whitespace-nowrap"
                            >
                              مشاركة
                            </button>
                          </div>
                        </div>
                        <textarea
                          readOnly
                          rows={2}
                          dir="ltr"
                          value={hostInviteCode}
                          onFocus={(e) => e.currentTarget.select()}
                          className="w-full px-2 py-1.5 rounded bg-black/70 border border-white/10 font-mono text-[10px] text-[#ebe3d6] resize-none"
                        />
                      </div>
                    )}

                    <div className="space-y-1.5 pt-1 border-t border-white/10">
                      <label className="block text-[11px] text-[#c5b9aa]">
                        ٢. ألصق رمز الرد من هاتف صديقك:
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          dir="ltr"
                          value={hostReplyInput}
                          onChange={(e) => setHostReplyInput(e.target.value)}
                          placeholder="LANZ:..."
                          className="flex-1 px-2.5 py-2 rounded-md bg-black/60 border border-white/20 font-mono text-xs text-[#e2b34a] focus:outline-none focus:border-[#e2b34a]"
                        />
                        <button
                          type="button"
                          disabled={lanBusy || !hostReplyInput.trim()}
                          onClick={handleAcceptReply}
                          className="px-4 py-2 rounded-md bg-[#2a221d] hover:bg-[#3a2f28] disabled:opacity-45 border border-[#e2b34a]/50 text-xs font-bold text-[#e2b34a] cursor-pointer whitespace-nowrap"
                        >
                          اتصال
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-[11px] text-[#c5b9aa] leading-relaxed">
                      ١. ألصق رمز الدعوة الذي أرسله المضيف. ٢. اضغط «توليد رمز الرد» وأرسله إليه،
                      وستدخل الغرفة تلقائياً فور قبوله.
                    </p>

                    <div className="space-y-1.5">
                      <label className="block text-[11px] text-[#c5b9aa]">
                        ١. رمز الدعوة من المضيف:
                      </label>
                      <textarea
                        rows={2}
                        dir="ltr"
                        value={guestInviteInput}
                        onChange={(e) => setGuestInviteInput(e.target.value)}
                        placeholder="LANZ:..."
                        className="w-full px-2.5 py-1.5 rounded-md bg-black/60 border border-white/20 font-mono text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a] resize-none"
                      />
                    </div>

                    <button
                      type="button"
                      disabled={lanBusy || !guestInviteInput.trim()}
                      onClick={handleGuestGenerateReply}
                      className="w-full py-2.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] disabled:opacity-45 border border-[#b3201a] font-display text-2xl text-[#ebe3d6] cursor-pointer"
                    >
                      {lanBusy ? 'جاري إنشاء الرد...' : '٢. توليد رمز الرد للمضيف'}
                    </button>

                    {guestReplyCode && (
                      <div className="space-y-2 bg-black/55 border border-[#e2b34a]/35 rounded-md p-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[11px] text-[#e2b34a] font-bold">
                            أرسل الرد للمضيف (بانتظار التأكيد...):
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => copyText(guestReplyCode, 'reply')}
                              className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 text-[11px] text-[#ebe3d6] cursor-pointer whitespace-nowrap"
                            >
                              {copiedKey === 'reply' ? 'تم النسخ ✓' : 'نسخ'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                shareText('رد الاتصال - بيت المطرقة LAN', guestReplyCode, 'reply')
                              }
                              className="px-2.5 py-1 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[11px] text-[#e2b34a] cursor-pointer whitespace-nowrap"
                            >
                              مشاركة
                            </button>
                          </div>
                        </div>
                        <textarea
                          readOnly
                          rows={2}
                          dir="ltr"
                          value={guestReplyCode}
                          onFocus={(e) => e.currentTarget.select()}
                          className="w-full px-2 py-1.5 rounded bg-black/70 border border-white/10 font-mono text-[10px] text-[#ebe3d6] resize-none"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3.5">
                {lanUrls.length > 0 && (
                  <div className="bg-black/45 border border-[#e2b34a]/30 rounded-lg p-3 space-y-1.5">
                    <div className="text-[11px] text-[#e2b34a] font-bold">
                      رابط الشبكة المحلية (افتحه من هاتف صديقك على نفس نقطة الاتصال):
                    </div>
                    {lanUrls.map((url) => (
                      <div key={url} className="flex items-center justify-between gap-2">
                        <span
                          dir="ltr"
                          className="font-mono text-xs text-[#ebe3d6] truncate"
                        >
                          {url}
                        </span>
                        <button
                          type="button"
                          onClick={() => copyText(url, url)}
                          className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 text-[11px] text-[#ebe3d6] cursor-pointer whitespace-nowrap shrink-0"
                        >
                          {copiedKey === url ? 'تم النسخ ✓' : 'نسخ الرابط'}
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => onCreateRoom(name.trim() || 'لاعب ١', difficulty)}
                  className="w-full py-2.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] font-display text-2xl text-[#ebe3d6] cursor-pointer transition-colors"
                >
                  إنشاء غرفة جديدة
                </button>

                <div className="relative flex items-center py-0.5">
                  <div className="flex-grow border-t border-white/10" />
                  <span className="mx-3 text-xs text-[#a09384]">أو انضم برمز الغرفة</span>
                  <div className="flex-grow border-t border-white/10" />
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    maxLength={4}
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    placeholder="ABCD"
                    dir="ltr"
                    className="flex-1 px-3 py-2 rounded-md bg-black/50 border border-white/20 text-center font-mono text-lg tracking-[0.35em] uppercase text-[#e2b34a] focus:outline-none focus:border-[#e2b34a]"
                  />
                  <button
                    type="button"
                    disabled={joinCode.trim().length < 4}
                    onClick={() => onJoinRoom(joinCode.trim(), name.trim() || 'لاعب ٢')}
                    className="px-5 py-2 rounded-md bg-[#2a221d] hover:bg-[#3a2f28] disabled:opacity-45 border border-[#e2b34a]/50 text-sm font-bold text-[#e2b34a] cursor-pointer"
                  >
                    انضمام
                  </button>
                </div>

                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setShowCustomIp((v) => !v)}
                    className="text-[11px] text-[#a09384] hover:text-[#e2b34a] underline cursor-pointer"
                  >
                    {showCustomIp
                      ? 'إخفاء إعداد عنوان خادم الشبكة المحلية'
                      : 'اتصال بعنوان IP مخصص على نقطة الاتصال (مثلاً 192.168.43.1:3000)'}
                  </button>
                  {showCustomIp && (
                    <div className="mt-2 flex gap-2">
                      <input
                        type="text"
                        dir="ltr"
                        value={serverIp}
                        onChange={(e) => applyCustomIp(e.target.value)}
                        placeholder="192.168.43.1:3000"
                        className="flex-1 px-2.5 py-1.5 rounded bg-black/60 border border-white/20 font-mono text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                      />
                      {serverIp && (
                        <button
                          type="button"
                          onClick={() => applyCustomIp('')}
                          className="px-2.5 py-1.5 rounded bg-white/10 text-[11px] text-[#c5b9aa] cursor-pointer"
                        >
                          افتراضي
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}

            <p className="text-[11px] text-[#a09384] bg-black/35 border border-white/10 rounded-md p-2.5 leading-relaxed">
              تظهر شخصية زميلك بوضوح داخل البيت بسترة ملونة، كشاف ضوئي، الأداة التي يحملها،
              واسمه فوق رأسه، مع دردشة فورية ومشاركة المفاتيح والأقفال.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Room Code / LAN Banner */}
            <div className="bg-black/50 border border-[#e2b34a]/35 rounded-lg p-3 flex items-center justify-between gap-3">
              <div>
                <div className="text-[11px] text-[#a09384]">
                  {isLanRoom ? 'وضع الشبكة المحلية المباشر (Hotspot LAN)' : 'رمز الغرفة (أرسله لصديقك)'}
                </div>
                <div
                  className="font-mono text-2xl sm:text-3xl font-bold tracking-[0.22em] text-[#e2b34a]"
                  dir="ltr"
                >
                  {isLanRoom ? 'LAN HOTSPOT' : room.code}
                </div>
              </div>
              {isLanRoom && isHost ? (
                <button
                  type="button"
                  onClick={() => setShowExtraInvite((v) => !v)}
                  className="px-3 py-1.5 rounded bg-white/10 hover:bg-white/15 border border-white/20 text-xs text-[#ebe3d6] cursor-pointer whitespace-nowrap"
                >
                  {showExtraInvite ? 'إغلاق الدعوة' : '+ دعوة لاعب إضافي'}
                </button>
              ) : !isLanRoom ? (
                <button
                  type="button"
                  onClick={() => copyText(room.code, 'roomCode')}
                  className="px-3 py-1.5 rounded bg-white/10 hover:bg-white/15 border border-white/20 text-xs text-[#ebe3d6] cursor-pointer whitespace-nowrap"
                >
                  {copiedKey === 'roomCode' ? 'تم النسخ ✓' : 'نسخ الرمز'}
                </button>
              ) : null}
            </div>

            {isLanRoom && isHost && showExtraInvite && (
              <div className="bg-black/45 border border-white/15 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#e2b34a]">إضافة لاعب آخر عبر نقطة الاتصال</span>
                  <button
                    type="button"
                    disabled={lanBusy}
                    onClick={handleGenerateInvite}
                    className="px-2.5 py-1 rounded bg-[#5e0d0a] border border-[#b3201a] text-[11px] text-[#ebe3d6] cursor-pointer"
                  >
                    {lanBusy ? 'جاري الإنشاء...' : 'توليد دعوة جديدة'}
                  </button>
                </div>
                {hostInviteCode && (
                  <div className="flex gap-1.5">
                    <input
                      readOnly
                      dir="ltr"
                      value={hostInviteCode}
                      onFocus={(e) => e.currentTarget.select()}
                      className="flex-1 px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px]"
                    />
                    <button
                      type="button"
                      onClick={() => copyText(hostInviteCode, 'extraInvite')}
                      className="px-2.5 py-1 rounded bg-white/10 text-[11px] cursor-pointer"
                    >
                      {copiedKey === 'extraInvite' ? '✓' : 'نسخ'}
                    </button>
                  </div>
                )}
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    dir="ltr"
                    value={hostReplyInput}
                    onChange={(e) => setHostReplyInput(e.target.value)}
                    placeholder="ألصق رمز الرد هنا..."
                    className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[11px]"
                  />
                  <button
                    type="button"
                    disabled={lanBusy || !hostReplyInput.trim()}
                    onClick={handleAcceptReply}
                    className="px-3 py-1 rounded bg-[#2a221d] border border-[#e2b34a]/50 text-[11px] text-[#e2b34a] cursor-pointer"
                  >
                    تأكيد
                  </button>
                </div>
              </div>
            )}

            {/* Connected Players List */}
            <div className="space-y-1.5">
              <div className="text-xs text-[#c5b9aa] font-bold">
                اللاعبون المتصلون ({toArabicDigits(room.peers.length)}/٤)
              </div>
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {room.peers.map((p) => {
                  const color = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
                  const isYou = p.id === selfId;
                  const isRoomHost = p.id === room.hostId;
                  return (
                    <div
                      key={p.id}
                      className="flex items-center justify-between px-3 py-2 rounded-md bg-white/5 border border-white/10 text-xs sm:text-sm"
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className="w-3 h-3 rounded-sm shrink-0 border border-white/40"
                          style={{ backgroundColor: color }}
                        />
                        <span className="font-bold text-[#ebe3d6]">{p.name}</span>
                        {isYou && (
                          <span className="text-[11px] px-1.5 py-0.5 rounded bg-white/10 text-[#c5b9aa]">
                            أنت
                          </span>
                        )}
                        {isRoomHost && (
                          <span className="text-[11px] px-1.5 py-0.5 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[#e2b34a]">
                            المضيف
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-[#a09384]">متصل</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Difficulty Selection (Host controls it) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-[#c5b9aa]">
                <span>مستوى الصعوبة:</span>
                <span className="text-[#e2b34a] font-bold">{DIFFICULTIES[room.diff].name}</span>
              </div>
              {isHost && (
                <div className="grid grid-cols-5 gap-1.5">
                  {DIFF_KEYS.map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => onChangeDiff(k)}
                      className={`py-1.5 rounded text-[11px] border cursor-pointer ${
                        room.diff === k
                          ? 'bg-[#5e0d0a] border-[#b3201a] text-white font-bold'
                          : 'bg-black/40 border-white/15 text-[#c5b9aa] hover:border-white/30'
                      }`}
                    >
                      {DIFFICULTIES[k].name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Lobby Chat */}
            <div className="bg-black/45 border border-white/10 rounded-lg p-2.5 space-y-2">
              <div className="text-[11px] text-[#a09384] font-bold">دردشة الغرفة</div>
              <div
                ref={chatScrollRef}
                className="h-24 overflow-y-auto space-y-1 text-xs pe-1"
              >
                {chatMessages.length === 0 ? (
                  <div className="text-[#a09384]/70 text-center py-5">
                    ابدأ المحادثة مع زملائك قبل دخول البيت...
                  </div>
                ) : (
                  chatMessages.map((m) => {
                    const color = PEER_COLORS[Math.abs(m.colorIndex) % PEER_COLORS.length];
                    return (
                      <div key={m.id} className="leading-snug break-words">
                        {m.system ? (
                          <span className="text-[#a09384] italic">{m.text}</span>
                        ) : (
                          <>
                            <span className="font-bold me-1.5" style={{ color }}>
                              {m.senderName}:
                            </span>
                            <span className="text-[#ebe3d6]">{m.text}</span>
                          </>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
              <form onSubmit={handleChatSubmit} className="flex gap-1.5">
                <input
                  type="text"
                  maxLength={160}
                  value={chatText}
                  onChange={(e) => setChatText(e.target.value)}
                  placeholder="اكتب رسالة..."
                  className="flex-1 px-2.5 py-1.5 rounded bg-black/60 border border-white/15 text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-xs font-bold text-[#ebe3d6] cursor-pointer"
                >
                  إرسال
                </button>
              </form>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pt-1">
              {isHost ? (
                <button
                  type="button"
                  onClick={onStartGame}
                  className="flex-1 py-2.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] font-display text-2xl text-[#ebe3d6] cursor-pointer"
                >
                  ابدأ اللعب الجماعي
                </button>
              ) : (
                <div className="flex-1 py-2 text-center text-xs text-[#e2b34a] bg-black/40 border border-[#e2b34a]/25 rounded-md">
                  في انتظار المضيف لبدء الليلة...
                </div>
              )}
              <button
                type="button"
                onClick={() => {
                  setHostInviteCode('');
                  setGuestReplyCode('');
                  onLeaveRoom();
                }}
                className="px-4 py-2.5 rounded-md border border-white/20 text-xs text-[#c5b9aa] hover:bg-white/10 cursor-pointer"
              >
                مغادرة الغرفة
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
