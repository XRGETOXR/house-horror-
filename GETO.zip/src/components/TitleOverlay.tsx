import { useState } from 'react';
import gameCoverImg from '../assets/images/hammer_house_cover_1794939975336.jpg';
import gameIconImg from '../assets/images/hammer_house_icon_1794939976192.jpg';
import { DIFFICULTIES, HOUSE_PRESETS, toArabicDigits } from '../game/constants';
import { DifficultyKey, HouseTheme } from '../game/types';

interface TitleOverlayProps {
  difficulty: DifficultyKey;
  houseTheme: HouseTheme;
  mpRoomCode: string | null;
  mpPeersCount: number;
  isFullscreen: boolean;
  onSelectDifficulty: (diff: DifficultyKey) => void;
  onSelectHouseTheme: (theme: HouseTheme) => void;
  onStart: () => void;
  onOpenMultiplayer: () => void;
  onOpenSettings: () => void;
  onToggleFullscreen: () => void;
}

const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];
const HOUSE_KEYS: HouseTheme[] = ['manor', 'classic'];

export function TitleOverlay({
  difficulty,
  houseTheme,
  mpRoomCode,
  mpPeersCount,
  isFullscreen,
  onSelectDifficulty,
  onSelectHouseTheme,
  onStart,
  onOpenMultiplayer,
  onOpenSettings,
  onToggleFullscreen,
}: TitleOverlayProps) {
  const [showGuide, setShowGuide] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadNote, setDownloadNote] = useState<string | null>(null);
  const isOfflineFile = typeof window !== 'undefined' && window.location.protocol === 'file:';

  const handleDownloadGame = async () => {
    if (downloading) return;
    setDownloading(true);
    setDownloadNote(null);
    try {
      const res = await fetch('/api/download-offline');
      if (!res.ok) throw new Error('failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HammerHouse-Game.html';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);
      setDownloadNote('تم تنزيل ملف اللعب أوفلاين بنجاح.');
    } catch {
      setDownloadNote('تعذر التنزيل من المعاينة الحالية.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-20 w-full h-full flex flex-col justify-between overflow-hidden select-none"
      dir="rtl"
    >
      {/* Full-Screen Atmospheric Cover Artwork blended over the live 3D hallway */}
      <img
        src={gameCoverImg}
        alt=""
        aria-hidden="true"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-center opacity-45 pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse at 50% 34%, rgba(16,8,7,0.22) 0%, rgba(7,4,4,0.72) 56%, rgba(4,2,2,0.96) 100%)',
        }}
      />

      {/* Top Game Title & Compact Toolbar */}
      <header className="relative z-10 flex items-start justify-between gap-2 px-3 pt-2.5 sm:px-6 sm:pt-4">
        <div className="flex items-center gap-2.5 min-w-0">
          <img
            src={gameIconImg}
            alt="شعار بيت المطرقة"
            referrerPolicy="no-referrer"
            className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg object-cover border border-[#e2b34a]/50 shadow-[0_4px_14px_rgba(0,0,0,0.85)] shrink-0"
          />
          <div className="min-w-0">
            <h1 className="font-display text-2xl sm:text-4xl leading-none text-[#dc281e] [text-shadow:0_2px_14px_rgba(0,0,0,0.95)]">
              بيت المطرقة
            </h1>
            <p className="text-[10px] sm:text-xs text-[#cfc3b4] mt-0.5 truncate">
              ٥ أيام للنجاة · رعب وبقاء
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {!isOfflineFile && (
            <button
              type="button"
              disabled={downloading}
              onClick={handleDownloadGame}
              className="min-h-[36px] px-2.5 py-1 rounded-md bg-black/55 hover:bg-black/75 disabled:opacity-50 border border-[#e2b34a]/35 text-[10px] sm:text-xs font-bold text-[#e2b34a] cursor-pointer transition-colors"
            >
              {downloading ? 'جارٍ...' : 'ملف أوفلاين'}
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowGuide((v) => !v)}
            className={`min-h-[36px] px-2.5 py-1 rounded-md border text-[10px] sm:text-xs font-bold cursor-pointer transition-colors ${
              showGuide
                ? 'bg-[#2a1710]/90 border-[#e2b34a] text-[#e2b34a]'
                : 'bg-black/55 hover:bg-black/75 border-white/20 text-[#ebe3d6]'
            }`}
          >
            دليل
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[36px] px-2.5 py-1 rounded-md bg-black/55 hover:bg-black/75 border border-white/20 text-[10px] sm:text-xs font-bold text-[#ebe3d6] cursor-pointer transition-colors"
          >
            الإعدادات
          </button>
          <button
            type="button"
            onClick={onToggleFullscreen}
            aria-label={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
            title={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
            className="min-w-[36px] min-h-[36px] rounded-md bg-black/55 hover:bg-black/75 border border-white/25 text-xs sm:text-sm text-[#ebe3d6] cursor-pointer flex items-center justify-center"
          >
            ⛶
          </button>
        </div>
      </header>

      {/* Center Collapsible Guide / Status Toast (leaves 3D horror vista unobstructed when closed) */}
      <div className="relative z-10 flex-1 flex items-center justify-center px-3 pointer-events-none">
        {downloadNote && !showGuide && (
          <div className="pointer-events-auto text-[11px] text-[#ebe3d6] bg-[rgba(18,28,20,0.92)] border border-[#45b877]/50 rounded-md px-3 py-1.5">
            {downloadNote}
          </div>
        )}
        {showGuide && (
          <div className="pointer-events-auto w-full max-w-[440px] bg-[rgba(10,6,5,0.92)] border border-[#e2b34a]/35 rounded-lg p-3 text-start text-[11px] sm:text-xs text-[#ebe3d6] space-y-1.5 shadow-2xl">
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold text-[#e2b34a]">كيف تهرب من البيت؟</span>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="text-[10px] text-[#a09384] hover:text-white cursor-pointer"
              >
                إغلاق ✕
              </button>
            </div>
            <p className="text-[#cfc3b4] leading-relaxed">
              ابحث في الصناديق عن المفاتيح، وفكّ أقفال بوابة الخروج بالترتيب: المطرقة ← قاطع الأسلاك (الطابق ٢) ← المفك (خزنة المكتبة — رمزها بالمطبخ).
            </p>
            <p className="text-[#a09384] leading-relaxed">
              الجوال: الدائرة يساراً للحركة · اسحب اليمين للالتفات · زر تفاعل للفتح والاختباء وإنعاش الزملاء في LAN.
            </p>
          </div>
        )}
      </div>

      {/* Bottom Full-Width Compact Mobile-Game Dock */}
      <footer className="relative z-10 w-full px-3 pb-3 sm:px-6 sm:pb-5">
        <div className="mx-auto w-full max-w-[680px] space-y-2">
          {/* House + Difficulty Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 sm:gap-2">
            <div className="grid grid-cols-2 gap-1.5">
              {HOUSE_KEYS.map((key) => {
                const hp = HOUSE_PRESETS[key];
                const active = houseTheme === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onSelectHouseTheme(key)}
                    className={`py-1.5 px-2 rounded-md border text-start transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#2c1512]/90 border-[#e2b34a] text-[#ebe3d6]'
                        : 'bg-black/60 border-white/15 text-[#b4a797] hover:border-white/30'
                    }`}
                  >
                    <span className="block text-[11px] sm:text-xs font-bold truncate">{hp.name}</span>
                    <span className="block text-[9px] sm:text-[10px] text-[#a09384] truncate">
                      {key === 'manor' ? 'قصر حجري ومدفأة' : 'خشبي كلاسيكي'}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-5 gap-1">
              {DIFF_KEYS.map((key) => {
                const d = DIFFICULTIES[key];
                const active = difficulty === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onSelectDifficulty(key)}
                    className={`py-1.5 px-1 rounded-md border text-center transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#5e0d0a]/95 border-[#d3261d] text-[#ebe3d6]'
                        : 'bg-black/60 border-white/15 text-[#c2b5a6] hover:border-white/30'
                    }`}
                  >
                    <span className="block text-[10px] sm:text-[11px] font-bold leading-tight">
                      {d.name}
                    </span>
                    <span className="block text-[9px] text-[#a09384] font-mono-num">
                      {toArabicDigits(d.keys)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <p className="text-[10px] sm:text-[11px] text-[#b8ab9c] text-center truncate">
            {DIFFICULTIES[difficulty].info}
          </p>

          {/* Primary Play + LAN Co-op Action Row */}
          <div className="grid grid-cols-[1.55fr_1fr] gap-2">
            <button
              type="button"
              onClick={onStart}
              className="min-h-[46px] sm:min-h-[50px] font-display text-xl sm:text-2xl py-1.5 rounded-lg bg-[#6b100c] hover:bg-[#851611] border border-[#cf2a22] text-[#ebe3d6] cursor-pointer transition-colors shadow-[0_6px_20px_rgba(179,32,26,0.4)]"
            >
              ابدأ اللعب
            </button>
            <button
              type="button"
              onClick={onOpenMultiplayer}
              className="min-h-[46px] sm:min-h-[50px] px-2 py-1.5 rounded-lg bg-[#1d1511]/92 hover:bg-[#2c201a] border border-[#e2b34a]/55 text-xs sm:text-sm font-bold text-[#e2b34a] cursor-pointer transition-colors"
            >
              {mpRoomCode
                ? mpRoomCode === 'LAN'
                  ? `LAN (${toArabicDigits(mpPeersCount)})`
                  : `${mpRoomCode} (${toArabicDigits(mpPeersCount)})`
                : 'لعب جماعي LAN'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

