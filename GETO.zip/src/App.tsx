/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { DayTransitionOverlay } from './components/DayTransitionOverlay';
import { DiaryNoteModal } from './components/DiaryNoteModal';
import { EndScreenModal } from './components/EndScreenModal';
import { HorrorHud } from './components/HorrorHud';
import { MultiplayerModal } from './components/MultiplayerModal';
import { PauseModal } from './components/PauseModal';
import { SafeKeypadModal } from './components/SafeKeypadModal';
import { SettingsModal } from './components/SettingsModal';
import { TitleOverlay } from './components/TitleOverlay';
import { DIARY_NOTES, MAX_DAYS } from './game/constants';
import {
  isGameFullscreen,
  requestGameFullscreen,
  toggleGameFullscreen,
} from './game/fullscreen';
import { GrannyEngine } from './game/GrannyEngine';
import {
  ChatMessage,
  DifficultyKey,
  GameSettings,
  HouseTheme,
  HudState,
  MultiplayerRoomSnapshot,
} from './game/types';
import { useDynamicHeartbeat } from './hooks/useDynamicHeartbeat';

const DEFAULT_SETTINGS: GameSettings = {
  gfx: 'med',
  sens: 1,
  vol: 0.75,
  bright: 1,
  diff: 'med',
  houseTheme: 'manor',
  touchMode: 'auto',
};

function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem('hh_set_v2');
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

const INITIAL_HUD: HudState = {
  state: 'menu',
  houseTheme: 'manor',
  day: 1,
  maxDays: MAX_DAYS,
  livesLeft: MAX_DAYS,
  roomName: '—',
  floor: 0,
  keys: 0,
  needKeys: 4,
  ammo: 0,
  hasGun: false,
  heldItem: null,
  heldLabel: 'فارغة',
  codeKnown: false,
  safeCode: 427,
  safeOpen: false,
  locks: {
    plankBroken: false,
    wireCut: false,
    panelOpened: false,
    keysUsed: false,
  },
  doorOpen: false,
  stamina: 1,
  exhausted: false,
  crouch: false,
  torch: true,
  hidden: false,
  hiddenKind: null,
  trappedTimer: 0,
  trapProgress: 0,
  stalkerState: 'patrol',
  stalkerStunLeft: 0,
  threat: 0,
  prompt: '',
  toast: '',
  toastId: 0,
  exitArrowAngle: null,
  exitArrowText: '',
  mapOpen: false,
  notesRead: [],
  activeNoteId: null,
  totalNotes: DIARY_NOTES.length,
  mpConnected: false,
  mpRoomCode: null,
  mpIsHost: false,
  mpPeers: [],
  mpSpectatingName: null,
  revivingTargetName: null,
  revivingTimeLeft: 0,
  revivingProgress: 0,
  playerX: 5.4,
  playerZ: 28.2,
  playerYaw: -Math.PI / 2,
  timeSeconds: 0,
  hidesCount: 0,
  chasesCount: 0,
  trapsTriggered: 0,
  killer: null,
  dayPhase: 'start',
  dayCross: false,
  daySub: '',
  cinemaCaption: '',
  cinemaBig: false,
  cinemaFlash: 0,
  cinemaBars: false,
  lidOpacity: 0,
  hitFlash: 0,
  dangerOpacity: 0,
};

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GrannyEngine | null>(null);

  const [settings, setSettings] = useState<GameSettings>(loadSettings);
  const [hud, setHud] = useState<HudState>(INITIAL_HUD);
  const [showSettingsFrom, setShowSettingsFrom] = useState<'menu' | 'pause' | null>(null);
  const [showMpModal, setShowMpModal] = useState(false);
  const [mpRoom, setMpRoom] = useState<MultiplayerRoomSnapshot | null>(null);
  const [mpSelfId, setMpSelfId] = useState<string | null>(null);
  const [mpError, setMpError] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatOpen, setChatOpen] = useState(false);
  const [unreadChat, setUnreadChat] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(() => isGameFullscreen());
  const chatOpenRef = useRef(false);
  chatOpenRef.current = chatOpen;

  const [isTouch, setIsTouch] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return (
      'ontouchstart' in window ||
      window.matchMedia?.('(pointer: coarse)')?.matches ||
      (navigator.maxTouchPoints ?? 0) > 0
    );
  });
  const [webglError, setWebglError] = useState<string | null>(null);

  const showTouch =
    settings.touchMode === 'on' || (settings.touchMode === 'auto' && isTouch);

  useDynamicHeartbeat(hud.threat, hud.state === 'play' || hud.state === 'pad');

  useEffect(() => {
    const onTouch = () => setIsTouch(true);
    const onPointerDown = (e: PointerEvent) => {
      if (e.pointerType === 'touch') setIsTouch(true);
    };
    const onFsChange = () => setIsFullscreen(isGameFullscreen());

    window.addEventListener('touchstart', onTouch, { passive: true });
    window.addEventListener('pointerdown', onPointerDown, { passive: true });
    document.addEventListener('fullscreenchange', onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    return () => {
      window.removeEventListener('touchstart', onTouch);
      window.removeEventListener('pointerdown', onPointerDown);
      document.removeEventListener('fullscreenchange', onFsChange);
      document.removeEventListener('webkitfullscreenchange', onFsChange);
    };
  }, []);

  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.touchMove.active = showTouch;
    }
  }, [showTouch]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    try {
      const engine = new GrannyEngine(
        container,
        settings,
        (nextHud) => {
          setHud(nextHud);
        },
        (room, selfId, err) => {
          setMpRoom(room);
          setMpSelfId(selfId);
          setMpError(err || null);
          if (!room) {
            setChatMessages([]);
            setChatOpen(false);
            setUnreadChat(0);
          } else if (room.messages) {
            setChatMessages(room.messages);
          }
          if (room?.phase === 'playing') {
            setShowMpModal(false);
          }
        },
        (msg) => {
          setChatMessages((prev) => {
            if (prev.some((m) => m.id === msg.id)) return prev;
            const next = [...prev, msg];
            return next.length > 60 ? next.slice(-60) : next;
          });
          if (!chatOpenRef.current) {
            setUnreadChat((n) => n + 1);
          }
        },
        () => {
          setChatOpen(true);
          setUnreadChat(0);
        }
      );
      engine.touchMove.active = showTouch;
      engineRef.current = engine;
      return () => {
        engine.dispose();
        engineRef.current = null;
      };
    } catch {
      setWebglError('متصفحك أو جهازك لا يدعم WebGL المطلوب لتشغيل اللعبة ثلاثية الأبعاد.');
      return undefined;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const updateSettings = useCallback((next: GameSettings) => {
    setSettings(next);
    try {
      localStorage.setItem('hh_set_v2', JSON.stringify(next));
    } catch {
      // ignore
    }
    engineRef.current?.applySettings(next);
  }, []);

  const handleSelectDifficulty = useCallback(
    (diff: DifficultyKey) => {
      updateSettings({ ...settings, diff });
    },
    [settings, updateSettings]
  );

  const handleSelectHouseTheme = useCallback(
    (houseTheme: HouseTheme) => {
      updateSettings({ ...settings, houseTheme });
    },
    [settings, updateSettings]
  );

  const handleStartWithFullscreen = useCallback(() => {
    void requestGameFullscreen();
    engineRef.current?.startGame();
  }, []);

  const handleTouchMove = useCallback((mx: number, mz: number) => {
    if (!engineRef.current) return;
    engineRef.current.touchMove.mx = mx;
    engineRef.current.touchMove.mz = mz;
  }, []);

  const handleTouchRun = useCallback((running: boolean) => {
    if (!engineRef.current) return;
    engineRef.current.touchMove.run = running;
  }, []);

  const handleTouchLook = useCallback((dx: number, dy: number) => {
    engineRef.current?.look(dx, dy, 0.0055);
  }, []);

  if (webglError) {
    return (
      <div className="fixed inset-0 bg-[#050404] text-[#ebe3d6] grid place-items-center p-6 text-center" dir="rtl">
        <div className="max-w-md space-y-3">
          <h1 className="font-display text-4xl text-[#b3201a]">بيت المطرقة</h1>
          <p className="text-sm text-[#a09384]">{webglError}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#050404]" dir="rtl" lang="ar">
      {/* Isolated WebGL Mount Container */}
      <div ref={mountRef} className="fixed inset-0 w-full h-full" />

      {/* Active HUD & Atmosphere Layers */}
      <HorrorHud
        hud={hud}
        isTouch={showTouch}
        isFullscreen={isFullscreen}
        chatMessages={chatMessages}
        chatOpen={chatOpen}
        unreadChat={unreadChat}
        onToggleChat={(open) => {
          setChatOpen(open);
          if (open) setUnreadChat(0);
          engineRef.current?.setChatOpen(open);
        }}
        onSendChat={(text) => engineRef.current?.sendMpChat(text)}
        onInteract={() => engineRef.current?.interact()}
        onDrop={() => engineRef.current?.dropHeldItem(true)}
        onFire={() => engineRef.current?.fireGun()}
        onToggleCrouch={() => engineRef.current?.toggleCrouch()}
        onToggleTorch={() => engineRef.current?.toggleTorch()}
        onToggleMap={() => engineRef.current?.toggleMap()}
        onOpenJournal={() => engineRef.current?.openJournal()}
        onPause={() => engineRef.current?.pauseGame()}
        onToggleFullscreen={toggleGameFullscreen}
        onCycleSpectate={() => engineRef.current?.cycleSpectate()}
        onExitSpectate={() => engineRef.current?.toMenu()}
        onTouchMove={handleTouchMove}
        onTouchRun={handleTouchRun}
        onTouchLook={handleTouchLook}
        onSkipCinema={() => engineRef.current?.skipCinema()}
      />

      {/* Title Screen */}
      {hud.state === 'menu' && !showSettingsFrom && !showMpModal && (
        <TitleOverlay
          difficulty={settings.diff}
          houseTheme={settings.houseTheme}
          mpRoomCode={mpRoom ? mpRoom.code : null}
          mpPeersCount={mpRoom ? mpRoom.peers.length : 0}
          isFullscreen={isFullscreen}
          onSelectDifficulty={handleSelectDifficulty}
          onSelectHouseTheme={handleSelectHouseTheme}
          onStart={handleStartWithFullscreen}
          onOpenMultiplayer={() => {
            setMpError(null);
            setShowMpModal(true);
          }}
          onOpenSettings={() => setShowSettingsFrom('menu')}
          onToggleFullscreen={toggleGameFullscreen}
        />
      )}

      {/* Multiplayer Lobby Modal */}
      {hud.state === 'menu' && showMpModal && (
        <MultiplayerModal
          room={mpRoom}
          selfId={mpSelfId}
          errorMsg={mpError}
          difficulty={mpRoom ? mpRoom.diff : settings.diff}
          chatMessages={chatMessages}
          onSendChat={(text) => engineRef.current?.sendMpChat(text)}
          onCreateRoom={(name, diff) => {
            setMpError(null);
            engineRef.current?.createMpRoom(name, diff);
          }}
          onJoinRoom={(code, name) => {
            setMpError(null);
            engineRef.current?.joinMpRoom(code, name);
          }}
          onSetServerUrl={(url) => engineRef.current?.setMpServerUrl(url)}
          onCreateLanInvite={async (name, diff) => {
            setMpError(null);
            if (!engineRef.current) throw new Error('المحرك غير جاهز');
            return engineRef.current.createLanInvite(name, diff);
          }}
          onAcceptLanReply={async (replyCode) => {
            setMpError(null);
            if (!engineRef.current) throw new Error('المحرك غير جاهز');
            return engineRef.current.acceptLanReply(replyCode);
          }}
          onJoinLanInvite={async (inviteCode, name) => {
            setMpError(null);
            if (!engineRef.current) throw new Error('المحرك غير جاهز');
            return engineRef.current.joinLanInvite(inviteCode, name);
          }}
          onChangeDiff={(diff) => {
            handleSelectDifficulty(diff);
            engineRef.current?.setMpDifficulty(diff);
          }}
          onStartGame={() => {
            void requestGameFullscreen();
            setShowMpModal(false);
            engineRef.current?.startMpGame();
          }}
          onLeaveRoom={() => {
            setMpError(null);
            engineRef.current?.leaveMpRoom();
          }}
          onClose={() => setShowMpModal(false)}
        />
      )}

      {/* Day Transition */}
      {hud.state === 'day' && (
        <DayTransitionOverlay
          day={hud.day}
          maxDays={hud.maxDays}
          phase={hud.dayPhase}
          cross={hud.dayCross}
          sub={hud.daySub}
        />
      )}

      {/* Safe Keypad */}
      {hud.state === 'pad' && (
        <SafeKeypadModal
          safeCode={hud.safeCode}
          onComplete={(opened) => engineRef.current?.submitSafeResult(opened)}
        />
      )}

      {/* Paper Diary Note Modal */}
      {hud.state === 'note' && hud.activeNoteId && (
        <DiaryNoteModal
          activeNoteId={hud.activeNoteId}
          notesRead={hud.notesRead}
          totalNotes={hud.totalNotes}
          onSelectNote={(id) => engineRef.current?.selectActiveNote(id)}
          onClose={() => engineRef.current?.closeDiaryNote()}
        />
      )}

      {/* Pause Overlay */}
      {hud.state === 'paused' && !showSettingsFrom && (
        <PauseModal
          isFullscreen={isFullscreen}
          onToggleFullscreen={toggleGameFullscreen}
          onResume={() => engineRef.current?.resumeGame()}
          onSettings={() => setShowSettingsFrom('pause')}
          onMenu={() => engineRef.current?.toMenu()}
        />
      )}

      {/* Settings Modal */}
      {showSettingsFrom && (
        <SettingsModal
          settings={settings}
          onChange={updateSettings}
          onBack={() => setShowSettingsFrom(null)}
        />
      )}

      {/* End Screen (Victory or Final Day / Team Wipe Death) */}
      {(hud.state === 'win' ||
        (hud.state === 'dead' && hud.killer && (hud.day >= hud.maxDays || hud.livesLeft <= 0))) && (
        <EndScreenModal
          hud={hud}
          onRestart={handleStartWithFullscreen}
          onSpectate={() => engineRef.current?.startSpectating()}
          onMenu={() => engineRef.current?.toMenu()}
        />
      )}
    </div>
  );
}
