import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  DIFFICULTIES,
  DOOR_W,
  EYE,
  EYE_C,
  FY,
  getHousePreset,
  HousePreset,
  ITEM_LABELS,
  MAX_DAYS,
  toArabicDigits,
} from './constants';
import { FirstPersonHands } from './hands';
import { buildHouseWorld, HouseBuildResult, NavNode } from './houseBuilder';
import { createBearTrapMesh, createGiantRig, createHammerManRig, GiantRig, HammerManRig } from './monsters';
import { MonsterNetPayload, MultiplayerClient } from './multiplayer';
import { animateSurvivorRig, createSurvivorRig, PlayerSurvivorRig, updateSurvivorNameTag } from './playerRig';
import { Snd } from './sound';
import { buildAllTextures, GameTextures, rand } from './textures';
import {
  BearTrap,
  Box2D,
  ChatMessage,
  DifficultyKey,
  DroppedProp,
  ExitLocks,
  GameSettings,
  GameState,
  HeldItemType,
  HideSpot,
  HouseTheme,
  HudState,
  MultiplayerPeer,
  MultiplayerRoomSnapshot,
  RoomWorldSnapshot,
  SearchSpot,
} from './types';

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface RemotePeerEntry {
  peer: MultiplayerPeer;
  rig: PlayerSurvivorRig;
  x: number;
  y: number;
  z: number;
  yaw: number;
}

interface LiveTarget {
  x: number;
  z: number;
  fl: 0 | 1;
  hidden: HideSpot | null;
  crouch: boolean;
  torch: boolean;
  noise: number;
}

function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

const SKY_STOPS: [number, number][] = [
  [0, 0x04060c],
  [0.35, 0x3a2a55],
  [0.7, 0xff9a55],
  [1, 0x8fb4d8],
];

const _cA = new THREE.Color();
const _cB = new THREE.Color();

function skyAt(k: number, out: THREE.Color): void {
  const clamped = Math.max(0, Math.min(1, k));
  for (let i = 0; i < SKY_STOPS.length - 1; i++) {
    if (clamped <= SKY_STOPS[i + 1][0]) {
      const f =
        (clamped - SKY_STOPS[i][0]) / (SKY_STOPS[i + 1][0] - SKY_STOPS[i][0]);
      _cA.setHex(SKY_STOPS[i][1]);
      _cB.setHex(SKY_STOPS[i + 1][1]);
      out.copy(_cA).lerp(_cB, f);
      return;
    }
  }
  out.setHex(SKY_STOPS[SKY_STOPS.length - 1][1]);
}

function ease(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  return c * c * (3 - 2 * c);
}

function lerp(a: number, b: number, k: number): number {
  return a + (b - a) * k;
}

function distBox(x: number, z: number, b: Box2D): number {
  const dx = Math.max(b.x1 - x, 0, x - b.x2);
  const dz = Math.max(b.z1 - z, 0, z - b.z2);
  return Math.hypot(dx, dz);
}

function segHits(ax: number, az: number, bx: number, bz: number, b: Box2D): boolean {
  const dx = bx - ax;
  const dz = bz - az;
  let t0 = 0;
  let t1 = 1;
  const p = [-dx, dx, -dz, dz];
  const q = [ax - b.x1, b.x2 - ax, az - b.z1, b.z2 - az];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) {
      if (q[i] < 0) return false;
    } else {
      const t = q[i] / p[i];
      if (p[i] < 0) {
        if (t > t1) return false;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return false;
        if (t < t1) t1 = t;
      }
    }
  }
  return true;
}

const _torchPos = new THREE.Vector3();
const _torchDir = new THREE.Vector3();

export class GrannyEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private torch: THREE.SpotLight;
  private amb: THREE.AmbientLight;
  private hemi: THREE.HemisphereLight;
  private redGlow: THREE.PointLight;
  private greenGlow: THREE.PointLight;
  private gunFlash: THREE.PointLight;
  private isSoftwareGl: boolean;
  private maxAniso = 4;

  private tex: GameTextures;
  private preset: HousePreset;
  private world: HouseBuildResult;
  private hmRig: HammerManRig;
  private giantRig: GiantRig;
  private hands: FirstPersonHands;

  private settings: GameSettings;
  private onHudUpdate: (hud: HudState) => void;
  private onMpRoomUpdate?: (
    room: MultiplayerRoomSnapshot | null,
    selfId: string | null,
    err?: string
  ) => void;
  private onMpChatMessage?: (msg: ChatMessage) => void;
  private onChatOpenRequest?: () => void;

  private mp: MultiplayerClient;
  private remotePeers = new Map<string, RemotePeerEntry>();
  private remoteMonsterTarget: MonsterNetPayload | null = null;
  private mpSendAcc = 0;
  private spectateId: string | null = null;
  private chatOpen = false;
  private reviveState: {
    targetId: string;
    targetName: string;
    x: number;
    y: number;
    z: number;
    fl: 0 | 1;
    elapsed: number;
    duration: number;
    nextNoiseAt: number;
  } | null = null;

  private frameId = 0;
  private lastTime = 0;
  private elapsedT0 = 0;
  private destroyed = false;
  private hudEmitAcc = 0;

  // Input state
  public keys: Record<string, boolean> = {};
  public touchMove = { mx: 0, mz: 0, run: false, active: false };
  private dragging = false;
  private pointerLocked = false;

  // Game State
  private state: GameState = 'menu';
  private day = 1;
  private dayPhase: 'start' | 'death' | 'final' = 'start';
  private dayCross = false;
  private daySub = '';
  private dayTok = 0;
  private dayFinal = false;

  private timeSeconds = 0;
  private keysCount = 0;
  private needKeys = 4;
  private doorOpen = false;
  private safeOpen = false;
  private safeCode = 427;
  private codeKnown = false;
  private locks: ExitLocks = {
    plankBroken: false,
    wireCut: false,
    panelOpened: false,
    keysUsed: false,
  };

  private giantOn = false;
  private lightTimer = 0;
  private lampOn = false;
  private lampFlicker = 0;
  private fogBase = 0.05;
  private currentFogDensity = 0.05;
  private mistTex!: THREE.CanvasTexture;
  private mistGeo!: THREE.BufferGeometry;
  private mistMat!: THREE.PointsMaterial;
  private mistPoints!: THREE.Points;
  private dustGeo!: THREE.BufferGeometry;
  private dustMat!: THREE.ShaderMaterial;
  private dustPoints!: THREE.Points;
  private mistSeeds: Array<{
    baseX: number;
    baseY: number;
    baseZ: number;
    speedX: number;
    speedZ: number;
    phase: number;
  }> = [];
  private lastFullscreenAt = 0;
  private threat = 0;
  private hbTimer = 1;
  private bangTimer = 25;
  private whisperTimer = 2.0;
  private clockTickAcc = 0;
  private lampSparkCD = 0;
  private ambient = {
    floorCreakTimer: 8,
    windTimer: 11,
    distantStepsTimer: 16,
    rattleTimer: 22,
  };
  private shake = 0;
  private proxShake = 0;
  private moving = false;
  private fireCD = 0;
  private noiseTimer = 0;
  private extraNoise = 0;
  private flashTimer = 0;
  private hitFlash = 0;
  private deadTimer = 0;
  private killer: 'hammer' | 'giant' | 'closet' | 'trap' | null = null;
  private msgShown = false;
  private wakeT = 0;
  private wk1 = false;
  private wk2 = false;
  private lidOpacity = 0;

  private stats = { hides: 0, chases: 0, traps: 0 };
  private mapOpen = false;
  private notesRead: string[] = [];
  private activeNoteId: string | null = null;

  // Player
  private P = {
    fl: 0 as 0 | 1,
    gy: 0,
    x: 5.4,
    z: 28.2,
    yaw: -Math.PI / 2,
    pitch: 0,
    eye: EYE,
    crouch: false,
    stamina: 1,
    exhausted: false,
    hidden: null as HideSpot | null,
    bob: 0,
    torch: true,
    noise: 0,
    roll: 0,
    stepSign: false,
    ammo: 0,
    hasGun: false,
    heldItem: null as HeldItemType,
    trappedTimer: 0,
    trapProgress: 0,
  };

  // Monsters
  private H = {
    catchIdx: -1,
    catchT: 0,
    fl: 0 as 0 | 1,
    gy: 0,
    x: 56,
    z: 8,
    dx: -1,
    dz: 0,
    v: 0,
    state: 'patrol' as 'patrol' | 'investigate' | 'chase' | 'hideCheck' | 'stunned',
    path: [] as { x: number; z: number; fl: 0 | 1 }[],
    wait: 0,
    stateT: 0,
    lose: 0,
    last: null as { x: number; z: number; fl: 0 | 1 } | null,
    atk: 0,
    atkAnim: 0,
    cool: 0,
    noiseCD: 0,
    stuckT: 0,
    sx: 56,
    sz: 8,
    phase: 0,
    closet: null as HideSpot | null,
    hstep: false,
    stun: 0,
    trapPlaceTimer: 12,
  };

  private G = {
    fl: 0 as 0 | 1,
    gy: 0,
    x: 40,
    z: 20,
    dx: -1,
    dz: 0,
    v: 0,
    atk: 0,
    atkAnim: 0,
    cool: 0,
    phase: 0,
    stepSign: false,
    goal: 0,
    stun: 0,
  };
  private pHa = 0;
  private pGa = 0;

  // Dynamic props, vases, and Bear Traps
  private droppedProps: DroppedProp[] = [];
  private propIdSeq = 1;
  private bearTraps: BearTrap[] = [];
  private trapIdSeq = 1;

  // Toast
  private toastText = '';
  private toastId = 0;
  private toastClearTimeout = 0;

  // Cinema
  private cinema = {
    t: 0,
    fired: {} as Record<string, boolean>,
    cut: -1,
    caption: '',
    big: false,
    flash: 0,
    bars: false,
  };

  constructor(
    container: HTMLElement,
    settings: GameSettings,
    onHudUpdate: (hud: HudState) => void,
    onMpRoomUpdate?: (
      room: MultiplayerRoomSnapshot | null,
      selfId: string | null,
      err?: string
    ) => void,
    onMpChatMessage?: (msg: ChatMessage) => void,
    onChatOpenRequest?: () => void
  ) {
    this.container = container;
    this.settings = { ...settings };
    this.onHudUpdate = onHudUpdate;
    this.onMpRoomUpdate = onMpRoomUpdate;
    this.onMpChatMessage = onMpChatMessage;
    this.onChatOpenRequest = onChatOpenRequest;
    this.mp = new MultiplayerClient({
      onRoomChange: (room, selfId) => {
        this.syncRemotePeersFromRoom(room);
        this.onMpRoomUpdate?.(room, selfId);
        this.emitHud();
      },
      onGameStarted: (room) => {
        this.settings = { ...this.settings, diff: room.diff };
        this.syncRemotePeersFromRoom(room);
        Snd.init();
        Snd.setAmbientActive(true);
        this.resetWorld();
        this.dayAnim(1, 'start', () => this.beginWake());
        this.requestLock();
        this.onMpRoomUpdate?.(room, this.mp.selfId);
      },
      onPeerState: (peer) => {
        this.upsertRemotePeer(peer);
      },
      onMonstersState: (data) => {
        this.remoteMonsterTarget = data;
      },
      onWorldEvent: (_fromId, ev, world) => {
        this.handleNetworkWorldEvent(ev, world);
      },
      onChatMessage: (chatMsg) => {
        if (chatMsg.senderId !== this.mp.selfId && !chatMsg.system) {
          Snd.chatMsg(false);
        }
        this.onMpChatMessage?.(chatMsg);
      },
      onError: (errMsg) => {
        this.onMpRoomUpdate?.(this.mp.room, this.mp.selfId, errMsg);
        this.showToast(errMsg, 3000);
      },
    });
    this.isSoftwareGl = detectSoftwareGl();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 1.5)
    );
    this.renderer.autoClear = false;
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.style.touchAction = 'none';
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020202);
    this.scene.fog = new THREE.FogExp2(0x030303, 0.05);

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    pmrem.dispose();

    this.camera = new THREE.PerspectiveCamera(74, 1, 0.08, 140);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    this.amb = new THREE.AmbientLight(0x4a4a5c, 0.65);
    this.scene.add(this.amb);
    this.hemi = new THREE.HemisphereLight(0x6c758a, 0x2a1f16, 0.35);
    this.scene.add(this.hemi);

    this.torch = new THREE.SpotLight(0xffeccc, 2.2, 34, 0.56, 0.5, 1.15);
    this.camera.add(this.torch);
    this.torch.position.set(0.12, -0.1, 0);
    this.camera.add(this.torch.target);
    this.torch.target.position.set(0, 0, -3);

    this.redGlow = new THREE.PointLight(0xff2a1a, 0.9, 9, 2);
    this.scene.add(this.redGlow);
    this.greenGlow = new THREE.PointLight(0x7cff9a, 0.6, 13, 2);
    this.scene.add(this.greenGlow);
    this.gunFlash = new THREE.PointLight(0xffd080, 0, 16, 2);
    this.scene.add(this.gunFlash);

    this.preset = getHousePreset(this.settings.houseTheme);
    this.maxAniso = this.isSoftwareGl
      ? 1
      : Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
    this.tex = buildAllTextures(this.maxAniso);
    this.world = buildHouseWorld(this.scene, this.tex, this.maxAniso, this.settings.houseTheme);

    this.hmRig = createHammerManRig(this.tex);
    this.scene.add(this.hmRig.group);
    this.giantRig = createGiantRig(this.tex);
    this.scene.add(this.giantRig.group);

    this.hands = new FirstPersonHands(this.tex.skin);
    this.createCorridorMist();
    this.createDustParticles();

    this.applySettings(this.settings);
    this.resize();
    this.resetWorld();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.lastTime = performance.now();
    this.scheduleNextTick();
    this.emitHud();
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('mouseup', this.handleMouseUp);
    window.addEventListener('blur', this.handleBlur);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
    document.addEventListener('pointerlockerror', this.handlePointerLockError);
    document.addEventListener('fullscreenchange', this.handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    document.addEventListener('mousemove', this.handleMouseMove);
    this.renderer.domElement.addEventListener('mousedown', this.handleMouseDown);
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
  }

  public dispose(): void {
    this.destroyed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    clearTimeout(this.toastClearTimeout);
    this.mp.dispose();
    this.clearRemotePeers();
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('mouseup', this.handleMouseUp);
    window.removeEventListener('blur', this.handleBlur);
    document.removeEventListener('mousemove', this.handleMouseMove);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);
    document.removeEventListener('pointerlockerror', this.handlePointerLockError);
    document.removeEventListener('fullscreenchange', this.handleFullscreenChange);
    document.removeEventListener('webkitfullscreenchange', this.handleFullscreenChange);
    this.renderer.domElement.removeEventListener('mousedown', this.handleMouseDown);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);

    try {
      if (document.pointerLockElement === this.renderer.domElement) {
        document.exitPointerLock();
      }
    } catch {
      // ignore
    }
    this.mistGeo?.dispose();
    this.mistMat?.dispose();
    this.mistTex?.dispose();
    this.dustGeo?.dispose();
    this.dustMat?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }

  private handleContextLost = (e: Event): void => {
    e.preventDefault();
  };

  private handleResize = (): void => {
    this.resize();
  };

  private handleFullscreenChange = (): void => {
    this.lastFullscreenAt = performance.now();
    this.resize();
  };

  public resize(): void {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.hands.resize(w / h);
    if (this.dustMat) {
      this.dustMat.uniforms.uPixelRatio.value = this.renderer.getPixelRatio();
    }
  }

  private rebuildWorldIfNeeded(theme: HouseTheme): void {
    if (theme === this.world.theme) return;
    this.world.houseRoot.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry?.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material?.dispose();
      }
    });
    this.scene.remove(this.world.houseRoot);
    this.preset = getHousePreset(theme);
    this.world = buildHouseWorld(this.scene, this.tex, this.maxAniso, theme);
    this.resetWorld();
    this.emitHud();
  }

  public applySettings(next: GameSettings): void {
    this.settings = { ...next };
    this.preset = getHousePreset(next.houseTheme);
    Snd.setVolume(next.vol);
    const dpr = window.devicePixelRatio || 1;
    const q = next.gfx;
    this.renderer.setPixelRatio(
      this.isSoftwareGl
        ? 1
        : q === 'low'
          ? Math.min(dpr, 0.75)
          : q === 'high'
            ? Math.min(dpr, 2)
            : Math.min(dpr, 1.25)
    );
    if (this.dustMat) {
      this.dustMat.uniforms.uPixelRatio.value = this.renderer.getPixelRatio();
    }
    this.fogBase = q === 'low' ? 0.075 : q === 'high' ? 0.042 : 0.052;
    this.currentFogDensity = this.fogBase;
    if (!this.lampOn && this.state !== 'cinema') {
      (this.scene.fog as THREE.FogExp2).density = this.fogBase;
    }
    this.camera.far = q === 'low' ? 45 : 140;
    this.camera.updateProjectionMatrix();
    this.amb.intensity = 0.65 * next.bright;
    this.rebuildWorldIfNeeded(next.houseTheme);
  }

  public requestLock(): void {
    if (this.touchMove.active) return;
    try {
      const r = this.renderer.domElement.requestPointerLock() as unknown as Promise<void> | undefined;
      if (r && r.catch) r.catch(() => {});
    } catch {
      // fallback to drag-to-look
    }
  }

  private exitLock(): void {
    try {
      if (document.pointerLockElement) document.exitPointerLock();
    } catch {
      // ignore
    }
  }

  private handlePointerLockChange = (): void => {
    const was = this.pointerLocked;
    this.pointerLocked = document.pointerLockElement === this.renderer.domElement;
    if (was && !this.pointerLocked && this.state === 'play' && !this.chatOpen) {
      this.pauseGame();
    }
  };

  private handlePointerLockError = (): void => {
    this.showToast('اسحب بالفأرة للنظر حولك', 2800);
  };

  private handleMouseDown = (): void => {
    if (this.state !== 'play' || this.chatOpen) return;
    if (this.pointerLocked) {
      if (this.P.heldItem === 'gun') this.fireGun();
    } else {
      this.dragging = true;
    }
  };

  private handleMouseUp = (): void => {
    this.dragging = false;
  };

  private handleMouseMove = (e: MouseEvent): void => {
    if (this.state !== 'play' || this.chatOpen) return;
    if (this.pointerLocked || this.dragging) {
      this.look(e.movementX || 0, e.movementY || 0, 0.0022);
    }
  };

  public look(dx: number, dy: number, sensitivityScale: number): void {
    const s = sensitivityScale * this.settings.sens;
    this.P.yaw -= dx * s;
    this.P.pitch = Math.max(-1.45, Math.min(1.45, this.P.pitch - dy * s));
  }

  private handleBlur = (): void => {
    this.keys = {};
    if (performance.now() - this.lastFullscreenAt < 700) return;
    if (this.state === 'play' && !this.chatOpen && !this.touchMove.active) this.pauseGame();
  };

  private handleKeyDown = (e: KeyboardEvent): void => {
    if (
      this.chatOpen ||
      e.target instanceof HTMLInputElement ||
      e.target instanceof HTMLTextAreaElement
    ) {
      return;
    }

    if (
      this.mp.room &&
      (this.state === 'play' || this.state === 'spec') &&
      (e.code === 'KeyT' || e.code === 'Enter') &&
      !e.repeat
    ) {
      e.preventDefault();
      this.setChatOpen(true);
      this.onChatOpenRequest?.();
      return;
    }

    if (this.state === 'play') {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
      }
      if (e.repeat) {
        this.keys[e.code] = true;
        return;
      }
      this.keys[e.code] = true;
      if (e.code === 'KeyE') this.interact();
      else if (e.code === 'KeyG') this.dropHeldItem(true);
      else if (e.code === 'KeyQ') this.fireGun();
      else if (e.code === 'KeyF') this.toggleTorch();
      else if (e.code === 'KeyC') this.toggleCrouch();
      else if (e.code === 'KeyM') this.toggleMap();
      else if (e.code === 'KeyN') this.openJournal();
      else if (e.code === 'KeyP' || e.code === 'Escape') this.pauseGame();
    } else if (this.state === 'spec') {
      if (e.code === 'KeyE') this.cycleSpectate();
      else if (e.code === 'Escape') this.toMenu();
    } else if (this.state === 'paused' && (e.code === 'KeyP' || e.code === 'Escape')) {
      this.resumeGame();
    } else if (this.state === 'cinema' && ['Enter', 'Space', 'Escape'].includes(e.code)) {
      this.skipCinema();
    }
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.keys[e.code] = false;
  };

  // ---------- Multiplayer Public Actions ----------
  public setChatOpen(open: boolean): void {
    this.chatOpen = open;
    if (open) {
      this.keys = {};
      this.dragging = false;
      this.exitLock();
    } else if (this.state === 'play') {
      this.lastTime = performance.now();
      this.requestLock();
    }
  }

  public sendMpChat(text: string): void {
    this.mp.sendChat(text);
  }

  public createMpRoom(name: string, diff: DifficultyKey): void {
    this.mp.createRoom(name, diff);
  }

  public joinMpRoom(code: string, name: string): void {
    this.mp.joinRoom(code, name);
  }

  public setMpServerUrl(url: string | null): void {
    this.mp.setCustomServerUrl(url);
  }

  public async createLanInvite(name: string, diff: DifficultyKey): Promise<string> {
    return this.mp.createLanInvite(name, diff);
  }

  public async acceptLanReply(replyCode: string): Promise<void> {
    return this.mp.acceptLanReply(replyCode);
  }

  public async joinLanInvite(inviteCode: string, name: string): Promise<string> {
    return this.mp.joinLanInvite(inviteCode, name);
  }

  public setMpDifficulty(diff: DifficultyKey): void {
    this.settings = { ...this.settings, diff };
    this.mp.setDifficulty(diff);
  }

  public startMpGame(): void {
    if (!this.mp.room || !this.mp.isHost) return;
    this.mp.startGame(this.settings.diff);
  }

  public leaveMpRoom(): void {
    this.mp.leaveRoom();
    this.clearRemotePeers();
    this.remoteMonsterTarget = null;
    this.spectateId = null;
    this.reviveState = null;
    this.emitHud();
  }

  private getOrderedAliveRemotePeers(): RemotePeerEntry[] {
    const hostId = this.mp.room?.hostId;
    return Array.from(this.remotePeers.values())
      .filter((e) => e.peer.alive && !e.peer.escaped)
      .sort((a, b) => {
        if (a.peer.id === hostId && b.peer.id !== hostId) return -1;
        if (b.peer.id === hostId && a.peer.id !== hostId) return 1;
        return a.peer.colorIndex - b.peer.colorIndex;
      });
  }

  public startSpectating(silent = false): boolean {
    if (!this.mp.room) return false;
    const aliveList = this.getOrderedAliveRemotePeers();
    const aliveEntry = aliveList[0];
    if (!aliveEntry) {
      if (!silent) {
        this.showToast('لا يوجد زملاء أحياء للمتابعة', 2200);
      }
      return false;
    }
    this.spectateId = aliveEntry.peer.id;
    this.state = 'spec';
    this.hitFlash = 0;
    this.lidOpacity = 0;
    this.threat = 0;
    this.exitLock();
    this.emitHud();
    return true;
  }

  public cycleSpectate(): void {
    const aliveList = this.getOrderedAliveRemotePeers();
    if (!aliveList.length) return;
    const idx = aliveList.findIndex((e) => e.peer.id === this.spectateId);
    this.spectateId = aliveList[(idx + 1) % aliveList.length].peer.id;
    this.emitHud();
  }

  // ---------- Public Game Actions ----------
  public startGame(): void {
    if (this.mp.room && this.mp.isHost) {
      this.mp.startGame(this.settings.diff);
      return;
    }
    Snd.init();
    Snd.setAmbientActive(true);
    this.resetWorld();
    this.dayAnim(1, 'start', () => this.beginWake());
    this.requestLock();
  }

  public pauseGame(): void {
    if (this.state !== 'play') return;
    this.state = 'paused';
    this.dragging = false;
    Snd.setAmbientActive(false);
    Snd.setWhisperProximity(0, 0);
    Snd.setThreatTension(0);
    this.exitLock();
    this.emitHud();
  }

  public resumeGame(): void {
    if (this.state !== 'paused') return;
    this.state = 'play';
    Snd.setAmbientActive(true);
    this.lastTime = performance.now();
    this.requestLock();
    this.emitHud();
  }

  public toMenu(): void {
    this.exitLock();
    this.dayTok++;
    this.cleanupCinema();
    Snd.setAmbientActive(false);
    Snd.setWhisperProximity(0, 0);
    Snd.setThreatTension(0);
    this.state = 'menu';
    this.resetWorld();
    this.emitHud();
  }

  public toggleTorch(): void {
    this.P.torch = !this.P.torch;
    this.emitHud();
  }

  public toggleCrouch(): void {
    if (!this.P.hidden && this.P.trappedTimer <= 0) {
      this.P.crouch = !this.P.crouch;
      this.emitHud();
    }
  }

  public toggleMap(): void {
    this.mapOpen = !this.mapOpen;
    this.emitHud();
  }

  public skipCinema(): void {
    if (this.state === 'cinema' && this.cinema.t < 26) {
      this.cinema.t = 26;
    }
  }

  public submitSafeResult(opened: boolean): void {
    if (this.state !== 'pad') return;
    if (opened) {
      this.safeOpen = true;
      Snd.chime();
      this.giveOrSwapItem('screwdriver');
      this.mp.sendWorldEvent({ kind: 'safe' });
      this.showToast('انفتحت الخزنة! أخذت المفك في يدك', 3200);
    }
    this.state = 'play';
    this.lastTime = performance.now();
    this.requestLock();
    this.emitHud();
  }

  public openDiaryNote(id: string): void {
    if (this.state !== 'play') return;
    const worldItem = this.world.diaryNotes.find((n) => n.id === id);
    if (worldItem) {
      worldItem.read = true;
      worldItem.glow.visible = false;
    }
    if (!this.notesRead.includes(id)) {
      this.notesRead.push(id);
    }
    this.activeNoteId = id;
    this.state = 'note';
    this.dragging = false;
    this.keys = {};
    Snd.paperRustle();
    Snd.setAmbientActive(true, 0.55);
    this.exitLock();
    this.emitHud();
  }

  public openJournal(): void {
    if (this.state !== 'play') return;
    if (this.notesRead.length === 0) {
      this.showToast('لم تعثر على أي مذكرات ورقية بعد — ابحث في أرجاء البيت', 2200);
      return;
    }
    this.activeNoteId = this.notesRead[this.notesRead.length - 1];
    this.state = 'note';
    this.dragging = false;
    this.keys = {};
    Snd.paperRustle();
    Snd.setAmbientActive(true, 0.55);
    this.exitLock();
    this.emitHud();
  }

  public selectActiveNote(id: string): void {
    if (this.state !== 'note' || !this.notesRead.includes(id)) return;
    this.activeNoteId = id;
    Snd.paperRustle();
    this.emitHud();
  }

  public closeDiaryNote(): void {
    if (this.state !== 'note') return;
    this.activeNoteId = null;
    this.state = 'play';
    Snd.paperRustle();
    Snd.setAmbientActive(true, 1.0);
    this.lastTime = performance.now();
    this.requestLock();
    this.emitHud();
  }

  public showToast(msg: string, ms = 2400): void {
    this.toastText = msg;
    this.toastId++;
    clearTimeout(this.toastClearTimeout);
    this.toastClearTimeout = window.setTimeout(() => {
      this.toastText = '';
      this.emitHud();
    }, ms);
    this.emitHud();
  }

  // ---------- World Reset & Seeding ----------
  private resetWorld(): void {
    const mpWorld = this.mp.room?.world;
    const activeDiff = mpWorld ? mpWorld.diff : this.settings.diff;
    if (mpWorld) this.settings = { ...this.settings, diff: mpWorld.diff };
    const diff = DIFFICULTIES[activeDiff];
    const rng = mpWorld ? mulberry32(mpWorld.keySeed) : Math.random;

    this.day = 1;
    this.dayFinal = false;
    this.dayPhase = 'start';
    this.dayCross = false;
    this.daySub = '';
    this.timeSeconds = 0;
    this.keysCount = 0;
    this.needKeys = diff.keys;
    this.doorOpen = mpWorld ? mpWorld.doorOpen : false;
    this.safeOpen = mpWorld ? mpWorld.safeOpen : false;
    this.codeKnown = false;
    this.safeCode = mpWorld ? mpWorld.safeCode : 100 + Math.floor(Math.random() * 900);
    this.locks = {
      plankBroken: mpWorld ? mpWorld.plankBroken : false,
      wireCut: mpWorld ? mpWorld.wireCut : false,
      panelOpened: mpWorld ? mpWorld.panelOpened : false,
      keysUsed: mpWorld ? mpWorld.doorOpen : false,
    };

    this.world.exitPlankMesh.visible = !this.locks.plankBroken;
    this.world.exitWireMesh.visible = !this.locks.wireCut;
    this.world.exitPanelMesh.visible = !this.locks.panelOpened;
    this.world.exitDoorPivot.rotation.y = this.doorOpen ? 1.5 : 0;

    if (this.doorOpen) {
      const ci = this.world.floors[0].co.indexOf(this.world.exitBox);
      if (ci >= 0) this.world.floors[0].co.splice(ci, 1);
      const bi = this.world.floors[0].bl.indexOf(this.world.exitBox);
      if (bi >= 0) this.world.floors[0].bl.splice(bi, 1);
    } else if (this.world.floors[0].co.indexOf(this.world.exitBox) < 0) {
      this.world.floors[0].co.push(this.world.exitBox);
      this.world.floors[0].bl.push(this.world.exitBox);
    }

    this.world.doors.forEach((d) => {
      d.ang = 0;
      d.target = 0;
      d.piv.rotation.y = 0;
      if (!d.solid) {
        this.world.floors[d.fl].co.push(d.box);
        this.world.floors[d.fl].bl.push(d.box);
        d.solid = true;
      }
    });

    // Place keys in non-special spots (seeded identically in multiplayer)
    this.world.spots.forEach((s) => {
      s.searched = false;
      s.key = false;
      s.mat.color.setHex(s.col);
      s.obj.visible = true;
    });
    const candidates: SearchSpot[] = [];
    this.world.spots.forEach((s) => {
      if (!s.special) candidates.push(s);
    });
    for (let i = candidates.length - 1; i > 0; i--) {
      const j = (rng() * (i + 1)) | 0;
      const tmp = candidates[i];
      candidates[i] = candidates[j];
      candidates[j] = tmp;
    }
    const count = Math.min(this.needKeys, candidates.length);
    for (let k = 0; k < count; k++) candidates[k].key = true;
    this.needKeys = count;

    if (mpWorld?.searchedSpots?.length) {
      for (const idx of mpWorld.searchedSpots) {
        const sp = this.world.spots[idx];
        if (!sp) continue;
        sp.searched = true;
        if (sp.hide) sp.obj.visible = false;
        else sp.mat.color.setHex(0x5a5048);
        if (sp.key) this.keysCount++;
      }
    }

    // Clear old dropped props & place initial distraction vases around house
    this.droppedProps.forEach((p) => {
      this.world.floors[p.fl].g.remove(p.mesh);
    });
    this.droppedProps = [];
    this.preset.vases.forEach((v) => {
      this.spawnFloorProp('vase', v.fl, v.x, v.y, v.z);
    });

    // Clear and spawn initial Bear Traps
    this.bearTraps.forEach((t) => {
      this.world.floors[t.fl].g.remove(t.mesh);
    });
    this.bearTraps = [];
    const trapCoords = this.preset.trapCoords;
    for (let i = 0; i < Math.min(diff.traps, trapCoords.length); i++) {
      this.spawnBearTrap(trapCoords[i].fl, trapCoords[i].x, trapCoords[i].z);
    }

    this.stats = { hides: 0, chases: 0, traps: 0 };
    this.lightTimer = 0;
    this.lampOn = false;
    this.lampFlicker = 0;
    this.proxShake = 0;
    this.world.pendantLamps.forEach((pl) => {
      pl.light.intensity = 0.42 * this.settings.bright;
      pl.light.distance = 16;
      (pl.bulb.material as THREE.MeshBasicMaterial).color.setHex(0xffd28a);
      pl.pivot.rotation.set(0, 0, 0);
    });
    this.world.stairLamp.intensity = 0.75;
    this.amb.intensity = 0.65 * this.settings.bright;
    this.currentFogDensity = this.fogBase;
    (this.scene.fog as THREE.FogExp2).density = this.fogBase;

    this.resetPlayerFull();
    this.giantOn = diff.monsters && (mpWorld ? mpWorld.giantRoll : Math.random()) < diff.giant;
    this.resetMonsters();
    this.remoteMonsterTarget = null;
    this.spectateId = null;
    this.reviveState = null;

    this.redGlow.intensity = diff.monsters ? 0.9 : 0;
    this.greenGlow.intensity = this.giantOn ? 0.6 : 0;
    this.hitFlash = 0;
    this.threat = 0;
    this.lidOpacity = 0;
    this.mapOpen = false;
    this.notesRead = [];
    this.activeNoteId = null;
    this.world.diaryNotes.forEach((n) => {
      n.read = false;
      n.glow.visible = true;
    });
    this.resetAmbientTimers();
    this.cleanupCinema();
  }

  private resetAmbientTimers(): void {
    this.ambient = {
      floorCreakTimer: rand(5, 12),
      windTimer: rand(6, 14),
      distantStepsTimer: rand(12, 22),
      rattleTimer: rand(16, 28),
    };
    this.whisperTimer = 2.0;
    Snd.setWhisperProximity(0, 0);
  }

  private resetPlayerFull(): void {
    const st = this.preset.startPos;
    this.P = {
      fl: 0,
      gy: 0,
      x: st.x,
      z: st.z,
      yaw: st.yaw,
      pitch: 0,
      eye: EYE,
      crouch: false,
      stamina: 1,
      exhausted: false,
      hidden: null,
      bob: 0,
      torch: true,
      noise: 0,
      roll: 0,
      stepSign: false,
      ammo: 0,
      hasGun: false,
      heldItem: null,
      trappedTimer: 0,
      trapProgress: 0,
    };
  }

  private resetMonsters(): void {
    const diff = DIFFICULTIES[this.settings.diff];
    this.H = {
      catchIdx: -1,
      catchT: 0,
      fl: 0,
      gy: 0,
      x: 56,
      z: 8,
      dx: -1,
      dz: 0,
      v: 0,
      state: 'patrol',
      path: [],
      wait: 0,
      stateT: 0,
      lose: 0,
      last: null,
      atk: 0,
      atkAnim: 0,
      cool: 0,
      noiseCD: 0,
      stuckT: 0,
      sx: 56,
      sz: 8,
      phase: 0,
      closet: null,
      hstep: false,
      stun: 0,
      trapPlaceTimer: 18,
    };
    this.G = {
      fl: 0,
      gy: 0,
      x: 40,
      z: 20,
      dx: -1,
      dz: 0,
      v: 0,
      atk: 0,
      atkAnim: 0,
      cool: 0,
      phase: 0,
      stepSign: false,
      goal: 0,
      stun: 0,
    };
    this.hmRig.group.visible = diff.monsters;
    this.giantRig.group.visible = this.giantOn;
    if (!diff.monsters) {
      this.H.x = 200;
      this.H.z = 200;
    } else {
      this.pickPatrol();
    }
    if (!this.giantOn) {
      this.G.x = 200;
      this.G.z = 200;
    }
  }

  // ---------- Props & Bear Traps ----------
  private spawnFloorProp(
    kind: Exclude<HeldItemType, null>,
    fl: 0 | 1,
    x: number,
    y: number,
    z: number
  ): DroppedProp {
    const mesh = this.world.createPropMesh(kind);
    mesh.position.set(x, y, z);
    this.world.floors[fl].g.add(mesh);
    const prop: DroppedProp = {
      id: this.propIdSeq++,
      kind,
      fl,
      x,
      y,
      z,
      vy: 0,
      mesh,
      label: `التقاط ${ITEM_LABELS[kind]}`,
      active: true,
    };
    this.droppedProps.push(prop);
    return prop;
  }

  private spawnBearTrap(fl: 0 | 1, x: number, z: number): void {
    const { mesh, jawL, jawR } = createBearTrapMesh();
    mesh.position.set(x, 0.01, z);
    this.world.floors[fl].g.add(mesh);
    this.bearTraps.push({
      id: this.trapIdSeq++,
      fl,
      x,
      z,
      mesh,
      jawL,
      jawR,
      armed: true,
    });
  }

  private addShake(amount: number, cap = 0.28): void {
    this.shake = Math.min(cap, Math.max(this.shake, amount));
  }

  private emitNoise(
    fl: 0 | 1,
    x: number,
    z: number,
    radius: number,
    alertMsg?: string,
    forceInvestigate = false
  ): void {
    // Subtle physical camera tremor from nearby loud noises in the house
    if (radius >= 20) {
      const dPlayer = Math.hypot(this.P.x - x, this.P.z - z) + (this.P.fl !== fl ? 8 : 0);
      if (dPlayer < radius * 0.9) {
        const strength = (1 - dPlayer / (radius * 0.9)) * Math.min(0.12, radius * 0.0024);
        this.addShake(strength, 0.16);
      }
    }

    const diff = DIFFICULTIES[this.settings.diff];
    if (!diff.monsters || this.H.stun > 0) return;
    const dist = Math.hypot(this.H.x - x, this.H.z - z) + (this.H.fl !== fl ? 8 : 0);
    if (forceInvestigate || dist < radius * diff.hear) {
      if (this.H.state !== 'chase' || forceInvestigate) {
        if (this.H.state !== 'chase') {
          this.H.state = 'investigate';
        }
        if (this.H.state !== 'chase') {
          this.setMonsterGoal(x, z, fl);
          this.H.wait = 0;
          this.H.noiseCD = forceInvestigate ? 0 : this.H.noiseCD;
        }
        if (alertMsg) this.showToast(alertMsg, 2400);
      }
    }
  }

  private emitReviveNoise(
    fl: 0 | 1,
    x: number,
    z: number,
    targetName: string,
    stage: 'start' | 'pulse' | 'complete'
  ): void {
    if (!this.mp.room || this.mp.isHost) {
      const msg =
        stage === 'start'
          ? 'ضجيج الإنعاش جذب رجل المطرقة! قادم لقتلك!'
          : undefined;
      this.emitNoise(fl, x, z, 75, msg, true);
    }
    if (this.mp.room) {
      this.mp.sendWorldEvent({
        kind: 'revive_noise',
        fl,
        x,
        z,
        targetName,
        stage,
      });
    }
  }

  private startRevive(entry: RemotePeerEntry): void {
    if (this.state !== 'play' || this.P.hidden || this.P.trappedTimer > 0) return;
    if (entry.peer.alive || entry.peer.escaped || entry.peer.fl !== this.P.fl) return;
    this.reviveState = {
      targetId: entry.peer.id,
      targetName: entry.peer.name,
      x: entry.x,
      y: entry.y,
      z: entry.z,
      fl: entry.peer.fl,
      elapsed: 0,
      duration: 5.0,
      nextNoiseAt: 1.7,
    };
    Snd.bang();
    this.addShake(0.085, 0.18);
    this.noiseTimer = Math.max(this.noiseTimer, 2.0);
    this.emitReviveNoise(entry.peer.fl, entry.x, entry.z, entry.peer.name, 'start');
    this.showToast(`بدأ إنعاش ${entry.peer.name} (٥ ثوانٍ) — الضجيج يجذب الوحش!`, 2600);
  }

  private cancelRevive(notify: boolean): void {
    if (!this.reviveState) return;
    this.reviveState = null;
    if (notify) {
      this.showToast('توقف الإنعاش — يجب البقاء بجانب الجثة ٥ ثوانٍ', 2000);
    }
    this.emitHud();
  }

  private updateRevive(dt: number): void {
    const rs = this.reviveState;
    if (!rs) return;
    const entry = this.remotePeers.get(rs.targetId);
    if (
      !entry ||
      entry.peer.alive ||
      entry.peer.escaped ||
      entry.peer.hiddenIdx >= 0 ||
      entry.peer.fl !== this.P.fl ||
      this.P.hidden ||
      this.P.trappedTimer > 0 ||
      Math.hypot(entry.x - this.P.x, entry.z - this.P.z) > 2.75
    ) {
      this.cancelRevive(Boolean(entry && !entry.peer.alive));
      return;
    }

    rs.x = entry.x;
    rs.y = entry.y;
    rs.z = entry.z;
    rs.fl = entry.peer.fl;
    rs.elapsed += dt;
    this.noiseTimer = Math.max(this.noiseTimer, 0.6);

    if (rs.elapsed >= rs.nextNoiseAt && rs.elapsed < rs.duration) {
      rs.nextNoiseAt += 1.7;
      Snd.bang();
      this.addShake(0.075, 0.16);
      this.emitReviveNoise(rs.fl, rs.x, rs.z, rs.targetName, 'pulse');
    }

    if (rs.elapsed >= rs.duration) {
      const done = rs;
      this.reviveState = null;
      entry.peer.alive = true;
      Snd.chime();
      Snd.bang();
      this.addShake(0.1, 0.2);
      this.emitReviveNoise(done.fl, done.x, done.z, done.targetName, 'complete');
      this.mp.sendWorldEvent({
        kind: 'revive',
        targetId: done.targetId,
        targetName: done.targetName,
        x: done.x,
        y: done.y,
        z: done.z,
        fl: done.fl,
      });
      this.showToast(`تم إنعاش ${done.targetName}! الضجيج جذب رجل المطرقة إليكما!`, 3200);
      this.emitHud();
    }
  }

  private giveOrSwapItem(item: Exclude<HeldItemType, null>): void {
    if (this.P.heldItem !== null) {
      // Drop current held item right at feet silently-ish (small clatter)
      this.dropHeldItem(false);
    }
    this.P.heldItem = item;
    if (item === 'gun') this.P.hasGun = true;
    this.emitHud();
  }

  public dropHeldItem(throwForward: boolean): void {
    if (this.state !== 'play' || !this.P.heldItem || this.P.hidden) return;
    const item = this.P.heldItem;
    this.P.heldItem = null;

    const dirX = -Math.sin(this.P.yaw);
    const dirZ = -Math.cos(this.P.yaw);
    const dist = throwForward ? 1.5 : 0.65;
    const dropPos = { x: this.P.x + dirX * dist, z: this.P.z + dirZ * dist, fl: this.P.fl };
    this.pushOut(dropPos, 0.25);

    const isCeramic = item === 'vase';
    Snd.dropNoise(isCeramic);

    if (isCeramic && throwForward) {
      // Vase shatters into loud sound lure, then respawns later on table? Or breaks to lure!
      this.emitNoise(
        this.P.fl,
        dropPos.x,
        dropPos.z,
        34,
        'تحطمت المزهرية! الرجل يتجه نحو الصوت'
      );
      this.checkTrapTriggerByProp(this.P.fl, dropPos.x, dropPos.z);
    } else {
      this.spawnFloorProp(item, this.P.fl, dropPos.x, 0.02, dropPos.z);
      this.emitNoise(
        this.P.fl,
        dropPos.x,
        dropPos.z,
        throwForward ? 26 : 16,
        throwForward ? 'أحدثت الأداة ضجيجاً! احذر' : undefined
      );
      this.checkTrapTriggerByProp(this.P.fl, dropPos.x, dropPos.z);
    }
    this.emitHud();
  }

  private checkTrapTriggerByProp(fl: 0 | 1, x: number, z: number): void {
    for (const trap of this.bearTraps) {
      if (trap.armed && trap.fl === fl && Math.hypot(trap.x - x, trap.z - z) < 0.85) {
        this.snapTrap(trap, false);
      }
    }
  }

  private snapTrap(trap: BearTrap, caughtPlayer: boolean): void {
    trap.armed = false;
    trap.jawL.rotation.x = Math.PI / 2 - 0.55;
    trap.jawR.rotation.x = Math.PI / 2 + 0.55;
    Snd.trapSnap();
    if (caughtPlayer) {
      this.P.trappedTimer = 3.2;
      this.P.trapProgress = 0;
      this.P.crouch = false;
      this.stats.traps++;
      this.shake = 0.35;
      this.hitFlash = 0.65;
      this.showToast('وقعت في فخ الدب! اضغط E باستمرار للتحرر سريعاً', 3200);
      this.emitNoise(this.P.fl, this.P.x, this.P.z, 45);
    } else {
      this.showToast('أبطلت مفعول فخ الدب!', 2000);
      this.emitNoise(trap.fl, trap.x, trap.z, 32);
    }
  }

  // ---------- Navigation & Collisions ----------
  private updFloor(e: { x: number; z: number; fl: 0 | 1; gy: number }): void {
    const s = this.preset.stairBounds;
    if (e.x > s.x1 && e.x < s.x2 && e.z > s.z1 && e.z < s.z2) {
      const u = (e.x - s.x1) / (s.x2 - s.x1);
      e.gy = u * FY;
      e.fl = u > 0.5 ? 1 : 0;
    } else {
      e.gy = e.fl * FY;
    }
  }

  private pushOut(p: { x: number; z: number; fl: 0 | 1 }, r: number): void {
    const co = this.world.floors[p.fl].co;
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 0; i < co.length; i++) {
        const b = co[i];
        const cx = Math.max(b.x1, Math.min(p.x, b.x2));
        const cz = Math.max(b.z1, Math.min(p.z, b.z2));
        const dx = p.x - cx;
        const dz = p.z - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 < r * r) {
          if (d2 > 1e-8) {
            const d = Math.sqrt(d2);
            const k = (r - d) / d;
            p.x += dx * k;
            p.z += dz * k;
          } else {
            const l = p.x - b.x1;
            const rr = b.x2 - p.x;
            const t = p.z - b.z1;
            const bt = b.z2 - p.z;
            const m = Math.min(l, rr, t, bt);
            if (m === l) p.x = b.x1 - r;
            else if (m === rr) p.x = b.x2 + r;
            else if (m === t) p.z = b.z1 - r;
            else p.z = b.z2 + r;
          }
        }
      }
    }
  }

  private blocked(ax: number, az: number, bx: number, bz: number, fl: 0 | 1): boolean {
    const bl = this.world.floors[fl].bl;
    for (let i = 0; i < bl.length; i++) {
      if (segHits(ax, az, bx, bz, bl[i])) return true;
    }
    return false;
  }

  private nearestNode(x: number, z: number, fl: 0 | 1): number {
    const nodes = this.world.nodes;
    let best = -1;
    let bd = 1e9;
    let bv = -1;
    let bvd = 1e9;
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i].fl !== fl) continue;
      const d = Math.hypot(nodes[i].x - x, nodes[i].z - z);
      if (d < bd) {
        bd = d;
        best = i;
      }
      if (d < bvd && !this.blocked(x, z, nodes[i].x, nodes[i].z, fl)) {
        bvd = d;
        bv = i;
      }
    }
    return bv >= 0 ? bv : best;
  }

  private route(a: number, b: number): number[] {
    const nodes: NavNode[] = this.world.nodes;
    const n = nodes.length;
    const dist = new Array<number>(n).fill(1e9);
    const prev = new Array<number>(n).fill(-1);
    const done = new Array<boolean>(n).fill(false);
    dist[a] = 0;
    for (let it = 0; it < n; it++) {
      let u = -1;
      let best = 1e9;
      for (let i = 0; i < n; i++) {
        if (!done[i] && dist[i] < best) {
          best = dist[i];
          u = i;
        }
      }
      if (u < 0 || u === b) break;
      done[u] = true;
      for (const e of nodes[u].adj) {
        const nd = dist[u] + e.d;
        if (nd < dist[e.n]) {
          dist[e.n] = nd;
          prev[e.n] = u;
        }
      }
    }
    if (prev[b] === -1 && b !== a) return [a];
    const path: number[] = [];
    let c = b;
    while (c !== -1) {
      path.unshift(c);
      c = prev[c];
    }
    return path;
  }

  private setMonsterGoal(x: number, z: number, fl: 0 | 1): void {
    const a = this.nearestNode(this.H.x, this.H.z, this.H.fl);
    const b = this.nearestNode(x, z, fl);
    const ids = this.route(a, b);
    const nodes = this.world.nodes;
    const p = ids.map((k) => ({ x: nodes[k].x, z: nodes[k].z, fl: nodes[k].fl }));
    if (nodes[b].fl === fl && !this.blocked(nodes[b].x, nodes[b].z, x, z, fl)) {
      p.push({ x, z, fl });
    }
    while (
      p.length > 1 &&
      p[0].fl === this.H.fl &&
      p[1].fl === this.H.fl &&
      !this.blocked(this.H.x, this.H.z, p[1].x, p[1].z, this.H.fl)
    ) {
      p.shift();
    }
    this.H.path = p;
  }

  private pickPatrol(): void {
    const rooms = this.preset.allRooms;
    const cur = this.nearestNode(this.H.x, this.H.z, this.H.fl);
    let r = rooms[0];
    let tries = 0;
    do {
      r = rooms[(Math.random() * rooms.length) | 0];
      tries++;
    } while (this.world.roomNode[r.id] === cur && tries < 6);
    this.setMonsterGoal(r.cx, r.cz, r.fl);
  }

  private stepTo(
    M: { x: number; z: number; dx: number; dz: number; v: number; fl: 0 | 1 },
    tx: number,
    tz: number,
    sp: number,
    dt: number,
    r: number,
    turn = 7
  ): number {
    const dx = tx - M.x;
    const dz = tz - M.z;
    const d = Math.hypot(dx, dz);
    if (d < 0.001) {
      M.v = 0;
      return 0;
    }
    const k = Math.min(1, dt * turn);
    M.dx += (dx / d - M.dx) * k;
    M.dz += (dz / d - M.dz) * k;
    const l = Math.hypot(M.dx, M.dz) || 1;
    M.dx /= l;
    M.dz /= l;
    const st = Math.min(sp * dt, d);
    M.x += M.dx * st;
    M.z += M.dz * st;
    this.pushOut(M, r);
    M.v = st / dt;
    return Math.hypot(tx - M.x, tz - M.z);
  }

  private followMonsterPath(dt: number, sp: number): boolean {
    if (!this.H.path.length) {
      this.H.v = 0;
      return true;
    }
    const w = this.H.path[0];
    const rem = this.stepTo(this.H, w.x, w.z, sp, dt, 0.45);
    if (rem < 0.55) this.H.path.shift();
    return this.H.path.length === 0;
  }

  private hmCanSee(): boolean {
    if (this.P.hidden || this.P.fl !== this.H.fl) return false;
    const diff = DIFFICULTIES[this.settings.diff];
    const d = Math.hypot(this.H.x - this.P.x, this.H.z - this.P.z);
    let range = (this.P.torch ? 17 : 10) * diff.see;
    if (this.P.crouch) range *= 0.62;
    if (d > range) return false;
    if (d > 3.2) {
      const dot = ((this.P.x - this.H.x) * this.H.dx + (this.P.z - this.H.z) * this.H.dz) / d;
      if (dot < 0.3) return false;
    }
    return !this.blocked(this.H.x, this.H.z, this.P.x, this.P.z, this.H.fl);
  }

  private startChase(): void {
    if (this.H.state !== 'chase') {
      this.H.state = 'chase';
      this.H.lose = 0;
      this.H.stateT = 0;
      this.stats.chases++;
      this.showToast('رجل المطرقة رآك! اهرب!', 1900);
      Snd.sting();
    }
  }

  // ---------- Interaction & Shooting ----------
  public nearTarget(): {
    type: string;
    label: string;
    run?: () => void;
    obj?: unknown;
  } | null {
    if (this.P.trappedTimer > 0) {
      return {
        type: 'trapBreak',
        label: 'تحرر من فخ الدب!',
        run: () => {
          this.P.trapProgress += 0.28;
          this.P.trappedTimer = Math.max(0, this.P.trappedTimer - 0.55);
          Snd.creak(0.14);
          if (this.P.trappedTimer <= 0 || this.P.trapProgress >= 1) {
            this.P.trappedTimer = 0;
            this.P.trapProgress = 0;
            this.showToast('تحررت من الفخ!', 1500);
          }
        },
      };
    }

    if (this.P.hidden) {
      const lbl =
        this.P.hidden.kind === 'bed' ? 'الخروج من تحت السرير' : 'الخروج من المخبأ';
      return { type: 'unhide', label: lbl };
    }

    // Revive fallen multiplayer teammate corpse in place (5 seconds, makes loud noise)
    if (this.mp.room) {
      let nearestCorpse: RemotePeerEntry | null = null;
      let nearestDist = 2.45;
      this.remotePeers.forEach((entry) => {
        const p = entry.peer;
        if (p.alive || p.escaped || p.hiddenIdx >= 0 || p.fl !== this.P.fl) return;
        const d = Math.hypot(entry.x - this.P.x, entry.z - this.P.z);
        if (d < nearestDist) {
          nearestDist = d;
          nearestCorpse = entry;
        }
      });
      if (nearestCorpse) {
        const target = nearestCorpse as RemotePeerEntry;
        if (this.reviveState && this.reviveState.targetId === target.peer.id) {
          const left = Math.ceil(
            Math.max(0, this.reviveState.duration - this.reviveState.elapsed)
          );
          return {
            type: 'reviveCancel',
            label: `جارٍ إنعاش ${target.peer.name}... (${toArabicDigits(left)} ث) — اضغط للإلغاء`,
            run: () => this.cancelRevive(true),
          };
        }
        return {
          type: 'revive',
          label: `إنعاش ${target.peer.name} (٥ ثوانٍ — يصدر ضجيجًا للوحش!)`,
          run: () => this.startRevive(target),
        };
      }
    }

    // Disarm bear trap if crouching nearby
    if (this.P.crouch) {
      for (const trap of this.bearTraps) {
        if (
          trap.armed &&
          trap.fl === this.P.fl &&
          Math.hypot(trap.x - this.P.x, trap.z - this.P.z) < 1.75
        ) {
          return {
            type: 'disarmTrap',
            label: 'تفكيك فخ الدب بهدوء',
            run: () => this.snapTrap(trap, false),
          };
        }
      }
    }

    // Pick up dropped prop / vase on floor
    for (const prop of this.droppedProps) {
      if (
        prop.active &&
        prop.fl === this.P.fl &&
        Math.hypot(prop.x - this.P.x, prop.z - this.P.z) < 1.85
      ) {
        return {
          type: 'prop',
          label: prop.label,
          run: () => {
            prop.active = false;
            this.world.floors[prop.fl].g.remove(prop.mesh);
            this.giveOrSwapItem(prop.kind);
            Snd.chime();
            this.showToast(`أخذت ${ITEM_LABELS[prop.kind]}`, 1800);
          },
        };
      }
    }

    // Ground-floor specials
    if (this.P.fl === 0) {
      const sw = this.preset.swPos;
      if (Math.hypot(sw.x - this.P.x, sw.z - this.P.z) < 2.0) {
        return {
          type: 'light',
          label: this.lightTimer > 0 ? 'الأضواء مضاءة' : 'تشغيل ضوء الممر',
          run: () => {
            if (this.lightTimer > 0) {
              this.showToast('الضوء مضاء بالفعل', 1200);
              return;
            }
            this.lightTimer = 10;
            this.noiseTimer = 0.5;
            Snd.tone('square', 320, 180, 0.14, 0.08);
            this.showToast('أُضيء الممر — عشر ثوانٍ فقط', 2400);
          },
        };
      }

      const sp = this.preset.safePos;
      if (!this.safeOpen && Math.hypot(sp.x - this.P.x, sp.z + 0.3 - this.P.z) < 2.2) {
        return {
          type: 'safe',
          label: 'الخزنة — إدخال الرمز',
          run: () => {
            this.state = 'pad';
            this.exitLock();
            this.emitHud();
          },
        };
      }

      const np = this.preset.notePos;
      if (Math.hypot(np.x - this.P.x, np.z - this.P.z) < 2.0) {
        return {
          type: 'note',
          label: 'قراءة الورقة',
          run: () => {
            this.codeKnown = true;
            Snd.paperRustle();
            this.showToast(`ورقة بخط مرتعش: «رمز الخزنة ${toArabicDigits(this.safeCode)}»`, 4200);
          },
        };
      }

      // Granny-style 3-Layer Exit Door Puzzle
      if (!this.doorOpen && distBox(this.P.x, this.P.z, this.world.exitBox) < 2.3) {
        if (!this.locks.plankBroken) {
          if (this.P.heldItem === 'hammer') {
            return {
              type: 'exitLock',
              label: 'نزع اللوح الخشبي بالمطرقة',
              run: () => {
                this.locks.plankBroken = true;
                this.world.exitPlankMesh.visible = false;
                this.hands.swing = 1;
                Snd.lockBreak();
                this.mp.sendWorldEvent({ kind: 'lock', lock: 'plankBroken' });
                this.emitNoise(0, 60, 32, 32, 'صوت نزع اللوح قد يجذب الوحش!');
                this.showToast('أزلت اللوح الخشبي! (١/٣)', 2400);
              },
            };
          }
          return {
            type: 'exitHint',
            label: 'لوح خشبي مسمّر — تحتاج المطرقة في يدك',
            run: () => {
              Snd.bang();
              this.showToast('ابحث عن المطرقة في غرفة الغسيل لنزع اللوح الخشبي', 2800);
            },
          };
        }

        if (!this.locks.wireCut) {
          if (this.P.heldItem === 'cutters') {
            return {
              type: 'exitLock',
              label: 'قطع سلك القفل بالقاطع',
              run: () => {
                this.locks.wireCut = true;
                this.world.exitWireMesh.visible = false;
                this.hands.swing = 1;
                Snd.lockBreak();
                this.mp.sendWorldEvent({ kind: 'lock', lock: 'wireCut' });
                this.showToast('قطعت السلك الكهربائي! (٢/٣)', 2400);
              },
            };
          }
          return {
            type: 'exitHint',
            label: 'سلك قفل مشدود — تحتاج قاطع الأسلاك (الطابق الثاني)',
            run: () => {
              Snd.bang();
              this.showToast('تحتاج قاطع الأسلاك من الطابق الثاني لقطع السلك', 2800);
            },
          };
        }

        if (!this.locks.panelOpened) {
          if (this.P.heldItem === 'screwdriver') {
            return {
              type: 'exitLock',
              label: 'فك غطاء القفل بالمفك',
              run: () => {
                this.locks.panelOpened = true;
                this.world.exitPanelMesh.visible = false;
                this.hands.swing = 1;
                Snd.lockBreak();
                this.mp.sendWorldEvent({ kind: 'lock', lock: 'panelOpened' });
                this.showToast('فككت الغطاء! الآن استخدم المفاتيح لفتح الباب (٣/٣)', 2600);
              },
            };
          }
          return {
            type: 'exitHint',
            label: 'غطاء معدني مثبّت — تحتاج المفك (داخل خزنة المكتبة)',
            run: () => {
              Snd.bang();
              this.showToast('المفك داخل الخزنة في المكتبة (رمزها في ورقة بالمطبخ)', 3000);
            },
          };
        }

        if (this.keysCount < this.needKeys) {
          return {
            type: 'exitHint',
            label: `الباب مقفل — ينقصك ${toArabicDigits(this.needKeys - this.keysCount)} من المفاتيح`,
            run: () => {
              Snd.bang();
              this.showToast(`اجمع ${toArabicDigits(this.needKeys)} مفاتيح لفتح الباب`, 2400);
            },
          };
        }

        return {
          type: 'openDoor',
          label: 'فتح الباب الحديدي بالمفاتيح',
          run: () => {
            this.locks.keysUsed = true;
            this.openExit(false);
            this.showToast('الباب مفتوح! اهرب الآن!', 2800);
          },
        };
      }
    }

    // Diary Paper Notes (both floors)
    for (const dn of this.world.diaryNotes) {
      if (dn.fl === this.P.fl && Math.hypot(dn.x - this.P.x, dn.z - this.P.z) < 1.95) {
        return {
          type: 'diaryNote',
          label: dn.read ? `إعادة قراءة: ${dn.title}` : 'التقاط وقراءة المذكرة الورقية',
          run: () => this.openDiaryNote(dn.id),
        };
      }
    }

    // Search spots
    for (const sp of this.world.spots) {
      if (
        !sp.searched &&
        sp.fl === this.P.fl &&
        Math.hypot(sp.x - this.P.x, sp.z - this.P.z) < (sp.r || 1.75)
      ) {
        return { type: 'spot', label: sp.label, obj: sp };
      }
    }

    // Hide spots (beds, closets, crates)
    for (const cl of this.world.closets) {
      if (cl.fl === this.P.fl && distBox(this.P.x, this.P.z, cl.box) < 1.2) {
        const label =
          cl.kind === 'bed'
            ? 'الاختباء تحت السرير'
            : cl.kind === 'crate'
              ? 'الاختباء في الصندوق'
              : 'الاختباء في الخزانة';
        return { type: 'hide', label, obj: cl };
      }
    }

    return null;
  }

  public interact(): void {
    if (this.state !== 'play') return;
    const t = this.nearTarget();
    if (!t) return;
    if (t.run) {
      t.run();
      this.emitHud();
      return;
    }

    if (t.type === 'spot') {
      const sp = t.obj as SearchSpot;
      const spotIdx = this.world.spots.indexOf(sp);
      sp.searched = true;
      if (sp.hide) sp.obj.visible = false;
      else sp.mat.color.setHex(0x5a5048);

      // Sync keys & empty spots globally; keep tools/guns reusable per teammate so nobody gets locked out
      if (!sp.item && spotIdx >= 0) {
        this.mp.sendWorldEvent({ kind: 'spot', index: spotIdx, foundKey: sp.key });
      }

      if (sp.key) {
        this.keysCount++;
        Snd.chime();
        this.showToast(
          `وجدت مفتاحًا (${toArabicDigits(this.keysCount)}/${toArabicDigits(this.needKeys)})${
            this.keysCount >= this.needKeys ? ' — توجه إلى قاعة الخروج' : ''
          }`,
          2600
        );
      } else if (sp.item === 'gun') {
        this.P.hasGun = true;
        this.P.ammo += 2;
        this.giveOrSwapItem('gun');
        Snd.chime();
        this.showToast('وجدت مسدسًا برصاصتين! اضغط Q أو انقر لإغماء الوحش مؤقتاً', 4400);
      } else if (sp.item === 'ammo') {
        this.P.ammo += sp.n || 3;
        Snd.chime();
        this.showToast(`أخذت ${toArabicDigits(sp.n || 3)} رصاصات (المجموع ${toArabicDigits(this.P.ammo)})`, 2400);
      } else if (sp.item === 'ham') {
        this.giveOrSwapItem('hammer');
        Snd.chime();
        this.showToast('أخذت المطرقة في يدك — استخدمها لنزع لوح باب الخروج', 3200);
      } else if (sp.item === 'cutters') {
        this.giveOrSwapItem('cutters');
        Snd.chime();
        this.showToast('أخذت قاطع الأسلاك في يدك — اقطع به سلك باب الخروج', 3200);
      } else {
        Snd.creak(0.1);
        this.showToast('لا شيء هنا', 1200);
      }
    } else if (t.type === 'hide') {
      const cl = t.obj as HideSpot;
      this.stats.hides++;
      this.P.hidden = cl;
      this.P.x = cl.x;
      this.P.z = cl.z;
      this.P.crouch = false;
      const diff = DIFFICULTIES[this.settings.diff];
      if (
        diff.monsters &&
        this.H.state === 'chase' &&
        this.H.fl === this.P.fl &&
        Math.hypot(this.H.x - this.P.x, this.H.z - this.P.z) < 18
      ) {
        this.H.state = 'hideCheck';
        this.H.closet = cl;
        this.H.stateT = 0;
        this.setMonsterGoal(cl.exit.x, cl.exit.z, cl.fl);
      }
    } else if (t.type === 'unhide' && this.P.hidden) {
      const cl = this.P.hidden;
      this.P.hidden = null;
      this.P.x = cl.exit.x;
      this.P.z = cl.exit.z;
      this.pushOut(this.P, 0.38);
    }
    this.emitHud();
  }

  public fireGun(): void {
    if (this.state !== 'play' || this.P.heldItem !== 'gun' || this.P.hidden) return;
    if (this.fireCD > 0) return;
    if (this.P.ammo <= 0) {
      this.fireCD = 0.5;
      Snd.tone('square', 1400, 900, 0.08, 0.03);
      this.showToast('نفد الرصاص — ابحث فوق الطاولات', 1800);
      return;
    }

    this.P.ammo--;
    this.fireCD = 0.6;
    this.hands.recoil = 1;
    this.flashTimer = 0.07;
    this.noiseTimer = 0.8;
    this.shake += 0.25;
    Snd.shot();

    this.gunFlash.position.set(
      this.camera.position.x - Math.sin(this.P.yaw) * 0.8,
      this.camera.position.y - 0.1,
      this.camera.position.z - Math.cos(this.P.yaw) * 0.8
    );

    const dx = -Math.sin(this.P.yaw);
    const dz = -Math.cos(this.P.yaw);
    let hit: { type: 'h' | 'g'; al: number } | null = null;

    const testHit = (M: { x: number; z: number; fl: 0 | 1 }, rad: number, type: 'h' | 'g') => {
      if (M.x > 150 || M.fl !== this.P.fl) return;
      const vx = M.x - this.P.x;
      const vz = M.z - this.P.z;
      const al = vx * dx + vz * dz;
      if (al < 0.4 || al > 34) return;
      if (Math.abs(vx * dz - vz * dx) > rad) return;
      if (this.blocked(this.P.x, this.P.z, M.x, M.z, this.P.fl)) return;
      if (!hit || al < hit.al) hit = { type, al };
    };

    const diff = DIFFICULTIES[this.settings.diff];
    if (diff.monsters && this.hmRig.group.visible) testHit(this.H, 0.85, 'h');
    if (this.giantOn) testHit(this.G, 1.35, 'g');

    if (hit) {
      const target = hit as { type: 'h' | 'g'; al: number };
      if (target.type === 'g') {
        this.G.stun = 6;
        this.mp.sendWorldEvent({ kind: 'stun', target: 'g', dur: 6 });
        this.showToast('أصبت العملاق! توقف لبضع ثوانٍ', 2200);
      } else {
        this.H.stun = diff.stunDuration;
        this.H.state = 'stunned';
        this.H.v = 0;
        this.H.atk = 0;
        this.mp.sendWorldEvent({ kind: 'stun', target: 'h', dur: diff.stunDuration });
        this.showToast(
          `أصبت رجل المطرقة! فاقد للوعي لمدة ${toArabicDigits(diff.stunDuration)} ثانية`,
          3000
        );
      }
      this.hitFlash = 0.25;
    } else if (diff.monsters && this.H.state !== 'chase' && this.H.stun <= 0) {
      this.H.state = 'investigate';
      this.setMonsterGoal(this.P.x, this.P.z, this.P.fl);
      this.H.wait = 0;
    }
    this.emitHud();
  }

  private openExit(fromRemote = false): void {
    this.doorOpen = true;
    this.locks.keysUsed = true;
    const co = this.world.floors[0].co;
    const bl = this.world.floors[0].bl;
    const i = co.indexOf(this.world.exitBox);
    if (i >= 0) co.splice(i, 1);
    const j = bl.indexOf(this.world.exitBox);
    if (j >= 0) bl.splice(j, 1);
    if (!fromRemote) {
      this.mp.sendWorldEvent({ kind: 'door' });
    }
    Snd.door();
    const diff = DIFFICULTIES[this.settings.diff];
    if (diff.monsters && this.H.state !== 'chase' && this.H.stun <= 0 && (!this.mp.room || this.mp.isHost)) {
      this.H.state = 'investigate';
      this.setMonsterGoal(this.P.x, this.P.z, this.P.fl);
      this.H.wait = 0;
    }
  }

  // ---------- Day & Wake-Up Progression ----------
  private dayAnim(n: number, mode: 'start' | 'death' | 'final', cb: () => void): void {
    const tok = ++this.dayTok;
    this.state = 'day';
    this.dayPhase = mode;
    this.dayCross = false;
    const rem = MAX_DAYS - n;
    if (mode === 'start') {
      this.daySub = `عندك ${toArabicDigits(MAX_DAYS)} أيام فقط للنجاة… انتبه للضجيج والأفخاخ`;
      this.emitHud();
      window.setTimeout(() => {
        if (this.dayTok === tok && !this.destroyed) cb();
      }, 2400);
    } else if (mode === 'death') {
      this.daySub = '';
      this.emitHud();
      window.setTimeout(() => {
        if (this.dayTok !== tok || this.destroyed) return;
        this.dayCross = true;
        Snd.bang();
        this.emitHud();
      }, 700);
      window.setTimeout(() => {
        if (this.dayTok !== tok || this.destroyed) return;
        this.day = n + 1;
        this.dayCross = false;
        this.dayPhase = 'start';
        this.daySub =
          rem === 1
            ? 'اليوم الأخير! لا ترتكب أي خطأ'
            : rem === 2
              ? 'بقي لك يومان فقط'
              : `بقيت لك ${toArabicDigits(rem)} أيام`;
        this.emitHud();
      }, 2300);
      window.setTimeout(() => {
        if (this.dayTok === tok && !this.destroyed) cb();
      }, 4100);
    } else {
      this.daySub = 'انتهت الأيام الخمسة';
      this.emitHud();
      window.setTimeout(() => {
        if (this.dayTok !== tok || this.destroyed) return;
        this.dayCross = true;
        Snd.bang();
        this.emitHud();
      }, 700);
      window.setTimeout(() => {
        if (this.dayTok === tok && !this.destroyed) cb();
      }, 2700);
    }
  }

  private beginWake(): void {
    this.state = 'wake';
    this.wakeT = 0;
    this.wk1 = false;
    this.wk2 = false;
    this.lidOpacity = 1;
    Snd.setAmbientActive(true, 0.8);
    Snd.setWhisperProximity(0, 0);
    Snd.setThreatTension(0);
    Snd.creak(0.1);
    this.lastTime = performance.now();
    this.emitHud();
  }

  private respawn(): void {
    // Keep discovered tools/locks/keys intact across days, just like Granny!
    const ammo = this.P.ammo;
    const hasGun = this.P.hasGun;
    const held = this.P.heldItem;
    this.resetPlayerFull();
    this.P.ammo = ammo;
    this.P.hasGun = hasGun;
    this.P.heldItem = held;

    this.resetMonsters();
    this.resetAmbientTimers();
    this.threat = 0;
    this.deadTimer = 0;
    this.msgShown = false;
    this.killer = null;
    this.pHa = 0;
    this.pGa = 0;
    this.shake = 0;
    this.proxShake = 0;
    this.moving = false;
    this.hitFlash = 0;
    this.beginWake();
  }

  private kill(by: 'hammer' | 'giant' | 'closet' | 'trap'): void {
    if (this.state !== 'play' && this.state !== 'pad') return;
    this.reviveState = null;
    if (this.mp.room && this.P.hidden) {
      // Pull corpse onto the floor outside closet/bed/crate so teammates can see and revive it
      const cl = this.P.hidden;
      this.P.x = cl.exit.x;
      this.P.z = cl.exit.z;
      this.P.hidden = null;
      this.pushOut(this.P, 0.38);
    }
    this.state = 'dead';
    this.deadTimer = 0;
    this.killer = by;
    this.msgShown = false;
    this.hitFlash = 0.85;
    this.mpSendAcc = 1;
    Snd.setAmbientActive(false);
    Snd.setWhisperProximity(0, 0);
    Snd.setThreatTension(0);
    Snd.hit();
    this.exitLock();
    this.emitHud();
  }

  // ---------- Frame Loop ----------
  private scheduleNextTick(): void {
    if (this.destroyed) return;
    if (this.isSoftwareGl) {
      this.afterDraw(() => this.tick());
    } else {
      this.frameId = requestAnimationFrame(() => this.tick());
    }
  }

  private afterDraw(cb: () => void): void {
    if (this.destroyed) return;
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.destroyed) return;
      const st = sync ? gl.getSyncParameter(sync, gl.SYNC_STATUS) : gl.SIGNALED;
      if (st === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick(): void {
    if (this.destroyed) return;
    const now = performance.now();
    const dt = Math.min(0.05, Math.max(0, (now - this.lastTime) / 1000));
    this.lastTime = now;

    if (this.state === 'play') this.updatePlay(dt);
    else if (this.state === 'dead') this.updateDead(dt);
    else if (this.state === 'spec') this.updateSpec(dt);
    else if (this.state === 'cinema') this.updateCinema(dt);
    else if (this.state === 'wake') this.updateWake(dt);
    else if (this.state === 'pad') this.updatePad(dt);
    else if (this.state === 'note') {
      this.elapsedT0 += dt;
      this.updateAmbientSounds(dt, true);
      this.updateRemotePeers(dt);
      this.updateMpSync(dt);
    } else if (this.state === 'day') {
      this.elapsedT0 += dt;
      this.updateRemotePeers(dt);
      this.updateMpSync(dt);
    } else if (this.state === 'menu') {
      this.elapsedT0 += dt;
      // Atmospheric haunted hallway pan on title screen
      const mc = this.preset.menuCamera;
      this.camera.position.set(
        mc.x + Math.sin(this.elapsedT0 * 0.25) * 4,
        mc.y,
        mc.z + Math.cos(this.elapsedT0 * 0.18) * 0.8
      );
      this.camera.rotation.set(0, mc.yaw + Math.sin(this.elapsedT0 * 0.2) * 0.15, 0);
      this.torch.intensity = 2.2 * this.settings.bright * (0.85 + 0.15 * Math.sin(now * 0.003));
      this.updateLights(dt);
      this.updateDynamicFog(dt, true);
      this.updateDustParticles(true);
      this.animateMonsters(dt);
    }

    this.renderAll();

    this.hudEmitAcc += dt;
    if (this.hudEmitAcc >= 0.08 && this.state !== 'menu') {
      this.hudEmitAcc = 0;
      this.emitHud();
    }

    this.scheduleNextTick();
  }

  private renderAll(): void {
    this.renderer.clear();
    this.renderer.render(this.scene, this.camera);
    const showHands =
      !this.P.hidden &&
      (this.state === 'play' || this.state === 'pad' || this.state === 'paused');
    if (showHands) {
      this.renderer.clearDepth();
      this.renderer.render(this.hands.scene, this.hands.camera);
    }
  }

  private updatePlay(dt: number): void {
    this.elapsedT0 += dt;
    this.timeSeconds += dt;

    // Handle trapped state (Bear Trap!)
    if (this.P.trappedTimer > 0) {
      this.P.trappedTimer = Math.max(0, this.P.trappedTimer - dt);
      if (this.P.trappedTimer <= 0) {
        this.P.trapProgress = 0;
        this.showToast('تحررت من الفخ!', 1400);
      }
    }

    const ix =
      (this.keys.KeyD || this.keys.ArrowRight ? 1 : 0) -
      (this.keys.KeyA || this.keys.ArrowLeft ? 1 : 0) +
      this.touchMove.mx;
    const iz =
      (this.keys.KeyW || this.keys.ArrowUp ? 1 : 0) -
      (this.keys.KeyS || this.keys.ArrowDown ? 1 : 0) +
      this.touchMove.mz;

    let moving = false;
    let sprint = false;
    if (!this.P.hidden && this.P.trappedTimer <= 0) {
      let len = Math.hypot(ix, iz);
      let nx = ix;
      let nz = iz;
      if (len > 1) {
        nx /= len;
        nz /= len;
        len = 1;
      }
      moving = len > 0.1;
      sprint =
        moving &&
        (this.keys.ShiftLeft || this.keys.ShiftRight || this.touchMove.run) &&
        !this.P.crouch &&
        !this.P.exhausted &&
        this.P.stamina > 0;
      const sp = this.P.crouch ? 1.55 : sprint ? 5.3 : 3.1;
      const s = Math.sin(this.P.yaw);
      const c = Math.cos(this.P.yaw);
      this.P.x += (-s * nz + c * nx) * sp * dt;
      this.P.z += (-c * nz - s * nx) * sp * dt;
      this.pushOut(this.P, 0.38);
      this.updFloor(this.P);

      if (moving) {
        this.P.bob += dt * (sprint ? 11 : this.P.crouch ? 6 : 8);
        const ss = Math.sin(this.P.bob) > 0;
        if (ss !== this.P.stepSign) {
          this.P.stepSign = ss;
          if (!this.P.crouch) Snd.noise(sprint ? 0.12 : 0.06, 0.07, 700);
        }
      }

      // Check Bear Traps
      for (const trap of this.bearTraps) {
        if (
          trap.armed &&
          trap.fl === this.P.fl &&
          Math.hypot(trap.x - this.P.x, trap.z - this.P.z) < 0.55
        ) {
          this.snapTrap(trap, true);
          break;
        }
      }

      // Check Creaky Floorboards
      for (const cb of this.world.creakBoards) {
        if (cb.cooldown > 0) cb.cooldown -= dt;
        if (
          moving &&
          !this.P.crouch &&
          cb.cooldown <= 0 &&
          cb.fl === this.P.fl &&
          Math.abs(this.P.x - cb.x) < cb.w / 2 &&
          Math.abs(this.P.z - cb.z) < cb.d / 2
        ) {
          cb.cooldown = 3.0;
          Snd.floorCreak();
          this.emitNoise(
            this.P.fl,
            this.P.x,
            this.P.z,
            sprint ? 24 : 16,
            'صرير الخشب فضح موقعك!'
          );
        }
      }

      // Knock over vases if sprinting right through them!
      if (sprint) {
        for (const prop of this.droppedProps) {
          if (
            prop.active &&
            prop.kind === 'vase' &&
            prop.fl === this.P.fl &&
            Math.hypot(prop.x - this.P.x, prop.z - this.P.z) < 0.72
          ) {
            prop.active = false;
            this.world.floors[prop.fl].g.remove(prop.mesh);
            Snd.dropNoise(true);
            this.emitNoise(
              prop.fl,
              prop.x,
              prop.z,
              32,
              'أسقطت مزهرية أثناء الجري! الصوت سيجذب الوحش'
            );
          }
        }
      }
    }

    this.moving = moving;
    if (sprint) {
      this.P.stamina -= 0.2 * dt;
      if (this.P.stamina <= 0) {
        this.P.stamina = 0;
        this.P.exhausted = true;
      }
    } else {
      this.P.stamina = Math.min(1, this.P.stamina + 0.14 * dt);
    }
    if (this.P.exhausted && this.P.stamina > 0.3) this.P.exhausted = false;

    this.P.noise = Math.max(
      this.extraNoise,
      moving && !this.P.hidden ? (sprint ? 15 : this.P.crouch ? 2.0 : 7.5) : 0
    );

    this.simBackground(dt);
    this.updateRevive(dt);
    this.checkKills();
    if (this.state !== 'play') return;

    this.fireCD = Math.max(0, this.fireCD - dt);
    this.noiseTimer = Math.max(0, this.noiseTimer - dt);
    this.extraNoise = this.noiseTimer > 0 ? 24 : 0;
    this.gunFlash.intensity = this.flashTimer > 0 ? (5 * this.flashTimer) / 0.07 : 0;
    this.flashTimer = Math.max(0, this.flashTimer - dt);
    this.hitFlash = Math.max(0, this.hitFlash - dt * 1.4);

    this.updateLights(dt);
    this.updateDynamicFog(dt, false);
    this.updateSafeAnim(dt);
    this.hands.update(
      dt,
      this.P.yaw,
      this.P.pitch,
      this.moving,
      this.P.bob,
      this.P.crouch,
      this.P.torch,
      this.P.heldItem
    );

    // Grandfather clock & rocking chair ambience
    this.world.pendulum.rotation.z = Math.sin(this.elapsedT0 * 2.1) * 0.22;
    this.world.rockingChair.rotation.x = Math.sin(this.elapsedT0 * 1.4) * 0.06;
    const clockDist =
      this.world.theme === 'manor'
        ? Math.hypot(this.P.x - 25.2, this.P.z - 39.2)
        : Math.hypot(this.P.x - 4, this.P.z - 38.8);
    if (this.P.fl === 0 && clockDist < 12) {
      this.clockTickAcc += dt;
      if (this.clockTickAcc >= 1.0) {
        this.clockTickAcc = 0;
        Snd.clockTick();
      }
    }

    const diff = DIFFICULTIES[this.settings.diff];
    const cosY = Math.cos(this.P.yaw);
    const sinY = Math.sin(this.P.yaw);
    const dirPan = (ex: number, ez: number): number => {
      const dx = ex - this.P.x;
      const dz = ez - this.P.z;
      const hd = Math.hypot(dx, dz);
      if (hd < 0.01) return 0;
      const raw = (dx / hd) * cosY - (dz / hd) * sinY;
      return Math.max(-0.92, Math.min(0.92, raw));
    };

    const hs = Math.sin(this.H.phase) > 0;
    const dh = Math.hypot(this.H.x - this.P.x, this.H.z - this.P.z) + (this.H.fl !== this.P.fl ? 9 : 0);
    const dg = Math.hypot(this.G.x - this.P.x, this.G.z - this.P.z) + (this.P.fl !== 0 ? 12 : 0);
    const hPan = dirPan(this.H.x, this.H.z);
    if (this.H.v > 0.3 && hs !== this.H.hstep) {
      this.H.hstep = hs;
      if (dh < 22) Snd.hstep(dh, hPan);
    }

    // "الهمس" (The Whisper): early directional whisper & murmur cues up to ~22m before visual contact
    let closestDist = 999;
    let closestPan = 0;
    let enemyHiddenWarning = false;
    if (diff.monsters && this.H.stun <= 0) {
      closestDist = dh;
      closestPan = hPan;
      enemyHiddenWarning = !this.hmCanSee();
    }
    if (diff.monsters && this.giantOn && this.G.stun <= 0 && dg < closestDist) {
      closestDist = dg;
      closestPan = dirPan(this.G.x, this.G.z);
      enemyHiddenWarning = true;
    }

    let whisperIntensity = 0;
    if (closestDist < 22) {
      whisperIntensity = Math.max(0, Math.min(1, (22 - closestDist) / 18));
      if (enemyHiddenWarning) {
        whisperIntensity = Math.min(1, whisperIntensity * 1.15);
      }
    }
    Snd.setWhisperProximity(whisperIntensity, closestPan);
    this.whisperTimer -= dt * (0.7 + whisperIntensity * 1.4);
    if (this.whisperTimer <= 0) {
      if (whisperIntensity > 0.08) {
        Snd.whisperBurst(whisperIntensity, closestPan);
      }
      this.whisperTimer = rand(1.9, 4.2);
    }

    let th = 0;
    if (diff.monsters && this.H.stun <= 0) {
      const stalkerProx = Math.max(0, Math.min(1, (20 - dh) / 17));
      th = Math.pow(stalkerProx, 1.25) * 0.68;
      if (this.H.state === 'chase') {
        th = Math.max(th, 0.66 + 0.34 * stalkerProx);
      } else if (this.H.state === 'investigate' || this.H.state === 'hideCheck' || this.hmCanSee()) {
        th = Math.max(th, 0.32 + 0.48 * stalkerProx);
      }
    }
    if (diff.monsters && this.giantOn && this.G.stun <= 0) {
      const gProx = Math.max(0, Math.min(1, (16 - dg) / 14));
      th = Math.max(th, Math.pow(gProx, 1.2) * 0.72);
    }
    const threatRate = th > this.threat ? 5.5 : 2.2;
    this.threat += (th - this.threat) * Math.min(1, dt * threatRate);
    Snd.setThreatTension(this.threat);

    // Subtle proximity camera dread tremor when Granny/Stalker or Giant gets close
    let targetProxShake = 0;
    if (diff.monsters && this.H.stun <= 0 && dh < 11) {
      targetProxShake = Math.pow(1 - dh / 11, 1.35) * (this.H.state === 'chase' ? 0.036 : 0.018);
    }
    if (diff.monsters && this.giantOn && this.G.stun <= 0 && dg < 11) {
      targetProxShake = Math.max(targetProxShake, Math.pow(1 - dg / 11, 1.3) * 0.025);
    }
    this.proxShake += (targetProxShake - this.proxShake) * Math.min(1, dt * 6);

    this.bangTimer -= dt;
    if (this.bangTimer <= 0) {
      Snd.bang();
      this.addShake(0.055, 0.14);
      this.bangTimer = rand(25, 50);
    }

    this.updateAmbientSounds(dt, false);

    let fl = 1;
    if (this.threat > 0.45 && Math.random() < 0.12) fl = rand(0.05, 0.6);
    this.torch.intensity = this.P.torch ? 2.2 * this.settings.bright * fl : 0;

    if (this.P.x > 61.2) {
      this.startCinema();
    }

    this.animateMonsters(dt);
    this.updateRemotePeers(dt);
    this.updateMpSync(dt);
    this.updateCamera(dt);
    this.updateDustParticles(false);
  }

  private updateAmbientSounds(dt: number, lightMode: boolean): void {
    // Scale continuous wind draft slightly with player elevation and threat tension
    const draftIntensity = (this.P.fl === 1 ? 1.25 : 0.9) + this.threat * 0.45;
    Snd.setAmbientActive(true, draftIntensity);

    // 1. Distant wooden floorboard creaks around the abandoned mansion
    this.ambient.floorCreakTimer -= dt * (1 + this.threat * 0.25);
    if (this.ambient.floorCreakTimer <= 0) {
      const pan = rand(-0.85, 0.85);
      Snd.ambientFloorCreak(rand(0.055, 0.115), pan);
      this.ambient.floorCreakTimer = rand(6.5, 15.5);
    }

    // 2. Howling wind gusts through broken shutters and upstairs corridors
    this.ambient.windTimer -= dt * (this.P.fl === 1 ? 1.2 : 1.0);
    if (this.ambient.windTimer <= 0) {
      const pan = rand(-0.75, 0.75);
      const vol = (this.P.fl === 1 ? 0.17 : 0.12) + Math.random() * 0.06;
      Snd.windGust(vol, pan);
      this.ambient.windTimer = rand(9, 20);
    }

    if (lightMode) return;

    // 3. Eerie distant footsteps echoing from another room or floor
    this.ambient.distantStepsTimer -= dt;
    if (this.ambient.distantStepsTimer <= 0) {
      const dh = Math.hypot(this.H.x - this.P.x, this.H.z - this.P.z);
      // Play distant phantom footsteps only when not actively in a close-range chase
      if (this.H.state !== 'chase' || dh > 14) {
        const steps = 3 + ((Math.random() * 4) | 0);
        const pan = rand(-0.9, 0.9);
        const floorAbove = this.P.fl === 0 && Math.random() < 0.65;
        Snd.distantFootsteps(steps, rand(0.08, 0.14), pan, floorAbove);
      }
      this.ambient.distantStepsTimer = rand(14, 28);
    }

    // 4. Occasional shutter/pipe rattle or muffled thump inside empty walls
    this.ambient.rattleTimer -= dt;
    if (this.ambient.rattleTimer <= 0) {
      Snd.houseRattle(rand(0.05, 0.1), rand(-0.9, 0.9));
      this.ambient.rattleTimer = rand(18, 34);
    }
  }

  private simBackground(dt: number): void {
    this.updateDoors(dt);
    const diff = DIFFICULTIES[this.settings.diff];
    if (!this.mp.room || this.mp.isHost) {
      if (diff.monsters) this.updateHammerMan(dt);
      if (this.giantOn) this.updateGiant(dt);
    } else {
      this.applyRemoteMonsters(dt);
    }
  }

  private getAllLiveTargets(): LiveTarget[] {
    const out: LiveTarget[] = [];
    if (this.state === 'play' || this.state === 'pad') {
      out.push({
        x: this.P.x,
        z: this.P.z,
        fl: this.P.fl,
        hidden: this.P.hidden,
        crouch: this.P.crouch,
        torch: this.P.torch,
        noise: this.P.noise,
      });
    }
    this.remotePeers.forEach((entry) => {
      const p = entry.peer;
      if (!p.alive || p.escaped) return;
      const hidden =
        p.hiddenIdx >= 0 && p.hiddenIdx < this.world.closets.length
          ? this.world.closets[p.hiddenIdx]
          : null;
      const noise = p.speed > 4.2 ? 15 : p.speed > 2.0 && !p.crouch ? 7.5 : 0;
      out.push({
        x: entry.x,
        z: entry.z,
        fl: p.fl,
        hidden,
        crouch: p.crouch,
        torch: p.torch,
        noise,
      });
    });
    return out;
  }

  private pickNearestVisibleTarget(): LiveTarget | null {
    const diff = DIFFICULTIES[this.settings.diff];
    let best: LiveTarget | null = null;
    let bestDist = 1e9;
    for (const tgt of this.getAllLiveTargets()) {
      if (tgt.hidden || tgt.fl !== this.H.fl) continue;
      const d = Math.hypot(this.H.x - tgt.x, this.H.z - tgt.z);
      let range = (tgt.torch ? 17 : 10) * diff.see;
      if (tgt.crouch) range *= 0.62;
      if (d > range || d >= bestDist) continue;
      if (d > 3.2) {
        const dot = ((tgt.x - this.H.x) * this.H.dx + (tgt.z - this.H.z) * this.H.dz) / d;
        if (dot < 0.3) continue;
      }
      if (!this.blocked(this.H.x, this.H.z, tgt.x, tgt.z, this.H.fl)) {
        best = tgt;
        bestDist = d;
      }
    }
    return best;
  }

  private updateDoors(dt: number): void {
    const allTargets = this.getAllLiveTargets();
    for (const d of this.world.doors) {
      let dp = 99;
      let nearestX = this.P.x;
      let nearestZ = this.P.z;
      for (const t of allTargets) {
        if (t.hidden || t.fl !== d.fl) continue;
        const distT = Math.hypot(t.x - d.cx, t.z - d.cz);
        if (distT < dp) {
          dp = distT;
          nearestX = t.x;
          nearestZ = t.z;
        }
      }
      const dh =
        this.H.fl !== d.fl ? 99 : Math.hypot(this.H.x - d.cx, this.H.z - d.cz);
      const dm = Math.min(dp, dh);
      if (d.target === 0 && dm < 3.6) {
        d.target = 1;
        const sx = dp <= dh ? { x: nearestX, z: nearestZ } : this.H;
        d.side =
          (d.ax === 'x' ? Math.sign(sx.z - d.fixed) : Math.sign(sx.x - d.fixed)) || 1;
        const distToLocal = Math.hypot(this.P.x - d.cx, this.P.z - d.cz);
        if (distToLocal < 14) Snd.creak(Math.max(0.03, 0.16 * (1 - distToLocal / 14)));
      } else if (d.target === 1 && dm > 4.6) {
        d.target = 0;
      }

      const goal = d.target ? 1.48 : 0;
      const df = goal - d.ang;
      const swingSpeed = dt * 10.5;
      d.ang += Math.max(-swingSpeed, Math.min(swingSpeed, df));
      d.piv.rotation.y = d.ax === 'x' ? d.side * d.ang : -d.side * d.ang;

      // Never re-enable door solidity if anyone stands near the doorway arc
      const shut = d.ang < 0.22 && dm > 1.8;
      if (shut && !d.solid) {
        this.world.floors[d.fl].co.push(d.box);
        this.world.floors[d.fl].bl.push(d.box);
        d.solid = true;
      } else if (!shut && d.solid) {
        const a = this.world.floors[d.fl].co.indexOf(d.box);
        if (a >= 0) this.world.floors[d.fl].co.splice(a, 1);
        const b = this.world.floors[d.fl].bl.indexOf(d.box);
        if (b >= 0) this.world.floors[d.fl].bl.splice(b, 1);
        d.solid = false;
      }
    }
  }

  private updateHammerMan(dt: number): void {
    const diff = DIFFICULTIES[this.settings.diff];
    this.updFloor(this.H);
    if (this.H.stun > 0) {
      this.H.stun = Math.max(0, this.H.stun - dt);
      this.H.v = 0;
      this.H.atk = 0;
      this.H.atkAnim = 0;
      if (this.H.stun <= 0) {
        this.H.state = 'patrol';
        this.pickPatrol();
        this.showToast('استعاد رجل المطرقة وعيه!', 2200);
      }
      return;
    }

    const targets = this.getAllLiveTargets();
    const seenTgt = this.pickNearestVisibleTarget();
    let d = Math.hypot(this.H.x - this.P.x, this.H.z - this.P.z);
    for (const t of targets) {
      if (!t.hidden && t.fl === this.H.fl) {
        d = Math.min(d, Math.hypot(this.H.x - t.x, this.H.z - t.z));
      }
    }
    this.H.stateT += dt;
    this.H.noiseCD -= dt;
    this.H.v = 0;

    if (this.H.catchT > 0) {
      this.H.catchT -= dt;
      if (this.H.catchT <= 0) this.H.catchIdx = -1;
    }

    if (this.H.atk > 0) {
      this.H.atk -= dt;
      this.H.atkAnim = 1 - Math.max(0, this.H.atk) / 0.55;
      if (this.H.atk <= 0) {
        this.H.atkAnim = 0;
        this.H.cool = 1.2;
      }
      return;
    }

    this.H.cool -= dt;

    // Stalker periodically sets a new bear trap on patrol
    if (diff.traps > 0 && (this.H.state === 'patrol' || this.H.state === 'investigate')) {
      this.H.trapPlaceTimer -= dt;
      if (this.H.trapPlaceTimer <= 0) {
        this.H.trapPlaceTimer = rand(22, 34);
        const armedCount = this.bearTraps.filter((t) => t.armed).length;
        const farFromPlayers = targets.every(
          (t) => Math.hypot(this.H.x - t.x, this.H.z - t.z) > 6
        );
        if (armedCount < diff.traps && farFromPlayers && this.H.gy < 0.4) {
          this.spawnBearTrap(this.H.fl, this.H.x, this.H.z);
        }
      }
    }

    if (
      this.H.state === 'patrol' ||
      this.H.state === 'investigate'
    ) {
      if (seenTgt) {
        this.H.last = { x: seenTgt.x, z: seenTgt.z, fl: seenTgt.fl };
        this.startChase();
      } else {
        const sp = (this.H.state === 'patrol' ? 1.4 : 2.15) * diff.hs;
        if (this.followMonsterPath(dt, sp)) {
          if (this.H.wait <= 0) {
            this.H.wait = this.H.state === 'patrol' ? rand(1.0, 2.5) : rand(2.5, 4.0);
          }
          this.H.wait -= dt;
          if (this.H.wait <= 0) {
            this.H.state = 'patrol';
            this.pickPatrol();
          }
        }
        if (this.H.noiseCD <= 0) {
          for (const t of targets) {
            if (t.noise <= 0 || t.hidden) continue;
            const nd = Math.hypot(this.H.x - t.x, this.H.z - t.z) + (this.H.fl !== t.fl ? 8 : 0);
            if (nd < t.noise * diff.hear) {
              this.H.noiseCD = 2.8;
              this.H.state = 'investigate';
              this.setMonsterGoal(t.x, t.z, t.fl);
              this.H.wait = 0;
              break;
            }
          }
        }
      }
    } else if (this.H.state === 'chase') {
      if (seenTgt) {
        this.H.lose = 0;
        this.H.last = { x: seenTgt.x, z: seenTgt.z, fl: seenTgt.fl };
        const td = Math.hypot(this.H.x - seenTgt.x, this.H.z - seenTgt.z);
        this.stepTo(this.H, seenTgt.x, seenTgt.z, 2.95 * diff.hs, dt, 0.45, 9);
        if (td < 1.95 && this.H.cool <= 0) {
          this.H.atk = 0.55;
          Snd.swing();
        }
      } else {
        // Check if any target hid nearby
        let hidSpot: HideSpot | null = null;
        for (const t of targets) {
          if (t.hidden && t.fl === this.H.fl && Math.hypot(this.H.x - t.x, this.H.z - t.z) < 18) {
            hidSpot = t.hidden;
            break;
          }
        }
        if (hidSpot) {
          this.H.state = 'hideCheck';
          this.H.closet = hidSpot;
          this.H.stateT = 0;
          this.setMonsterGoal(hidSpot.exit.x, hidSpot.exit.z, hidSpot.fl);
        } else {
          this.H.lose += dt;
          if ((this.H.lose < 0.3 || !this.H.path.length) && this.H.last) {
            this.setMonsterGoal(this.H.last.x, this.H.last.z, this.H.last.fl);
          }
          this.followMonsterPath(dt, 2.75 * diff.hs);
          if (this.H.lose > 5.5) {
            this.H.state = 'investigate';
            this.H.wait = 0;
          }
        }
      }
    } else if (this.H.state === 'hideCheck' && this.H.closet) {
      if (seenTgt) {
        this.H.last = { x: seenTgt.x, z: seenTgt.z, fl: seenTgt.fl };
        this.startChase();
      } else {
        const cl = this.H.closet;
        const dc = Math.hypot(this.H.x - cl.exit.x, this.H.z - cl.exit.z);
        if (dc > 1.2 || this.H.fl !== cl.fl) {
          this.followMonsterPath(dt, 2.5 * diff.hs);
          this.H.stateT = 0;
        } else {
          this.H.v = 0;
          if (this.H.stateT > 1.7) {
            const occupied = targets.some((t) => t.hidden === cl);
            if (occupied) {
              this.H.catchIdx = this.world.closets.indexOf(cl);
              this.H.catchT = 1.2;
            }
            this.H.state = 'patrol';
            this.H.wait = 0;
            this.pickPatrol();
          }
        }
      }
    }

    this.H.stuckT += dt;
    if (this.H.stuckT > 1.2) {
      if (
        this.H.v > 0.2 &&
        Math.hypot(this.H.x - this.H.sx, this.H.z - this.H.sz) < 0.2 &&
        this.H.path.length
      ) {
        this.H.path.shift();
      }
      this.H.sx = this.H.x;
      this.H.sz = this.H.z;
      this.H.stuckT = 0;
    }
  }

  private updateGiant(dt: number): void {
    const diff = DIFFICULTIES[this.settings.diff];
    if (this.G.stun > 0) {
      this.G.stun = Math.max(0, this.G.stun - dt);
      this.G.v = 0;
      this.G.atk = 0;
      this.G.atkAnim = 0;
      return;
    }

    let hallTarget: LiveTarget | null = null;
    let hallDist = 1e9;
    for (const t of this.getAllLiveTargets()) {
      const inHall = !t.hidden && t.fl === 0 && t.z > 14.5 && t.z < 25.5 && t.x > 0 && t.x < 60;
      if (!inHall) continue;
      const dist = Math.hypot(this.G.x - t.x, this.G.z - t.z);
      if (dist < hallDist) {
        hallDist = dist;
        hallTarget = t;
      }
    }
    const d = Math.hypot(this.G.x - this.P.x, this.G.z - this.P.z);

    if (this.G.atk > 0) {
      this.G.atk -= dt;
      this.G.atkAnim = 1 - Math.max(0, this.G.atk) / 1.4;
      this.G.v = 0;
      if (this.G.atk <= 0) {
        this.G.atkAnim = 0;
        this.G.cool = 1.6;
      }
    } else {
      this.G.cool -= dt;
      let tx: number;
      let tz: number;
      let sp: number;
      if (hallTarget && hallDist < 48) {
        tx = hallTarget.x;
        tz = Math.max(19.4, Math.min(20.6, hallTarget.z));
        sp = 0.65 * diff.gs;
        if (hallDist < 2.9 && this.G.cool <= 0) {
          this.G.atk = 1.4;
          Snd.groan();
        }
      } else {
        if (!this.G.goal || Math.abs(this.G.x - this.G.goal) < 1) {
          this.G.goal = rand(5, 55);
        }
        tx = this.G.goal;
        tz = 20 + Math.sin(this.elapsedT0 * 0.1) * 0.5;
        sp = 0.5 * diff.gs;
      }

      if (this.G.atk <= 0 && !(hallTarget && hallDist < 2.4)) {
        this.stepTo(this.G, tx, tz, sp, dt, 1.2, 1.4);
      } else {
        this.G.v = 0;
      }
      this.G.x = Math.max(2.2, Math.min(57.8, this.G.x));
      this.G.z = Math.max(19.3, Math.min(20.7, this.G.z));
    }

    this.G.phase += dt * this.G.v * 1.9;
    const s = Math.sin(this.G.phase);
    if (this.G.v > 0.05 && s > 0 !== this.G.stepSign) {
      this.G.stepSign = s > 0;
      if (d < 40) {
        Snd.gstep(d);
        if (d < 14) {
          this.shake = Math.max(this.shake, 0.05 * (1 - d / 14) + 0.012);
        }
      }
    }
  }

  private checkKills(): void {
    if (this.state !== 'play') return;
    const diff = DIFFICULTIES[this.settings.diff];
    const dh = Math.hypot(this.H.x - this.P.x, this.H.z - this.P.z);
    const dg = Math.hypot(this.G.x - this.P.x, this.G.z - this.P.z);

    if (diff.monsters && this.H.stun <= 0) {
      if (this.pHa > 0 && this.H.atk <= 0 && !this.P.hidden && dh < 2.6 && this.P.fl === this.H.fl) {
        this.kill('hammer');
      }
      if (
        this.state === 'play' &&
        this.H.catchIdx >= 0 &&
        this.P.hidden &&
        this.world.closets.indexOf(this.P.hidden) === this.H.catchIdx
      ) {
        this.kill('closet');
      }
    }

    if (
      this.state === 'play' &&
      this.giantOn &&
      this.G.stun <= 0 &&
      this.pGa > 0 &&
      this.G.atk <= 0 &&
      !this.P.hidden &&
      dg < 3.4 &&
      this.P.fl === 0
    ) {
      this.kill('giant');
    }

    this.pHa = this.H.atk;
    this.pGa = this.G.atk;
  }

  private animateMonsters(dt: number): void {
    const A = this.hmRig;
    this.H.phase += dt * this.H.v * 2.6;
    const w = Math.sin(this.H.phase) * Math.min(1, this.H.v / 1.6) * 0.75;
    A.legL.rotation.x = w;
    A.legR.rotation.x = -w;
    A.armL.rotation.x = -w * 0.5;
    const swing = this.H.atk > 0 ? this.H.atkAnim : 0;
    A.armR.rotation.x =
      this.H.atk > 0
        ? swing < 0.7
          ? -2.6 * (swing / 0.7)
          : -2.6 + 3.5 * ((swing - 0.7) / 0.3)
        : 0.15 + w * 0.25;
    A.head.rotation.y = Math.sin(this.elapsedT0 * 1.3) * 0.2 * (this.H.state === 'patrol' ? 1 : 0.3);
    A.group.position.set(this.H.x, this.H.gy + Math.abs(w) * 0.05, this.H.z);
    A.group.rotation.y = Math.atan2(this.H.dx, this.H.dz);

    if (this.H.stun > 0) {
      A.group.rotation.x = -Math.PI / 2;
      A.group.position.y = this.H.gy + 0.35;
      A.head.rotation.x = 0.2;
    } else {
      A.group.rotation.x = 0;
      A.head.rotation.x = 0;
    }
    this.redGlow.position.set(this.H.x, this.H.gy + 1.6, this.H.z);

    const B = this.giantRig;
    const gw = Math.sin(this.G.phase);
    B.legL.rotation.x = gw * 0.5;
    B.legR.rotation.x = -gw * 0.5;
    B.body.rotation.z = gw * 0.05;
    B.body.position.y = 2.4 + Math.abs(gw) * 0.08;
    B.armL.rotation.x = -gw * 0.25;
    B.armR.rotation.x =
      this.G.atk > 0
        ? this.G.atkAnim < 0.8
          ? -2.5 * (this.G.atkAnim / 0.8)
          : -2.5 + 3.3 * ((this.G.atkAnim - 0.8) / 0.2)
        : gw * 0.25;
    B.head.rotation.y = Math.sin(this.elapsedT0 * 0.4) * 0.25;
    B.group.position.set(this.G.x, 0, this.G.z);
    B.group.rotation.y = Math.atan2(this.G.dx, this.G.dz);
    this.greenGlow.position.set(this.G.x, 3.5, this.G.z);

    this.world.exitDoorPivot.rotation.y +=
      ((this.doorOpen ? 1.5 : 0) - this.world.exitDoorPivot.rotation.y) *
      Math.min(1, dt * 2.5);
  }

  private updateCamera(dt: number): void {
    if (this.P.hidden) {
      this.P.eye = this.P.hidden.eye;
    } else if (this.P.trappedTimer > 0) {
      this.P.eye += (EYE_C - this.P.eye) * Math.min(1, dt * 8);
    } else {
      this.P.eye += ((this.P.crouch ? EYE_C : EYE) - this.P.eye) * Math.min(1, dt * 10);
    }

    const by = this.moving ? Math.sin(this.P.bob) * 0.045 : 0;
    this.shake *= Math.max(0, 1 - dt * 4);
    const sh = Math.min(0.32, this.shake + this.proxShake);
    this.camera.position.set(
      this.P.x + (Math.random() - 0.5) * sh,
      this.P.gy + this.P.eye + by + (Math.random() - 0.5) * sh,
      this.P.z + (Math.random() - 0.5) * sh
    );
    const rollTremor = (Math.random() - 0.5) * sh * 0.22;
    this.camera.rotation.set(this.P.pitch, this.P.yaw, this.P.roll + rollTremor);
  }

  private updateLights(dt: number): void {
    let f = 0;
    if (this.lightTimer > 0) {
      this.lightTimer -= dt;
      if (!this.lampOn) {
        this.lampOn = true;
      }
      f = this.lightTimer > 2 ? 1 : Math.random() < 0.55 ? 1 : 0.08;
      if (this.lightTimer <= 0) {
        this.lightTimer = 0;
        f = 0;
        Snd.tone('square', 200, 120, 0.12, 0.1);
      }
    }
    this.lampFlicker = f;
    if (this.lightTimer <= 0 && this.lampOn) {
      this.lampOn = false;
      this.lampFlicker = 0;
    }

    const switchActive = this.lightTimer > 0;
    const baseAmb = (switchActive ? 0.65 + 0.5 * f : 0.65) * this.settings.bright;
    const diff = DIFFICULTIES[this.settings.diff];
    const monsterLive = diff.monsters && this.H.stun <= 0;
    const t = this.elapsedT0;
    this.lampSparkCD = Math.max(0, this.lampSparkCD - dt);

    let maxNearInstab = 0;
    for (const pl of this.world.pendantLamps) {
      const distKiller = monsterLive
        ? Math.hypot(this.H.x - pl.x, this.H.z - pl.z) + (this.H.fl !== pl.fl ? 10 : 0)
        : 999;
      const killerNear = monsterLive ? Math.max(0, Math.min(1, (19 - distKiller) / 14)) : 0;
      const instab = Math.max(killerNear, this.threat * 0.68);
      if (instab > maxNearInstab) maxNearInstab = instab;

      const baseIntensity = switchActive ? 2.3 * f : 0.42;
      pl.light.distance = switchActive ? 26 : 16;

      let flick = 1;
      if (instab > 0.06) {
        const wave =
          Math.sin(t * (22 + instab * 18) + pl.phase) *
          Math.sin(t * (53 + instab * 29) + pl.phase * 1.7);
        if (wave < -0.55 + instab * 0.35 || Math.random() < instab * 0.18) {
          // Sharp unstable voltage dropout
          flick = 0.04 + Math.random() * 0.18;
          if (this.lampSparkCD <= 0 && instab > 0.48) {
            const distPlayer =
              Math.hypot(this.P.x - pl.x, this.P.z - pl.z) + (this.P.fl !== pl.fl ? 10 : 0);
            if (distPlayer < 14) {
              Snd.noise(0.022 * instab, 0.045, 2200);
              this.lampSparkCD = rand(0.35, 0.95);
            }
          }
        } else {
          flick = Math.max(0.15, 0.85 + wave * 0.35 * instab);
        }
      }

      const finalInt = baseIntensity * flick * this.settings.bright;
      pl.light.intensity = finalInt;
      const bulbMat = pl.bulb.material as THREE.MeshBasicMaterial;
      if (flick < 0.22) {
        bulbMat.color.setHex(0x1e1710);
      } else if (instab > 0.4 && flick < 0.65) {
        bulbMat.color.setHex(0xb85a1c);
      } else {
        bulbMat.color.setHex(switchActive ? 0xffe6aa : 0xffcf82);
      }

      // Gentle draft & killer-proximity sway on hanging cord
      const swayAmp = 0.015 + instab * 0.045;
      pl.pivot.rotation.z = Math.sin(t * (1.3 + instab * 1.8) + pl.phase) * swayAmp;
      pl.pivot.rotation.x = Math.cos(t * 0.9 + pl.phase) * (swayAmp * 0.6);
    }

    // Subtle flicker on stairwell lamp too when Stalker is near stairs/threat rises
    const stairWave = Math.sin(t * 37) * Math.sin(t * 71);
    const stairFlick =
      maxNearInstab > 0.25 && (stairWave < -0.4 || Math.random() < maxNearInstab * 0.1)
        ? 0.15 + Math.random() * 0.35
        : 1;
    this.world.stairLamp.intensity = 0.75 * stairFlick * this.settings.bright;

    // Slight ambient dip during severe flickering
    this.amb.intensity = baseAmb * (1 - maxNearInstab * 0.18 * (Math.random() < 0.4 ? 1 : 0.2));

    // Hearth fire flicker inside Gothic Manor fireplace
    if (this.world.fireplaceLight) {
      const fireWave = 0.8 + 0.2 * Math.sin(t * 11.4) * Math.cos(t * 7.3) + (Math.random() - 0.5) * 0.14;
      this.world.fireplaceLight.intensity = 0.72 * Math.max(0.45, fireWave) * this.settings.bright;
    }
  }

  private createCorridorMist(): void {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const grad = ctx.createRadialGradient(32, 32, 2, 32, 32, 31);
      grad.addColorStop(0, 'rgba(205, 218, 232, 0.34)');
      grad.addColorStop(0.5, 'rgba(145, 162, 184, 0.15)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 64, 64);
    }
    this.mistTex = new THREE.CanvasTexture(canvas);

    const count = 96;
    const positions = new Float32Array(count * 3);
    this.mistSeeds = [];

    for (let i = 0; i < count; i++) {
      let x = 30;
      let y = 0.8;
      let z = 20;
      if (i < 44) {
        // Ground floor main corridor
        x = rand(3, 57);
        y = rand(0.3, 1.8);
        z = rand(16.8, 23.2);
      } else if (i < 72) {
        // Upper floor corridor
        x = rand(3, 57);
        y = FY + rand(0.3, 1.8);
        z = rand(16.8, 23.2);
      } else if (i < 84) {
        // Basement / Cellar (القبو)
        x = rand(41.5, 58.5);
        y = rand(0.3, 1.6);
        z = rand(41.5, 54.5);
      } else {
        // Upper dark rooms (العلية / غرفة المرايا / المخزن)
        x = rand(4, 56);
        y = FY + rand(0.35, 1.6);
        z = rand(41.5, 54.5);
      }

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
      this.mistSeeds.push({
        baseX: x,
        baseY: y,
        baseZ: z,
        speedX: rand(0.18, 0.48) * (Math.random() < 0.5 ? 1 : -1),
        speedZ: rand(0.14, 0.36),
        phase: rand(0, Math.PI * 2),
      });
    }

    this.mistGeo = new THREE.BufferGeometry();
    this.mistGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.mistMat = new THREE.PointsMaterial({
      map: this.mistTex,
      size: 3.2,
      transparent: true,
      opacity: 0.16,
      depthWrite: false,
      color: 0x9aaec4,
      fog: true,
    });
    this.mistPoints = new THREE.Points(this.mistGeo, this.mistMat);
    this.mistPoints.frustumCulled = false;
    this.scene.add(this.mistPoints);
  }

  private createDustParticles(): void {
    const count = 1100;
    const positions = new Float32Array(count * 3);
    const seeds = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const fl: 0 | 1 = i < 620 ? 0 : 1;
      const baseY = fl * FY;
      let x: number;
      let y: number;
      let z: number;

      if (i % 4 === 0) {
        // Hallways / corridors
        x = rand(1.5, 58.5);
        y = baseY + rand(0.45, 3.15);
        z = rand(16.4, 23.6);
      } else {
        // Indoor dark rooms
        x = rand(1.5, 58.5);
        y = baseY + rand(0.35, 3.05);
        z = Math.random() < 0.35 ? rand(1.2, 15.2) : rand(24.8, 54.8);
      }

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      seeds[i * 3] = rand(0, Math.PI * 2);
      seeds[i * 3 + 1] = rand(0.65, 1.45);
      seeds[i * 3 + 2] = rand(0.3, 1.0);
    }

    this.dustGeo = new THREE.BufferGeometry();
    this.dustGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.dustGeo.setAttribute('aSeed', new THREE.BufferAttribute(seeds, 3));

    this.dustMat = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uPixelRatio: { value: this.renderer.getPixelRatio() },
        uTorchPos: { value: new THREE.Vector3() },
        uTorchDir: { value: new THREE.Vector3(0, 0, -1) },
        uTorchOn: { value: 1 },
        uLampOn: { value: 0 },
        uFogColor: { value: new THREE.Color(0x030303) },
        uFogDensity: { value: 0.05 },
      },
      vertexShader: /* glsl */ `
        attribute vec3 aSeed;
        uniform float uTime;
        uniform float uPixelRatio;
        uniform vec3 uTorchPos;
        uniform vec3 uTorchDir;
        uniform float uTorchOn;
        uniform float uLampOn;
        varying float vAlpha;
        varying float vWarmth;
        varying float vFogDist;

        void main() {
          vec3 pos = position;
          float ph = aSeed.x;
          float sz = aSeed.y;
          pos.x += sin(uTime * 0.28 + ph) * 0.34;
          pos.y += sin(uTime * 0.41 + ph * 1.7) * 0.16;
          pos.z += cos(uTime * 0.24 + ph * 1.3) * 0.34;

          vec3 toP = pos - uTorchPos;
          float dist = length(toP);
          vec3 dirP = toP / max(dist, 0.001);
          float coneCos = dot(dirP, normalize(uTorchDir));
          // Matches SpotLight angle ~0.56 rad with soft penumbra ~0.5
          float spot = smoothstep(0.76, 0.96, coneCos);
          float atten = 1.0 / (1.0 + dist * dist * 0.048);
          float beam = uTorchOn * spot * atten * step(dist, 24.0);

          float ambientMote = 0.035 + uLampOn * 0.14;
          vAlpha = clamp((ambientMote + beam * 0.88) * aSeed.z, 0.0, 0.85);
          vWarmth = clamp(beam * 1.15, 0.0, 1.0);
          vFogDist = dist;

          vec4 mv = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mv;
          gl_PointSize = clamp((13.0 * sz + beam * 10.0) * uPixelRatio / max(-mv.z, 0.45), 1.4, 8.5);
        }
      `,
      fragmentShader: /* glsl */ `
        uniform vec3 uFogColor;
        uniform float uFogDensity;
        varying float vAlpha;
        varying float vWarmth;
        varying float vFogDist;

        void main() {
          vec2 c = gl_PointCoord - vec2(0.5);
          float r2 = dot(c, c);
          if (r2 > 0.25) discard;
          float soft = pow(1.0 - r2 * 4.0, 1.65);

          vec3 baseCol = vec3(0.52, 0.56, 0.64);
          vec3 torchCol = vec3(1.0, 0.88, 0.66);
          vec3 col = mix(baseCol, torchCol, vWarmth);

          float fogFactor = 1.0 - exp(-uFogDensity * uFogDensity * vFogDist * vFogDist);
          col = mix(col, uFogColor, clamp(fogFactor * 0.72, 0.0, 0.85));

          gl_FragColor = vec4(col, soft * vAlpha);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    this.dustPoints = new THREE.Points(this.dustGeo, this.dustMat);
    this.dustPoints.frustumCulled = false;
    this.scene.add(this.dustPoints);
  }

  private updateDustParticles(menuPreview: boolean): void {
    if (!this.dustMat || !this.dustPoints) return;
    if (this.state === 'cinema') {
      this.dustPoints.visible = false;
      return;
    }
    this.dustPoints.visible = true;
    this.dustMat.uniforms.uTime.value = this.elapsedT0;
    this.camera.getWorldPosition(_torchPos);
    this.camera.getWorldDirection(_torchDir);
    this.dustMat.uniforms.uTorchPos.value.copy(_torchPos);
    this.dustMat.uniforms.uTorchDir.value.copy(_torchDir);
    this.dustMat.uniforms.uTorchOn.value = menuPreview ? 1 : this.P.torch ? 1 : 0;
    this.dustMat.uniforms.uLampOn.value = this.lampFlicker;
    const fog = this.scene.fog as THREE.FogExp2;
    this.dustMat.uniforms.uFogDensity.value = fog.density;
    this.dustMat.uniforms.uFogColor.value.copy(fog.color);
  }

  private updateDynamicFog(dt: number, menuPreview: boolean): void {
    if (this.state === 'cinema') return;

    const mc = this.preset.menuCamera;
    const px = menuPreview ? mc.x : this.P.x;
    const pz = menuPreview ? mc.z : this.P.z;
    const pfl = menuPreview ? 0 : this.P.fl;

    // 1. Area / Dark Zone & Corridor Darkness Factor
    let areaFog = 0;
    const inCorridor = pz >= 16 && pz <= 24;
    if (inCorridor) {
      areaFog = pfl === 1 ? 0.028 : 0.022;
      const sx = (this.preset.stairBounds.x1 + this.preset.stairBounds.x2) / 2;
      if (Math.hypot(px - sx, pz - 22.5) < 6.5) {
        areaFog += 0.007;
      }
    } else {
      for (const r of this.preset.allRooms) {
        if (r.fl === pfl && px >= r.x1 && px <= r.x2 && pz >= r.z1 && pz <= r.z2) {
          if (r.id === 'cell') areaFog = 0.036;
          else if (r.id === 'stor') areaFog = 0.03;
          else if (r.id.startsWith('b')) areaFog = 0.026;
          else if (r.id === 'laun' || r.id === 'a3' || r.id === 'a4') areaFog = 0.022;
          else if (r.id === 'bed' || r.id === 'bath' || r.id === 'nur' || r.id === 'n2' || r.id === 'n4') {
            areaFog = 0.012;
          }
          break;
        }
      }
    }

    if (!menuPreview) {
      if (!this.P.torch) areaFog += 0.026;
      if (this.P.hidden) areaFog += 0.02;
    }

    // 2. Night Progression Factor (both current night clock & passing days 1..5)
    const dayRatio = Math.max(0, Math.min(1, (this.day - 1) / Math.max(1, MAX_DAYS - 1)));
    const nightCycle = menuPreview ? 0.35 : Math.min(1, this.timeSeconds / 240);
    const nightBoost = dayRatio * 0.022 + nightCycle * 0.024;

    // 3. Subtle Organic Mist Drift & Hallway Lamp Reduction
    const swirl =
      Math.sin(this.elapsedT0 * 0.42) * 0.0045 +
      Math.sin(this.elapsedT0 * 0.19) * 0.003;
    const lampCut = 1 - 0.52 * this.lampFlicker;

    const targetDensity = Math.max(
      0.028,
      Math.min(0.165, (this.fogBase + areaFog + nightBoost + swirl) * lampCut)
    );
    this.currentFogDensity +=
      (targetDensity - this.currentFogDensity) * Math.min(1, Math.max(0.05, dt * 1.8));

    const fog = this.scene.fog as THREE.FogExp2;
    fog.density = this.currentFogDensity;

    // Subtle atmospheric fog tint: damp midnight blue-grey -> pitch dark / faint crimson threat
    const tNight = Math.min(1, (nightBoost / 0.046 + (inCorridor ? 0.35 : 0)) * 0.7);
    const r = lerp(0.014, 0.028, tNight) + this.threat * 0.028;
    const g = lerp(0.015, 0.032, tNight) * (1 - this.threat * 0.45);
    const b = lerp(0.018, 0.044, tNight) * (1 - this.threat * 0.5);
    fog.color.setRGB(r, g, b);
    (this.scene.background as THREE.Color).copy(fog.color);

    // Animate drifting corridor mist sprites
    if (this.mistPoints && this.mistGeo) {
      this.mistPoints.visible = true;
      const posAttr = this.mistGeo.getAttribute('position') as THREE.BufferAttribute;
      const arr = posAttr.array as Float32Array;
      for (let i = 0; i < this.mistSeeds.length; i++) {
        const s = this.mistSeeds[i];
        arr[i * 3] = s.baseX + Math.sin(this.elapsedT0 * s.speedX + s.phase) * 2.1;
        arr[i * 3 + 1] = s.baseY + Math.sin(this.elapsedT0 * 0.35 + s.phase) * 0.14;
        arr[i * 3 + 2] = s.baseZ + Math.cos(this.elapsedT0 * s.speedZ + s.phase) * 0.65;
      }
      posAttr.needsUpdate = true;

      const mistIntensity = Math.min(
        1,
        (areaFog / 0.036) * 0.55 + (nightBoost / 0.046) * 0.45
      );
      this.mistMat.opacity = (0.1 + mistIntensity * 0.22) * lampCut;
    }
  }

  private updateSafeAnim(dt: number): void {
    const tg = this.safeOpen ? -1.8 : 0;
    this.world.safeObj.piv.rotation.y +=
      (tg - this.world.safeObj.piv.rotation.y) * Math.min(1, dt * 4);
    this.world.safeObj.sd.visible =
      !this.safeOpen || this.world.safeObj.piv.rotation.y > -1.0;
    (this.world.safeObj.led.material as THREE.MeshBasicMaterial).color.setHex(
      this.safeOpen ? 0x30ff60 : 0xff2a1a
    );
  }

  private updateWake(dt: number): void {
    this.wakeT += dt;
    const t = this.wakeT;
    const T = 3.8;
    this.elapsedT0 += dt;
    this.updateAmbientSounds(dt, true);
    this.animateMonsters(dt);

    let x: number;
    let y: number;
    let z: number;
    let pitch: number;
    let roll: number;
    let lid: number;

    const bedWake = this.preset.bedWake;
    if (t < 1.0) {
      x = bedWake.x;
      y = bedWake.y;
      z = bedWake.z;
      pitch = 1.3;
      roll = 0.05 * Math.sin(t * 3);
      lid =
        t < 0.35
          ? 1
          : t < 0.7
            ? 1 - 0.75 * ((t - 0.35) / 0.35)
            : 0.25 + 0.35 * ((t - 0.7) / 0.3);
    } else if (t < 2.5) {
      const u = ease((t - 1.0) / 1.5);
      x = bedWake.x + (this.P.x - 0.9 - bedWake.x) * u;
      y = bedWake.y + (1.2 - bedWake.y) * u;
      z = bedWake.z + (this.P.z - bedWake.z) * u * 0.5;
      pitch = 1.3 - 0.8 * u;
      roll = 0.04 * Math.sin(t * 2) * (1 - u);
      lid = t < 1.6 ? 0.6 * (1 - (t - 1.0) / 0.6) : t > 1.85 && t < 2.0 ? 0.8 : 0;
      if (!this.wk1) {
        this.wk1 = true;
        Snd.creak(0.08);
        Snd.beat(0.3);
      }
    } else {
      const v = ease((t - 2.5) / 1.3);
      const sx = this.P.x - 0.9;
      const sz = bedWake.z + (this.P.z - bedWake.z) * 0.5;
      x = sx + (this.P.x - sx) * v;
      z = sz + (this.P.z - sz) * v;
      y = 1.2 + (EYE - 1.2) * v;
      pitch = 0.5 * (1 - v);
      roll = 0;
      lid = 0;
      if (!this.wk2 && v > 0.3) {
        this.wk2 = true;
        Snd.noise(0.05, 0.07, 500);
      }
    }

    this.lidOpacity = lid;
    this.camera.position.set(x, y, z);
    this.camera.rotation.set(pitch, this.P.yaw, roll);

    if (t >= T) {
      this.lidOpacity = 0;
      this.state = 'play';
      this.lastTime = performance.now();
      if (this.day === 1) {
        this.showToast(
          `اليوم ١ — ابحث عن ${toArabicDigits(this.needKeys)} مفاتيح وأدوات كسر الأقفال الثلاثة`,
          4200
        );
      } else {
        this.showToast(
          `اليوم ${toArabicDigits(this.day)} — الأقفال والمفاتيح التي أنجزتها ما زالت محفوظة`,
          3600
        );
      }
      this.emitHud();
    }
  }

  private updatePad(dt: number): void {
    this.elapsedT0 += dt;
    this.timeSeconds += dt;
    this.simBackground(dt);
    this.updateAmbientSounds(dt, true);
    this.checkKills();
    if (this.state !== 'pad') return;
    this.animateMonsters(dt);
    this.updateCamera(dt);
  }

  private updateDead(dt: number): void {
    this.deadTimer += dt;
    const M = this.killer === 'giant' ? this.G : this.H;
    const tgt = Math.atan2(-(M.x - this.P.x), -(M.z - this.P.z));
    let df = tgt - this.P.yaw;
    while (df > Math.PI) df -= Math.PI * 2;
    while (df < -Math.PI) df += Math.PI * 2;

    this.P.yaw += df * Math.min(1, dt * 6);
    this.P.pitch += (0.25 - this.P.pitch) * Math.min(1, dt * 3);
    this.P.eye += (0.4 - this.P.eye) * Math.min(1, dt * 2.5);
    this.P.roll += (0.9 - this.P.roll) * Math.min(1, dt * 2);
    this.hitFlash = Math.max(0.35, 0.85 - this.deadTimer * 0.3);
    this.H.v = 0;
    this.G.v = 0;
    this.animateMonsters(dt);
    this.updateRemotePeers(dt);
    this.updateMpSync(dt);
    this.updateCamera(dt);

    if (this.deadTimer > 1.8 && !this.msgShown) {
      this.msgShown = true;
      if (this.mp.room) {
        // In LAN / Multiplayer, corpse stays in place and camera switches to Player 1 (or first survivor)
        if (this.startSpectating(true)) {
          const specPeer = this.spectateId ? this.remotePeers.get(this.spectateId)?.peer : null;
          this.showToast(
            `سقطت! جثتك في مكانها — تتابع الآن ${specPeer ? specPeer.name : 'اللاعب الأول'} حتى ينعشك`,
            3800
          );
        } else {
          this.dayFinal = true;
          this.state = 'dead';
          this.emitHud();
        }
      } else if (this.day < MAX_DAYS) {
        const currentDay = this.day;
        this.dayAnim(currentDay, 'death', () => this.respawn());
      } else {
        this.dayAnim(this.day, 'final', () => {
          this.dayFinal = true;
          this.state = 'dead';
          this.emitHud();
        });
      }
    }
  }

  private updateSpec(dt: number): void {
    this.elapsedT0 += dt;
    this.simBackground(dt);
    this.updateLights(dt);
    this.animateMonsters(dt);
    this.updateRemotePeers(dt);
    this.updateMpSync(dt);

    let entry = this.spectateId ? this.remotePeers.get(this.spectateId) : undefined;
    if (!entry || !entry.peer.alive || entry.peer.escaped) {
      entry = this.getOrderedAliveRemotePeers()[0];
      this.spectateId = entry ? entry.peer.id : null;
    }

    if (!entry) {
      this.state = 'dead';
      this.dayFinal = true;
      this.emitHud();
      return;
    }

    const p = entry.peer;
    const eyeH = entry.y + (p.crouch ? 1.1 : 1.55);
    const backX = Math.sin(entry.yaw);
    const backZ = Math.cos(entry.yaw);
    let camDist = 1.6;
    for (let s = 1; s <= 8; s++) {
      const d = (s / 8) * 1.6;
      if (this.blocked(entry.x, entry.z, entry.x + backX * d, entry.z + backZ * d, p.fl)) {
        camDist = Math.max(0.25, ((s - 1) / 8) * 1.6);
        break;
      }
    }
    this.camera.position.set(entry.x + backX * camDist, eyeH + 0.35, entry.z + backZ * camDist);
    this.camera.lookAt(entry.x - backX * 3, eyeH, entry.z - backZ * 3);
    this.torch.intensity = 1.1 * this.settings.bright;
    this.updateDustParticles(false);
  }

  // ---------- Multiplayer Helpers ----------
  private clearRemotePeers(): void {
    this.remotePeers.forEach((entry) => {
      this.scene.remove(entry.rig.group);
    });
    this.remotePeers.clear();
  }

  private syncRemotePeersFromRoom(room: MultiplayerRoomSnapshot | null): void {
    if (!room) {
      this.clearRemotePeers();
      return;
    }
    const activeIds = new Set<string>();
    for (const p of room.peers) {
      if (p.id === this.mp.selfId) continue;
      activeIds.add(p.id);
      this.upsertRemotePeer(p);
    }
    this.remotePeers.forEach((entry, id) => {
      if (!activeIds.has(id)) {
        this.scene.remove(entry.rig.group);
        this.remotePeers.delete(id);
      }
    });
  }

  private upsertRemotePeer(p: MultiplayerPeer): void {
    if (p.id === this.mp.selfId) return;
    let entry = this.remotePeers.get(p.id);
    if (!entry) {
      const rig = createSurvivorRig(p.name, p.colorIndex, this.tex.skin, this.tex.glow);
      rig.group.position.set(p.x, p.y, p.z);
      this.scene.add(rig.group);
      entry = { peer: p, rig, x: p.x, y: p.y, z: p.z, yaw: p.yaw };
      this.remotePeers.set(p.id, entry);
    } else {
      entry.peer = p;
    }
  }

  private updateRemotePeers(dt: number): void {
    const k = Math.min(1, dt * 14);
    this.remotePeers.forEach((entry) => {
      const p = entry.peer;
      entry.x += (p.x - entry.x) * k;
      entry.y += (p.y - entry.y) * k;
      entry.z += (p.z - entry.z) * k;
      let dyaw = p.yaw - entry.yaw;
      while (dyaw > Math.PI) dyaw -= Math.PI * 2;
      while (dyaw < -Math.PI) dyaw += Math.PI * 2;
      entry.yaw += dyaw * k;

      const rig = entry.rig;
      rig.group.visible = this.state !== 'menu' && p.hiddenIdx < 0 && !p.escaped;
      rig.group.position.set(entry.x, entry.y, entry.z);
      rig.group.rotation.y = entry.yaw + Math.PI;
      animateSurvivorRig(rig, dt, p.speed, p.crouch, p.torch, p.heldItem, p.alive);

      const isBeingRevived = this.reviveState?.targetId === p.id;
      const status = !p.alive
        ? isBeingRevived
          ? 'جارٍ الإنعاش...'
          : 'جثة · إنعاش (٥ ث)'
        : p.escaped
          ? 'هرب'
          : p.hiddenIdx >= 0
            ? 'مختبئ'
            : '';
      updateSurvivorNameTag(rig, p.name, status);
    });
  }

  private applyRemoteMonsters(dt: number): void {
    const data = this.remoteMonsterTarget;
    if (!data) return;
    const h = data.h;
    const k = Math.min(1, dt * 12);
    this.H.x += (h[0] - this.H.x) * k;
    this.H.gy += (h[1] - this.H.gy) * k;
    this.H.fl = h[2];
    this.H.z += (h[3] - this.H.z) * k;
    this.H.dx = h[4];
    this.H.dz = h[5];
    this.H.v = h[6];
    this.H.atk = h[7];
    this.H.atkAnim = h[8];
    this.H.stun = h[9];
    this.H.catchIdx = h[10];
    if (this.H.atk > 0 && this.pHa <= 0) Snd.swing();

    const g = data.g;
    this.G.x += (g[0] - this.G.x) * k;
    this.G.z += (g[1] - this.G.z) * k;
    this.G.dx = g[2];
    this.G.dz = g[3];
    this.G.v = g[4];
    this.G.atk = g[5];
    this.G.atkAnim = g[6];
    this.G.stun = g[7];
    this.G.phase += dt * this.G.v * 1.9;
  }

  private updateMpSync(dt: number): void {
    if (!this.mp.room) return;
    this.mpSendAcc += dt;
    if (this.mpSendAcc < 0.08) return;
    this.mpSendAcc = 0;

    const alive =
      this.state === 'play' ||
      this.state === 'pad' ||
      this.state === 'note' ||
      this.state === 'wake';
    const escaped = this.state === 'cinema' || this.state === 'win';
    const hiddenIdx = this.P.hidden ? this.world.closets.indexOf(this.P.hidden) : -1;
    const speed =
      this.moving && !this.P.hidden && this.state === 'play'
        ? this.P.crouch
          ? 1.55
          : this.keys.ShiftLeft || this.keys.ShiftRight || this.touchMove.run
            ? 5.3
            : 3.1
        : 0;

    this.mp.sendPlayerState({
      x: Number(this.P.x.toFixed(3)),
      y: Number(this.P.gy.toFixed(3)),
      z: Number(this.P.z.toFixed(3)),
      yaw: Number(this.P.yaw.toFixed(3)),
      fl: this.P.fl,
      crouch: this.P.crouch,
      torch: this.P.torch,
      hiddenIdx,
      heldItem: this.P.heldItem,
      alive,
      escaped,
      day: this.day,
      speed,
    });

    if (this.mp.isHost) {
      this.mp.sendMonstersState({
        h: [
          Number(this.H.x.toFixed(3)),
          Number(this.H.gy.toFixed(3)),
          this.H.fl,
          Number(this.H.z.toFixed(3)),
          Number(this.H.dx.toFixed(3)),
          Number(this.H.dz.toFixed(3)),
          Number(this.H.v.toFixed(2)),
          Number(this.H.atk.toFixed(2)),
          Number(this.H.atkAnim.toFixed(2)),
          Number(this.H.stun.toFixed(2)),
          this.H.catchIdx,
        ],
        g: [
          Number(this.G.x.toFixed(3)),
          Number(this.G.z.toFixed(3)),
          Number(this.G.dx.toFixed(3)),
          Number(this.G.dz.toFixed(3)),
          Number(this.G.v.toFixed(2)),
          Number(this.G.atk.toFixed(2)),
          Number(this.G.atkAnim.toFixed(2)),
          Number(this.G.stun.toFixed(2)),
        ],
      });
    }
  }

  private handleNetworkWorldEvent(
    ev: Record<string, unknown>,
    _world: RoomWorldSnapshot
  ): void {
    const kind = String(ev.kind || '');
    if (kind === 'spot' && typeof ev.index === 'number') {
      const sp = this.world.spots[ev.index];
      if (sp && !sp.searched) {
        sp.searched = true;
        if (sp.hide) sp.obj.visible = false;
        else sp.mat.color.setHex(0x5a5048);
        if (sp.key) {
          this.keysCount++;
          Snd.chime();
          this.showToast(
            `وجد زميلك مفتاحًا! (${toArabicDigits(this.keysCount)}/${toArabicDigits(this.needKeys)})`,
            2600
          );
        }
      }
    } else if (kind === 'lock') {
      const lock = String(ev.lock || '');
      if (lock === 'plankBroken' && !this.locks.plankBroken) {
        this.locks.plankBroken = true;
        this.world.exitPlankMesh.visible = false;
        Snd.lockBreak();
        this.showToast('أزال زميلك اللوح الخشبي عن باب الخروج!', 2400);
      } else if (lock === 'wireCut' && !this.locks.wireCut) {
        this.locks.wireCut = true;
        this.world.exitWireMesh.visible = false;
        Snd.lockBreak();
        this.showToast('قطع زميلك سلك قفل الخروج!', 2400);
      } else if (lock === 'panelOpened' && !this.locks.panelOpened) {
        this.locks.panelOpened = true;
        this.world.exitPanelMesh.visible = false;
        Snd.lockBreak();
        this.showToast('فك زميلك غطاء القفل المعدني!', 2400);
      }
    } else if (kind === 'safe' && !this.safeOpen) {
      this.safeOpen = true;
      Snd.chime();
      this.showToast('فتح زميلك الخزنة!', 2400);
    } else if (kind === 'door' && !this.doorOpen) {
      this.openExit(true);
      this.showToast('فتح زميلك باب الخروج! اهرب الآن!', 3200);
    } else if (kind === 'stun') {
      const dur = Number(ev.dur || 10);
      if (ev.target === 'g') {
        this.G.stun = dur;
      } else {
        this.H.stun = dur;
        this.H.state = 'stunned';
        this.H.v = 0;
        this.H.atk = 0;
      }
      this.showToast('أصاب زميلك الوحش! استغل الفرصة!', 2400);
    } else if (kind === 'revive_noise') {
      const fl = (ev.fl === 1 ? 1 : 0) as 0 | 1;
      const nx = typeof ev.x === 'number' ? ev.x : this.P.x;
      const nz = typeof ev.z === 'number' ? ev.z : this.P.z;
      Snd.bang();
      this.addShake(0.06, 0.14);
      if (!this.mp.room || this.mp.isHost) {
        this.emitNoise(
          fl,
          nx,
          nz,
          75,
          ev.stage === 'start' ? 'ضجيج الإنعاش جذب رجل المطرقة!' : undefined,
          true
        );
      } else if (ev.stage === 'start') {
        this.showToast('ضجيج إنعاش! الوحش يتجه نحو الصوت!', 2200);
      }
    } else if (kind === 'revive') {
      const targetId = String(ev.targetId || '');
      const targetName = String(ev.targetName || '');
      if (this.reviveState && this.reviveState.targetId === targetId) {
        this.reviveState = null;
      }
      if (targetId && targetId === this.mp.selfId) {
        this.dayTok++;
        this.state = 'play';
        this.spectateId = null;
        this.killer = null;
        this.dayFinal = false;
        this.deadTimer = 0;
        this.msgShown = false;
        this.P.hidden = null;
        this.P.crouch = false;
        this.P.trappedTimer = 0;
        this.P.trapProgress = 0;
        this.P.stamina = 1;
        this.P.exhausted = false;
        this.P.roll = 0;
        this.P.pitch = 0;
        this.P.eye = EYE;
        if (typeof ev.x === 'number') this.P.x = ev.x;
        if (typeof ev.z === 'number') this.P.z = ev.z;
        if (ev.fl === 0 || ev.fl === 1) this.P.fl = ev.fl;
        this.updFloor(this.P);
        this.pushOut(this.P, 0.38);
        this.hitFlash = 0.28;
        this.lidOpacity = 0;
        this.mpSendAcc = 1;
        Snd.chime();
        Snd.setAmbientActive(true, 1.0);
        this.lastTime = performance.now();
        this.requestLock();
        this.showToast('تم إنعاشك في مكانك! اهرب — رجل المطرقة قادم نحو الضجيج!', 3400);
      } else if (targetId) {
        const entry = this.remotePeers.get(targetId);
        if (entry) {
          entry.peer.alive = true;
        }
        this.showToast(`تم إنعاش ${targetName || entry?.peer.name || 'زميلك'}!`, 2400);
      }
    }
    this.emitHud();
  }

  // ---------- Escape Cinema ----------
  private startCinema(): void {
    this.state = 'cinema';
    Snd.setAmbientActive(false);
    Snd.setWhisperProximity(0, 0);
    Snd.setThreatTension(0);
    this.exitLock();
    this.world.outdoorGroup.visible = true;
    this.world.outPane.visible = false;
    this.cinema = {
      t: 0,
      fired: {},
      cut: -1,
      caption: '',
      big: false,
      flash: 0,
      bars: true,
    };

    this.H.x = 58.8;
    this.H.z = 32;
    this.H.fl = 0;
    this.H.gy = 0;
    this.H.dx = 1;
    this.H.dz = 0;
    this.H.v = 0;
    this.H.atk = 0;
    this.H.stun = 0;
    this.H.state = 'patrol';
    this.hmRig.group.visible = true;

    const diff = DIFFICULTIES[this.settings.diff];
    if (this.giantOn || !diff.monsters) {
      this.G.x = 30;
      this.G.z = -14;
      this.G.dx = 0;
      this.G.dz = 1;
      this.G.v = 0;
      this.giantRig.group.visible = diff.monsters;
    }

    this.redGlow.intensity = 0;
    this.greenGlow.intensity = 0;
    this.torch.intensity = 0;
    if (this.mistPoints) this.mistPoints.visible = false;
    if (this.dustPoints) this.dustPoints.visible = false;
    (this.scene.fog as THREE.FogExp2).density = 0.004;
    Snd.pad([220, 261.6, 329.6], 5, 0.05);
    this.emitHud();
  }

  private cleanupCinema(): void {
    this.world.outdoorGroup.visible = false;
    this.world.outPane.visible = true;
    this.world.sunLight.intensity = 0;
    if (this.mistPoints) this.mistPoints.visible = true;
    if (this.dustPoints) this.dustPoints.visible = true;
    (this.scene.background as THREE.Color).setHex(0x020202);
    (this.scene.fog as THREE.FogExp2).color.setHex(0x030303);
    this.camera.fov = 74;
    this.camera.updateProjectionMatrix();
    this.cinema.caption = '';
    this.cinema.flash = 0;
    this.cinema.bars = false;
    this.applySettings(this.settings);
  }

  private updateCinema(dt: number): void {
    const C = this.cinema;
    C.t += dt;
    const t = C.t;
    let fov = 74;
    const cp = this.camera.position;
    const cy = 32;

    if (t < 4.5) {
      const u = t / 4.5;
      const k = ease(u);
      cp.set(lerp(57, 74, k), 1.6 + Math.sin(t * 9) * 0.05, cy + Math.sin(t * 4.5) * 0.06);
      this.camera.lookAt(cp.x + 8, 1.5, cy);
      fov = lerp(74, 100, u);
      C.flash = u > 0.7 ? (u - 0.7) / 0.3 : 0;
      if (!C.fired.a) {
        C.fired.a = true;
        Snd.kick(0.5);
      }
      C.caption = u > 0.15 && u < 0.9 ? 'اركض نحو النور — الباب خلفك مفتوح' : '';
      C.big = false;
    } else if (t < 9) {
      const u = (t - 4.5) / 4.5;
      cp.set(lerp(66, 72, u), lerp(0.35, 0.6, u), lerp(36, 34, u));
      this.camera.lookAt(58.6, 1.5, cy);
      fov = lerp(62, 50, u);
      C.flash = Math.max(0, 1 - (t - 4.5) * 2.5);
      if (!C.fired.b) {
        C.fired.b = true;
        Snd.pad([174.6, 220, 261.6], 5, 0.05);
        Snd.tone('sawtooth', 90, 45, 0.14, 1.4);
      }
      if (t > 6.6) {
        this.H.dx = -1;
        this.H.dz = 0;
        this.H.v = Math.min(1.1, (t - 6.6) * 0.8);
        this.H.x -= this.H.v * dt;
      }
      C.caption = 'لم يتمكن من اللحاق بك';
      C.big = false;
    } else if (t < 14.5) {
      const u = (t - 9) / 5.5;
      const k = ease(u);
      cp.set(lerp(74, 100, k), lerp(1.2, 30, k), lerp(32, 18, k));
      this.camera.lookAt(58, lerp(2, 6, k), 30);
      fov = lerp(55, 50, u);
      this.H.v = 0;
      skyAt((t - 9) / 8, this.scene.background as THREE.Color);
      (this.scene.fog as THREE.FogExp2).color.copy(this.scene.background as THREE.Color);
      const sk = ease((t - 9) / 8);
      this.world.sunSprite.position.y = lerp(-10, 45, sk);
      this.world.sunLight.intensity = sk * 1.2;
      this.amb.intensity = 0.7 + sk * 0.9;
      if (!C.fired.c) {
        C.fired.c = true;
        Snd.pad([261.6, 329.6, 392, 523.3], 6, 0.06);
      }
      C.caption = t > 10 ? 'انبلج الفجر' : '';
      C.big = false;
    } else if (t < 20) {
      const uu = (t - 14.5) / 1.1;
      const ci = Math.min(4, Math.floor(uu));
      const u = uu - ci;
      skyAt(0.9, this.scene.background as THREE.Color);
      (this.scene.fog as THREE.FogExp2).color.copy(this.scene.background as THREE.Color);
      this.world.sunSprite.position.y = 45;
      const shots = [
        [100, 22, 8, 94, 18, 6, 30, 6, 28],
        [30, 48, -46, 30, 44, -40, 30, 4, 28],
        [30, 95, 34, 30, 85, 34, 30, 0, 28],
        [66, 2.4, 26, 64, 2, 28, 60, 1.8, cy],
        [-34, 10, 36, -30, 10, 30, 30, 5, 28],
      ];
      const s = shots[ci];
      cp.set(lerp(s[0], s[3], u), lerp(s[1], s[4], u), lerp(s[2], s[5], u));
      this.camera.lookAt(s[6], s[7], s[8]);
      fov = ci === 3 ? 60 : 64;
      if (C.cut !== ci) {
        C.cut = ci;
        Snd.whoosh();
        Snd.kick(0.55);
        C.flash = 0.7;
        const cards = [
          `اليوم ${toArabicDigits(this.day)} من ${toArabicDigits(MAX_DAYS)}`,
          `المفاتيح ${toArabicDigits(this.keysCount)}/${toArabicDigits(this.needKeys)}`,
          `الاختباء ${toArabicDigits(this.stats.hides)} مرة`,
          `المطاردات ${toArabicDigits(this.stats.chases)} مرة`,
          'بيت المطرقة · ٢٧ غرفة',
        ];
        C.caption = cards[ci];
        C.big = false;
      }
      C.flash = Math.max(0, 0.7 - u * 2.2);
    } else {
      const a = 0.6 + (t - 20) * 0.12;
      const kk = Math.min(1, (t - 20) / 8);
      skyAt(1, this.scene.background as THREE.Color);
      (this.scene.fog as THREE.FogExp2).color.copy(this.scene.background as THREE.Color);
      cp.set(30 + Math.cos(a) * 95, lerp(22, 36, kk), 28 + Math.sin(a) * 95);
      this.camera.lookAt(30, 6, 28);
      fov = 52;
      if (!C.fired.d) {
        C.fired.d = true;
        Snd.pad([261.6, 329.6, 392, 523.3, 659.3], 8, 0.07);
        Snd.kick(0.7);
        C.flash = 0.8;
      }
      if (t < 24) {
        C.caption = 'نجوت من بيت المطرقة';
        C.big = true;
      } else if (t < 26.5) {
        C.caption = 'تطوير Asoma Okazi';
        C.big = false;
      } else if (!C.fired.e) {
        C.fired.e = true;
        C.caption = '';
        C.big = false;
        this.state = 'win';
        this.emitHud();
      }
      if (t < 24.5) C.flash = Math.max(0, 0.8 - (t - 20) * 2);
    }

    if (this.camera.fov !== fov) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
    this.animateMonsters(dt);
  }

  private roomAt(x: number, z: number, fl: 0 | 1): string {
    if (x > 60) return 'الخارج';
    const st = this.preset.stairBounds;
    if (x > st.x1 && x < st.x2 && z > st.z1 && z < st.z2) {
      return 'الدرج';
    }
    if (z >= 16 && z <= 24) return fl ? 'الطابق الثاني · الصالة العليا' : 'الممر الطويل';
    for (const r of this.preset.allRooms) {
      if (r.fl === fl && x >= r.x1 && x <= r.x2 && z >= r.z1 && z <= r.z2) {
        return fl ? `الطابق الثاني · ${r.name}` : r.name;
      }
    }
    return '—';
  }

  private emitHud(): void {
    const t = this.state === 'play' ? this.nearTarget() : null;
    let exitArrowAngle: number | null = null;
    let exitArrowText = '';

    const allToolsAndKeysReady =
      this.keysCount >= this.needKeys &&
      this.locks.plankBroken &&
      this.locks.wireCut &&
      this.locks.panelOpened;

    if (allToolsAndKeysReady || this.keysCount >= this.needKeys) {
      const st = this.preset.stairBounds;
      let gx = 60;
      let gz = this.preset.rooms0[8].cz;
      let lab = this.doorOpen ? 'اهرب إلى الخارج' : 'توجه لباب الخروج';
      if (this.P.fl === 1) {
        gx = st.x2;
        gz = (st.z1 + st.z2) / 2;
        lab = 'انزل إلى الطابق الأرضي';
      }
      const tx = gx - this.P.x;
      const tz = gz - this.P.z;
      const sy = Math.sin(this.P.yaw);
      const cy = Math.cos(this.P.yaw);
      exitArrowAngle = Math.atan2(tx * cy - tz * sy, -tx * sy - tz * cy);
      exitArrowText = `${lab} · ${toArabicDigits(Math.round(Math.hypot(tx, tz)))} م`;
    }

    const livesLeft =
      this.state === 'dead' && this.dayFinal
        ? 0
        : Math.max(0, MAX_DAYS - this.day + 1);
    const mpPeers = this.mp.room
      ? this.mp.room.peers.filter((p) => p.id !== this.mp.selfId)
      : [];
    const specEntry =
      this.state === 'spec' && this.spectateId
        ? this.remotePeers.get(this.spectateId)
        : undefined;

    this.onHudUpdate({
      state: this.state === 'dead' && this.dayFinal ? 'dead' : this.state,
      houseTheme: this.world.theme,
      day: this.day,
      maxDays: MAX_DAYS,
      livesLeft,
      roomName: this.roomAt(this.P.x, this.P.z, this.P.fl),
      floor: this.P.fl,
      keys: this.keysCount,
      needKeys: this.needKeys,
      ammo: this.P.ammo,
      hasGun: this.P.hasGun,
      heldItem: this.P.heldItem,
      heldLabel: this.P.heldItem ? ITEM_LABELS[this.P.heldItem] : 'فارغة',
      codeKnown: this.codeKnown,
      safeCode: this.safeCode,
      safeOpen: this.safeOpen,
      locks: { ...this.locks },
      doorOpen: this.doorOpen,
      stamina: this.P.stamina,
      exhausted: this.P.exhausted,
      crouch: this.P.crouch,
      torch: this.P.torch,
      hidden: Boolean(this.P.hidden),
      hiddenKind: this.P.hidden ? this.P.hidden.kind : null,
      trappedTimer: this.P.trappedTimer,
      trapProgress: this.P.trapProgress,
      stalkerState: this.H.state,
      stalkerStunLeft: Math.ceil(this.H.stun),
      threat: this.threat,
      prompt: t ? t.label : '',
      toast: this.toastText,
      toastId: this.toastId,
      exitArrowAngle,
      exitArrowText,
      mapOpen: this.mapOpen,
      notesRead: [...this.notesRead],
      activeNoteId: this.activeNoteId,
      totalNotes: this.world.diaryNotes.length,
      mpConnected: this.mp.connected,
      mpRoomCode: this.mp.room ? this.mp.room.code : null,
      mpIsHost: this.mp.isHost,
      mpPeers,
      mpSpectatingName: specEntry ? specEntry.peer.name : null,
      revivingTargetName: this.reviveState ? this.reviveState.targetName : null,
      revivingTimeLeft: this.reviveState
        ? Math.max(0, this.reviveState.duration - this.reviveState.elapsed)
        : 0,
      revivingProgress: this.reviveState
        ? Math.min(1, this.reviveState.elapsed / this.reviveState.duration)
        : 0,
      playerX: this.P.x,
      playerZ: this.P.z,
      playerYaw: this.P.yaw,
      timeSeconds: this.timeSeconds,
      hidesCount: this.stats.hides,
      chasesCount: this.stats.chases,
      trapsTriggered: this.stats.traps,
      killer: this.dayFinal || this.state === 'dead' ? this.killer : null,
      dayPhase: this.dayPhase,
      dayCross: this.dayCross,
      daySub: this.daySub,
      cinemaCaption: this.cinema.caption,
      cinemaBig: this.cinema.big,
      cinemaFlash: this.cinema.flash,
      cinemaBars: this.cinema.bars,
      lidOpacity: this.lidOpacity,
      hitFlash: this.hitFlash,
      dangerOpacity: Math.min(0.9, this.threat * 0.9),
    });
  }
}
