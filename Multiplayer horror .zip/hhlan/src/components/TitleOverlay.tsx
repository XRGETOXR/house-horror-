import { useState } from 'react';
import { DIFFICULTIES, HOUSE_PRESETS, toArabicDigits } from '../game/constants';
import { DifficultyKey, HouseTheme } from '../game/types';

const GAME_ART_URL = '/assets/aistudio/file_000000007894820a93476de9a2c43a0a_d643db35.png';

interface TitleOverlayProps {
  difficulty: DifficultyKey;
  houseTheme: HouseTheme;
  mpServerLabel: string | null;
  mpPeersCount: number;
  isFullscreen: boolean;
  onSelectDifficulty: (diff: DifficultyKey) => void;
  onSelectHouseTheme: (theme: HouseTheme) => void;
  onStart: () => void;
  onOpenMultiplayer: () => void;
  onOpenSettings: () => void;
  onToggleFullscreen: () => void;
}

const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];
const HOUSE_KEYS: HouseTheme[] = ['manor', 'classic'];

export function TitleOverlay({
  difficulty,
  houseTheme,
  mpServerLabel,
  mpPeersCount,
  isFullscreen,
  onSelectDifficulty,
  onSelectHouseTheme,
  onStart,
  onOpenMultiplayer,
  onOpenSettings,
  onToggleFullscreen,
}: TitleOverlayProps) {
  const [showGuide, setShowGuide] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [downloadNote, setDownloadNote] = useState<string | null>(null);
  const isOfflineFile = typeof window !== 'undefined' && window.location.protocol === 'file:';

  const handleDownloadGame = async () => {
    if (downloading) return;
    setDownloading(true);
    setDownloadNote(null);
    try {
      const res = await fetch('/api/download-offline');
      if (!res.ok) throw new Error('failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HammerHouse-Game.html';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 4000);
      setDownloadNote('تم تنزيل ملف اللعب أوفلاين بنجاح.');
    } catch {
      setDownloadNote('تعذر التنزيل من المعاينة الحالية.');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-20 w-full h-full min-h-[100lvh] flex flex-col justify-between overflow-hidden select-none bg-[#050404]"
      dir="rtl"
    >
      {/* Full-Screen User Cover Artwork blended edge-to-edge */}
      <img
        src={GAME_ART_URL}
        alt="غلاف لعبة بيت المطرقة"
        referrerPolicy="no-referrer"
        className="fixed inset-0 w-full h-full object-cover object-center opacity-75 pointer-events-none"
      />
      <div
        aria-hidden="true"
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            'linear-gradient(180deg, rgba(4,2,2,0.72) 0%, rgba(7,4,4,0.16) 35%, rgba(7,4,4,0.28) 62%, rgba(4,2,2,0.92) 100%)',
        }}
      />

      {/* Compact Top Title Bar (padded inside display cutout / safe areas) */}
      <header className="relative z-10 flex items-start justify-between gap-2 pt-[max(0.45rem,env(safe-area-inset-top))] ps-[max(0.6rem,env(safe-area-inset-left))] pe-[max(0.6rem,env(safe-area-inset-right))] sm:px-5 sm:pt-3">
        <div className="flex items-center gap-2 min-w-0">
          <img
            src={GAME_ART_URL}
            alt="شعار بيت المطرقة"
            referrerPolicy="no-referrer"
            className="w-9 h-9 sm:w-11 sm:h-11 rounded-md object-cover border border-[#e2b34a]/55 shadow-[0_3px_10px_rgba(0,0,0,0.9)] shrink-0"
          />
          <div className="min-w-0">
            <h1 className="font-display text-xl sm:text-3xl leading-none text-[#dc281e] [text-shadow:0_2px_12px_rgba(0,0,0,0.95)]">
              بيت المطرقة
            </h1>
            <p className="text-[9px] sm:text-[11px] text-[#cfc3b4] mt-0.5 truncate">
              ٥ أيام للنجاة · رعب وبقاء
            </p>
            <p className="text-[8px] sm:text-[10px] text-[#e2b34a] mt-0.5 tracking-wide">
              مطور اللعبة: Asoma Okazi
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {!isOfflineFile && (
            <button
              type="button"
              disabled={downloading}
              onClick={handleDownloadGame}
              className="min-h-[30px] sm:min-h-[34px] px-2 py-0.5 rounded bg-black/55 hover:bg-black/75 disabled:opacity-50 border border-[#e2b34a]/35 text-[9px] sm:text-[11px] font-bold text-[#e2b34a] cursor-pointer transition-colors"
            >
              {downloading ? 'جارٍ...' : 'أوفلاين'}
            </button>
          )}
          <button
            type="button"
            onClick={() => setShowGuide((v) => !v)}
            className={`min-h-[30px] sm:min-h-[34px] px-2 py-0.5 rounded border text-[9px] sm:text-[11px] font-bold cursor-pointer transition-colors ${
              showGuide
                ? 'bg-[#2a1710]/90 border-[#e2b34a] text-[#e2b34a]'
                : 'bg-black/55 hover:bg-black/75 border-white/20 text-[#ebe3d6]'
            }`}
          >
            دليل
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[30px] sm:min-h-[34px] px-2 py-0.5 rounded bg-black/55 hover:bg-black/75 border border-white/20 text-[9px] sm:text-[11px] font-bold text-[#ebe3d6] cursor-pointer transition-colors"
          >
            الإعدادات
          </button>
          <button
            type="button"
            data-fs-toggle="true"
            onClick={onToggleFullscreen}
            aria-label={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
            title={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
            className={`min-h-[30px] sm:min-h-[34px] px-2 rounded border text-[10px] sm:text-xs font-bold cursor-pointer flex items-center justify-center gap-1 transition-colors ${
              isFullscreen
                ? 'min-w-[30px] sm:min-w-[34px] bg-black/55 hover:bg-black/75 border-white/25 text-[#ebe3d6]'
                : 'bg-[#2b1810]/90 hover:bg-[#3d2217] border-[#e2b34a]/70 text-[#e2b34a]'
            }`}
          >
            <span>⛶</span>
            {!isFullscreen && <span className="text-[9px] sm:text-[10px]">شاشة كاملة</span>}
          </button>
        </div>
      </header>

      {/* Center Collapsible Guide / Status Toast */}
      <div className="relative z-10 flex-1 flex items-center justify-center px-3 pointer-events-none">
        {downloadNote && !showGuide && (
          <div className="pointer-events-auto text-[10px] text-[#ebe3d6] bg-[rgba(18,28,20,0.92)] border border-[#45b877]/50 rounded px-2.5 py-1">
            {downloadNote}
          </div>
        )}
        {showGuide && (
          <div className="pointer-events-auto w-full max-w-[390px] bg-[rgba(10,6,5,0.93)] border border-[#e2b34a]/35 rounded-lg p-2.5 text-start text-[10px] sm:text-[11px] text-[#ebe3d6] space-y-1 shadow-2xl">
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold text-[#e2b34a]">كيف تهرب من البيت؟</span>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="text-[10px] text-[#a09384] hover:text-white cursor-pointer"
              >
                إغلاق ✕
              </button>
            </div>
            <p className="text-[#cfc3b4] leading-relaxed">
              فتّش الأدراج والخزائن ورفوف الكتب عن المفاتيح، واختبئ داخل خزائن الغرف عند اقتراب الوحش، وفكّ أقفال الخروج: المطرقة ← قاطع الأسلاك (ط٢) ← المفك (خزنة المكتبة).
            </p>
            <p className="text-[#a09384] leading-relaxed">
              الجوال: الدائرة يساراً للحركة · اسحب اليمين للالتفات · زر تفاعل للاختباء والفتح والإنعاش.
            </p>
          </div>
        )}
      </div>

      {/* Compact Mobile-Game Bottom Dock */}
      <footer className="relative z-10 w-full pb-[max(0.5rem,env(safe-area-inset-bottom))] ps-[max(0.6rem,env(safe-area-inset-left))] pe-[max(0.6rem,env(safe-area-inset-right))] sm:px-5 sm:pb-4">
        <div className="mx-auto w-full max-w-[540px] space-y-1.5">
          {/* House + Difficulty Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 sm:gap-1.5">
            <div className="grid grid-cols-2 gap-1">
              {HOUSE_KEYS.map((key) => {
                const hp = HOUSE_PRESETS[key];
                const active = houseTheme === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onSelectHouseTheme(key)}
                    className={`py-1 px-2 rounded border text-start transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#2c1512]/90 border-[#e2b34a] text-[#ebe3d6]'
                        : 'bg-black/60 border-white/15 text-[#b4a797] hover:border-white/30'
                    }`}
                  >
                    <span className="block text-[10px] sm:text-[11px] font-bold truncate leading-tight">
                      {hp.name}
                    </span>
                    <span className="block text-[8px] sm:text-[9px] text-[#a09384] truncate">
                      {key === 'manor' ? 'قصر حجري ومدفأة' : 'خشبي كلاسيكي'}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-5 gap-1">
              {DIFF_KEYS.map((key) => {
                const d = DIFFICULTIES[key];
                const active = difficulty === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => onSelectDifficulty(key)}
                    className={`py-1 px-0.5 rounded border text-center transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#5e0d0a]/95 border-[#d3261d] text-[#ebe3d6]'
                        : 'bg-black/60 border-white/15 text-[#c2b5a6] hover:border-white/30'
                    }`}
                  >
                    <span className="block text-[9px] sm:text-[10px] font-bold leading-tight">
                      {d.name}
                    </span>
                    <span className="block text-[8px] text-[#a09384] font-mono-num">
                      {toArabicDigits(d.keys)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <p className="text-[9px] sm:text-[10px] text-[#b8ab9c] text-center truncate">
            {DIFFICULTIES[difficulty].info}
          </p>

          {/* Compact Play + Multiplayer Action Row */}
          <div className="grid grid-cols-[1.5fr_1fr] gap-1.5">
            <button
              type="button"
              onClick={onStart}
              className="min-h-[40px] sm:min-h-[44px] font-display text-base sm:text-xl py-1 rounded-md bg-[#6b100c] hover:bg-[#851611] border border-[#cf2a22] text-[#ebe3d6] cursor-pointer transition-colors shadow-[0_4px_14px_rgba(179,32,26,0.4)]"
            >
              ابدأ اللعب
            </button>
            <button
              type="button"
              onClick={onOpenMultiplayer}
              className="min-h-[40px] sm:min-h-[44px] px-2 py-1 rounded-md bg-[#1d1511]/92 hover:bg-[#2c201a] border border-[#e2b34a]/55 text-[11px] sm:text-xs font-bold text-[#e2b34a] cursor-pointer transition-colors truncate"
            >
              {mpServerLabel
                ? `${mpServerLabel} (${toArabicDigits(mpPeersCount)})`
                : 'سيرفرات LAN'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
