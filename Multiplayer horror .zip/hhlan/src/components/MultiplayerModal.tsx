import { Capacitor, registerPlugin } from '@capacitor/core';
import { useEffect, useRef, useState } from 'react';
import { DIFFICULTIES, toArabicDigits } from '../game/constants';
import {
  ChatMessage,
  DifficultyKey,
  MultiplayerRoomSnapshot,
  PublicRoomSummary,
} from '../game/types';

interface LanInfoResponse {
  port: number;
  addresses: string[];
  urls: string[];
}

interface MultiplayerModalProps {
  room: MultiplayerRoomSnapshot | null;
  rooms: PublicRoomSummary[];
  selfId: string | null;
  errorMsg: string | null;
  difficulty: DifficultyKey;
  chatMessages: ChatMessage[];
  onSendChat: (text: string) => void;
  onRefreshRooms: () => void;
  onCreateRoom: (name: string, diff: DifficultyKey, serverName?: string) => void;
  onJoinRoom: (code: string, name: string) => void;
  onSetServerUrl: (url: string | null) => void;
  onCreateLanInvite: (name: string, diff: DifficultyKey) => Promise<string>;
  onAcceptLanReply: (replyCode: string) => Promise<void>;
  onJoinLanInvite: (inviteCode: string, name: string) => Promise<string>;
  onChangeDiff: (diff: DifficultyKey) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
  onClose: () => void;
}

const LanServer = registerPlugin<{ start(options: { port: number }): Promise<{ port: number; addresses: string[] }>; discover(): Promise<void>; stop(): Promise<void>; addListener(event: 'serverFound', listener: (data: { name: string; host: string; port: number }) => void): Promise<{ remove(): Promise<void> }> }>('LanServer');

const PEER_COLORS = ['#38a3cc', '#e09132', '#45b877', '#d15a82'];
const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];

function loadSavedName(): string {
  try {
    return localStorage.getItem('hh_name_v2') || '';
  } catch {
    return '';
  }
}

function loadSavedServerUrl(): string {
  try {
    return localStorage.getItem('hh_lan_url_v1') || '';
  } catch {
    return '';
  }
}

export function MultiplayerModal({
  room,
  rooms,
  selfId,
  errorMsg,
  difficulty,
  chatMessages,
  onSendChat,
  onRefreshRooms,
  onCreateRoom,
  onJoinRoom,
  onSetServerUrl,
  onCreateLanInvite,
  onAcceptLanReply,
  onJoinLanInvite,
  onChangeDiff,
  onStartGame,
  onLeaveRoom,
  onClose,
}: MultiplayerModalProps) {
  const isOfflineFile = typeof window !== 'undefined' && window.location.protocol === 'file:';
  const [name, setName] = useState<string>(loadSavedName);
  const [serverNameInput, setServerNameInput] = useState('');
  const [mode, setMode] = useState<'server' | 'hotspot'>('server');
  const [hotspotRole, setHotspotRole] = useState<'host' | 'guest'>('host');

  // Optional advanced / manual code or IP
  const [httpRooms, setHttpRooms] = useState<PublicRoomSummary[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [serverIp, setServerIp] = useState<string>(loadSavedServerUrl);
  const [lanUrls, setLanUrls] = useState<string[]>([]);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Hotspot P2P WebRTC state
  const [hostInviteCode, setHostInviteCode] = useState('');
  const [hostReplyInput, setHostReplyInput] = useState('');
  const [guestInviteInput, setGuestInviteInput] = useState('');
  const [guestReplyCode, setGuestReplyCode] = useState('');
  const [lanBusy, setLanBusy] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [showExtraInvite, setShowExtraInvite] = useState(false);

  // Chat state
  const [chatText, setChatText] = useState('');
  const chatScrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages.length]);

  useEffect(() => {
    if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return;
    let active = true;
    let handle: { remove(): Promise<void> } | null = null;
    // Register the event listener before starting NSD discovery so that fast
    // mDNS responses are not lost on newer Android devices.
    LanServer.addListener('serverFound', (data) => {
      if (!active) return;
      const address = `${data.host}:${data.port}`;
      setLanUrls((current) => current.includes(address) ? current : [...current, address]);
    }).then((h) => {
      handle = h;
      if (active) LanServer.discover().catch(() => {});
      else h.remove().catch(() => {});
    }).catch(() => {});
    return () => { active = false; handle?.remove().catch(() => {}); };
  }, []);

  useEffect(() => {
    if (serverIp.trim()) {
      onSetServerUrl(serverIp.trim());
    }
    // Only apply saved LAN server IP on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (isOfflineFile) return;
    let active = true;

    const loadHttpRooms = () => {
      fetch('/api/rooms')
        .then((res) => (res.ok ? res.json() : null))
        .then((data: { rooms?: PublicRoomSummary[] } | null) => {
          if (active && data && Array.isArray(data.rooms)) {
            setHttpRooms(data.rooms);
          }
        })
        .catch(() => {
          // Ignore HTTP fallback error
        });
    };

    loadHttpRooms();
    const timer = window.setInterval(loadHttpRooms, 4000);

    fetch('/api/lan-info')
      .then((res) => (res.ok ? res.json() : null))
      .then((data: LanInfoResponse | null) => {
        if (active && data && Array.isArray(data.urls)) {
          setLanUrls(data.urls);
        }
      })
      .catch(() => {
        // Ignore if bundled offline
      });

    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [isOfflineFile]);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = chatText.trim();
    if (!clean) return;
    onSendChat(clean);
    setChatText('');
  };

  const isHost = Boolean(room && selfId && room.hostId === selfId);
  const isLanRoom = room?.code === 'LAN';
  const visibleRooms = rooms.length > 0 ? rooms : httpRooms;

  const saveName = (val: string) => {
    setName(val);
    try {
      localStorage.setItem('hh_name_v2', val);
    } catch {
      // ignore
    }
  };

  const applyCustomIp = (val: string) => {
    setServerIp(val);
    try {
      localStorage.setItem('hh_lan_url_v1', val);
    } catch {
      // ignore
    }
    onSetServerUrl(val.trim() || null);
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey((prev) => (prev === key ? null : prev)), 1800);
  };

  const shareText = (title: string, text: string, key: string) => {
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      navigator.share({ title, text }).catch(() => copyText(text, key));
    } else {
      copyText(text, key);
    }
  };

  const handleCreateServer = async () => {
    setLocalError(null);
    const cleanPlayer = name.trim() || 'لاعب ١';
    const customSrv = serverNameInput.trim();
    try {
      // Android APK hosts the WebSocket service inside the app; desktop/web keeps server.ts.
      if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android') {
        await LanServer.start({ port: 3000 });
        // Loopback is only for this hosting session; do not persist it as the
        // default server address or this phone would try localhost next time.
        setServerIp('');
        try { localStorage.removeItem('hh_lan_url_v1'); } catch { /* ignore */ }
        onSetServerUrl('127.0.0.1:3000');
      }
      onCreateRoom(cleanPlayer, difficulty, customSrv || undefined);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'تعذر تشغيل سيرفر LAN على هذا الهاتف');
    }
  };

  const handleJoinListedServer = (code: string) => {
    setLocalError(null);
    onJoinRoom(code, name.trim() || 'لاعب ٢');
  };

  const handleGenerateInvite = async () => {
    setLocalError(null);
    setLanBusy(true);
    try {
      const code = await onCreateLanInvite(name.trim() || 'لاعب ١', difficulty);
      setHostInviteCode(code);
      setHostReplyInput('');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'تعذر إنشاء دعوة نقطة الاتصال');
    } finally {
      setLanBusy(false);
    }
  };

  const handleAcceptReply = async () => {
    const clean = hostReplyInput.trim();
    if (!clean) return;
    setLocalError(null);
    setLanBusy(true);
    try {
      await onAcceptLanReply(clean);
      setHostReplyInput('');
      setHostInviteCode('');
      setShowExtraInvite(false);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'رمز الرد غير صالح');
    } finally {
      setLanBusy(false);
    }
  };

  const handleGuestGenerateReply = async () => {
    const clean = guestInviteInput.trim();
    if (!clean) return;
    setLocalError(null);
    setLanBusy(true);
    try {
      const reply = await onJoinLanInvite(clean, name.trim() || 'لاعب ٢');
      setGuestReplyCode(reply);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'رمز الدعوة غير صالح');
    } finally {
      setLanBusy(false);
    }
  };

  const activeError = localError || errorMsg;
  const activeHostName =
    room?.hostName ||
    room?.peers.find((p) => p.id === room.hostId)?.name ||
    'المضيف';
  const activeServerTitle =
    room?.serverName || (isLanRoom ? 'نقطة اتصال مباشرة (LAN)' : `سيرفر ${activeHostName}`);

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-2.5 sm:p-4 bg-[rgba(2,1,1,0.88)] overflow-y-auto"
      dir="rtl"
    >
      <div className="w-full max-w-[440px] bg-[rgba(14,10,9,0.97)] border border-[rgba(235,227,214,0.2)] rounded-xl p-3.5 sm:p-4 space-y-3 text-[#ebe3d6]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-2">
          <div>
            <h2 className="font-display text-xl sm:text-2xl text-[#e2b34a] leading-none">
              اللعب الجماعي (LAN)
            </h2>
            <p className="text-[10px] sm:text-[11px] text-[#a09384] mt-0.5">
              نظام LAN كلاسيكي عبر Wi-Fi أو نقطة الاتصال، مثل ألعاب الشبكة القديمة
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-2.5 py-1 rounded border border-white/20 text-[11px] text-[#c5b9aa] hover:bg-white/10 cursor-pointer whitespace-nowrap shrink-0"
          >
            إغلاق
          </button>
        </div>

        {activeError && (
          <div className="bg-[#4b0e0b] border border-[#b3201a] text-[#ffdad6] text-[11px] rounded-md px-2.5 py-1.5 text-center">
            {activeError}
          </div>
        )}

        {!room ? (
          <div className="space-y-3">
            {/* Player Name */}
            <div className="space-y-1">
              <label className="block text-[11px] text-[#c5b9aa]" htmlFor="mp-name-input">
                اسمك في اللعب
              </label>
              <input
                id="mp-name-input"
                type="text"
                maxLength={14}
                value={name}
                onChange={(e) => saveName(e.target.value)}
                placeholder="مثال: أحمد"
                className="w-full px-2.5 py-1.5 rounded-md bg-black/50 border border-white/20 text-xs sm:text-sm text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
              />
            </div>

            {/* Classic LAN server browser and direct IP connection */}
            {true ? (
              <div className="space-y-2.5">
                {/* Create Server Card */}
                <div className="bg-black/40 border border-white/10 rounded-lg p-2.5 space-y-2">
                  <input
                    type="text"
                    maxLength={24}
                    value={serverNameInput}
                    onChange={(e) => setServerNameInput(e.target.value)}
                    placeholder={`اسم السيرفر (تلقائياً: سيرفر ${name.trim() || 'لاعب'})`}
                    className="w-full px-2.5 py-1.5 rounded bg-black/60 border border-white/15 text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                  />
                  <button
                    type="button"
                    onClick={handleCreateServer}
                    className="w-full py-2 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] font-display text-lg sm:text-xl text-[#ebe3d6] cursor-pointer transition-colors"
                  >
                    فتح سيرفر جديد
                  </button>
                </div>

                {/* Live Open Servers Browser */}
                <div className="bg-black/40 border border-white/10 rounded-lg p-2.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-[#e2b34a]">
                      السيرفرات المفتوحة ({toArabicDigits(visibleRooms.length)})
                    </span>
                    <button
                      type="button"
                      onClick={onRefreshRooms}
                      className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#ebe3d6] cursor-pointer"
                    >
                      تحديث
                    </button>
                  </div>

                  {visibleRooms.length === 0 ? (
                    <div className="text-[11px] text-[#a09384] text-center py-4 px-2 bg-black/30 rounded border border-white/5">
                      لا توجد سيرفرات مفتوحة حالياً — افتح سيرفراً ليظهر هنا لأصدقائك مباشرة.
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-44 overflow-y-auto pe-0.5">
                      {visibleRooms.map((srv) => {
                        const isFull = srv.playerCount >= srv.maxPlayers;
                        return (
                          <div
                            key={srv.code}
                            className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-md bg-black/55 border border-white/12 hover:border-[#e2b34a]/45 transition-colors"
                          >
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-[#ebe3d6] truncate">
                                {srv.serverName}
                              </div>
                              <div className="text-[10px] text-[#a09384] truncate">
                                صانع السيرفر: <span className="text-[#e2b34a]">{srv.hostName}</span>
                                {' · '}
                                {DIFFICULTIES[srv.diff]?.name || 'متوسط'}
                                {' · '}
                                <span className="font-mono-num">
                                  {toArabicDigits(srv.playerCount)}/{toArabicDigits(srv.maxPlayers)}
                                </span>
                                {srv.phase === 'playing' ? ' · بدأ اللعب' : ' · في الانتظار'}
                              </div>
                            </div>
                            <button
                              type="button"
                              disabled={isFull}
                              onClick={() => handleJoinListedServer(srv.code)}
                              className="px-3 py-1.5 rounded bg-[#2c1512] hover:bg-[#5e0d0a] disabled:opacity-45 border border-[#e2b34a]/50 text-[11px] font-bold text-[#e2b34a] hover:text-white cursor-pointer whitespace-nowrap shrink-0"
                            >
                              {isFull ? 'ممتلئ' : 'دخول'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Collapsible Advanced Options (Manual code / Local Wi-Fi URL / Custom IP) */}
                <div>
                  <button
                    type="button"
                    onClick={() => setShowAdvanced((v) => !v)}
                    className="text-[10px] text-[#a09384] hover:text-[#e2b34a] underline cursor-pointer"
                  >
                    {showAdvanced
                      ? 'إخفاء الخيارات المتقدمة'
                      : 'خيارات متقدمة (رابط Wi-Fi أو اتصال برمز/IP)'}
                  </button>

                  {showAdvanced && (
                    <div className="mt-2 space-y-2 bg-black/45 border border-white/10 rounded-lg p-2.5">
                      {lanUrls.length > 0 && (
                        <div className="space-y-1">
                          <div className="text-[10px] text-[#e2b34a] font-bold">
                            سيرفرات LAN المكتشفة على الشبكة:
                          </div>
                          {lanUrls.map((url) => (
                            <div key={url} className="flex items-center justify-between gap-2">
                              <span dir="ltr" className="font-mono text-[10px] text-[#ebe3d6] truncate">{url}</span>
                              <div className="flex gap-1 shrink-0">
                                <button type="button" onClick={() => { applyCustomIp(url); onRefreshRooms(); }} className="px-2 py-0.5 rounded bg-[#5e0d0a] border border-[#e2b34a]/40 text-[10px] text-[#e2b34a] cursor-pointer">اتصال</button>
                                <button type="button" onClick={() => copyText(url, url)} className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#ebe3d6] cursor-pointer">{copiedKey === url ? 'تم ✓' : 'نسخ'}</button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          maxLength={4}
                          value={joinCode}
                          onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                          placeholder="رمز يدوي"
                          dir="ltr"
                          className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 text-center font-mono text-xs tracking-[0.2em] uppercase text-[#e2b34a] focus:outline-none"
                        />
                        <button
                          type="button"
                          disabled={joinCode.trim().length < 4}
                          onClick={() => handleJoinListedServer(joinCode.trim())}
                          className="px-3 py-1 rounded bg-[#2a221d] disabled:opacity-45 border border-[#e2b34a]/40 text-[11px] font-bold text-[#e2b34a] cursor-pointer"
                        >
                          دخول
                        </button>
                      </div>

                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          dir="ltr"
                          value={serverIp}
                          onChange={(e) => applyCustomIp(e.target.value)}
                          placeholder="IP مخصص (192.168.43.1:3000)"
                          className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[10px] text-[#ebe3d6] focus:outline-none"
                        />
                        {serverIp && (
                          <button
                            type="button"
                            onClick={() => applyCustomIp('')}
                            className="px-2 py-1 rounded bg-white/10 text-[10px] text-[#c5b9aa] cursor-pointer"
                          >
                            افتراضي
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-2.5 bg-black/40 border border-white/10 rounded-lg p-3">
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setLocalError(null);
                      setHotspotRole('host');
                    }}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border cursor-pointer ${
                      hotspotRole === 'host'
                        ? 'bg-[#2a221d] border-[#e2b34a] text-[#e2b34a]'
                        : 'bg-black/40 border-white/15 text-[#c5b9aa]'
                    }`}
                  >
                    أنا المضيف (أنشئ الاتصال)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLocalError(null);
                      setHotspotRole('guest');
                    }}
                    className={`py-1.5 px-2 rounded text-[11px] font-bold border cursor-pointer ${
                      hotspotRole === 'guest'
                        ? 'bg-[#2a221d] border-[#e2b34a] text-[#e2b34a]'
                        : 'bg-black/40 border-white/15 text-[#c5b9aa]'
                    }`}
                  >
                    أنا الضيف (لدي دعوة)
                  </button>
                </div>

                {hotspotRole === 'host' ? (
                  <div className="space-y-2.5">
                    <p className="text-[10px] text-[#c5b9aa] leading-relaxed">
                      ١. اتصلا بنفس نقطة الاتصال (Hotspot). ٢. أنشئ رمز الدعوة وأرسله لصديقك. ٣. ألصق رمز الرد منه للدخول مباشرة.
                    </p>

                    <button
                      type="button"
                      disabled={lanBusy}
                      onClick={handleGenerateInvite}
                      className="w-full py-2 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] disabled:opacity-50 border border-[#b3201a] font-display text-lg text-[#ebe3d6] cursor-pointer"
                    >
                      {lanBusy ? 'جاري تجهيز رمز نقطة الاتصال...' : '١. توليد رمز الدعوة'}
                    </button>

                    {hostInviteCode && (
                      <div className="space-y-1.5 bg-black/55 border border-[#e2b34a]/35 rounded-md p-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[10px] text-[#e2b34a] font-bold">
                            أرسل هذا الرمز لصديقك:
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => copyText(hostInviteCode, 'invite')}
                              className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#ebe3d6] cursor-pointer"
                            >
                              {copiedKey === 'invite' ? 'تم ✓' : 'نسخ'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                shareText('دعوة لعبة بيت المطرقة LAN', hostInviteCode, 'invite')
                              }
                              className="px-2 py-0.5 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[10px] text-[#e2b34a] cursor-pointer"
                            >
                              مشاركة
                            </button>
                          </div>
                        </div>
                        <textarea
                          readOnly
                          rows={2}
                          dir="ltr"
                          value={hostInviteCode}
                          onFocus={(e) => e.currentTarget.select()}
                          className="w-full px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px] text-[#ebe3d6] resize-none"
                        />
                      </div>
                    )}

                    <div className="space-y-1 pt-1 border-t border-white/10">
                      <label className="block text-[10px] text-[#c5b9aa]">
                        ٢. ألصق رمز الرد من هاتف صديقك:
                      </label>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          dir="ltr"
                          value={hostReplyInput}
                          onChange={(e) => setHostReplyInput(e.target.value)}
                          placeholder="LANZ:..."
                          className="flex-1 px-2 py-1.5 rounded-md bg-black/60 border border-white/20 font-mono text-xs text-[#e2b34a] focus:outline-none focus:border-[#e2b34a]"
                        />
                        <button
                          type="button"
                          disabled={lanBusy || !hostReplyInput.trim()}
                          onClick={handleAcceptReply}
                          className="px-3 py-1.5 rounded-md bg-[#2a221d] hover:bg-[#3a2f28] disabled:opacity-45 border border-[#e2b34a]/50 text-xs font-bold text-[#e2b34a] cursor-pointer"
                        >
                          اتصال
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <p className="text-[10px] text-[#c5b9aa] leading-relaxed">
                      ١. ألصق رمز الدعوة من المضيف. ٢. اضغط «توليد رمز الرد» وأرسله إليه لتدخلا اللعب معاً.
                    </p>

                    <div className="space-y-1">
                      <label className="block text-[10px] text-[#c5b9aa]">
                        ١. رمز الدعوة من المضيف:
                      </label>
                      <textarea
                        rows={2}
                        dir="ltr"
                        value={guestInviteInput}
                        onChange={(e) => setGuestInviteInput(e.target.value)}
                        placeholder="LANZ:..."
                        className="w-full px-2 py-1.5 rounded-md bg-black/60 border border-white/20 font-mono text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a] resize-none"
                      />
                    </div>

                    <button
                      type="button"
                      disabled={lanBusy || !guestInviteInput.trim()}
                      onClick={handleGuestGenerateReply}
                      className="w-full py-2 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] disabled:opacity-45 border border-[#b3201a] font-display text-lg text-[#ebe3d6] cursor-pointer"
                    >
                      {lanBusy ? 'جاري إنشاء الرد...' : '٢. توليد رمز الرد للمضيف'}
                    </button>

                    {guestReplyCode && (
                      <div className="space-y-1.5 bg-black/55 border border-[#e2b34a]/35 rounded-md p-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-[10px] text-[#e2b34a] font-bold">
                            أرسل الرد للمضيف (بانتظار التأكيد...):
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => copyText(guestReplyCode, 'reply')}
                              className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#ebe3d6] cursor-pointer"
                            >
                              {copiedKey === 'reply' ? 'تم ✓' : 'نسخ'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                shareText('رد الاتصال - بيت المطرقة LAN', guestReplyCode, 'reply')
                              }
                              className="px-2 py-0.5 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[10px] text-[#e2b34a] cursor-pointer"
                            >
                              مشاركة
                            </button>
                          </div>
                        </div>
                        <textarea
                          readOnly
                          rows={2}
                          dir="ltr"
                          value={guestReplyCode}
                          onFocus={(e) => e.currentTarget.select()}
                          className="w-full px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px] text-[#ebe3d6] resize-none"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {/* Server Banner */}
            <div className="bg-black/50 border border-[#e2b34a]/35 rounded-lg p-2.5 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-bold text-[#e2b34a] truncate">
                  {activeServerTitle}
                </div>
                <div className="text-[10px] text-[#c5b9aa] mt-0.5 truncate">
                  صانع السيرفر: <span className="font-bold text-[#ebe3d6]">{activeHostName}</span>
                  {!isLanRoom && (
                    <span className="text-[#a09384] ms-2 font-mono">({room.code})</span>
                  )}
                </div>
              </div>
              {isLanRoom && isHost ? (
                <button
                  type="button"
                  onClick={() => setShowExtraInvite((v) => !v)}
                  className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 border border-white/20 text-[10px] text-[#ebe3d6] cursor-pointer whitespace-nowrap shrink-0"
                >
                  {showExtraInvite ? 'إغلاق الدعوة' : '+ دعوة لاعب'}
                </button>
              ) : null}
            </div>

            {isLanRoom && isHost && showExtraInvite && (
              <div className="bg-black/45 border border-white/15 rounded-lg p-2.5 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#e2b34a]">إضافة لاعب آخر</span>
                  <button
                    type="button"
                    disabled={lanBusy}
                    onClick={handleGenerateInvite}
                    className="px-2 py-0.5 rounded bg-[#5e0d0a] border border-[#b3201a] text-[10px] text-[#ebe3d6] cursor-pointer"
                  >
                    {lanBusy ? 'جاري الإنشاء...' : 'توليد دعوة'}
                  </button>
                </div>
                {hostInviteCode && (
                  <div className="flex gap-1.5">
                    <input
                      readOnly
                      dir="ltr"
                      value={hostInviteCode}
                      onFocus={(e) => e.currentTarget.select()}
                      className="flex-1 px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px]"
                    />
                    <button
                      type="button"
                      onClick={() => copyText(hostInviteCode, 'extraInvite')}
                      className="px-2 py-1 rounded bg-white/10 text-[10px] cursor-pointer"
                    >
                      {copiedKey === 'extraInvite' ? '✓' : 'نسخ'}
                    </button>
                  </div>
                )}
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    dir="ltr"
                    value={hostReplyInput}
                    onChange={(e) => setHostReplyInput(e.target.value)}
                    placeholder="ألصق رمز الرد هنا..."
                    className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[10px]"
                  />
                  <button
                    type="button"
                    disabled={lanBusy || !hostReplyInput.trim()}
                    onClick={handleAcceptReply}
                    className="px-2.5 py-1 rounded bg-[#2a221d] border border-[#e2b34a]/50 text-[10px] text-[#e2b34a] cursor-pointer"
                  >
                    تأكيد
                  </button>
                </div>
              </div>
            )}

            {/* Connected Players List */}
            <div className="space-y-1">
              <div className="text-[11px] text-[#c5b9aa] font-bold">
                اللاعبون في السيرفر ({toArabicDigits(room.peers.length)}/٤)
              </div>
              <div className="space-y-1 max-h-32 overflow-y-auto">
                {room.peers.map((p) => {
                  const color = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
                  const isYou = p.id === selfId;
                  const isRoomHost = p.id === room.hostId;
                  return (
                    <div
                      key={p.id}
                      className="flex items-center justify-between px-2.5 py-1.5 rounded-md bg-white/5 border border-white/10 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-sm shrink-0 border border-white/40"
                          style={{ backgroundColor: color }}
                        />
                        <span className="font-bold text-[#ebe3d6]">{p.name}</span>
                        {isYou && (
                          <span className="text-[10px] px-1 py-0.5 rounded bg-white/10 text-[#c5b9aa]">
                            أنت
                          </span>
                        )}
                        {isRoomHost && (
                          <span className="text-[10px] px-1 py-0.5 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[#e2b34a]">
                            صانع السيرفر
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-[#45b877]">متصل</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Difficulty Selection (Host controls it) */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] text-[#c5b9aa]">
                <span>مستوى الصعوبة:</span>
                <span className="text-[#e2b34a] font-bold">{DIFFICULTIES[room.diff].name}</span>
              </div>
              {isHost && (
                <div className="grid grid-cols-5 gap-1">
                  {DIFF_KEYS.map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => onChangeDiff(k)}
                      className={`py-1 rounded text-[10px] border cursor-pointer ${
                        room.diff === k
                          ? 'bg-[#5e0d0a] border-[#b3201a] text-white font-bold'
                          : 'bg-black/40 border-white/15 text-[#c5b9aa] hover:border-white/30'
                      }`}
                    >
                      {DIFFICULTIES[k].name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Lobby Chat */}
            <div className="bg-black/45 border border-white/10 rounded-lg p-2 space-y-1.5">
              <div className="text-[10px] text-[#a09384] font-bold">دردشة السيرفر</div>
              <div
                ref={chatScrollRef}
                className="h-20 overflow-y-auto space-y-1 text-[11px] pe-1"
              >
                {chatMessages.length === 0 ? (
                  <div className="text-[#a09384]/70 text-center py-4">
                    ابدأ المحادثة قبل دخول البيت...
                  </div>
                ) : (
                  chatMessages.map((m) => {
                    const color = PEER_COLORS[Math.abs(m.colorIndex) % PEER_COLORS.length];
                    return (
                      <div key={m.id} className="leading-snug break-words">
                        {m.system ? (
                          <span className="text-[#a09384] italic">{m.text}</span>
                        ) : (
                          <>
                            <span className="font-bold me-1.5" style={{ color }}>
                              {m.senderName}:
                            </span>
                            <span className="text-[#ebe3d6]">{m.text}</span>
                          </>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
              <form onSubmit={handleChatSubmit} className="flex gap-1.5">
                <input
                  type="text"
                  maxLength={160}
                  value={chatText}
                  onChange={(e) => setChatText(e.target.value)}
                  placeholder="اكتب رسالة..."
                  className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 text-[11px] text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[11px] font-bold text-[#ebe3d6] cursor-pointer"
                >
                  إرسال
                </button>
              </form>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1.5 pt-0.5">
              {isHost ? (
                <button
                  type="button"
                  onClick={onStartGame}
                  className="flex-1 py-2 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] font-display text-lg sm:text-xl text-[#ebe3d6] cursor-pointer"
                >
                  ابدأ اللعب الجماعي
                </button>
              ) : (
                <div className="flex-1 py-2 text-center text-[11px] text-[#e2b34a] bg-black/40 border border-[#e2b34a]/25 rounded-md">
                  في انتظار {activeHostName} لبدء اللعب...
                </div>
              )}
              <button
                type="button"
                onClick={() => {
                  setHostInviteCode('');
                  setGuestReplyCode('');
                  onLeaveRoom();
                }}
                className="px-3 py-2 rounded-md border border-white/20 text-[11px] text-[#c5b9aa] hover:bg-white/10 cursor-pointer"
              >
                مغادرة
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
