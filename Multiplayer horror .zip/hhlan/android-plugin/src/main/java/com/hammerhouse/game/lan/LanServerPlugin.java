package com.hammerhouse.game.lan;

import android.util.Log;
import android.content.Context;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.java_websocket.WebSocket;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@CapacitorPlugin(name = "LanServer")
public class LanServerPlugin extends Plugin {
  private LocalLanServer server;
  private NsdManager nsd;
  private NsdManager.RegistrationListener registrationListener;
  private NsdManager.DiscoveryListener discoveryListener;

  @PluginMethod public void start(PluginCall call) {
    int port = call.getInt("port", 3000);
    try {
      if (server != null) server.stop();
      server = new LocalLanServer(port);
      server.start();
      if (!server.awaitStarted(2500)) throw new IllegalStateException("انتهت مهلة تشغيل السيرفر");
      nsd = (NsdManager) getContext().getSystemService(Context.NSD_SERVICE);
      NsdServiceInfo service = new NsdServiceInfo();
      service.setServiceName("HammerHouse-" + android.os.Build.MODEL.replaceAll("[^A-Za-z0-9_-]", ""));
      service.setServiceType("_hammerhouse._tcp.");
      service.setPort(port);
      registrationListener = new NsdManager.RegistrationListener() {
        public void onServiceRegistered(NsdServiceInfo info) { Log.i("LanServer", "NSD registered " + info.getServiceName()); }
        public void onRegistrationFailed(NsdServiceInfo info, int error) { Log.w("LanServer", "NSD registration failed " + error); }
        public void onServiceUnregistered(NsdServiceInfo info) {}
        public void onUnregistrationFailed(NsdServiceInfo info, int error) {}
      };
      nsd.registerService(service, NsdManager.PROTOCOL_DNS_SD, registrationListener);
      JSONObject out = new JSONObject();
      out.put("port", port);
      JSONArray ips = new JSONArray();
      Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
      while (interfaces.hasMoreElements()) {
        NetworkInterface ni = interfaces.nextElement();
        for (InetAddress a : Collections.list(ni.getInetAddresses())) {
          if (!a.isLoopbackAddress() && a instanceof java.net.Inet4Address) ips.put(a.getHostAddress());
        }
      }
      out.put("addresses", ips);
      call.resolve(out);
    } catch (Exception e) { call.reject("تعذر تشغيل سيرفر LAN: " + e.getMessage(), e); }
  }

  @PluginMethod public void discover(PluginCall call) {
    try {
      if (nsd == null) nsd = (NsdManager) getContext().getSystemService(Context.NSD_SERVICE);
      if (discoveryListener != null) { try { nsd.stopServiceDiscovery(discoveryListener); } catch (Exception ignored) {} }
      discoveryListener = new NsdManager.DiscoveryListener() {
        public void onDiscoveryStarted(String type) {}
        public void onDiscoveryStopped(String type) {}
        public void onStartDiscoveryFailed(String type, int error) { try { com.getcapacitor.JSObject data = new com.getcapacitor.JSObject(); data.put("code", error); notifyListeners("discoveryError", data); } catch (Exception ignored) {} }
        public void onStopDiscoveryFailed(String type, int error) {}
        public void onServiceLost(NsdServiceInfo info) {}
        public void onServiceFound(NsdServiceInfo info) {
          if (!"_hammerhouse._tcp.".equals(info.getServiceType())) return;
          nsd.resolveService(info, new NsdManager.ResolveListener() {
            public void onResolveFailed(NsdServiceInfo service, int error) {}
            public void onServiceResolved(NsdServiceInfo service) {
              try {
                com.getcapacitor.JSObject data = new com.getcapacitor.JSObject();
                data.put("name", service.getServiceName()); data.put("host", service.getHost().getHostAddress()); data.put("port", service.getPort());
                notifyListeners("serverFound", data);
              } catch (Exception ignored) {}
            }
          });
        }
      };
      nsd.discoverServices("_hammerhouse._tcp.", NsdManager.PROTOCOL_DNS_SD, discoveryListener);
      call.resolve();
    } catch (Exception e) { call.reject("تعذر البحث عن سيرفرات LAN: " + e.getMessage(), e); }
  }

  @PluginMethod public void stop(PluginCall call) {
    try {
      if (discoveryListener != null && nsd != null) { try { nsd.stopServiceDiscovery(discoveryListener); } catch (Exception ignored) {} discoveryListener = null; }
      if (registrationListener != null && nsd != null) { try { nsd.unregisterService(registrationListener); } catch (Exception ignored) {} registrationListener = null; }
      if (server != null) { server.stop(); server = null; } call.resolve(); }
    catch (Exception e) { call.reject(e.getMessage(), e); }
  }

  private static class Peer {
    WebSocket socket; JSONObject state;
    Peer(WebSocket s, JSONObject st) { socket=s; state=st; }
  }
  private static class Room {
    String code, serverName, hostId, phase="lobby", diff;
    JSONObject world; LinkedHashMap<String,Peer> peers=new LinkedHashMap<>(); JSONArray messages=new JSONArray();
  }

  private static class LocalLanServer extends org.java_websocket.server.WebSocketServer {
    Map<String,Room> rooms = new LinkedHashMap<>(); Map<WebSocket,String> clients=new LinkedHashMap<>(); int counter=1;
    private final java.util.concurrent.CountDownLatch started = new java.util.concurrent.CountDownLatch(1);
    boolean awaitStarted(long ms) throws InterruptedException { return started.await(ms, java.util.concurrent.TimeUnit.MILLISECONDS); }
    LocalLanServer(int port) { super(new java.net.InetSocketAddress("0.0.0.0", port)); setReuseAddr(true); }
    JSONObject obj(Object... kv) throws Exception { JSONObject o=new JSONObject(); for(int i=0;i<kv.length;i+=2)o.put((String)kv[i],kv[i+1]); return o; }
    void send(WebSocket c, JSONObject o) { if(c!=null && c.isOpen()) c.send(o.toString()); }
    JSONObject initialWorld(String diff) throws Exception { return obj("roundId",System.currentTimeMillis(),"diff",diff,"safeCode",100+(int)(Math.random()*900),"keySeed",(long)(Math.random()*4294967295L),"giantRoll",Math.random(),"searchedSpots",new JSONArray(),"plankBroken",false,"wireCut",false,"panelOpened",false,"safeOpen",false,"doorOpen",false,"takenTorches",new JSONArray()); }
    JSONObject state(String id,String name,int color) throws Exception { return obj("id",id,"name",name,"colorIndex",color,"x",4.8,"y",0,"z",3.8,"yaw",-Math.PI/2,"fl",0,"crouch",false,"torch",false,"hiddenIdx",-1,"heldItem",JSONObject.NULL,"alive",true,"escaped",false,"day",1,"speed",0); }
    String hostName(Room r) { Peer p=r.peers.get(r.hostId); return p==null?"المضيف":p.state.optString("name","المضيف"); }
    JSONObject snapshot(Room r) throws Exception { JSONArray ps=new JSONArray(); for(Peer p:r.peers.values()) ps.put(p.state); return obj("code",r.code,"serverName",r.serverName,"hostName",hostName(r),"hostId",r.hostId,"phase",r.phase,"diff",r.diff,"world",r.world,"peers",ps,"messages",r.messages); }
    JSONArray roomList() throws Exception { JSONArray a=new JSONArray(); for(Room r:rooms.values()) a.put(obj("code",r.code,"serverName",r.serverName,"hostName",hostName(r),"diff",r.diff,"phase",r.phase,"playerCount",r.peers.size(),"maxPlayers",4,"createdAt",System.currentTimeMillis())); return a; }
    void broadcast(Room r,JSONObject o, String except) { for(Map.Entry<String,Peer> e:r.peers.entrySet()) if(!e.getKey().equals(except)) send(e.getValue().socket,o); }
    void roomsList() throws Exception { JSONObject o=obj("type","rooms:list","rooms",roomList()); for(WebSocket c:getConnections())send(c,o); }
    void leave(WebSocket c) throws Exception { String id=clients.get(c); if(id==null)return; Room found=null; for(Room r:rooms.values())if(r.peers.containsKey(id)){found=r;break;} if(found!=null){ Room r=found; r.peers.remove(id); if(r.peers.isEmpty())rooms.remove(r.code); else { if(r.hostId.equals(id))r.hostId=r.peers.keySet().iterator().next(); broadcast(r,obj("type","room:update","room",snapshot(r)),null); } } roomsList(); }
    @Override public void onOpen(WebSocket c, org.java_websocket.handshake.ClientHandshake h) { try { clients.put(c,"p_"+(counter++)+"_"+UUID.randomUUID().toString().substring(0,4)); send(c,obj("type","rooms:list","rooms",roomList())); } catch(Exception e){Log.e("LanServer", "open",e);} }
    @Override public void onMessage(WebSocket c,String raw) { try { JSONObject m=new JSONObject(raw); String type=m.optString("type"); String id=clients.get(c); Room r=null; for(Room x:rooms.values())if(x.peers.containsKey(id)){r=x;break;}
      if(type.equals("rooms:list")){send(c,obj("type","rooms:list","rooms",roomList()));return;}
      if(type.equals("room:create")){leave(c); id=clients.get(c); String diff=m.optString("diff","med"); if(!diff.matches("practice|easy|med|hard|nightmare"))diff="med"; String name=m.optString("name","لاعب").trim(); if(name.isEmpty())name="لاعب"; Room nr=new Room(); nr.code=UUID.randomUUID().toString().substring(0,4).toUpperCase(); nr.diff=diff; nr.serverName=m.optString("serverName","سيرفر "+name); nr.hostId=id; nr.world=initialWorld(diff); nr.peers.put(id,new Peer(c,state(id,name,0))); rooms.put(nr.code,nr); send(c,obj("type","room:joined","selfId",id,"room",snapshot(nr))); roomsList(); return; }
      if(type.equals("room:join")){String code=m.optString("code").trim().toUpperCase(); r=rooms.get(code); if(r==null){send(c,obj("type","room:error","message","السيرفر لم يعد متاحاً"));return;} if(r.peers.size()>=4){send(c,obj("type","room:error","message","السيرفر ممتلئ"));return;} leave(c); id=clients.get(c); int color=r.peers.size()%4; r.peers.put(id,new Peer(c,state(id,m.optString("name","لاعب"),color))); send(c,obj("type","room:joined","selfId",id,"room",snapshot(r))); broadcast(r,obj("type","room:update","room",snapshot(r)),id); roomsList(); return; }
      if(type.equals("room:leave")){leave(c);send(c,obj("type","room:left"));return;} if(r==null)return;
      if(type.equals("room:diff")&&id.equals(r.hostId)){r.diff=m.optString("diff",r.diff);broadcast(r,obj("type","room:update","room",snapshot(r)),null);return;}
      if(type.equals("game:start")&&id.equals(r.hostId)){r.phase="playing";r.diff=m.optString("diff",r.diff);r.world=initialWorld(r.diff);broadcast(r,obj("type","game:started","room",snapshot(r)),null);return;}
      if(type.equals("player:state")){Peer p=r.peers.get(id); String[] keys={"x","y","z","yaw","fl","crouch","torch","hiddenIdx","heldItem","alive","escaped","day","speed"}; for(String k:keys)if(m.has(k))p.state.put(k,m.get(k)); broadcast(r,obj("type","peer:state","peer",p.state),id);return;}
      if(type.equals("monsters:state")&&id.equals(r.hostId)){broadcast(r,obj("type","monsters:state","data",m.optJSONObject("data")),id);return;}
      if(type.equals("world:event")){JSONObject ev=m.optJSONObject("event"); if(ev==null)return; String kind=ev.optString("kind"); if(kind.equals("safe"))r.world.put("safeOpen",true); if(kind.equals("door"))r.world.put("doorOpen",true); if(kind.equals("lock")){String lock=ev.optString("lock");if(lock.equals("plankBroken")||lock.equals("wireCut")||lock.equals("panelOpened"))r.world.put(lock,true);} broadcast(r,obj("type","world:event","fromId",id,"event",ev,"world",r.world),id);return;}
      if(type.equals("chat:send")){Peer p=r.peers.get(id);String txt=m.optString("text").trim();if(txt.isEmpty())return;JSONObject chat=obj("id","m_"+counter++,"senderId",id,"senderName",p.state.optString("name"),"colorIndex",p.state.optInt("colorIndex"),"text",txt.substring(0,Math.min(160,txt.length())),"ts",System.currentTimeMillis());r.messages.put(chat);broadcast(r,obj("type","chat:message","message",chat),null);}
    } catch(Exception e){Log.e("LanServer","message",e);} }
    @Override public void onClose(WebSocket c,int code,String reason,boolean remote){try{leave(c);}catch(Exception ignored){} clients.remove(c);}
    @Override public void onError(WebSocket c,Exception e){Log.e("LanServer","socket",e);}
    @Override public void onStart(){Log.i("LanServer","LAN server started on "+getPort()); started.countDown();}
  }
}
