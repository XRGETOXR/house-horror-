(function(){
'use strict';
var $=function(id){return document.getElementById(id);};
var cv=$('view'), panel=$('panel');
function fail(msg){panel.innerHTML='<p class="lead">'+msg+'</p>';}
if(!window.THREE){fail('تعذّر تحميل محرّك الرسوم ثلاثية الأبعاد. تحقق من الاتصال ثم أعد تحميل الصفحة.');return;}
var THREE=window.THREE, renderer;
try{renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true});}catch(err){fail('متصفحك أو جهازك لا يدعم WebGL المطلوب لتشغيل اللعبة.');return;}
var S={name:'',gfx:'med',sens:1,vol:0.75,bright:1,diff:'med'};
try{var _s=JSON.parse(localStorage.getItem('hh_set')||'null');if(_s)for(var _k in _s)if(_k in S)S[_k]=_s[_k];}catch(e){}
function saveS(){try{localStorage.setItem('hh_set',JSON.stringify(S));}catch(e){}}
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.25));

/* ---------- constants ---------- */
var WALL_H=3.3, HALL_H=7.1, FY=7.1, T=0.3, DOOR_W=2.8, EYE=1.65, EYE_C=1.05, PR=0.38;

/* ---------- scene ---------- */
var scene=new THREE.Scene();
scene.background=new THREE.Color(0x020202);
scene.fog=new THREE.FogExp2(0x030303,0.05);
var camera=new THREE.PerspectiveCamera(74,1,0.08,140);
camera.rotation.order='YXZ';
scene.add(camera);
var amb=new THREE.AmbientLight(0x4a4a5c,0.7);scene.add(amb);
var TORCH_I=1.9;
var torch=new THREE.SpotLight(0xffeccc,TORCH_I,32,0.56,0.5,1.2);
camera.add(torch); torch.position.set(0.12,-0.1,0);
camera.add(torch.target); torch.target.position.set(0,0,-3);
var redGlow=new THREE.PointLight(0xff2a1a,0.9,9,2); scene.add(redGlow);
var greenGlow=new THREE.PointLight(0x7cff9a,0.6,13,2); scene.add(greenGlow);

function applyGfx(){
  var dpr=window.devicePixelRatio||1,q=S.gfx;
  renderer.setPixelRatio(q==='low'?Math.min(dpr,0.75):(q==='high'?Math.min(dpr,2):Math.min(dpr,1.25)));
  scene.fog.density=q==='low'?0.075:(q==='high'?0.042:0.052);
  camera.far=q==='low'?45:140;camera.updateProjectionMatrix();
  amb.intensity=0.7*S.bright;resize();
}
function resize(){
  var w=cv.clientWidth||window.innerWidth, h=cv.clientHeight||window.innerHeight;
  renderer.setSize(w,h,false); camera.aspect=w/h; camera.updateProjectionMatrix();
  if(hcam){hcam.aspect=w/h;hcam.updateProjectionMatrix();}
}
window.addEventListener('resize',resize); resize();

/* ---------- procedural textures ---------- */
function cnv(w,h){var c=document.createElement('canvas');c.width=w;c.height=h;return c;}
function R(a,b){return a+Math.random()*(b-a);}
function toTex(c,rx,ry){var t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;if(rx)t.repeat.set(rx,ry);t.anisotropy=4;return t;}
function speckle(g,w,h,n,tpl,smax){for(var i=0;i<n;i++){g.fillStyle=tpl.replace('A',(Math.random()*0.5).toFixed(2));var s=R(1,smax||3);g.fillRect(Math.random()*w,Math.random()*h,s,s);}}
function wallCanvas(){
  var c=cnv(256,256),g=c.getContext('2d'),i;
  g.fillStyle='#6b5a4c';g.fillRect(0,0,256,256);
  for(var x=0;x<256;x+=32){g.fillStyle='rgba(255,235,210,0.06)';g.fillRect(x,0,16,256);}
  for(var y=12;y<256;y+=40){for(var x2=16;x2<256;x2+=32){g.fillStyle='rgba(0,0,0,0.12)';g.beginPath();g.arc(x2,y+(((x2/32)|0)%2?10:0),3,0,6.3);g.fill();}}
  for(i=0;i<6;i++){var gx=R(0,256),gy=R(0,200),gr=g.createRadialGradient(gx,gy,2,gx,gy,R(20,55));gr.addColorStop(0,'rgba(40,25,10,0.4)');gr.addColorStop(1,'rgba(40,25,10,0)');g.fillStyle=gr;g.fillRect(0,0,256,256);}
  var mold=g.createLinearGradient(0,150,0,256);mold.addColorStop(0,'rgba(0,0,0,0)');mold.addColorStop(1,'rgba(0,0,0,0.5)');g.fillStyle=mold;g.fillRect(0,150,256,106);
  speckle(g,256,256,900,'rgba(0,0,0,A)',2);
  return c;
}
function floorCanvas(){
  var c=cnv(256,256),g=c.getContext('2d'),cols=['#5a3d27','#4d3321','#63452d','#563a25'];
  for(var r=0;r<8;r++){
    g.fillStyle=cols[r%4];g.fillRect(0,r*32,256,32);
    g.fillStyle='rgba(0,0,0,0.55)';g.fillRect(0,r*32,256,2);
    var j=R(30,226);g.fillRect(j,r*32,2,32);
    for(var k=0;k<5;k++){g.strokeStyle='rgba(0,0,0,0.18)';g.beginPath();g.moveTo(0,r*32+R(4,28));g.lineTo(256,r*32+R(4,28));g.stroke();}
  }
  speckle(g,256,256,700,'rgba(0,0,0,A)',2);
  return c;
}
function ceilCanvas(){
  var c=cnv(128,128),g=c.getContext('2d');g.fillStyle='#3b3430';g.fillRect(0,0,128,128);
  speckle(g,128,128,400,'rgba(0,0,0,A)',2);
  var gr=g.createRadialGradient(64,64,2,64,64,50);gr.addColorStop(0,'rgba(20,10,0,0.45)');gr.addColorStop(1,'rgba(20,10,0,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);
  return c;
}
function bloodCanvas(){
  var c=cnv(256,256),g=c.getContext('2d'),i;
  g.fillStyle='rgba(105,8,8,0.92)';
  for(i=0;i<14;i++){g.beginPath();g.ellipse(128+R(-60,60),128+R(-60,60),R(6,26),R(5,22),R(0,3),0,6.3);g.fill();}
  for(i=0;i<40;i++){var a=R(0,6.28),d=R(40,120);g.beginPath();g.arc(128+Math.cos(a)*d,128+Math.sin(a)*d,R(1.5,6),0,6.3);g.fill();}
  g.strokeStyle='rgba(90,6,6,0.85)';g.lineWidth=R(6,14);g.lineCap='round';g.beginPath();g.moveTo(128,128);g.quadraticCurveTo(R(60,200),R(60,200),R(20,236),R(20,236));g.stroke();
  return c;
}
function clothCanvas(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#3a312c';g.fillRect(0,0,128,128);
  for(i=0;i<16;i++){g.fillStyle='rgba(135,16,14,'+R(0.5,0.9).toFixed(2)+')';g.beginPath();g.arc(R(0,128),R(0,128),R(4,20),0,6.3);g.fill();}
  g.strokeStyle='rgba(120,12,10,0.8)';g.lineWidth=3;for(i=0;i<8;i++){var x=R(0,128);g.beginPath();g.moveTo(x,R(0,30));g.lineTo(x+R(-4,4),R(70,128));g.stroke();}
  speckle(g,128,128,200,'rgba(0,0,0,A)',2);
  return c;
}
function faceCanvas(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#b3a99b';g.fillRect(0,0,128,128);
  g.strokeStyle='rgba(140,14,12,0.9)';g.lineCap='round';
  for(i=0;i<9;i++){g.lineWidth=R(3,9);var x=R(0,128);g.beginPath();g.moveTo(x,R(0,40));g.lineTo(x+R(-8,8),R(60,128));g.stroke();}
  for(i=0;i<12;i++){g.fillStyle='rgba(120,10,10,0.8)';g.beginPath();g.arc(R(0,128),R(0,128),R(2,9),0,6.3);g.fill();}
  return c;
}
function closetCanvas(){
  var c=cnv(128,256),g=c.getContext('2d');
  g.fillStyle='#4a3322';g.fillRect(0,0,128,256);
  g.strokeStyle='rgba(0,0,0,0.6)';g.lineWidth=3;g.strokeRect(8,10,52,236);g.strokeRect(68,10,52,236);
  g.fillStyle='rgba(0,0,0,0.75)';for(var i=0;i<5;i++){g.fillRect(16,26+i*9,36,3);g.fillRect(76,26+i*9,36,3);}
  g.fillStyle='#8a7a55';g.fillRect(54,120,4,16);g.fillRect(70,120,4,16);
  speckle(g,128,256,300,'rgba(0,0,0,A)',2);
  return c;
}
function crateCanvas(){
  var c=cnv(128,128),g=c.getContext('2d');
  g.fillStyle='#6b4e2e';g.fillRect(0,0,128,128);
  for(var i=0;i<8;i++){g.fillStyle=i%2?'rgba(0,0,0,0.12)':'rgba(255,220,160,0.06)';g.fillRect(0,i*16,128,16);g.fillStyle='rgba(0,0,0,0.5)';g.fillRect(0,i*16,128,2);}
  g.strokeStyle='rgba(30,18,8,0.9)';g.lineWidth=10;g.strokeRect(5,5,118,118);
  g.lineWidth=8;g.beginPath();g.moveTo(8,8);g.lineTo(120,120);g.moveTo(120,8);g.lineTo(8,120);g.stroke();
  speckle(g,128,128,300,'rgba(0,0,0,A)',2);
  return c;
}
function glowCanvas(){
  var c=cnv(64,64),g=c.getContext('2d'),gr=g.createRadialGradient(32,32,1,32,32,31);
  gr.addColorStop(0,'rgba(255,220,120,0.9)');gr.addColorStop(1,'rgba(255,200,80,0)');g.fillStyle=gr;g.fillRect(0,0,64,64);
  return c;
}
function textTex(txt,font,col){
  var c=cnv(512,160),g=c.getContext('2d');
  g.font=font;g.fillStyle=col;g.textAlign='center';g.textBaseline='middle';g.shadowColor=col;g.shadowBlur=10;
  try{g.direction='rtl';}catch(e){}
  g.fillText(txt,256,84);
  return new THREE.CanvasTexture(c);
}

var TEX={};
function makeTextures(){
  TEX.wall=toTex(wallCanvas(),1,1);
  TEX.floor=toTex(floorCanvas(),30,28);
  TEX.ceil=toTex(ceilCanvas(),1,1);
  TEX.blood=toTex(bloodCanvas(),1,1);
  TEX.cloth=toTex(clothCanvas(),1,1);
  TEX.face=toTex(faceCanvas(),1,1);
  TEX.closet=toTex(closetCanvas(),1,1);
  TEX.crate=toTex(crateCanvas(),1,1);
  TEX.glow=new THREE.CanvasTexture(glowCanvas());
}

/* ---------- geometry helpers & colliders ---------- */
var FL=[{co:[],bl:[],g:new THREE.Group()},{co:[],bl:[],g:new THREE.Group()}];
FL[1].g.position.y=FY;scene.add(FL[0].g);scene.add(FL[1].g);
var colliders=FL[0].co, blockers=FL[0].bl, CURG=FL[0].g, CUR=0, wallMatCache={};
function setBuild(f){CUR=f;colliders=FL[f].co;blockers=FL[f].bl;CURG=FL[f].g;}
function wallMat(len,h){
  var k=Math.round(len*2)+'_'+Math.round(h*2);
  if(!wallMatCache[k]){
    var t=TEX.wall.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;
    t.repeat.set(Math.max(1,len/3),Math.max(1,h/3));
    wallMatCache[k]=new THREE.MeshPhongMaterial({map:t,shininess:4,specular:0x111111});
  }
  return wallMatCache[k];
}
function wallSeg(ax,fixed,a,b,h){
  var len=b-a; if(len<0.02)return;
  var cx,cz,w,d;
  if(ax==='x'){cx=(a+b)/2;cz=fixed;w=len;d=T;}else{cx=fixed;cz=(a+b)/2;w=T;d=len;}
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),wallMat(len,h));
  m.position.set(cx,h/2,cz);CURG.add(m);
  var box={x1:cx-w/2,x2:cx+w/2,z1:cz-d/2,z2:cz+d/2};
  colliders.push(box);blockers.push(box);
}
function wallDoors(ax,fixed,from,to,doors,h){
  var pts=doors.slice().sort(function(p,q){return p-q;}),cur=from-T/2;
  pts.forEach(function(c){
    var a=c-DOOR_W/2,b=c+DOOR_W/2;
    wallSeg(ax,fixed,cur,a,h);
    if(h>2.8){
      var lh=h-2.8,lm=new THREE.Mesh(new THREE.BoxGeometry(ax==='x'?DOOR_W:T,lh,ax==='x'?T:DOOR_W),wallMat(DOOR_W,lh));
      lm.position.set(ax==='x'?c:fixed,2.8+lh/2,ax==='x'?fixed:c);CURG.add(lm);
    }
    cur=b;
  });
  wallSeg(ax,fixed,cur,to+T/2,h);
}
function matP(col,sh){return new THREE.MeshPhongMaterial({color:col,shininess:sh||5,specular:0x111111});}
function F(x,z,w,d,h,col,o){
  o=o||{};
  var mat=o.map?new THREE.MeshPhongMaterial({map:o.map,shininess:5}):matP(col);
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
  m.position.set(x,(o.y||0)+h/2,z);CURG.add(m);
  var b={x1:x-w/2,x2:x+w/2,z1:z-d/2,z2:z+d/2};
  if(!o.nocol){colliders.push(b);if(h>=1.8)blockers.push(b);}
  return {mesh:m,box:b};
}
function deco(x,y,z,w,h,d,col){
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),matP(col));
  m.position.set(x,y+h/2,z);CURG.add(m);return m;
}
function planeAt(w,d,x,y,z,rx,mat){
  var m=new THREE.Mesh(new THREE.PlaneGeometry(w,d),mat);
  m.rotation.x=rx;m.position.set(x,y,z);CURG.add(m);return m;
}
function addText(txt,x,y,z,ry,w,h,col,basic){
  var t=textTex(txt,'bold 96px Lalezar, Tajawal, sans-serif',col);
  var mat=basic?new THREE.MeshBasicMaterial({map:t,transparent:true,depthWrite:false}):
    new THREE.MeshPhongMaterial({map:t,transparent:true,depthWrite:false,shininess:1});
  var m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),mat);
  m.position.set(x,y,z);m.rotation.y=ry;CURG.add(m);return m;
}

/* ---------- house plan ---------- */
var ROOMS=[
  {id:'bed',name:'غرفة النوم',x1:0,z1:0,x2:14,z2:16},
  {id:'kit',name:'المطبخ',x1:14,z1:0,x2:28,z2:16},
  {id:'lib',name:'المكتبة',x1:28,z1:0,x2:42,z2:16},
  {id:'bath',name:'الحمّام',x1:42,z1:0,x2:52,z2:16},
  {id:'stor',name:'المخزن',x1:52,z1:0,x2:60,z2:16},
  {id:'liv',name:'غرفة المعيشة',x1:0,z1:24,x2:18,z2:40},
  {id:'din',name:'غرفة الطعام',x1:18,z1:24,x2:34,z2:40},
  {id:'nur',name:'غرفة الأطفال',x1:34,z1:24,x2:46,z2:40},
  {id:'exit',name:'قاعة الخروج',x1:46,z1:24,x2:60,z2:40},
  {id:'laun',name:'غرفة الغسيل',x1:0,z1:40,x2:20,z2:56},
  {id:'stu',name:'المرسم',x1:20,z1:40,x2:40,z2:56},
  {id:'cell',name:'القبو',x1:40,z1:40,x2:60,z2:56}
];
var ROOM={};
ROOMS.forEach(function(r){r.cx=(r.x1+r.x2)/2;r.cz=(r.z1+r.z2)/2;r.fl=0;ROOM[r.id]=r;});
var closets=[], keyItems=[], exitDoor=null, exitDoorPivot=null, exitBox=null;

var doors=[], NEWDOORS=[10,31,52];
var doorMat=null, brassMat=null;
function addDoor(ax,fixed,c){
  if(!doorMat){doorMat=matP(0x4a3322,6);brassMat=new THREE.MeshPhongMaterial({color:0xb58a3a,shininess:60,specular:0xffffff});}
  var w=DOOR_W-0.06,piv=new THREE.Group(),hinge=c-DOOR_W/2+0.03;
  if(ax==='x')piv.position.set(hinge,0,fixed);else piv.position.set(fixed,0,hinge);
  var leaf=new THREE.Mesh(new THREE.BoxGeometry(ax==='x'?w:0.12,2.78,ax==='x'?0.12:w),doorMat);
  leaf.position.set(ax==='x'?w/2:0,1.39,ax==='x'?0:w/2);piv.add(leaf);
  var kn=new THREE.Mesh(new THREE.SphereGeometry(0.07,8,8),brassMat);
  kn.position.set(ax==='x'?w-0.25:0,1.05,ax==='x'?0:w-0.25);
  var kb=kn.clone();
  if(ax==='x'){kn.position.z=0.09;kb.position.z=-0.09;}else{kn.position.x=0.09;kb.position.x=-0.09;}
  piv.add(kn);piv.add(kb);CURG.add(piv);
  var box=ax==='x'?{x1:c-DOOR_W/2,x2:c+DOOR_W/2,z1:fixed-0.07,z2:fixed+0.07}:{x1:fixed-0.07,x2:fixed+0.07,z1:c-DOOR_W/2,z2:c+DOOR_W/2};
  colliders.push(box);blockers.push(box);
  doors.push({fl:CUR,ax:ax,fixed:fixed,c:c,piv:piv,box:box,ang:0,target:0,side:1,solid:true,cx:ax==='x'?c:fixed,cz:ax==='x'?fixed:c});
}
function buildWalls(){
  var north=ROOMS.slice(0,5).map(function(r){return r.cx;});
  var south=ROOMS.slice(5,9).map(function(r){return r.cx;});
  wallDoors('x',16,0,60,north,HALL_H);
  wallDoors('x',24,0,60,south,HALL_H);
  wallSeg('z',0,16-T/2,24+T/2,HALL_H);
  wallSeg('z',60,16-T/2,24+T/2,HALL_H);
  wallDoors('x',0,0,60,[],WALL_H);
  wallDoors('x',40,0,60,NEWDOORS,WALL_H);
  wallDoors('x',56,0,60,[],WALL_H);
  wallDoors('z',0,0,16,[],WALL_H);
  wallDoors('z',0,24,56,[],WALL_H);
  wallDoors('z',60,0,16,[],WALL_H);
  wallDoors('z',60,24,56,[ROOM.exit.cz],WALL_H);
  [14,28,42,52].forEach(function(x){wallDoors('z',x,0,16,[8],WALL_H);addDoor('z',x,8);});
  [18,34,46].forEach(function(x){wallDoors('z',x,24,40,[32],WALL_H);addDoor('z',x,32);});
  [20,40].forEach(function(x){wallDoors('z',x,40,56,[48],WALL_H);addDoor('z',x,48);});
  north.forEach(function(c){addDoor('x',16,c);});
  south.forEach(function(c){addDoor('x',24,c);});
  NEWDOORS.forEach(function(c){addDoor('x',40,c);});
}
function buildShell(){
  setBuild(0);
  var fm=new THREE.MeshPhongMaterial({map:TEX.floor,shininess:6,specular:0x222222});
  planeAt(60,56,30,0,28,-Math.PI/2,fm);
  ROOMS.forEach(function(r){
    var t=TEX.ceil.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set((r.x2-r.x1)/3,(r.z2-r.z1)/3);
    planeAt(r.x2-r.x1,r.z2-r.z1,r.cx,WALL_H,r.cz,Math.PI/2,new THREE.MeshPhongMaterial({map:t,shininess:1}));
  });
  planeAt(56,2.4,30,0.012,20,-Math.PI/2,new THREE.MeshPhongMaterial({color:0x4a1210,shininess:2}));
}

function C(x,z,w,d,room){
  var o=F(x,z,w,d,2.3,0,{map:TEX.closet});
  var r=ROOM[room],ex=x,ez=z,rdx=r.cx-x,rdz=r.cz-z;
  if(Math.abs(rdx)>Math.abs(rdz))ex=x+(rdx>0?1:-1)*(w/2+0.9);else ez=z+(rdz>0?1:-1)*(d/2+0.9);
  closets.push({x:x,z:z,w:w,d:d,box:o.box,exit:{x:ex,z:ez},room:room,kind:'closet',eye:1.5,fl:CUR});
}
function CR(x,z,room){
  var o=F(x,z,1.5,1.5,1.5,0,{map:TEX.crate});
  var r=ROOM[room],ex=x,ez=z,rdx=r.cx-x,rdz=r.cz-z;
  if(Math.abs(rdx)>Math.abs(rdz))ex=x+(rdx>0?1:-1)*1.65;else ez=z+(rdz>0?1:-1)*1.65;
  closets.push({x:x,z:z,w:1.5,d:1.5,box:o.box,exit:{x:ex,z:ez},room:room,kind:'crate',eye:0.95,fl:CUR});
}
function buildKey(x,y,z){
  var g=new THREE.Group(),m=new THREE.MeshPhongMaterial({color:0xe2b34a,emissive:0x6b4a10,shininess:70,specular:0xffffff});
  var ring=new THREE.Mesh(new THREE.TorusGeometry(0.11,0.035,8,16),m);ring.position.y=0.2;g.add(ring);
  var shaft=new THREE.Mesh(new THREE.BoxGeometry(0.06,0.38,0.05),m);shaft.position.y=-0.05;g.add(shaft);
  var t1=new THREE.Mesh(new THREE.BoxGeometry(0.14,0.05,0.05),m);t1.position.set(0.07,-0.17,0);g.add(t1);
  var t2=new THREE.Mesh(new THREE.BoxGeometry(0.1,0.05,0.05),m);t2.position.set(0.05,-0.07,0);g.add(t2);
  var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));
  sp.scale.set(1.1,1.1,1);g.add(sp);
  g.scale.set(1.3,1.3,1.3);g.position.set(x,y,z);CURG.add(g);
  keyItems.push({obj:g,x:x,z:z,y:y,taken:false});
}
function buildFurniture(){
  /* غرفة النوم */
  F(2.4,3.6,2.4,3.4,0.7,0x4a3b38);deco(2.4,0.7,2.4,2.2,0.18,0.7,0x6a5a52);deco(2.4,0.7,4.6,2.2,0.08,2.0,0x5a2220);
  F(5.0,0.8,0.9,0.9,0.6,0x3b2a1e);F(1.2,13.4,1.2,2.4,1.0,0x3b2a1e);F(12.2,13.2,0.8,0.8,0.9,0x4a3322);
  C(11.5,0.9,2.0,1.1,'bed');
  /* المطبخ */
  F(19,0.7,6,1.2,1.0,0x555048);F(25,4,2.2,1.6,0.9,0x4a3a2a);F(27.2,12.5,1.2,1.2,2.0,0x8a8a84);
  deco(24.2,0.9,3.6,0.4,0.4,0.4,0x606060);C(15.2,13.5,1.2,2.0,'kit');
  /* المكتبة */
  F(31.5,0.7,5,0.6,2.6,0x2e2016);F(38.5,0.7,5,0.6,2.6,0x2e2016);
  F(40.2,11.5,2.4,1.2,0.85,0x4a3322);F(30.5,4,0.9,0.9,0.9,0x5a2a2a);
  C(29.2,13.6,1.2,2.0,'lib');
  /* الحمّام */
  F(44.5,1.0,2.2,1.0,0.7,0x9a9a92);deco(44.5,0.7,1.0,2.0,0.1,0.8,0x5a0d0d);
  F(50.6,0.8,0.7,0.8,0.5,0xa8a8a0);F(48.4,0.5,1.0,0.6,0.9,0x9a9a92);C(43.2,13.8,1.0,1.8,'bath');
  /* المخزن */
  F(59.2,3.5,0.8,4,2.2,0x3a2a1c);F(53.4,13.5,1.0,1.0,1.0,0x6a5030);F(54.6,13.8,1.0,1.0,1.0,0x5a4228);
  F(58.5,13.5,0.9,0.9,1.0,0x3a3a3a);
  /* غرفة المعيشة */
  F(1.2,27,1.0,2.6,0.8,0x3a2a30);F(14,39.4,2.4,0.8,0.9,0x2a2a2a);F(4,38.8,0.8,0.6,2.2,0x3b2a1e);
  F(13.5,27.5,2.0,1.4,0.7,0x4a3322);C(17.3,37.5,1.0,2.0,'liv');
  /* غرفة الطعام */
  F(26,37,5,1.6,0.9,0x4a3322);F(32.8,26,0.8,3.0,2.0,0x3b2a1e);F(23.4,35.6,0.5,0.5,0.9,0x3a2a1c);F(28.6,35.6,0.5,0.5,0.9,0x3a2a1c);
  C(19.3,37.5,0.9,1.8,'din');
  /* غرفة الأطفال */
  F(36.5,38,1.2,2.0,1.0,0x7a6a5a);
  F(44.5,26.5,1.2,0.8,0.6,0x5a3a2a);F(43.5,37,0.8,0.9,0.9,0x4a3322);C(35.0,26.5,1.2,2.0,'nur');
  /* قاعة الخروج */
  F(55.5,27,0.9,0.9,3.3,0x4a4640);F(55.5,37,0.9,0.9,3.3,0x4a4640);F(48,26.5,1.2,1.2,1.0,0x4a3a2a);
  C(47.1,37.8,1.0,2.0,'exit');
  /* صناديق كبيرة للاختباء */
  CR(12.9,14.6,'bed');CR(16.2,3.5,'kit');CR(40.6,3.6,'lib');CR(50.6,13.6,'bath');CR(55.0,2.4,'stor');
  CR(1.6,35.0,'liv');CR(20.2,26.5,'din');CR(44.8,38.6,'nur');CR(58.5,26.5,'exit');
  /* غرفة الغسيل */
  F(1.8,42.2,1.6,1.4,1.0,0xb0b0a8);F(4.2,42.2,1.6,1.4,1.0,0xa8a8a0);F(2.0,53.8,2.6,1.4,0.9,0x5a4a3a);F(17.6,54.2,2.0,1.2,0.9,0x6a6a66);
  C(18.8,42.5,1.0,2.0,'laun');CR(14.5,52.5,'laun');deco(8.0,0,53.6,0.9,0.5,0.9,0x6a5a40);
  /* المرسم */
  F(23.5,42,0.6,3,2.0,0x3a2a1c);F(36,53.5,3,1.2,0.9,0x4a3a2a);F(21.5,53.8,1.0,1.0,1.0,0x5a4a3a);
  C(38.8,42.6,1.0,2.0,'stu');CR(25.5,54,'stu');deco(30,0,54.2,0.12,1.9,0.12,0x2a1c10);deco(30,1.0,54.2,1.0,0.8,0.08,0x6a5a4a);
  /* القبو */
  F(58.3,42.2,1.0,1.0,1.1,0x3a3a3a);F(55,41.8,0.9,0.9,1.1,0x3a3a3a);F(56.8,53.8,1.4,1.4,1.0,0x6a5030);
  F(44,54.2,2.2,1.2,1.0,0x5a4228);C(41.2,42.6,1.0,2.0,'cell');CR(58.6,50.5,'cell');
  /* الباب الحديدي */
  exitDoorPivot=new THREE.Group();exitDoorPivot.position.set(60,0,ROOM.exit.cz-DOOR_W/2+0.02);
  var dm=new THREE.Mesh(new THREE.BoxGeometry(0.22,2.78,DOOR_W-0.05),new THREE.MeshPhongMaterial({color:0x2a2c30,shininess:30,specular:0x555555}));
  dm.position.set(0,1.39,(DOOR_W-0.05)/2);exitDoorPivot.add(dm);
  var bar=new THREE.Mesh(new THREE.BoxGeometry(0.3,0.16,DOOR_W-0.1),new THREE.MeshPhongMaterial({color:0x5a1010}));
  bar.position.set(-0.05,1.4,(DOOR_W-0.05)/2);exitDoorPivot.add(bar);
  CURG.add(exitDoorPivot);
  exitBox={x1:59.8,x2:60.2,z1:ROOM.exit.cz-DOOR_W/2,z2:ROOM.exit.cz+DOOR_W/2,door:true};
  colliders.push(exitBox);blockers.push(exitBox);
  var out=outPane=new THREE.Mesh(new THREE.PlaneGeometry(14,8),new THREE.MeshBasicMaterial({color:0x8fa4b8}));
  out.position.set(64,3,ROOM.exit.cz);out.rotation.y=-Math.PI/2;CURG.add(out);
  planeAt(14,14,67,0.01,ROOM.exit.cz,-Math.PI/2,new THREE.MeshBasicMaterial({color:0x56626e}));
}
function buildDecor(){
  var bm=new THREE.MeshPhongMaterial({map:TEX.blood,transparent:true,depthWrite:false,shininess:30,specular:0x331111,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  function splat(x,z,s){var m=new THREE.Mesh(new THREE.PlaneGeometry(s,s),bm);m.rotation.x=-Math.PI/2;m.rotation.z=R(0,6.28);m.position.set(x,0.02,z);CURG.add(m);}
  ROOMS.forEach(function(r){for(var i=0;i<4;i++)splat(R(r.x1+1.5,r.x2-1.5),R(r.z1+1.5,r.z2-1.5),R(1.2,3));});
  for(var j=0;j<9;j++)splat(R(4,56),R(17.2,22.8),R(1.5,3.4));
  addText('اهرب',15,2.4,16.19,0,3.6,1.12,'#8d0f0c');
  addText('لا تنظر خلفك',45,2.4,23.81,Math.PI,4.4,1.38,'#8d0f0c');
  addText('ابقَ هادئًا',0.19,1.9,8,Math.PI/2,3.2,1.0,'#8d0f0c');
  addText('هو يسمعك',40,2.2,39.81,Math.PI,3.2,1.0,'#8d0f0c');
  addText('ثلاثة مفاتيح',48.4,2.4,39.81,Math.PI,3.2,1.0,'#8d0f0c');
  addText('مخرج',59.83,3.05,ROOM.exit.cz,-Math.PI/2,1.5,0.47,'#46ff82',true);
}

/* ---------- navigation graph (hammer man) ---------- */
var nodes=[], roomNode={};
function addNode(x,z,fl){nodes.push({x:x,z:z,fl:fl,adj:[]});return nodes.length-1;}
function link(a,b){var d=Math.hypot(nodes[a].x-nodes[b].x,nodes[a].z-nodes[b].z);nodes[a].adj.push({n:b,d:d});nodes[b].adj.push({n:a,d:d});}
function hallChain(xs,fl){
  xs=xs.slice().sort(function(a,b){return a-b;});
  var map={},prev=-1;
  xs.forEach(function(x){var n=addNode(x,20,fl);map[x]=n;if(prev>=0)link(prev,n);prev=n;});
  return map;
}
function seqLink(ids){for(var i=0;i<ids.length-1;i++)link(roomNode[ids[i]],roomNode[ids[i+1]]);}
function buildGraph(){
  ROOMS.concat(ROOMS2).forEach(function(r){roomNode[r.id]=addNode(r.cx,r.cz,r.fl);});
  var main=ROOMS.slice(0,9),m0=hallChain(main.map(function(r){return r.cx;}),0);
  main.forEach(function(r){link(roomNode[r.id],m0[r.cx]);});
  seqLink(['bed','kit','lib','bath','stor']);seqLink(['liv','din','nur','exit']);seqLink(['laun','stu','cell']);
  [['liv','laun',10],['din','stu',31],['exit','cell',52]].forEach(function(p){
    var d=addNode(p[2],40,0);link(roomNode[p[0]],d);link(d,roomNode[p[1]]);
  });
  var nx=ROOMS2.slice(0,6).map(function(r){return r.cx;}),m1=hallChain(nx.concat([6,30,42,54]),1);
  ROOMS2.slice(0,6).forEach(function(r){link(roomNode[r.id],m1[r.cx]);});
  [['a0',6],['a2',30],['a3',42],['a4',54]].forEach(function(p){link(roomNode[p[0]],m1[p[1]]);});
  seqLink(['n0','n1','n2','n3','n4','n5']);seqLink(['a0','a1','a2','a3','a4']);seqLink(['b0','b1','b2','b3']);
  [['a0','b0',7.5],['a1','b1',22.5],['a3','b2',37.5],['a4','b3',52.5]].forEach(function(p){
    var d=addNode(p[2],40,1);link(roomNode[p[0]],d);link(d,roomNode[p[1]]);
  });
  var sb=addNode(9.6,22.6,0),st=addNode(25.6,22.6,1);
  link(sb,m0[9]);link(st,m1[30]);link(st,m1[25]);link(sb,st);
}
function route(a,b){
  var n=nodes.length,dist=[],prev=[],done=[],i;
  for(i=0;i<n;i++){dist[i]=1e9;prev[i]=-1;done[i]=false;}
  dist[a]=0;
  for(var it=0;it<n;it++){
    var u=-1,best=1e9;
    for(i=0;i<n;i++)if(!done[i]&&dist[i]<best){best=dist[i];u=i;}
    if(u<0||u===b)break;
    done[u]=true;
    for(var k=0;k<nodes[u].adj.length;k++){var e=nodes[u].adj[k],nd=dist[u]+e.d;if(nd<dist[e.n]){dist[e.n]=nd;prev[e.n]=u;}}
  }
  var path=[],c=b;
  if(prev[c]===-1&&c!==a)return [a];
  while(c!==-1){path.unshift(c);c=prev[c];}
  return path;
}

/* ---------- collision / line of sight ---------- */
function pushOut(p,r){
  var colliders=FL[p.fl||0].co;
  for(var pass=0;pass<2;pass++){
    for(var i=0;i<colliders.length;i++){
      var b=colliders[i],cx=Math.max(b.x1,Math.min(p.x,b.x2)),cz=Math.max(b.z1,Math.min(p.z,b.z2));
      var dx=p.x-cx,dz=p.z-cz,d2=dx*dx+dz*dz;
      if(d2<r*r){
        if(d2>1e-8){var d=Math.sqrt(d2),k=(r-d)/d;p.x+=dx*k;p.z+=dz*k;}
        else{
          var l=p.x-b.x1,rr=b.x2-p.x,t=p.z-b.z1,bt=b.z2-p.z,m=Math.min(l,rr,t,bt);
          if(m===l)p.x=b.x1-r;else if(m===rr)p.x=b.x2+r;else if(m===t)p.z=b.z1-r;else p.z=b.z2+r;
        }
      }
    }
  }
}
function segHits(ax,az,bx,bz,b){
  var dx=bx-ax,dz=bz-az,t0=0,t1=1,p=[-dx,dx,-dz,dz],q=[ax-b.x1,b.x2-ax,az-b.z1,b.z2-az];
  for(var i=0;i<4;i++){
    if(p[i]===0){if(q[i]<0)return false;}
    else{var t=q[i]/p[i];if(p[i]<0){if(t>t1)return false;if(t>t0)t0=t;}else{if(t<t0)return false;if(t<t1)t1=t;}}
  }
  return true;
}
function blocked(ax,az,bx,bz,fl){var blockers=FL[fl||0].bl;for(var i=0;i<blockers.length;i++)if(segHits(ax,az,bx,bz,blockers[i]))return true;return false;}
function nearestNode(x,z,fl){
  var best=-1,bd=1e9,bv=-1,bvd=1e9;
  for(var i=0;i<nodes.length;i++){
    if(nodes[i].fl!==fl)continue;
    var d=Math.hypot(nodes[i].x-x,nodes[i].z-z);
    if(d<bd){bd=d;best=i;}
    if(d<bvd&&!blocked(x,z,nodes[i].x,nodes[i].z,fl)){bvd=d;bv=i;}
  }
  return bv>=0?bv:best;
}
function distBox(x,z,b){var dx=Math.max(b.x1-x,0,x-b.x2),dz=Math.max(b.z1-z,0,z-b.z2);return Math.hypot(dx,dz);}

/* ---------- second floor, stairs, key spots ---------- */
var ROOMS2=[], STAIR={x1:10.8,x2:24.4,z1:21.55,z2:23.65};
(function(){
  ['غرفة الضيوف','المكتب','غرفة الملابس','غرفة الألعاب','غرفة الصلاة','الشرفة المغلقة'].forEach(function(n,i){ROOMS2.push({id:'n'+i,name:n,x1:i*10,z1:0,x2:i*10+10,z2:16});});
  ['غرفة الخادمة','المكتبة العليا','غرفة الضيوف الثانية','المعمل القديم','الغرفة الحمراء'].forEach(function(n,i){ROOMS2.push({id:'a'+i,name:n,x1:i*12,z1:24,x2:i*12+12,z2:40});});
  ['العلّية','غرفة الأرشيف','غرفة الدمى','غرفة المرايا'].forEach(function(n,i){ROOMS2.push({id:'b'+i,name:n,x1:i*15,z1:40,x2:i*15+15,z2:56});});
  ROOMS2.forEach(function(r){r.fl=1;r.cx=(r.x1+r.x2)/2;r.cz=(r.z1+r.z2)/2;ROOM[r.id]=r;});
})();

function freeAt(x,z,hw,hd,m){
  var co=FL[CUR].co;
  for(var i=0;i<co.length;i++){
    var b=co[i];
    if(x+hw+m>b.x1&&x-hw-m<b.x2&&z+hd+m>b.z1&&z-hd-m<b.z2)return false;
  }
  return true;
}
function floorPiece(x1,z1,x2,z2){
  if(x2-x1<0.05||z2-z1<0.05)return;
  var t=TEX.floor.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set((x2-x1)/2,(z2-z1)/2);
  var m=new THREE.Mesh(new THREE.PlaneGeometry(x2-x1,z2-z1),new THREE.MeshPhongMaterial({map:t,shininess:6,specular:0x222222,side:THREE.DoubleSide}));
  m.rotation.x=-Math.PI/2;m.position.set((x1+x2)/2,0,(z1+z2)/2);CURG.add(m);
}
function buildFloor2(){
  setBuild(1);
  var s=STAIR;
  floorPiece(0,0,60,s.z1);floorPiece(0,s.z2,60,56);floorPiece(0,s.z1,s.x1,s.z2);floorPiece(s.x2,s.z1,60,s.z2);
  ROOMS2.forEach(function(r){
    var t=TEX.ceil.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set((r.x2-r.x1)/3,(r.z2-r.z1)/3);
    planeAt(r.x2-r.x1,r.z2-r.z1,r.cx,WALL_H,r.cz,Math.PI/2,new THREE.MeshPhongMaterial({map:t,shininess:1}));
  });
  var ht=TEX.ceil.clone();ht.needsUpdate=true;ht.wrapS=ht.wrapT=THREE.RepeatWrapping;ht.repeat.set(20,3);
  planeAt(60,8,30,HALL_H,20,Math.PI/2,new THREE.MeshPhongMaterial({map:ht,shininess:1}));
  var nd=ROOMS2.slice(0,6).map(function(r){return r.cx;}),ad=[6,30,42,54],bd=[7.5,22.5,37.5,52.5];
  wallDoors('x',16,0,60,nd,HALL_H);wallDoors('x',24,0,60,ad,HALL_H);
  wallSeg('z',0,16-T/2,24+T/2,HALL_H);wallSeg('z',60,16-T/2,24+T/2,HALL_H);
  wallDoors('x',0,0,60,[],WALL_H);wallDoors('x',40,0,60,bd,WALL_H);wallDoors('x',56,0,60,[],WALL_H);
  wallDoors('z',0,0,16,[],WALL_H);wallDoors('z',0,24,56,[],WALL_H);
  wallDoors('z',60,0,16,[],WALL_H);wallDoors('z',60,24,56,[],WALL_H);
  [10,20,30,40,50].forEach(function(x){wallDoors('z',x,0,16,[8],WALL_H);addDoor('z',x,8);});
  [12,24,36,48].forEach(function(x){wallDoors('z',x,24,40,[32],WALL_H);addDoor('z',x,32);});
  [15,30,45].forEach(function(x){wallDoors('z',x,40,56,[48],WALL_H);addDoor('z',x,48);});
  nd.forEach(function(c){addDoor('x',16,c);});
  ad.forEach(function(c){addDoor('x',24,c);});
  bd.forEach(function(c){addDoor('x',40,c);});
  /* حواجز فتحة الدرج في الطابق الثاني */
  box1(s.x1,s.x2,s.z1-0.15,s.z1);box1(s.x1,s.x2,s.z2,s.z2+0.2);box1(s.x1-0.15,s.x1,s.z1-0.15,s.z2+0.2);
  var rail=matP(0x2e2016,8);
  [[0.5],[1.0]].forEach(function(h){
    var a=new THREE.Mesh(new THREE.BoxGeometry(s.x2-s.x1,0.07,0.07),rail);a.position.set((s.x1+s.x2)/2,h[0],s.z1-0.07);CURG.add(a);
    var b=new THREE.Mesh(new THREE.BoxGeometry(0.07,0.07,s.z2-s.z1+0.3),rail);b.position.set(s.x1-0.07,h[0],(s.z1+s.z2)/2+0.07);CURG.add(b);
  });
  for(var px=s.x1;px<=s.x2;px+=2.2){var p=new THREE.Mesh(new THREE.BoxGeometry(0.09,1.0,0.09),rail);p.position.set(px,0.5,s.z1-0.07);CURG.add(p);}
  dressFloor2();
  addText('لا تنظر إلى الأسفل',48,2.5,15.81,0,3.8,1.2,'#8d0f0c');
  addText('اهرب',0.19,2.0,5,Math.PI/2,2.4,0.75,'#8d0f0c');
  addText('هو في الأسفل',30,2.4,24.19,Math.PI,3.2,1.0,'#8d0f0c');
}
function box1(x1,x2,z1,z2){FL[CUR].co.push({x1:x1,x2:x2,z1:z1,z2:z2});}
function dressFloor2(){
  var kinds=[
    function(x,z){F(x,z,2.0,3.0,0.7,0x4a3b38);deco(x,0.7,z,1.8,0.16,2.6,0x6a5a52);},
    function(x,z){F(x,z,1.7,1.1,0.8,0x4a3322);},
    function(x,z){F(x,z,2.6,0.6,2.2,0x2e2016);},
    function(x,z){F(x,z,2.2,0.9,0.8,0x3a2a30);},
    function(x,z){F(x,z,1.4,1.2,1.1,0x2a2a2a);}
  ];
  ROOMS2.forEach(function(r,i){
    var wide=r.x2-r.x1;
    var cc=[[r.x1+1.3,r.z2-0.75],[r.x2-1.3,r.z2-0.75],[r.x1+1.3,r.z1+0.75],[r.x2-1.3,r.z1+0.75]];
    for(var a=0;a<cc.length;a++){
      if(freeAt(cc[a][0],cc[a][1],1.0,0.55,0.5)){C(cc[a][0],cc[a][1],2.0,1.1,r.id);break;}
    }
    var cr=[[r.x2-1.2,r.z1+1.2],[r.x1+1.2,r.z1+1.2],[r.x2-1.2,r.z2-1.2],[r.x1+1.2,r.z2-1.2]];
    for(var b=0;b<cr.length;b++){
      if(freeAt(cr[b][0],cr[b][1],0.75,0.75,0.7)){CR(cr[b][0],cr[b][1],r.id);break;}
    }
    var fp=[[r.cx-wide*0.3,r.z1+2.0],[r.cx+wide*0.3,r.z1+2.0],[r.cx-wide*0.3,r.z2-2.4],[r.cx+wide*0.3,r.z2-2.4]];
    var placed=0;
    for(var c=0;c<fp.length&&placed<2;c++){
      var k=kinds[(i+c)%kinds.length];
      if(freeAt(fp[c][0],fp[c][1],1.4,1.5,0.9)){k(fp[c][0],fp[c][1]);placed++;}
    }
  });
}
function buildStairs(){
  var s=STAIR,dx=s.x2-s.x1,L=Math.hypot(dx,FY),ang=Math.atan2(FY,dx),cx=(s.x1+s.x2)/2,cz=(s.z1+s.z2)/2,w=s.z2-s.z1;
  var c=cnv(64,64),g=c.getContext('2d');
  g.fillStyle='#5a3d27';g.fillRect(0,0,64,64);g.fillStyle='#7a5636';g.fillRect(0,0,50,64);g.fillStyle='rgba(0,0,0,0.5)';g.fillRect(58,0,6,64);
  speckle(g,64,64,60,'rgba(0,0,0,A)',2);
  var t=toTex(c,L/0.85,1);
  var ramp=new THREE.Mesh(new THREE.BoxGeometry(L,0.22,w),new THREE.MeshPhongMaterial({map:t,shininess:6}));
  ramp.position.set(cx,FY/2-0.12,cz);ramp.rotation.z=ang;scene.add(ramp);
  var dark=matP(0x2a1c10,3),sh=new THREE.Shape();
  sh.moveTo(0,0);sh.lineTo(dx,0);sh.lineTo(dx,FY);sh.closePath();
  var geo=new THREE.ExtrudeGeometry(sh,{depth:0.12,bevelEnabled:false});
  var s1=new THREE.Mesh(geo,dark);s1.position.set(s.x1,0,s.z1-0.12);scene.add(s1);
  var s2=new THREE.Mesh(geo,dark);s2.position.set(s.x1,0,s.z2);scene.add(s2);
  var endw=new THREE.Mesh(new THREE.BoxGeometry(0.15,FY,w+0.24),dark);endw.position.set(s.x2+0.075,FY/2,cz);scene.add(endw);
  setBuild(0);
  box1(s.x1,s.x2,s.z1-0.2,s.z1);box1(s.x1,s.x2,s.z2,s.z2+0.2);box1(s.x2,s.x2+0.2,s.z1-0.2,s.z2+0.2);
  /* مصباح خافت عند أسفل الدرج */
  var lamp=new THREE.PointLight(0xffb060,0.7,10,2);lamp.position.set(s.x1+1.5,2.6,cz);scene.add(lamp);
}

/* ---------- key spots ---------- */
var spots=[];

var DIFF={
  easy:{name:'سهل',keys:3,hs:0.85,gs:0.85,see:0.8,monsters:true,giant:0.5,info:'٣ مفاتيح · وحوش أبطأ وأقل يقظة · قد لا يظهر العملاق'},
  med:{name:'متوسط',keys:5,hs:1,gs:1,see:1,monsters:true,giant:0.7,info:'٥ مفاتيح · وحوش بسرعة عادية · قد لا يظهر العملاق'},
  hard:{name:'صعب',keys:10,hs:1.15,gs:1.1,see:1.2,monsters:true,giant:0.9,info:'١٠ مفاتيح · وحوش أسرع وأكثر يقظة'},
  none:{name:'بلا وحوش',keys:20,hs:1,gs:1,see:1,monsters:false,giant:0,info:'٢٠ مفتاحًا · بلا وحوش إطلاقًا، استكشف بهدوء'}
};
var D=DIFF.med;
function updFloor(e){
  var s=STAIR;
  if(e.x>s.x1&&e.x<s.x2&&e.z>s.z1&&e.z<s.z2){var u=(e.x-s.x1)/(s.x2-s.x1);e.gy=u*FY;e.fl=u>0.5?1:0;}
  else e.gy=(e.fl||0)*FY;
}

/* ---------- monsters: models ---------- */
function mk(geo,mat,x,y,z){var m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);return m;}
function pivot(x,y,z){var g=new THREE.Group();g.position.set(x,y,z);return g;}
var HM={}, GM={};
/* ---------- monsters: state ---------- */
var P,H,G,hmGroup,gGroup,T0=0,game={};
function dist2(a,b){return Math.hypot(a.x-b.x,a.z-b.z);}
function stepTo(M,tx,tz,sp,dt,r,turn){
  var dx=tx-M.x,dz=tz-M.z,d=Math.hypot(dx,dz);
  if(d<0.001){M.v=0;return 0;}
  var k=Math.min(1,dt*(turn||7));
  M.dx+=(dx/d-M.dx)*k;M.dz+=(dz/d-M.dz)*k;
  var l=Math.hypot(M.dx,M.dz)||1;M.dx/=l;M.dz/=l;
  var st=Math.min(sp*dt,d);M.x+=M.dx*st;M.z+=M.dz*st;pushOut(M,r);M.v=st/dt;
  return Math.hypot(tx-M.x,tz-M.z);
}
function setGoal(M,x,z,fl){
  if(fl===undefined)fl=M.fl||0;
  var a=nearestNode(M.x,M.z,M.fl||0),b=nearestNode(x,z,fl),ids=route(a,b);
  var p=ids.map(function(k){return {x:nodes[k].x,z:nodes[k].z,fl:nodes[k].fl};});
  if(nodes[b].fl===fl&&!blocked(nodes[b].x,nodes[b].z,x,z,fl))p.push({x:x,z:z,fl:fl});
  while(p.length>1&&p[0].fl===(M.fl||0)&&p[1].fl===(M.fl||0)&&!blocked(M.x,M.z,p[1].x,p[1].z,M.fl||0))p.shift();
  M.path=p;
}
function follow(M,dt,sp){
  if(!M.path.length){M.v=0;return true;}
  var w=M.path[0],rem=stepTo(M,w.x,w.z,sp,dt,0.45);
  if(rem<0.55)M.path.shift();
  return M.path.length===0;
}
function pickPatrol(){
  var all=ROOMS.concat(ROOMS2),cur=nearestNode(H.x,H.z,H.fl||0),tries=0,r;
  do{r=all[(Math.random()*all.length)|0];tries++;}while(roomNode[r.id]===cur&&tries<6);
  setGoal(H,r.cx,r.cz,r.fl);
}
var TG=null;
function hmCanSee(e){
  if(e.hidden||e.fl!==H.fl)return false;
  var d=dist2(H,e),range=(e.torch?17:10)*D.see;
  if(e.crouch)range*=0.65;
  if(d>range)return false;
  if(d>3.2){var dot=((e.x-H.x)*H.dx+(e.z-H.z)*H.dz)/d;if(dot<0.3)return false;}
  return !blocked(H.x,H.z,e.x,e.z,H.fl);
}
function pickTarget(){
  var l=mpPlayers(),best=null,bd=1e9,i,e,d;
  if(H.state==='hideCheck'&&TG&&l.indexOf(TG)>=0)return;
  for(i=0;i<l.length;i++){
    e=l[i];d=dist2(H,e)+(e.fl!==H.fl?9:0);
    if(hmCanSee(e))d-=1000;
    if(e===TG&&H.state==='chase')d-=6;
    if(d<bd){bd=d;best=e;}
  }
  TG=best||P;
}
function hearNoise(){
  var l=mpPlayers(),i,e;
  for(i=0;i<l.length;i++){e=l[i];if(e.noise>0&&!e.hidden&&dist2(H,e)+(e.fl!==H.fl?8:0)<e.noise)return e;}
  return null;
}
function startChase(e){
  if(H.state!=='chase'){
    H.state='chase';H.lose=0;H.stateT=0;
    if(e===P){game.stats.chases++;toast('الرجل رآك! اهرب!',1800);}
    if(dist2(H,P)<25)Snd.sting();
  }
}
function updateHammerMan(dt){
  updFloor(H);
  if(H.stun>0){H.stun-=dt;H.v=0;H.atk=0;H.atkAnim=0;return;}
  var d=dist2(H,TG),see=hmCanSee(TG);
  H.stateT+=dt;H.noiseCD-=dt;H.v=0;
  if(H.catchT>0){H.catchT-=dt;if(H.catchT<=0)H.catch=-1;}
  if(H.atk>0){
    H.atk-=dt;H.atkAnim=1-Math.max(0,H.atk)/0.55;
    if(H.atk<=0){H.atkAnim=0;H.cool=1.2;}
    return;
  }
  H.cool-=dt;
  if(H.state==='patrol'||H.state==='search'||H.state==='investigate'){
    if(see){startChase(TG);}
    else{
      var sp=(H.state==='patrol'?1.35:2.0)*D.hs;
      if(follow(H,dt,sp)){
        if(H.state==='patrol'||H.wait<=0){
          if(H.wait<=0){H.wait=H.state==='patrol'?R(1,2.6):R(2.5,4);}
        }
        H.wait-=dt;
        if(H.wait<=0){H.state='patrol';pickPatrol();}
      }
      var hn=H.noiseCD<=0?hearNoise():null;
      if(hn){H.noiseCD=3;H.state='investigate';setGoal(H,hn.x,hn.z,hn.fl);H.wait=0;}
    }
  }else if(H.state==='chase'){
    if(see){
      H.lose=0;H.last={x:TG.x,z:TG.z,fl:TG.fl};
      stepTo(H,TG.x,TG.z,2.9*D.hs,dt,0.45,9);
      if(d<1.9&&H.cool<=0){H.atk=0.55;Snd.swing();}
    }else if(TG.hidden&&dist2(H,TG)<18&&H.fl===TG.fl){
      H.state='hideCheck';H.closet=TG.hidden;H.stateT=0;setGoal(H,H.closet.exit.x,H.closet.exit.z,H.closet.fl);
    }else{
      H.lose+=dt;
      if(H.lose<0.3||!H.path.length){if(H.last)setGoal(H,H.last.x,H.last.z,H.last.fl);}
      follow(H,dt,2.7*D.hs);
      if(H.lose>5.5){H.state='search';H.wait=0;}
    }
  }else if(H.state==='hideCheck'){
    if(see){startChase(TG);}
    else{
      var cl=H.closet,dc=Math.hypot(H.x-cl.exit.x,H.z-cl.exit.z);
      if(dc>1.2||H.fl!==cl.fl){follow(H,dt,2.5*D.hs);H.stateT=0;}
      else{
        H.v=0;
        if(H.stateT>1.7){
          if(TG.hidden===cl){H.catch=closets.indexOf(cl);H.catchT=1.2;}
          H.state='search';H.wait=0;
        }
      }
    }
  }
  H.stuckT+=dt;
  if(H.stuckT>1.2){
    if(H.v>0.2&&Math.hypot(H.x-H.sx,H.z-H.sz)<0.2&&H.path.length){H.path.shift();}
    H.sx=H.x;H.sz=H.z;H.stuckT=0;
  }
}
function giantTarget(){
  var l=mpPlayers(),best=null,bd=1e9,i,e,d;
  for(i=0;i<l.length;i++){
    e=l[i];
    if(e.hidden||e.fl!==0||(e.gy||0)>=1.5||!(e.z>14.5&&e.z<25.5&&e.x>0&&e.x<60))continue;
    d=dist2(G,e);if(d<48&&d<bd){bd=d;best=e;}
  }
  return best;
}
function updateGiant(dt){
  if(G.stun>0){G.stun-=dt;G.v=0;G.atk=0;G.atkAnim=0;return;}
  var GT=giantTarget(),d=GT?dist2(G,GT):1e9,inHall=!!GT,tx,tz,sp;
  if(G.atk>0){
    G.atk-=dt;G.atkAnim=1-Math.max(0,G.atk)/1.4;G.v=0;
    if(G.atk<=0){G.atkAnim=0;G.cool=1.6;}
  }else{
    G.cool-=dt;
    if(inHall){
      tx=GT.x;tz=Math.max(19.4,Math.min(20.6,GT.z));sp=0.65*D.gs;
      if(d<2.9&&G.cool<=0){G.atk=1.4;Snd.groan();}
    }else{
      if(!G.goal||Math.abs(G.x-G.goal)<1){G.goal=R(5,55);}
      tx=G.goal;tz=20+Math.sin(T0*0.1)*0.5;sp=0.5*D.gs;
    }
    if(G.atk<=0&&!(inHall&&d<2.4))stepTo(G,tx,tz,sp,dt,1.2,1.4);else G.v=0;
    G.x=Math.max(2.2,Math.min(57.8,G.x));G.z=Math.max(19.3,Math.min(20.7,G.z));
  }
  G.phase+=dt*G.v*1.9;
  giantSteps();
}
function giantSteps(){
  var s=Math.sin(G.phase),dl=dist2(G,P);
  if(G.v>0.05&&(s>0)!==G.stepSign){G.stepSign=(s>0);if(dl<40){Snd.gstep(dl);if(dl<14)game.shake=Math.max(game.shake,0.05*(1-dl/14)+0.012);}}
}
function checkKills(){
  if(game.state!=='play')return;
  var ha=game.pHa||0,ga=game.pGa||0;
  if(D.monsters){
    if(ha>0&&H.atk<=0&&!P.hidden&&dist2(H,P)<2.6&&P.fl===H.fl)kill('hammer');
    if(game.state==='play'&&H.catch>=0&&P.hidden&&closets.indexOf(P.hidden)===H.catch)kill('closet');
  }
  if(game.state==='play'&&game.giantOn&&ga>0&&G.atk<=0&&!P.hidden&&dist2(G,P)<3.4&&P.fl===0)kill('giant');
  game.pHa=H.atk;game.pGa=G.atk;
}

/* ---------- audio ---------- */
var AC=null, master=null, noiseBuf=null;
var Snd={
  init:function(){
    if(AC){if(AC.state==='suspended')AC.resume();return;}
    try{
      AC=new (window.AudioContext||window.webkitAudioContext)();
      master=AC.createGain();master.gain.value=S.vol;master.connect(AC.destination);
      noiseBuf=AC.createBuffer(1,AC.sampleRate,AC.sampleRate);
      var d=noiseBuf.getChannelData(0);for(var i=0;i<d.length;i++)d[i]=Math.random()*2-1;
      [48,50.5,73].forEach(function(f,i){
        var o=AC.createOscillator(),g=AC.createGain();o.type=i===2?'triangle':'sine';o.frequency.value=f;g.gain.value=0.035;
        o.connect(g);g.connect(master);o.start();
        var l=AC.createOscillator(),lg=AC.createGain();l.frequency.value=0.07+i*0.03;lg.gain.value=0.02;l.connect(lg);lg.connect(g.gain);l.start();
      });
    }catch(e){AC=null;}
  },
  tone:function(type,f0,f1,vol,dur){
    if(!AC)return;var t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();
    o.type=type;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
    g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(Math.max(0.0002,vol),t+0.012);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
    o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+0.05);
  },
  noise:function(vol,dur,freq){
    if(!AC)return;var t=AC.currentTime,s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();
    s.buffer=noiseBuf;f.type='lowpass';f.frequency.value=freq;
    g.gain.setValueAtTime(Math.max(0.0002,vol),t);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
    s.connect(f);f.connect(g);g.connect(master);s.start(t);s.stop(t+dur+0.05);
  },
  beat:function(v){Snd.tone('sine',62,30,v,0.2);setTimeout(function(){Snd.tone('sine',54,28,v*0.8,0.18);},170);},
  gstep:function(d){var v=Math.max(0.05,0.75*(1-d/40));Snd.tone('sine',52,22,v,0.45);Snd.noise(v*0.5,0.35,180);},
  hstep:function(d){Snd.noise(Math.max(0.02,0.18*(1-d/14)),0.09,900);},
  sting:function(){Snd.tone('sawtooth',420,70,0.22,0.9);Snd.tone('square',233,60,0.1,0.9);},
  swing:function(){Snd.noise(0.35,0.4,1400);},
  groan:function(){Snd.tone('sawtooth',90,45,0.18,1.2);},
  chime:function(){Snd.tone('sine',880,880,0.16,0.5);setTimeout(function(){Snd.tone('sine',1320,1320,0.12,0.6);},120);},
  hit:function(){Snd.noise(0.9,0.6,500);Snd.tone('sine',90,25,0.9,0.7);},
  bang:function(){Snd.noise(0.5,0.5,600);Snd.tone('sine',70,30,0.5,0.4);},
  creak:function(v){Snd.tone('sawtooth',150,85,v,0.45);},
  door:function(){Snd.tone('sawtooth',70,40,0.2,1.2);Snd.noise(0.2,0.8,300);}
};

/* ---------- UI helpers ---------- */
var AR=['٠','١','٢','٣'];
var toastTimer=0;
function toast(msg,ms){
  var el=$('toast');el.textContent=msg;el.style.opacity=1;
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.style.opacity=0;},ms||2200);
}
function showScreen(html){var s=$('scr');panel.innerHTML=html;s.hidden=false;s.style.display='flex';s.style.background='';s.style.alignItems='';}
function hideScreen(){var s=$('scr');s.hidden=true;s.style.display='none';}
function fmtTime(t){var m=Math.floor(t/60),s=Math.floor(t%60);return AR_NUM(m)+':'+(s<10?AR_NUM(0):'')+AR_NUM(s);}
function AR_NUM(n){return String(n).replace(/\d/g,function(d){return '٠١٢٣٤٥٦٧٨٩'.charAt(+d);});}

function menuHTML(){
  var seg=['easy','med','hard','none'].map(function(k){var d=DIFF[k];
    return '<button type="button" class="seg'+(S.diff===k?' on':'')+'" data-d="'+k+'"><b>'+d.name+'</b><small>'+AR_NUM(d.keys)+' مفتاحًا</small></button>';}).join('');
  return '<h1>بيت المطرقة</h1>'+
  '<p class="lead">أنت محبوس في بيت مهجور من طابقين. رجل ملطخ بالدم يحمل مطرقة بأشواك يجوب الغرف، وفي الممر الطويل عملاق بطيء قد يظهر وقد لا يظهر.</p>'+
  '<div class="segs" id="segs">'+seg+'</div><p id="dinfo">'+DIFF[S.diff].info+'</p>'+
  mpBadge()+
  '<div class="goal"><ol><li>ابحث عن المفاتيح المخبأة في الصناديق وتحت الدرج، في الطابقين.</li>'+
  '<li>اجمع السلاح والأدوات: المسدس في صندوق، والمطرقة في صندوق، والمفك داخل الخزنة (رمزها في ورقة بالمطبخ).</li><li>اذهب إلى قاعة الخروج، أصلح الباب الحديدي ثم افتحه بالمفاتيح.</li>'+
  '<li>اهرب قبل أن يجدك أحدهما.</li></ol></div>'+
  '<div class="ctl desk"><span><kbd>W A S D</kbd>حركة</span><span><kbd>الفأرة</kbd>نظر</span>'+
  '<span><kbd>Shift</kbd>جري</span><span><kbd>C</kbd>انحناء</span>'+
  '<span><kbd>E</kbd>بحث / اختباء</span><span><kbd>F</kbd>الكشاف</span>'+
  '<span><kbd>Q</kbd>إطلاق النار</span><span><kbd>M</kbd>الخريطة</span><span><kbd>P</kbd>إيقاف مؤقت</span></div>'+
  '<div class="btns"><button class="btn" id="go" type="button">ابدأ اللعبة</button><button class="btn alt" id="mpb" type="button">👥 اللعب الجماعي</button><button class="btn alt" id="setb" type="button">الإعدادات</button></div>'+
  '<p class="fine">لعبة رعب. يُفضّل استخدام سماعات.<br>تطوير: Asoma Okazi</p>';
}
function showMenu(){
  game.state='menu';showScreen(menuHTML());bindGo(startGame);
  var bs=document.querySelectorAll('#segs .seg');
  Array.prototype.forEach.call(bs,function(b){
    b.addEventListener('click',function(){
      S.diff=b.getAttribute('data-d');saveS();
      Array.prototype.forEach.call(bs,function(x){x.classList.toggle('on',x===b);});
      $('dinfo').textContent=DIFF[S.diff].info;
    });
  });
  $('setb').addEventListener('click',function(){showSettings('menu');});
  $('mpb').addEventListener('click',showMP);
  bindMP();if(NET.room)NET.room.presence({st:'lobby'}).catch(function(){});
}
function settingsHTML(){
  return '<h2>الإعدادات</h2><div class="form">'+
  '<label>جودة الرسوم<select id="sGfx"><option value="low">منخفضة (أسرع)</option><option value="med">متوسطة</option><option value="high">عالية (أوضح)</option></select></label>'+
  '<label>حساسية النظر<input type="range" id="sSens" min="0.4" max="2" step="0.1"></label>'+
  '<label>مستوى الصوت<input type="range" id="sVol" min="0" max="1" step="0.05"></label>'+
  '<label>السطوع<input type="range" id="sBri" min="0.6" max="1.8" step="0.1"></label></div>'+
  '<button class="btn" id="back" type="button">رجوع</button><p class="fine">تطوير: Asoma Okazi</p>';
}
function showSettings(from){
  showScreen(settingsHTML());
  $('sGfx').value=S.gfx;$('sSens').value=S.sens;$('sVol').value=S.vol;$('sBri').value=S.bright;
  $('sGfx').addEventListener('change',function(e){S.gfx=e.target.value;applyGfx();saveS();});
  $('sSens').addEventListener('input',function(e){S.sens=+e.target.value;saveS();});
  $('sVol').addEventListener('input',function(e){S.vol=+e.target.value;if(master)master.gain.value=S.vol;saveS();});
  $('sBri').addEventListener('input',function(e){S.bright=+e.target.value;applyGfx();saveS();});
  $('back').addEventListener('click',function(){if(from==='pause')showPause();else showMenu();});
  $('back').focus();
}
function bindGo(fn){var b=$('go');if(b){b.addEventListener('click',fn);b.focus();}var m=$('menub');if(m)m.addEventListener('click',toMenu);}

/* ---------- input ---------- */
var keys={}, touch={mx:0,mz:0,run:false,on:false}, dragging=false, lockOn=false, mapOn=false;
function look(dx,dy,s){s*=S.sens;P.yaw-=dx*s;P.pitch=Math.max(-1.45,Math.min(1.45,P.pitch-dy*s));}
function requestLock(){
  if(touch.on)return;
  try{var r=cv.requestPointerLock();if(r&&r.catch)r.catch(function(){});}catch(e){}
}
document.addEventListener('pointerlockchange',function(){
  var was=lockOn;lockOn=(document.pointerLockElement===cv);
  if(was&&!lockOn&&game.state==='play')pauseGame();
});
document.addEventListener('mousemove',function(e){
  if(game.state!=='play')return;
  if(lockOn||dragging)look(e.movementX||0,e.movementY||0,0.0022);
});
cv.addEventListener('mousedown',function(){if(game.state==='play'){if(lockOn)fire();else dragging=true;}});
window.addEventListener('mouseup',function(){dragging=false;});
window.addEventListener('keydown',function(e){
  if(game.state==='play'){
    if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].indexOf(e.code)>=0)e.preventDefault();
    if(e.repeat){keys[e.code]=true;return;}
    keys[e.code]=true;
    if(e.code==='KeyE')interact();
    else if(e.code==='KeyQ')fire();
    else if(e.code==='KeyF')toggleTorch();
    else if(e.code==='KeyC')toggleCrouch();
    else if(e.code==='KeyM')toggleMap();
    else if(e.code==='KeyP'||e.code==='Escape')pauseGame();
  }else if(game.state==='paused'&&e.code==='KeyP'){resumeGame();}
  else if(game.state==='spec'&&e.code==='KeyE')NET.spec++;
  else if(game.state==='cinema'&&(e.code==='Enter'||e.code==='Space'||e.code==='Escape'))skipCinema();
});
window.addEventListener('keyup',function(e){keys[e.code]=false;if(e.code==='Space')e.preventDefault();});
window.addEventListener('blur',function(){keys={};if(game.state==='play')pauseGame();});

function setTouchMode(){
  if(touch.on)return;touch.on=true;document.body.classList.add('touch');
  $('cross').hidden=false;
}
(function bindTouch(){
  var stick=$('stick'),knob=$('knob'),sid=null,cx=0,cy=0,lid=null,lx=0,ly=0;
  window.addEventListener('touchstart',setTouchMode,{passive:true});
  stick.addEventListener('touchstart',function(e){
    e.preventDefault();var t=e.changedTouches[0];sid=t.identifier;
    var r=stick.getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;mv(t);
  },{passive:false});
  function mv(t){
    var dx=t.clientX-cx,dy=t.clientY-cy,l=Math.hypot(dx,dy),m=52;
    if(l>m){dx*=m/l;dy*=m/l;}
    knob.style.transform='translate('+dx+'px,'+dy+'px)';touch.mx=dx/m;touch.mz=-dy/m;
  }
  stick.addEventListener('touchmove',function(e){
    e.preventDefault();for(var i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===sid)mv(e.changedTouches[i]);
  },{passive:false});
  function end(e){
    for(var i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===sid){sid=null;touch.mx=0;touch.mz=0;knob.style.transform='none';}
  }
  stick.addEventListener('touchend',end);stick.addEventListener('touchcancel',end);
  cv.addEventListener('touchstart',function(e){
    e.preventDefault();if(lid!==null)return;var t=e.changedTouches[0];lid=t.identifier;lx=t.clientX;ly=t.clientY;
  },{passive:false});
  cv.addEventListener('touchmove',function(e){
    e.preventDefault();
    for(var i=0;i<e.changedTouches.length;i++){var t=e.changedTouches[i];
      if(t.identifier===lid&&game.state==='play'){look(t.clientX-lx,t.clientY-ly,0.0055);lx=t.clientX;ly=t.clientY;}}
  },{passive:false});
  function lend(e){for(var i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===lid)lid=null;}
  cv.addEventListener('touchend',lend);cv.addEventListener('touchcancel',lend);
  function hold(id,on){
    var b=$(id);
    b.addEventListener('touchstart',function(e){e.preventDefault();touch.run=true;b.classList.add('on');},{passive:false});
    var off=function(e){touch.run=false;b.classList.remove('on');};
    b.addEventListener('touchend',off);b.addEventListener('touchcancel',off);
  }
  hold('bRun');
  function tap(id,fn){$(id).addEventListener('touchstart',function(e){e.preventDefault();if(game.state==='play')fn();},{passive:false});}
  tap('bUse',function(){interact();});tap('bCrouch',function(){toggleCrouch();});
  tap('bFire',function(){fire();});tap('bTorch',function(){toggleTorch();});tap('bMap',function(){toggleMap();});
})();

function toggleTorch(){P.torch=!P.torch;}
function toggleCrouch(){if(!P.hidden)P.crouch=!P.crouch;}
function toggleMap(){mapOn=!mapOn;$('mapwrap').style.display=mapOn?'block':'none';}
function pauseGame(){
  if(game.state!=='play')return;
  game.state='paused';dragging=false;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  showPause();
}
function showPause(){
  showScreen('<h2>متوقف مؤقتًا</h2><p class="lead">الوحوش تنتظرك.</p><div class="btns"><button class="btn" id="go" type="button">متابعة</button><button class="btn alt" id="setb" type="button">الإعدادات</button><button class="btn alt" id="exb" type="button">خروج</button></div>');
  bindGo(resumeGame);
  $('setb').addEventListener('click',function(){showSettings('pause');});
  $('exb').addEventListener('click',exitGame);
}
function exitGame(){
  try{if(window.AndroidLan&&AndroidLan.exitApp){AndroidLan.exitApp();return;}}catch(e){}
  toMenu();
}
function resumeGame(){
  if(game.state!=='paused')return;
  hideScreen();game.state='play';game.last=performance.now();requestLock();
}

/* ---------- interaction ---------- */
function nearTarget(){
  if(P.hidden)return {type:'unhide',label:'الخروج من المخبأ'};
  var i,k,xt=extraTarget();if(xt)return xt;
  for(i=0;i<spots.length;i++){k=spots[i];if(!k.searched&&k.fl===P.fl&&Math.hypot(k.x-P.x,k.z-P.z)<(k.r||1.7))return {type:'spot',obj:k,label:k.label};}
  for(i=0;i<closets.length;i++){
    if(closets[i].fl===P.fl&&distBox(P.x,P.z,closets[i].box)<1.15)return {type:'hide',obj:closets[i],label:closets[i].kind==='crate'?'الاختباء في الصندوق':'الاختباء في الخزانة'};
  }
  if(P.fl===0&&exitBox&&exitBox.door&&distBox(P.x,P.z,exitBox)<2.2){
    return {type:'door',label:game.keys>=game.need?'فتح الباب الحديدي':'الباب مقفل — تحتاج '+AR_NUM(game.need)+' مفاتيح'};
  }
  return null;
}
function interact(){
  var t=nearTarget();if(!t||game.state!=='play')return;
  if(t.run){t.run();return;}
  if(t.type==='spot'){
    var sp=t.obj;markSearched(sp);game.lastSearchI=spots.indexOf(sp);game.lastSearchT=Date.now();
    if(sp.key){
      game.keys++;Snd.chime();
      toast('وجدت مفتاحًا ('+AR_NUM(game.keys)+'/'+AR_NUM(game.need)+')'+(game.keys>=game.need?' — اتبع السهم إلى الباب الحديدي':''),2600);
    }else if(sp.item){takeItem(sp);}else{Snd.creak(0.1);toast('لا شيء هنا',1200);}
  }else if(t.type==='hide'){
    var c=t.obj;game.stats.hides++;P.hidden=c;P.x=c.x;P.z=c.z;P.crouch=false;
    if(D.monsters&&H.state==='chase'&&H.fl===P.fl&&dist2(H,P)<18){H.state='hideCheck';H.closet=c;H.stateT=0;setGoal(H,c.exit.x,c.exit.z,c.fl);}
  }else if(t.type==='unhide'){
    var cl=P.hidden;P.hidden=null;P.x=cl.exit.x;P.z=cl.exit.z;pushOut(P,PR);
  }else if(t.type==='door'){
    if(game.keys>=game.need&&!game.doorOpen){
      openExit();toast('الباب مفتوح! اهرب!',2600);
    }else if(game.keys<game.need){toast('الباب مقفل. ما زال ينقصك '+AR_NUM(game.need-game.keys)+' من المفاتيح.',2200);Snd.bang();}
  }
}
function kill(by){
  if(game.state!=='play'&&game.state!=='pad')return;
  closePad(false);
  game.state='dead';game.deadT=0;game.killer=by;game.msgShown=false;
  Snd.hit();$('hit').style.opacity=0.85;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
}

$('menuBtn').addEventListener('click',function(){if(game.state==='play')pauseGame();});

/* ---------- game flow ---------- */
var START={x:4.8,z:3.8,yaw:-Math.PI/2};
function newPlayer(){return {fl:0,gy:0,x:START.x,z:START.z,yaw:START.yaw,pitch:0,eye:EYE,crouch:false,stamina:1,exhausted:false,hidden:null,bob:0,torch:true,noise:0,roll:0,stepSign:false,gun:false,ammo:0};}
function resetMonsters(){
  H={catch:-1,catchT:0,fl:0,gy:0,x:56,z:8,dx:-1,dz:0,v:0,state:'patrol',path:[],wait:0,stateT:0,lose:0,last:null,atk:0,atkAnim:0,cool:0,noiseCD:0,stuckT:0,sx:56,sz:8,phase:0,closet:null,hstep:false,stun:0};
  G={fl:0,gy:0,x:40,z:20,dx:-1,dz:0,v:0,atk:0,atkAnim:0,cool:0,phase:0,stepSign:false,goal:0,stun:0};
  hmGroup.visible=D.monsters;gGroup.visible=game.giantOn;
  if(!D.monsters){H.x=200;H.z=200;}
  if(!game.giantOn){G.x=200;G.z=200;}
  if(D.monsters)pickPatrol();
}
function reset(){
  P=newPlayer();
  game.stats={hides:0,chases:0};cinemaCleanup();
  game.keys=0;game.doorOpen=false;game.time=0;game.shake=0;game.threat=0;game.hbT=1;game.bangT=R(20,40);game.moving=false;
  game.rnd=game.rnd||0;game.pHa=0;game.pGa=0;game.specEnd=false;game.need=placeKeys(D.keys,rng(game.seed||1));
  if(FL[0].co.indexOf(exitBox)<0){FL[0].co.push(exitBox);FL[0].bl.push(exitBox);}
  game.giantOn=D.monsters&&rng((game.seed||1)^0x9e3779b9)()<D.giant;
  resetMonsters();
  redGlow.intensity=D.monsters?0.9:0;greenGlow.intensity=game.giantOn?0.6:0;
  exitDoorPivot.rotation.y=0;
  $('hit').style.opacity=0;$('slits').hidden=true;$('danger').style.opacity=0;$('warn').style.opacity=0;
  mapOn=false;$('mapwrap').style.display='none';
  resetDoors();$('exitHint').hidden=true;
  resetExtras();
}
function startGame(){
  if(!mpPrepare())return;Snd.init();reset();hideScreen();
  $('hud').hidden=true;$('prompt').hidden=false;$('cross').hidden=true;
  dayAnim(1,'start',beginWake);
  requestLock();
}
function win(){startCinema();}
function showDeath(){
  if(dayDeath())return;
  if(showDeathMP())return;
  var msg={hammer:'حطّمتك المطرقة',giant:'سحقك العملاق',closet:'اكتشف مخبأك'}[game.killer]||'انتهت اللعبة';
  $('hud').hidden=true;$('prompt').style.opacity=0;$('slits').hidden=true;
  showScreen('<h2>'+msg+'</h2><p class="lead">صمدت '+fmtTime(game.time)+' وجمعت '+AR_NUM(game.keys)+' من '+AR_NUM(game.need)+' مفاتيح.</p><div class="btns"><button class="btn" id="go" type="button">حاول مرة أخرى</button><button class="btn alt" id="menub" type="button">القائمة</button></div>');
  bindGo(startGame);
}

/* ---------- per-frame ---------- */
function update(dt){
  T0+=dt;game.time+=dt;
  var ix=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+touch.mx;
  var iz=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)+touch.mz;
  var moving=false,sprint=false;
  if(!P.hidden){
    var len=Math.hypot(ix,iz);if(len>1){ix/=len;iz/=len;len=1;}
    moving=len>0.1;
    sprint=moving&&(keys.ShiftLeft||keys.ShiftRight||touch.run)&&!P.crouch&&!P.exhausted&&P.stamina>0;
    var sp=P.crouch?1.5:(sprint?5.4:3.1),s=Math.sin(P.yaw),c=Math.cos(P.yaw);
    P.x+=(-s*iz+c*ix)*sp*dt;P.z+=(-c*iz-s*ix)*sp*dt;
    pushOut(P,PR);updFloor(P);
    if(moving)P.bob+=dt*(sprint?11:(P.crouch?6:8));
    if(moving){var ss=Math.sin(P.bob)>0;if(ss!==P.stepSign){P.stepSign=ss;if(!P.crouch)Snd.noise(sprint?0.12:0.06,0.07,700);}}
  }
  game.moving=moving;
  if(sprint){P.stamina-=0.2*dt;if(P.stamina<=0){P.stamina=0;P.exhausted=true;}}
  else P.stamina=Math.min(1,P.stamina+0.14*dt);
  if(P.exhausted&&P.stamina>0.3)P.exhausted=false;
  P.noise=Math.max(game.extraNoise||0,(moving&&!P.hidden)?(sprint?14:(P.crouch?2.5:7)):0);

  simBackground(dt);
  checkKills();
  if(game.state!=='play'){return;}
  extraUpdate(dt);
  var hs=Math.sin(H.phase||0)>0,dh=dist2(H,P)+(H.fl!==P.fl?9:0),dg=dist2(G,P)+(P.fl!==0?12:0);
  if(H.v>0.3&&hs!==H.hstep){H.hstep=hs;if(dh<14)Snd.hstep(dh);}

  var th=0;
  if(H.state==='chase')th=0.55+0.45*Math.max(0,1-dh/16);else th=Math.max(0,1-dh/9)*0.45;
  th=Math.max(th,Math.max(0,1-dg/10)*0.6);
  game.threat+=(th-game.threat)*Math.min(1,dt*3);
  game.hbT-=dt;
  if(game.threat>0.12&&game.hbT<=0){Snd.beat(0.15+0.5*game.threat);game.hbT=1.15-0.7*game.threat;}
  game.bangT-=dt;if(game.bangT<=0){Snd.bang();game.bangT=R(25,50);}

  var fl=1;if(game.threat>0.45&&Math.random()<0.12)fl=R(0.05,0.6);
  torch.intensity=P.torch?TORCH_I*S.bright*fl:0;

  if(P.x>61.2)win();
  animateMonsters(dt);
  updateCamera(dt);
  updateHUD();
}
function updateCamera(dt){
  if(P.hidden)P.eye=P.hidden.eye||1.5;else P.eye+=((P.crouch?EYE_C:EYE)-P.eye)*Math.min(1,dt*10);
  var by=game.moving?Math.sin(P.bob)*0.045:0;
  game.shake*=Math.max(0,1-dt*4);
  var sh=game.shake;
  camera.position.set(P.x+(Math.random()-0.5)*sh,(P.gy||0)+P.eye+by+(Math.random()-0.5)*sh,P.z+(Math.random()-0.5)*sh);
  camera.rotation.set(P.pitch,P.yaw,P.roll);
}
function updateDead(dt){
  game.deadT+=dt;
  var M=game.killer==='giant'?G:H;
  var tgt=Math.atan2(-(M.x-P.x),-(M.z-P.z)),df=tgt-P.yaw;
  while(df>Math.PI)df-=6.2832;while(df<-Math.PI)df+=6.2832;
  P.yaw+=df*Math.min(1,dt*6);
  P.pitch+=(0.25-P.pitch)*Math.min(1,dt*3);
  P.eye+=(0.4-P.eye)*Math.min(1,dt*2.5);
  P.roll+=(0.9-P.roll)*Math.min(1,dt*2);
  $('hit').style.opacity=Math.max(0.35,0.85-game.deadT*0.3);
  if(NET.room)simBackground(dt);else{H.v=0;G.v=0;}
  animateMonsters(dt);updateCamera(dt);
  if(game.deadT>1.8&&!game.msgShown){game.msgShown=true;showDeath();}
}
var lastPrompt='';
function updateHUD(){
  $('kc').textContent=AR_NUM(game.keys)+'/'+AR_NUM(game.need);
  var bar=$('stam');bar.firstElementChild.style.transform='scaleX('+P.stamina.toFixed(3)+')';
  bar.className=P.exhausted?'bar low':'bar';
  var rn=roomAt(P.x,P.z,P.fl);if($('room').textContent!==rn)$('room').textContent=rn;
  $('danger').style.opacity=Math.min(0.9,game.threat*0.9).toFixed(2);
  $('warn').style.opacity=H.state==='chase'?1:0;
  $('slits').hidden=!P.hidden;
  var t=nearTarget(),txt=t?((touch.on?'':'<b>E</b>')+t.label):'';
  if(txt!==lastPrompt){lastPrompt=txt;var pe=$('prompt');pe.innerHTML=txt;pe.style.opacity=txt?1:0;}
  var eh=$('exitHint');
  if(game.keys>=game.need){
    var gx=60,gz=ROOM.exit.cz,lab=game.doorOpen?'اهرب إلى الخارج':'الباب الحديدي';
    if(P.fl===1){gx=STAIR.x2;gz=(STAIR.z1+STAIR.z2)/2;lab='انزل إلى الطابق الأرضي';}
    var tx=gx-P.x,tz=gz-P.z,sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);
    var a=Math.atan2(tx*cy-tz*sy,-tx*sy-tz*cy);
    eh.hidden=false;$('arrow').style.transform='rotate('+a.toFixed(3)+'rad)';
    $('exitTxt').textContent=lab+' · '+AR_NUM(Math.round(Math.hypot(tx,tz)))+' م';
  }else eh.hidden=true;
  if(mapOn)drawMap();
}
function resetDoors(){
  doors.forEach(function(d){
    d.ang=0;d.target=0;d.piv.rotation.y=0;
    if(!d.solid){FL[d.fl].co.push(d.box);FL[d.fl].bl.push(d.box);d.solid=true;}
  });
}
function updateDoors(dt){
  for(var i=0;i<doors.length;i++){
    var d=doors[i],dp=(P.hidden||P.fl!==d.fl)?99:Math.hypot(P.x-d.cx,P.z-d.cz),dh=(H.fl!==d.fl)?99:Math.hypot(H.x-d.cx,H.z-d.cz);
    var dm=Math.min(dp,dh);
    if(d.target===0&&dm<2.8){
      d.target=1;
      var sx=dp<=dh?P:H;
      d.side=(d.ax==='x'?Math.sign(sx.z-d.fixed):Math.sign(sx.x-d.fixed))||1;
      if(dp<14)Snd.creak(Math.max(0.03,0.16*(1-dp/14)));
    }else if(d.target===1&&dm>3.8){d.target=0;}
    var goal=d.target?1.45:0,df=goal-d.ang;
    d.ang+=Math.max(-dt*5,Math.min(dt*5,df));
    d.piv.rotation.y=d.ax==='x'?d.side*d.ang:-d.side*d.ang;
    var shut=d.ang<0.55;
    if(shut&&!d.solid){FL[d.fl].co.push(d.box);FL[d.fl].bl.push(d.box);d.solid=true;}
    else if(!shut&&d.solid){var a=FL[d.fl].co.indexOf(d.box);if(a>=0)FL[d.fl].co.splice(a,1);var b=FL[d.fl].bl.indexOf(d.box);if(b>=0)FL[d.fl].bl.splice(b,1);d.solid=false;}
  }
}
function roomAt(x,z,fl){
  if(x>60)return 'الخارج';
  if(x>STAIR.x1&&x<STAIR.x2&&z>STAIR.z1&&z<STAIR.z2)return 'الدرج';
  if(z>=16&&z<=24)return fl?'الطابق الثاني · الصالة العليا':'الممر الطويل';
  var list=fl?ROOMS2:ROOMS;
  for(var i=0;i<list.length;i++){var r=list[i];if(x>=r.x1&&x<=r.x2&&z>=r.z1&&z<=r.z2)return fl?'الطابق الثاني · '+r.name:r.name;}
  return '—';
}
function drawMap(){
  var c=$('map'),g=c.getContext('2d'),Z=5,list=P.fl?ROOMS2:ROOMS;
  g.clearRect(0,0,300,290);g.fillStyle='rgba(0,0,0,0.5)';g.fillRect(0,0,300,290);
  g.lineWidth=1;g.strokeStyle='rgba(235,227,214,0.55)';g.fillStyle='rgba(235,227,214,0.7)';g.font='9px Tajawal, sans-serif';g.textAlign='center';
  list.forEach(function(r){g.strokeRect(r.x1*Z+0.5,r.z1*Z+0.5,(r.x2-r.x1)*Z,(r.z2-r.z1)*Z);g.fillText(r.name,r.cx*Z,r.cz*Z);});
  g.strokeRect(0.5,16*Z+0.5,60*Z,8*Z);g.fillText(P.fl?'الصالة العليا':'الممر الطويل',40*Z,19*Z);
  g.fillStyle='rgba(226,179,74,0.45)';g.fillRect(STAIR.x1*Z,STAIR.z1*Z,(STAIR.x2-STAIR.x1)*Z,(STAIR.z2-STAIR.z1)*Z);
  g.fillStyle='rgba(235,227,214,0.85)';g.fillText('الدرج',17.6*Z,STAIR.z1*Z-3);
  if(!P.fl){g.fillStyle='#46ff82';g.fillRect(59*Z,(ROOM.exit.cz-1.4)*Z,4,2.8*Z);}
  g.fillStyle='rgba(235,227,214,0.85)';g.textAlign='start';g.fillText(P.fl?'الطابق الثاني':'الطابق الأرضي',6,12);
  g.save();g.translate(P.x*Z,P.z*Z);g.rotate(-P.yaw+Math.PI);
  g.fillStyle='#ff6a4a';g.beginPath();g.moveTo(0,-7);g.lineTo(5,5);g.lineTo(-5,5);g.closePath();g.fill();g.restore();
}
function toMenu(){
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  $('hud').hidden=true;$('prompt').style.opacity=0;$('hit').style.opacity=0;$('slits').hidden=true;$('danger').style.opacity=0;
  cleanupExtras();game.state='menu';reset();showMenu();
}

/* ---------- main loop & boot ---------- */
function frame(now){
  requestAnimationFrame(frame);
  var dt=Math.min(0.05,Math.max(0,(now-game.last)/1000));game.last=now;
  if(game.state==='play')update(dt);
  else if(game.state==='dead')updateDead(dt);
  else if(game.state==='spec'){updateSpec(dt);}
  else if(game.state==='cinema'){updateCinema(dt);}
  else if(game.state==='wake'){updateWake(dt);}
  else if(game.state==='day'){updateDay(dt);}
  else if(game.state==='pad'){updatePad(dt);}
  else{
    if(game.state==='menu'){
      camera.position.set(24,1.7,20);camera.rotation.set(0,-Math.PI/2,0);
      torch.intensity=TORCH_I*S.bright*(0.85+0.15*Math.sin(now*0.003));
    }
    T0+=dt;animateMonsters(dt);
  }
  renderAll();
}
document.addEventListener('pointerlockerror',function(){toast('اسحب بالفأرة للنظر حولك',3000);});

function init(){
  makeTextures();buildShell();buildWalls();buildFurniture();buildDecor();buildStairs();buildFloor2();placeSpots();setBuild(0);buildGraph();
  hmGroup=buildHammerMan();gGroup=buildGiant();
  placeSpecials();buildExtras();dressHouse();buildHands();
  applyGfx();reset();
  game.last=performance.now();showMenu();
  requestAnimationFrame(frame);
}
var fontJob=Promise.resolve();
try{
  if(document.fonts&&document.fonts.load){
    fontJob=Promise.all([document.fonts.load('bold 96px Lalezar','اهرب'),document.fonts.load('16px Tajawal','ا')]);
  }
}catch(e){}
Promise.race([fontJob,new Promise(function(r){setTimeout(r,2000);})]).then(function(){
  try{init();}catch(err){fail('حدث خطأ أثناء تجهيز اللعبة: '+(err&&err.message));}
},function(){
  try{init();}catch(err){fail('حدث خطأ أثناء تجهيز اللعبة: '+(err&&err.message));}
});
/* boot fallback: if the loader is still shown after 6 s, offer a retry button */
(function(){var r=document.getElementById('ldRetry');if(r)r.addEventListener('click',function(){location.reload();});})();

/* ---------- cinematic ending ---------- */
var outPane=null, OUT=null, sunLight=null, sunSprite=null, CIN=null;
var cA=new THREE.Color(), cB=new THREE.Color();
var SKYS=[[0,0x04060c],[0.35,0x3a2a55],[0.7,0xff9a55],[1,0x8fb4d8]];
function skyAt(k,col){
  k=Math.max(0,Math.min(1,k));
  for(var i=0;i<SKYS.length-1;i++){
    if(k<=SKYS[i+1][0]){var f=(k-SKYS[i][0])/(SKYS[i+1][0]-SKYS[i][0]);cA.setHex(SKYS[i][1]);cB.setHex(SKYS[i+1][1]);col.copy(cA).lerp(cB,f);return;}
  }
  col.setHex(SKYS[SKYS.length-1][1]);
}
function ease(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
function lerp(a,b,k){return a+(b-a)*k;}
Snd.pad=function(freqs,dur,vol){
  if(!AC)return;var t=AC.currentTime;
  freqs.forEach(function(f){
    var o=AC.createOscillator(),g=AC.createGain();o.type='triangle';o.frequency.value=f;
    g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(vol,t+dur*0.4);g.gain.linearRampToValueAtTime(0.0001,t+dur);
    o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+0.1);
  });
};
Snd.kick=function(v){Snd.tone('sine',130,38,v,0.24);};
Snd.whoosh=function(){Snd.noise(0.28,0.45,2400);};

function buildOutdoor(){
  if(OUT)return;
  OUT=new THREE.Group();OUT.visible=false;scene.add(OUT);
  var gc=cnv(128,128),g=gc.getContext('2d');
  g.fillStyle='#34522d';g.fillRect(0,0,128,128);speckle(g,128,128,900,'rgba(0,25,0,A)',3);speckle(g,128,128,300,'rgba(130,170,90,A)',2);
  var gm=new THREE.Mesh(new THREE.PlaneGeometry(420,420),new THREE.MeshPhongMaterial({map:toTex(gc,90,90),shininess:1}));
  gm.rotation.x=-Math.PI/2;gm.position.set(30,-0.03,28);OUT.add(gm);
  var pm=new THREE.Mesh(new THREE.PlaneGeometry(70,3.4),matP(0x7a6a52));
  pm.rotation.x=-Math.PI/2;pm.position.set(95,0.02,ROOM.exit.cz);OUT.add(pm);
  var tg=new THREE.CylinderGeometry(0.25,0.32,2.6,6),cg=new THREE.ConeGeometry(1.7,3.4,7);
  var tm=matP(0x3a2a1c),c1=matP(0x1f3a22),c2=matP(0x2a4a2a);
  for(var i=0;i<90;i++){
    var x,z,tries=0;
    do{x=R(-110,150);z=R(-110,140);tries++;}while(tries<20&&((x>-9&&x<71&&z>-9&&z<65)||(x>58&&Math.abs(z-ROOM.exit.cz)<5)));
    var s=R(0.8,1.7),tr=new THREE.Group();
    var tk=new THREE.Mesh(tg,tm);tk.position.y=1.3;tr.add(tk);
    var a=new THREE.Mesh(cg,c1);a.position.y=3.6;tr.add(a);
    var b=new THREE.Mesh(cg,c2);b.position.y=5.0;b.scale.set(0.75,0.75,0.75);tr.add(b);
    tr.position.set(x,0,z);tr.scale.set(s,s,s);OUT.add(tr);
  }
  var wm=new THREE.MeshPhongMaterial({color:0x7d6c5a,shininess:2});
  function panel(w,h,d,x,y,z){var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),wm);m.position.set(x,y,z);OUT.add(m);}
  var H2=FY*2;
  panel(61,H2,0.1,30,H2/2,-0.25);panel(61,H2,0.1,30,H2/2,56.25);panel(0.1,H2,57,-0.25,H2/2,28);
  var dz=ROOM.exit.cz,hw=DOOR_W/2;
  panel(0.1,H2,dz-hw+0.25,60.3,H2/2,(dz-hw-0.25)/2);
  panel(0.1,H2,56.25-(dz+hw),60.3,H2/2,(dz+hw+56.25)/2);
  panel(0.1,H2-2.8,DOOR_W,60.3,2.8+(H2-2.8)/2,dz);
  var roof=new THREE.Mesh(new THREE.BoxGeometry(62,0.5,58),matP(0x2a2220));roof.position.set(30,H2+0.1,28);OUT.add(roof);
  sunSprite=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,color:0xffd29a,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}));
  sunSprite.scale.set(110,110,1);sunSprite.position.set(260,-10,ROOM.exit.cz);OUT.add(sunSprite);
  sunLight=new THREE.DirectionalLight(0xffc890,0);sunLight.position.set(200,40,32);scene.add(sunLight);
}
function setCap(html,cls){var c=$('cap');c.innerHTML=html;c.className=cls||'';c.style.opacity=html?1:0;}
function flash(v){$('flash').style.opacity=v;}
function startCinema(){
  game.state='cinema';
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  $('hud').hidden=true;$('prompt').style.opacity=0;$('cross').hidden=true;$('mapwrap').style.display='none';
  $('danger').style.opacity=0;$('slits').hidden=true;$('hit').style.opacity=0;
  buildOutdoor();OUT.visible=true;if(outPane)outPane.visible=false;
  CIN={t:0,fired:{},cap:-1,cut:-1};
  if(NET.room){hmGroup.visible=false;gGroup.visible=false;}
  else{
  H.x=58.8;H.z=ROOM.exit.cz;H.fl=0;H.gy=0;H.dx=1;H.dz=0;H.v=0;H.atk=0;H.state='patrol';hmGroup.visible=true;
  if(game.giantOn||!D.monsters){G.x=30;G.z=-14;G.dx=0;G.dz=1;G.v=0;gGroup.visible=D.monsters;}
  }
  redGlow.intensity=0;greenGlow.intensity=0;torch.intensity=0;
  scene.fog.density=0.004;
  $('bars').classList.add('on');$('skip').style.display='block';
  Snd.pad([220,261.6,329.6],5,0.05);
}
function skipCinema(){if(CIN&&CIN.t<26)CIN.t=26;}
function cinemaCleanup(){
  if(!OUT)return;
  OUT.visible=false;if(outPane)outPane.visible=true;
  if(sunLight)sunLight.intensity=0;
  scene.background.setHex(0x020202);scene.fog.color.setHex(0x030303);
  camera.fov=74;camera.updateProjectionMatrix();
  $('bars').classList.remove('on');$('skip').style.display='none';setCap('');flash(0);
  redGlow.intensity=D.monsters?0.9:0;
  applyGfx();
}
function stat(label,val){return label+'<small>'+val+'</small>';}
function updateCinema(dt){
  var C=CIN;if(!C)return;C.t+=dt;if(NET.room)simBackground(dt);var t=C.t,fov=74,u,k,ci;
  var cp=camera.position,cy=ROOM.exit.cz;
  if(t<4.5){
    u=t/4.5;k=ease(u);cp.set(lerp(57,74,k),1.6+Math.sin(t*9)*0.05,cy+Math.sin(t*4.5)*0.06);
    camera.lookAt(cp.x+8,1.5,cy);fov=lerp(74,100,u);flash(u>0.7?(u-0.7)/0.3:0);
    if(!C.fired.a){C.fired.a=1;Snd.kick(0.5);}
    if(u>0.15)setCap(u<0.9?stat('ركض إلى النور','الباب خلفك مفتوح'):'','');
  }else if(t<9){
    u=(t-4.5)/4.5;cp.set(lerp(66,72,u),lerp(0.35,0.6,u),lerp(36,34,u));
    camera.lookAt(58.6,1.5,cy);fov=lerp(62,50,u);flash(Math.max(0,1-(t-4.5)*2.5));
    if(!C.fired.b){C.fired.b=1;Snd.pad([174.6,220,261.6],5,0.05);Snd.tone('sawtooth',90,45,0.14,1.4);}
    if(t>6.6&&!NET.room){H.dx=-1;H.dz=0;H.v=Math.min(1.1,(t-6.6)*0.8);H.x-=H.v*dt;}
    setCap('لم يلحق بك','');
  }else if(t<14.5){
    u=(t-9)/5.5;k=ease(u);cp.set(lerp(74,100,k),lerp(1.2,30,k),lerp(32,18,k));
    camera.lookAt(58,lerp(2,6,k),30);fov=lerp(55,50,u);if(!NET.room)H.v=0;
    skyAt((t-9)/8,scene.background);scene.fog.color.copy(scene.background);
    var sk=ease((t-9)/8);sunSprite.position.y=lerp(-10,45,sk);sunLight.intensity=sk*1.2;amb.intensity=0.7+sk*0.9;
    if(!C.fired.c){C.fired.c=1;Snd.pad([261.6,329.6,392,523.3],6,0.06);}
    setCap(t>10?'الفجر':'','');
  }else if(t<20){
    var uu=(t-14.5)/1.1;ci=Math.min(4,Math.floor(uu));u=uu-ci;
    skyAt(0.9,scene.background);scene.fog.color.copy(scene.background);sunSprite.position.y=45;
    var shots=[[100,22,8,94,18,6,30,6,28],[30,48,-46,30,44,-40,30,4,28],[30,95,34,30,85,34,30,0,28],[66,2.4,26,64,2,28,60,1.8,cy],[-34,10,36,-30,10,30,30,5,28]];
    var s=shots[ci];cp.set(lerp(s[0],s[3],u),lerp(s[1],s[4],u),lerp(s[2],s[5],u));camera.lookAt(s[6],s[7],s[8]);
    fov=ci===3?60:64;
    if(C.cut!==ci){
      C.cut=ci;Snd.whoosh();Snd.kick(0.55);flash(0.7);
      var cards=[stat('⏱ الوقت',fmtTime(game.time)),stat('🔑 المفاتيح',AR_NUM(game.keys)+'/'+AR_NUM(game.need)),stat('🕳 اختبأت',AR_NUM(game.stats.hides)+' مرة'),stat('😱 طاردك الوحش',AR_NUM(game.stats.chases)+' مرة'),stat('🏠 بيت المطرقة','٢٧ غرفة · طابقان')];
      setCap(cards[ci],'');
    }
    flash(Math.max(0,0.7-u*2.2));
  }else{
    var a=0.6+(t-20)*0.12,kk=Math.min(1,(t-20)/8);
    skyAt(1,scene.background);scene.fog.color.copy(scene.background);
    cp.set(30+Math.cos(a)*95,lerp(22,36,kk),28+Math.sin(a)*95);camera.lookAt(30,6,28);fov=52;
    if(!C.fired.d){C.fired.d=1;Snd.pad([261.6,329.6,392,523.3,659.3],8,0.07);Snd.kick(0.7);flash(0.8);}
    if(t<24)setCap('نجوت<small>بيت المطرقة</small>','big');
    else if(t<26.5)setCap('تطوير Asoma Okazi','');
    else if(!C.fired.e){C.fired.e=1;setCap('');showEnd();}
    if(t<24.5)flash(Math.max(0,0.8-(t-20)*2));
  }
  if(camera.fov!==fov){camera.fov=fov;camera.updateProjectionMatrix();}
  H.phase=(H.phase||0);
  animateMonsters(dt);
}
function showEnd(){
  var sc=$('scr');
  showScreen('<h2 style="color:#6fbf73">هربت من البيت</h2><p class="lead">الوقت '+fmtTime(game.time)+' · المفاتيح '+AR_NUM(game.keys)+'/'+AR_NUM(game.need)+' · الاختباء '+AR_NUM(game.stats.hides)+' مرة</p><div class="btns"><button class="btn" id="go" type="button">العب مجددًا</button><button class="btn alt" id="menub" type="button">القائمة</button></div><p class="fine">تطوير: Asoma Okazi</p>');
  sc.style.background='linear-gradient(transparent,rgba(2,1,1,.85))';sc.style.alignItems='flex-end';
  bindGo(startGame);
}

$('skip').addEventListener('click',skipCinema);

/* ---------- multiplayer (room capability) ---------- */
var ROOMAPI=null;
var NET={hz:{},room:null,code:'',cfg:null,lastRnd:0,acc:0,ents:{},spec:0,unsub:null};
var STC=['patrol','search','investigate','chase','hideCheck'];
try{
  if(window.claude&&window.claude.use){
    window.claude.use('room').then(function(r){ROOMAPI=r||null;if(game.state==='menu'&&$('mp'))refreshMP();}).catch(function(){});
  }
}catch(e){}
function rng(seed){
  var a=seed>>>0;
  return function(){a=(a+0x6D2B79F5)>>>0;var t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function cleanName(n){n=String(n||'').replace(/[^\p{L}\p{N} _-]/gu,'').trim().slice(0,14);return n||'لاعب';}
function r2(v){return Math.round((v||0)*100)/100;}

function netPlayers(){
  var a=[];if(!NET.room)return a;
  NET.room.peers().forEach(function(p){if(p.kind==='viewer'&&p.presence&&p.presence.v===1)a.push(p);});
  return a;
}
function hostPeer(){
  var ps=netPlayers(),rd=ps.filter(function(p){var s=p.presence.st;return s==='play'||s==='dead'||s==='win';});
  var use=(rd.length&&game.state!=='menu')?rd:ps,h=null;
  use.forEach(function(p){if(!h||p.peer<h.peer)h=p;});
  return h;
}
function isHost(){if(!NET.room)return true;var h=hostPeer();return !h||(h.isMe&&h.sameTab);}
function mpPlayers(){
  var a=[];
  if(game.state==='play'||game.state==='pad')a.push(P);
  var k;for(k in NET.ents){if(NET.ents[k].alive)a.push(NET.ents[k]);}
  return a;
}

/* avatars */
function labelSprite(txt){
  var c=cnv(256,64),g=c.getContext('2d');
  g.font='bold 30px Tajawal, sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff';g.shadowColor='#000';g.shadowBlur=6;g.fillText(txt,128,34);
  var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true}));
  sp.scale.set(1.8,0.45,1);sp.position.y=2.25;return sp;
}
function makeAvatar(id,name){
  var g=new THREE.Group(),h=0,i;
  for(i=0;i<id.length;i++)h=(h*31+id.charCodeAt(i))%360;
  var shirt=new THREE.MeshPhongMaterial({color:new THREE.Color().setHSL(h/360,0.5,0.42),shininess:6});
  var pants=matP(0x2b2f3a),skin=matP(0xd8c0a8),hair=matP(0x221a14);
  function limb(x,y,len,w,mat){var p=new THREE.Group();p.position.set(x,y,0);var m=new THREE.Mesh(new THREE.BoxGeometry(w,len,w*1.1),mat);m.position.y=-len/2;p.add(m);return p;}
  var rig={legL:limb(-0.12,0.85,0.85,0.2,pants),legR:limb(0.12,0.85,0.85,0.2,pants),armL:limb(-0.33,1.42,0.62,0.16,shirt),armR:limb(0.33,1.42,0.62,0.16,shirt)};
  rig.torso=new THREE.Mesh(new THREE.BoxGeometry(0.5,0.62,0.28),shirt);rig.torso.position.y=1.16;
  var head=new THREE.Mesh(new THREE.SphereGeometry(0.2,14,10),skin);head.position.y=1.74;
  var hr=new THREE.Mesh(new THREE.SphereGeometry(0.215,14,8,0,Math.PI*2,0,Math.PI*0.55),hair);hr.position.y=1.76;
  g.add(rig.legL,rig.legR,rig.armL,rig.armR,rig.torso,head,hr);
  var lamp=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.06,0.2,8),matP(0x333333));lamp.position.y=-0.62;rig.armR.add(lamp);
  var beam=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.9,5,14,1,true),new THREE.MeshBasicMaterial({color:0xffe9b0,transparent:true,opacity:0.14,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide}));
  beam.position.y=-0.62-2.5;rig.armR.add(beam);beam.visible=false;
  var lbl=labelSprite(name);g.add(lbl);
  g.userData={name:name,lbl:lbl,rig:rig,beam:beam,ph:0};
  scene.add(g);return g;
}
function animAvatar(av,dt,e){
  var u=av.userData,r=u.rig;if(!r)return;
  var moving=e.spd>0.4;
  u.ph+=dt*(moving?(e.spd>4.2?9:7):0);
  var sw=moving?Math.sin(u.ph)*0.55:0;
  r.legL.rotation.x=sw;r.legR.rotation.x=-sw;
  r.armL.rotation.x=-sw*0.6;
  r.armR.rotation.x=e.torch?-1.25:sw*0.6;
  r.torso.position.y=e.crouch?0.9:1.16;
  av.scale.y=e.crouch?0.72:1;
  u.beam.visible=!!e.torch&&e.alive&&!e.hidden;
}
/* search markers: ring on the table a teammate is searching (shown ~2.5 s) */
function updateMarks(now){
  NET.marks=NET.marks||{};
  spots.forEach(function(s,i){
    if(!s.ring){
      var rg=new THREE.Mesh(new THREE.RingGeometry(0.32,0.42,28),new THREE.MeshBasicMaterial({color:0xffb347,transparent:true,opacity:0.9,depthWrite:false,side:THREE.DoubleSide}));
      rg.rotation.x=-Math.PI/2;scene.add(rg);s.ring=rg;
    }
    var on=!!NET.room&&(NET.marks[i]||0)>now;
    s.ring.visible=on;
    if(on)s.ring.position.set(s.x,(s.fl?FY:0)+0.98,s.z);
  });
}
function relabel(av,name){
  av.remove(av.userData.lbl);var l=labelSprite(name);av.add(l);av.userData.lbl=l;av.userData.name=name;
}
function clearNet(){
  var k;for(k in NET.ents){if(NET.ents[k].av)scene.remove(NET.ents[k].av);}
  NET.ents={};
}

/* per-frame sync */
function netSync(dt){
  if(!NET.room)return;
  var seen={},now=Date.now(),anyDoor=false,found={};
  NET.room.peers().forEach(function(p){
    var pr=p.presence;
    if(!pr||pr.v!==1||p.kind!=='viewer')return;
    if(pr.rd===game.rnd){
      if(pr.sr)pr.sr.forEach(function(i){found[i]=1;});
      if(pr.dr)anyDoor=true;
      if(pr.fx)game.fixed=true;
      if(pr.so)game.safeOpen=true;
      if(!(p.isMe&&p.sameTab)){
        var hk=NET.hz[p.peer];
        if(!hk||hk.rd!==pr.rd){NET.hz[p.peer]={rd:pr.rd,n:pr.hz||0};}
        else if((pr.hz||0)>hk.n){hk.n=pr.hz;if(isHost())applyHit(pr.ht);}
      }
    }
    if(p.isMe&&p.sameTab)return;
    if(pr.sg!==undefined&&pr.sg>=0&&pr.rd===game.rnd&&spots[pr.sg]){NET.marks=NET.marks||{};var wasOn=NET.marks[pr.sg]>now;NET.marks[pr.sg]=now+2500;if(!wasOn&&game.state==='play'&&!spots[pr.sg].searched)toast('زميلك يفتّش على الطاولة المحددة',2000);}
    var id=p.peer;seen[id]=1;
    var e=NET.ents[id];
    if(!e)e=NET.ents[id]={x:pr.x||0,z:pr.z||0,fl:pr.fl||0,gy:pr.y||0,hidden:null,crouch:false,torch:true,noise:0,alive:false,st:'lobby',yaw:0,px:pr.x||0,pz:pr.z||0,pt:now,last:null,name:'',av:null,spd:0};
    if(e.last!==pr){
      var dtp=(now-e.pt)/1000;
      if(dtp>0.04){var sp=Math.hypot((pr.x||0)-e.px,(pr.z||0)-e.pz)/dtp;e.noise=sp>0.4?(sp>4.2?14:(pr.c?2.5:7)):0;e.spd=sp;e.px=pr.x||0;e.pz=pr.z||0;e.pt=now;}
      e.last=pr;
    }
    var k=Math.min(1,dt*12),tx=pr.x||0,tz=pr.z||0;
    if(Math.hypot(tx-e.x,tz-e.z)>5){e.x=tx;e.z=tz;}else{e.x+=(tx-e.x)*k;e.z+=(tz-e.z)*k;}
    e.fl=pr.fl||0;e.gy=pr.y||0;e.yaw=pr.a||0;
    e.hidden=(pr.h>=0&&closets[pr.h])?closets[pr.h]:null;
    e.crouch=!!pr.c;e.torch=!!pr.t;e.st=pr.st||'lobby';e.alive=(e.st==='play');e.name=pr.n||'لاعب';
    if(now-e.pt>700)e.noise=0;
    if(!e.av)e.av=makeAvatar(id,e.name);
    if(e.av.userData.name!==e.name)relabel(e.av,e.name);
    e.av.position.set(e.x,e.gy,e.z);e.av.rotation.y=e.yaw+Math.PI;e.av.visible=e.alive&&!e.hidden;animAvatar(e.av,dt,e);
  });
  Object.keys(NET.ents).forEach(function(id){
    if(!seen[id]){var e=NET.ents[id];if(e.av)scene.remove(e.av);delete NET.ents[id];}
  });
  spots.forEach(function(s,i){if(found[i]&&!s.searched)markSearched(s);});
  updateMarks(now);
  syncTools();
  var kc=0;spots.forEach(function(s){if(s.key&&s.searched)kc++;});
  if(kc>game.keys&&(game.state==='play'||game.state==='spec'))toast('زميلك وجد مفتاحًا ('+AR_NUM(kc)+'/'+AR_NUM(game.need)+')',2200);
  game.keys=kc;
  if(anyDoor&&!game.doorOpen){openExit();if(game.state==='play')toast('زميلك فتح الباب الحديدي!',2500);}
}
function packMon(){
  var sc=STC.indexOf(H.state);
  return {
    h:[r2(H.x),r2(H.z),H.fl||0,r2(H.dx),r2(H.dz),r2(H.v),sc<0?0:sc,r2(Math.max(0,H.atk)),r2(H.atkAnim),H.catch===undefined?-1:H.catch],
    g:[r2(G.x),r2(G.z),r2(G.dx),r2(G.dz),r2(G.v),r2(Math.max(0,G.atk)),r2(G.atkAnim)]
  };
}
function netTick(dt){
  if(!NET.room)return;
  NET.acc+=dt;if(NET.acc<0.1)return;NET.acc=0;
  var sr=[];spots.forEach(function(s,i){if(s.searched)sr.push(i);});
  var gs=game.state,st=(gs==='play'||gs==='pad'||gs==='wake'||(gs==='day'&&!game.dayDeath))?'play':((gs==='dead'||gs==='spec'||gs==='day')?'dead':(gs==='cinema'?'win':'lobby'));
  var pr={v:1,n:S.name||'لاعب',st:st,rd:game.rnd||0,x:r2(P.x),z:r2(P.z),y:r2(P.gy),a:r2(P.yaw),fl:P.fl||0,
    h:P.hidden?closets.indexOf(P.hidden):-1,c:P.crouch?1:0,t:P.torch?1:0,sr:sr,dr:game.doorOpen?1:0,fx:game.fixed?1:0,so:game.safeOpen?1:0,hz:game.hitSeq||0,ht:game.hitType||'h',sg:(game.lastSearchT&&Date.now()-game.lastSearchT<2500)?game.lastSearchI:-1};
  if(D.monsters&&isHost()){var m=packMon();pr.m=m;}
  NET.room.presence(pr).catch(function(){});
}
function netApplyMon(dt){
  var hp=hostPeer();if(!hp||(hp.isMe&&hp.sameTab))return;
  var m=hp.presence.m;if(!m)return;
  var k=Math.min(1,dt*10),h=m.h,g=m.g;
  if(h&&D.monsters){
    if(Math.hypot(h[0]-H.x,h[1]-H.z)>6){H.x=h[0];H.z=h[1];}else{H.x+=(h[0]-H.x)*k;H.z+=(h[1]-H.z)*k;}
    H.fl=h[2];H.dx=h[3];H.dz=h[4];H.v=h[5];
    var ns=STC[h[6]]||'patrol';
    if(ns==='chase'&&H.state!=='chase'&&dist2(H,P)<25&&game.state==='play')Snd.sting();
    H.state=ns;H.atk=h[7];H.atkAnim=h[8];H.catch=h[9];updFloor(H);
  }
  if(g&&game.giantOn){
    if(Math.hypot(g[0]-G.x,g[1]-G.z)>6){G.x=g[0];G.z=g[1];}else{G.x+=(g[0]-G.x)*k;G.z+=(g[1]-G.z)*k;}
    G.dx=g[2];G.dz=g[3];G.v=g[4];G.atk=g[5];G.atkAnim=g[6];
    G.phase+=dt*G.v*1.9;giantSteps();
  }
}
function simBackground(dt){
  updateDoors(dt);
  netSync(dt);
  var host=isHost();
  if(D.monsters){if(host){pickTarget();updateHammerMan(dt);}else netApplyMon(dt);}
  if(game.giantOn){if(host)updateGiant(dt);else if(!D.monsters)netApplyMon(dt);}
  netTick(dt);
}
function openExit(){
  game.doorOpen=true;
  var i=FL[0].co.indexOf(exitBox);if(i>=0)FL[0].co.splice(i,1);
  var j=FL[0].bl.indexOf(exitBox);if(j>=0)FL[0].bl.splice(j,1);
  Snd.door();
  if(D.monsters&&H.state!=='chase'&&isHost()&&game.state==='play'){H.state='investigate';setGoal(H,P.x,P.z,P.fl);H.wait=0;}
}

/* spectating and round end */
function specTarget(){
  var l=mpPlayers().filter(function(e){return e!==P;});
  if(!l.length)return null;
  return l[((NET.spec%l.length)+l.length)%l.length];
}
function updateSpec(dt){
  T0+=dt;game.time+=dt;
  simBackground(dt);
  var t=specTarget();
  if(t){
    camera.position.set(t.x,(t.gy||0)+1.6,t.z);camera.rotation.set(0,t.yaw||0,0);
    var pe=$('prompt');pe.innerHTML='<b>E</b>تتابع: '+esc(t.name||'لاعب');pe.style.opacity=1;
  }else if(!game.specEnd){game.specEnd=true;showRoundEnd();}
  animateMonsters(dt);
}
function goSpec(){
  hideScreen();game.state='spec';game.specEnd=false;NET.spec=0;
  $('hit').style.opacity=0;$('hud').hidden=true;$('prompt').hidden=false;
}
function showDeathMP(){
  if(!NET.room)return false;
  var alive=mpPlayers().filter(function(e){return e!==P;}).length;
  if(alive===0)return false;
  var msg={hammer:'حطّمتك المطرقة',giant:'سحقك العملاق',closet:'اكتشف مخبأك'}[game.killer]||'سقطت';
  $('hud').hidden=true;$('prompt').style.opacity=0;$('slits').hidden=true;
  showScreen('<h2>'+msg+'</h2><p class="lead">سقطت، لكن زملاءك ما زالوا يقاتلون ('+AR_NUM(alive)+').</p><div class="btns"><button class="btn" id="spec" type="button">تابع زملاءك</button><button class="btn alt" id="menub" type="button">القائمة</button></div>');
  $('spec').addEventListener('click',goSpec);bindGo(function(){});
  return true;
}
function showRoundEnd(){
  var ps=netPlayers(),won=ps.filter(function(p){return p.presence.st==='win';}).length;
  $('prompt').style.opacity=0;
  showScreen('<h2>انتهت الجولة</h2><p class="lead">نجا '+AR_NUM(won)+' من '+AR_NUM(ps.length)+' لاعبين.</p><div class="btns"><button class="btn" id="go" type="button">جولة جديدة</button><button class="btn alt" id="menub" type="button">القائمة</button></div>');
  bindGo(startGame);
}

/* menu */
function playerNames(){
  return netPlayers().map(function(p){return esc(p.presence.n||'لاعب')+((p.isMe&&p.sameTab)?' (أنت)':'');}).join('، ');
}
function mpBadge(){
  if(NET.room)return '<p class="fine">👥 أنت في غرفة <b>'+esc(NET.code)+'</b> ('+AR_NUM(netPlayers().length)+' لاعبين)</p>';
  return '';
}
function mpHTML(){
  if(window.LANMODE&&!NET.room)return window.lanHTML();
  if(!ROOMAPI)return '<div class="mpst bad"><b>اللعب الجماعي غير متاح الآن</b><span>يعمل فقط عند فتح اللعبة من حساب مدعو: اضغط «Share» (مشاركة) أعلى الصفحة، أرسل الرابط لأصدقائك، ثم افتحوه جميعًا.</span></div><button class="btn" id="mpGo" type="button">العب منفردًا</button>';
  if(NET.room){
    var hint=window.lanRoomHint?window.lanRoomHint():'';
    var hp=hostPeer(),list=netPlayers().map(function(p){
      return '<li>'+esc(p.presence.n||'لاعب')+((p.isMe&&p.sameTab)?' <small>(أنت)</small>':'')+((hp&&hp.peer===p.peer)?' <small class="host">منشئ الجولة</small>':'')+'</li>';}).join('');
    return hint+'<div class="mpst ok"><b>غرفة: '+esc(NET.code)+'</b><span>اللاعبون ('+AR_NUM(netPlayers().length)+'):</span><ul class="plist">'+list+'</ul>'+
      '<span>'+(isHost()?'أنت منشئ الجولة: اضغط «ابدأ الجولة» ليدخل الجميع.':'انتظر منشئ الغرفة ثم اضغط «ابدأ الجولة».')+'</span></div>'+
      '<div class="btns"><button class="btn" id="mpGo" type="button">ابدأ الجولة</button><button class="btn alt" id="mpLeave" type="button">مغادرة الغرفة</button></div>';
  }
  return '<div class="mpst ok"><b>متصل بخدمة اللعب الجماعي</b><span>اكتب اسمك ورمز غرفة يتفق عليه أصدقاؤك (حروف إنجليزية أو أرقام)، ثم انضموا.</span></div>'+
    '<div class="mpf"><input id="mpName" maxlength="14" placeholder="اسمك" value="'+esc(S.name||'')+'"><input id="mpCode" maxlength="20" placeholder="رمز الغرفة مثل: home1" dir="ltr"></div>'+
    '<div class="btns"><button class="btn" id="mpJoin" type="button">انضم إلى الغرفة</button><button class="btn alt" id="mpGo" type="button">العب منفردًا</button></div>';
}
function refreshMP(){var m=$('mp');if(!m)return;m.innerHTML=mpHTML();bindMP();}
function bindMP(){
  var j=$('mpJoin'),l=$('mpLeave'),g=$('mpGo');
  if(g)g.addEventListener('click',startGame);
  if(j)j.addEventListener('click',mpJoin);
  if(l)l.addEventListener('click',mpLeave);
}
function mpJoin(){
  var code=($('mpCode').value||'').toLowerCase().replace(/[^a-z0-9_.-]/g,'').replace(/^[^a-z0-9]+/,'').slice(0,20);
  if(!code){toast('اكتب رمز الغرفة بحروف إنجليزية أو أرقام',2400);return;}
  S.name=cleanName($('mpName').value);saveS();
  ROOMAPI.join('hh-'+code).then(function(r){
    NET.room=r;NET.code=code;NET.lastRnd=0;
    NET.unsub=r.onPeers(function(){if(game.state==='menu')refreshMP();},function(){});
    r.presence({v:1,n:S.name,st:'lobby'}).catch(function(){});
    refreshMP();
  }).catch(function(e){toast(window.LANMODE?'تعذّر الاتصال بالمضيف ('+((e&&e.message)||'خطأ')+'). تأكد أنه يستضيف الجولة وأنك على نفس نقطة الاتصال.':'تعذّر الانضمام إلى الغرفة. تأكد أن الرابط مشارك معك.',4200);});
}
function mpLeave(){
  var r=NET.room;NET.room=null;
  if(NET.unsub){try{NET.unsub();}catch(e){}NET.unsub=null;}
  if(r)r.leave().catch(function(){});
  clearNet();refreshMP();
}
function mpPrepare(){
  if(NET.room){
    var hp=hostPeer(),host=isHost(),cfg;
    if(host){cfg={diff:S.diff,seed:(Math.random()*4294967295)>>>0,rnd:Date.now()};}
    else{
      cfg=hp&&hp.presence.cfg;
      if(!cfg||cfg.rnd===NET.lastRnd){toast('بانتظار منشئ الغرفة ليبدأ الجولة',2500);return false;}
    }
    NET.cfg=cfg;NET.lastRnd=cfg.rnd;D=DIFF[cfg.diff]||DIFF.med;game.seed=cfg.seed;game.rnd=cfg.rnd;
    if(host)NET.room.presence({cfg:cfg,v:1,n:S.name||'لاعب',st:'lobby',rd:cfg.rnd}).catch(function(){});
    return true;
  }
  D=DIFF[S.diff]||DIFF.med;game.seed=(Math.random()*4294967295)>>>0;game.rnd=0;
  return true;
}

/* ========== p9a: items, tools, safe, light switch, gun, hands ========== */
var DAYS=6,hs=null,hcam=null,HND={t:0,sx:0,sy:0,rec:0,flashT:0};
var gunFlash=null,lampLights=[],lampBulbs=[],lampOn=false,fogBase=0.05;
var SW={x:17.5,y:1.35,z:16.3},SAFE={x:35,z:0.5},NOTE={x:17,y:1.02,z:0.8};
var safeObj=null,padBuf='';

function markSearched(s){s.searched=true;if(s.keyMesh)s.keyMesh.visible=false;if(s.hide)s.obj.visible=false;else s.mat.color.setHex(0x5a5048);}

/* ---- special chests (deliberate corners) and table items ---- */
function placeSpecials(){
  function room(id){var r=null;ROOMS.concat(ROOMS2).forEach(function(q){if(q.id===id)r=q;});return r;}
  function corner(id,label,item,col){
    var r=room(id);if(!r)return;
    setBuild(r.fl);
    var cand=[[r.x2-1.1,r.z2-1.1],[r.x1+1.1,r.z2-1.1],[r.x2-1.1,r.z1+1.1],[r.x1+1.1,r.z1+1.1]],i,p,clash,spot=null;
    function ok(p,strict){
      if(strict)for(var k=0;k<spots.length;k++)if(spots[k].fl===r.fl&&Math.hypot(spots[k].x-p[0],spots[k].z-p[1])<1.8)return false;
      return freeAt(p[0],p[1],0.55,0.4,0.45);
    }
    for(i=0;i<cand.length&&!spot;i++)if(ok(cand[i],true))spot=cand[i];
    for(i=0;i<cand.length&&!spot;i++)if(ok(cand[i],false))spot=cand[i];
    if(!spot){for(var x=r.x1+1;x<r.x2-1&&!spot;x+=1)for(var z=r.z1+1;z<r.z2-1&&!spot;z+=1)if(ok([x,z],false))spot=[x,z];}
    if(!spot)return;
    addSpot(r.fl,spot[0],spot[1],label,col,'chest');
    var s=spots[spots.length-1];s.special=true;s.item=item;
  }
  corner('nur','افتح الصندوق الحديدي','gun',0x6a6a72);
  corner('laun','ابحث في الصندوق','ham',0x7a6a52);
  addTableItem(25.1,0.92,4.35,'خذ الرصاص من فوق الطاولة');
  addTableItem(27.6,0.92,37.0,'خذ الرصاص من فوق الطاولة');
  setBuild(0);
}
function addTableItem(x,y,z,label){
  setBuild(0);
  var g=new THREE.Group(),mat=new THREE.MeshPhongMaterial({color:0x4a5a34,shininess:20});
  g.add(mk(new THREE.BoxGeometry(0.3,0.12,0.2),mat,0,0.06,0));
  g.add(mk(new THREE.BoxGeometry(0.32,0.02,0.22),matP(0x2a3220),0,0.125,0));
  var bm=new THREE.MeshPhongMaterial({color:0xc8a040,shininess:80,specular:0xffffff});
  for(var i=0;i<3;i++){var b=mk(new THREE.CylinderGeometry(0.014,0.014,0.07,8),bm,-0.08+i*0.08,0.016+0.0,0.2);b.rotation.z=Math.PI/2;g.add(b);}
  var gl=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,color:0xffd070}));
  gl.scale.set(0.6,0.6,1);gl.position.y=0.15;g.add(gl);
  g.position.set(x,y,z);CURG.add(g);
  spots.push({fl:0,x:x,z:z,label:label,obj:g,mat:mat,col:0x4a5a34,searched:false,key:false,item:'ammo',n:3,special:true,hide:true,r:2.6});
}
function takeItem(sp){
  Snd.chime();
  if(sp.item==='gun'){P.gun=true;P.ammo+=2;toast('وجدت مسدسًا! فيه رصاصتان — اضغط Q أو النقر للإطلاق. ابحث عن بقية الرصاص فوق الطاولات.',4600);}
  else if(sp.item==='ammo'){P.ammo+=sp.n;toast('أخذت '+AR_NUM(sp.n)+' رصاصات (المجموع '+AR_NUM(P.ammo)+')',2400);}
  else if(sp.item==='ham'){game.ham=true;toast('وجدت مطرقة صغيرة — تفيد في إصلاح الباب الحديدي',3200);}
}
function syncTools(){spots.forEach(function(s){if(s.item==='ham'&&s.searched)game.ham=true;});if(game.safeOpen)game.sd=true;}

/* ---- scene extras: light switch, hall lamps, safe, note ---- */
function buildExtras(){
  setBuild(0);
  var sw=new THREE.Group();
  sw.add(mk(new THREE.BoxGeometry(0.17,0.26,0.05),matP(0xd8d0bc,30),0,0,0));
  sw.add(mk(new THREE.BoxGeometry(0.04,0.1,0.05),matP(0x2a2a2a),0,0.03,0.04));
  sw.add(mk(new THREE.SphereGeometry(0.018,8,8),new THREE.MeshBasicMaterial({color:0x44ff77}),0,-0.09,0.03));
  sw.position.set(SW.x,SW.y,SW.z);CURG.add(sw);
  var gl=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,color:0x66ff99}));
  gl.scale.set(0.5,0.5,1);gl.position.set(SW.x,SW.y-0.09,SW.z-0.05);CURG.add(gl);
  [8,24,40,54].forEach(function(x){
    var lp=new THREE.PointLight(0xffd9a0,0,26,1.6);lp.position.set(x,4.2,17.4);CURG.add(lp);lampLights.push(lp);
    var arm=mk(new THREE.BoxGeometry(0.1,0.1,0.35),matP(0x2a2018),x,3.55,16.35);CURG.add(arm);
    var bulb=mk(new THREE.SphereGeometry(0.17,10,8),new THREE.MeshBasicMaterial({color:0x2a2418}),x,3.62,16.55);CURG.add(bulb);lampBulbs.push(bulb);
    var sh=mk(new THREE.ConeGeometry(0.3,0.34,12,1,true),new THREE.MeshPhongMaterial({color:0x6a5238,side:THREE.DoubleSide,shininess:4}),x,3.78,16.55);CURG.add(sh);
  });
  /* الخزنة */
  var g=new THREE.Group(),steel=new THREE.MeshPhongMaterial({color:0x3c4048,shininess:60,specular:0x888888}),brass=new THREE.MeshPhongMaterial({color:0xb58a3a,shininess:60,specular:0xffffff});
  g.add(mk(new THREE.BoxGeometry(1.0,1.15,0.6),steel,0,0.575,0));
  var inner=mk(new THREE.BoxGeometry(0.84,0.99,0.5),matP(0x0e0e10),0,0.575,0.06);g.add(inner);
  var piv=pivot(-0.42,0,0.3);
  piv.add(mk(new THREE.BoxGeometry(0.86,1.0,0.06),new THREE.MeshPhongMaterial({color:0x4a4e58,shininess:80,specular:0xaaaaaa}),0.43,0.575,0.03));
  var dial=mk(new THREE.CylinderGeometry(0.1,0.1,0.05,20),brass,0.43,0.72,0.075);dial.rotation.x=Math.PI/2;piv.add(dial);
  piv.add(mk(new THREE.BoxGeometry(0.26,0.05,0.05),brass,0.43,0.42,0.08));
  var led=mk(new THREE.BoxGeometry(0.07,0.035,0.02),new THREE.MeshBasicMaterial({color:0xff2a1a}),0.7,0.95,0.065);piv.add(led);
  g.add(piv);
  var sd=new THREE.Group();
  var shaft=mk(new THREE.CylinderGeometry(0.012,0.012,0.22,8),new THREE.MeshPhongMaterial({color:0x9a9aa2,shininess:70}),0,0,0);shaft.rotation.z=Math.PI/2;sd.add(shaft);
  var hnd=mk(new THREE.CylinderGeometry(0.03,0.026,0.13,10),matP(0xc03020,20),-0.17,0,0);hnd.rotation.z=Math.PI/2;sd.add(hnd);
  sd.position.set(0.1,0.12,0.1);g.add(sd);
  g.position.set(SAFE.x,0,SAFE.z+0.3);CURG.add(g);
  box1(SAFE.x-0.6,SAFE.x+0.6,0,SAFE.z+0.65);
  safeObj={g:g,piv:piv,sd:sd,led:led};
  /* الورقة (رمز الخزنة) فوق طاولة المطبخ الجانبية */
  var note=new THREE.Group();
  note.add(mk(new THREE.BoxGeometry(0.28,0.006,0.2),new THREE.MeshPhongMaterial({color:0xd8cfae,shininess:2}),0,0,0));
  var ng=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,color:0xffe0a0}));ng.scale.set(0.5,0.5,1);ng.position.y=0.1;note.add(ng);
  note.position.set(NOTE.x,NOTE.y,NOTE.z);note.rotation.y=0.4;CURG.add(note);
  /* لوحة أرقام الخزنة */
  var grid=$('padGrid');
  if(grid&&!grid.children.length){
    ['1','2','3','4','5','6','7','8','9','⌫','0','✓'].forEach(function(k){
      var b=document.createElement('button');b.type='button';b.textContent=k;b.addEventListener('click',function(){padKey(k);});grid.appendChild(b);
    });
    $('padX').addEventListener('click',function(){closePad(true);});
    window.addEventListener('keydown',function(e){
      if(game.state!=='pad')return;
      if(e.code==='Escape'){closePad(true);e.preventDefault();return;}
      if(/^[0-9]$/.test(e.key))padKey(e.key);else if(e.code==='Backspace')padKey('⌫');
    });
  }
  setBuild(0);
}
function resetExtras(){
  game.day=1;game.dayFinal=false;game.dayDeath=false;
  game.fixed=false;game.safeOpen=false;game.ham=false;game.sd=false;game.codeKnown=false;
  game.lightT=0;game.hitSeq=0;game.hitType='h';game.fireCD=0;game.noiseT=0;game.extraNoise=0;game.repairing=false;game.fixT=0;
  game.code=100+Math.floor(rng((game.seed||1)^0x51ed)()*900);
  if(safeObj){safeObj.piv.rotation.y=0;safeObj.sd.visible=true;safeObj.led.material.color.setHex(0xff2a1a);}
  if(lampOn)scene.fog.density=fogBase;
  lampOn=false;lampLights.forEach(function(l){l.intensity=0;});lampBulbs.forEach(function(b){b.material.color.setHex(0x2a2418);});
  amb.intensity=0.7*S.bright;
  var inv=$('inv');if(inv)inv.hidden=true;
  closePad(false);
}

/* ---- interaction targets ---- */
function extraTarget(){
  if(P.fl!==0)return null;
  var x=P.x,z=P.z;
  if(Math.hypot(SW.x-x,SW.z-z)<2.0)return {type:'x',label:game.lightT>0?'الأضواء مضاءة':'تشغيل الضوء',run:toggleLight};
  if(!game.safeOpen&&Math.hypot(SAFE.x-x,SAFE.z+0.5-z)<2.1)return {type:'x',label:'الخزنة — إدخال الرمز',run:openPad};
  if(Math.hypot(NOTE.x-x,NOTE.z-z)<2.0)return {type:'x',label:'قراءة الورقة',run:readNote};
  if(exitBox&&exitBox.door&&!game.doorOpen&&!game.fixed&&distBox(x,z,exitBox)<2.2){
    if(game.ham&&game.sd)return {type:'x',label:game.repairing?'جارٍ الإصلاح…':'إصلاح قفل الباب بالمفك والمطرقة',run:startRepair};
    var need=[];if(!game.ham)need.push('مطرقة');if(!game.sd)need.push('مفك');
    return {type:'x',label:'قفل الباب محطّم — تحتاج '+need.join(' و'),run:function(){Snd.bang();toast('الباب الحديدي يحتاج إصلاحًا: '+need.join(' و')+'. المفك داخل الخزنة والمطرقة في صندوق.',3000);}};
  }
  return null;
}
function toggleLight(){
  if(game.lightT>0){toast('الضوء مضاء بالفعل',1200);return;}
  game.lightT=10;game.noiseT=0.5;Snd.tone('square',320,180,0.14,0.08);setTimeout(function(){Snd.tone('square',200,140,0.1,0.06);},70);
  toast('أُضيء الممر — عشر ثوانٍ فقط',2400);
}
function readNote(){
  game.codeKnown=true;toast('ورقة بخط مرتعش: «رمز الخزنة '+AR_NUM(game.code)+'»',4200);
  Snd.creak(0.06);
}
function openPad(){
  if(game.state!=='play')return;
  game.state='pad';padBuf='';
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  var p=$('pad');p.hidden=false;p.style.display='flex';p.className='screen';padRender();
}
function closePad(back){
  var p=$('pad');if(!p)return;
  p.hidden=true;p.style.display='none';
  if(game.state==='pad'){game.state='play';game.last=performance.now();if(back!==false)requestLock();}
}
function padRender(){
  var s='';for(var i=0;i<3;i++)s+=(i<padBuf.length?padBuf.charAt(i):'-')+(i<2?' ':'');
  $('padDisp').textContent=s;
}
function padKey(k){
  if(game.state!=='pad')return;
  if(k==='⌫'){padBuf=padBuf.slice(0,-1);padRender();return;}
  if(k==='✓'){if(padBuf.length<3)return;}
  else if(padBuf.length<3)padBuf+=k;
  padRender();Snd.tone('square',700+padBuf.length*80,700,0.06,0.05);
  if(padBuf.length===3){
    var p=$('pad'),good=(padBuf===String(game.code));
    setTimeout(function(){
      if(game.state!=='pad')return;
      if(good){
        p.className='screen ok';Snd.chime();game.safeOpen=true;syncTools();
        setTimeout(function(){closePad(true);toast('انفتحت الخزنة! وجدت مفكًّا',3200);},650);
      }else{
        p.className='screen bad';Snd.bang();padBuf='';
        setTimeout(function(){p.className='screen';padRender();},450);
      }
    },200);
  }
}
function startRepair(){
  if(game.repairing)return;
  game.repairing=true;game.fixT=0;toast('جارٍ إصلاح القفل… ابقَ قرب الباب (الضجيج قد يجذب الرجل)',3200);
}
function updateRepair(dt){
  if(!game.repairing)return;
  if(P.hidden||P.fl!==0||distBox(P.x,P.z,exitBox)>2.6){game.repairing=false;toast('توقف الإصلاح',1500);return;}
  game.fixT+=dt;
  game.rep2=(game.rep2||0)-dt;
  if(game.rep2<=0){game.rep2=0.55;Snd.tone('square',900,700,0.12,0.04);Snd.noise(0.2,0.06,1800);}
  if(game.fixT>=3){game.repairing=false;game.fixed=true;Snd.door();toast('تم إصلاح القفل! افتح الباب بالمفاتيح',3200);}
}

/* ---- gun ---- */
function applyHit(type){
  if(type==='g'){if(game.giantOn&&G)G.stun=3;}
  else if(D.monsters&&H){H.stun=6;}
}
function fire(){
  if(game.state!=='play'||!P.gun||P.hidden)return;
  if(game.fireCD>0)return;
  if(P.ammo<=0){game.fireCD=0.5;Snd.tone('square',1400,900,0.08,0.03);toast('لا توجد رصاصات — ابحث فوق الطاولات',1600);return;}
  P.ammo--;game.fireCD=0.6;HND.rec=1;HND.flashT=0.07;game.noiseT=0.7;game.shake+=0.25;
  Snd.shot();
  if(gunFlash){gunFlash.position.set(camera.position.x-Math.sin(P.yaw)*0.8,camera.position.y-0.1,camera.position.z-Math.cos(P.yaw)*0.8);}
  var dx=-Math.sin(P.yaw),dz=-Math.cos(P.yaw),hit=null;
  function test(M,rad,type){
    if(!M||M.x>150||(M.fl||0)!==P.fl)return;
    var vx=M.x-P.x,vz=M.z-P.z,al=vx*dx+vz*dz;
    if(al<0.4||al>34)return;
    if(Math.abs(vx*dz-vz*dx)>rad)return;
    if(blocked(P.x,P.z,M.x,M.z,P.fl))return;
    if(!hit||al<hit.al)hit={type:type,al:al};
  }
  if(D.monsters&&hmGroup.visible)test(H,0.75,'h');
  if(game.giantOn)test(G,1.3,'g');
  if(hit){
    if(!NET.room||isHost())applyHit(hit.type);
    else{game.hitSeq++;game.hitType=hit.type;}
    toast(hit.type==='g'?'أصبت العملاق! توقف لثوانٍ':'أصبته! سقط على ركبتيه لثوانٍ',1800);
    $('hit').style.opacity=0.25;setTimeout(function(){if(game.state==='play')$('hit').style.opacity=0;},90);
  }
  if(!NET.room||isHost()){if(D.monsters&&H.state!=='chase'&&dist2(H,P)<26&&H.stun<=0){H.state='investigate';setGoal(H,P.x,P.z,P.fl);H.wait=0;}}
}
Snd.shot=function(){Snd.noise(0.9,0.3,3000);Snd.tone('square',220,40,0.4,0.22);Snd.noise(0.5,0.7,350);};

/* ---- lights ---- */
function updateLights(dt){
  var f=0;
  if(game.lightT>0){
    game.lightT-=dt;
    if(!lampOn){lampOn=true;fogBase=scene.fog.density;}
    f=game.lightT>2?1:(Math.random()<0.55?1:0.08);
    if(game.lightT<=0){game.lightT=0;f=0;Snd.tone('square',200,120,0.12,0.1);}
  }
  if(game.lightT>0||lampOn){
    lampLights.forEach(function(l){l.intensity=2.3*f*S.bright;});
    lampBulbs.forEach(function(b){b.material.color.setHex(f>0.5?0xffe6aa:0x2a2418);});
    amb.intensity=(0.7+0.5*f)*S.bright;
    scene.fog.density=fogBase*(1-0.5*f);
    if(game.lightT<=0){lampOn=false;scene.fog.density=fogBase;amb.intensity=0.7*S.bright;}
  }
}
function updateSafe(dt){
  if(!safeObj)return;
  var tg=game.safeOpen?-1.8:0;
  safeObj.piv.rotation.y+=(tg-safeObj.piv.rotation.y)*Math.min(1,dt*4);
  safeObj.sd.visible=!game.safeOpen||safeObj.piv.rotation.y>-1.0;
  safeObj.led.material.color.setHex(game.safeOpen?0x30ff60:0xff2a1a);
  if(game.safeOpen&&safeObj.piv.rotation.y<-1.0)safeObj.sd.visible=false;
}
function extraUpdate(dt){
  game.fireCD=Math.max(0,(game.fireCD||0)-dt);
  game.noiseT=Math.max(0,(game.noiseT||0)-dt);
  game.extraNoise=Math.max(game.noiseT>0?20:0,game.repairing?9:0);
  if(gunFlash){gunFlash.intensity=HND.flashT>0?5*HND.flashT/0.07:0;}
  HND.flashT=Math.max(0,HND.flashT-dt);
  updateLights(dt);updateSafe(dt);updateRepair(dt);updateHands(dt);syncTools();
  var inv=$('inv'),t=[];
  if(P.gun)t.push('🔫 '+AR_NUM(P.ammo));else if(P.ammo>0)t.push('رصاص '+AR_NUM(P.ammo));
  if(game.ham)t.push('🔨');if(game.sd)t.push('🪛');
  if(game.codeKnown&&!game.safeOpen)t.push('🔢 '+AR_NUM(game.code));
  if(game.fixed)t.push('✔ الباب');
  var txt=t.join('  ');
  if(inv){inv.hidden=!txt;if(inv.textContent!==txt)inv.textContent=txt;}
  var fb=$('bFire');if(fb)fb.style.display=(touch.on&&P.gun)?'':'none';
}

/* ---- first-person hands ---- */
function skinTexture(){
  var c=cnv(64,64),g=c.getContext('2d'),i;
  g.fillStyle='#d6a07a';g.fillRect(0,0,64,64);
  for(i=0;i<46;i++){g.fillStyle='rgba('+(150+((Math.random()*40)|0))+',92,70,0.10)';g.fillRect(R(0,64),R(0,64),R(2,12),R(1,3));}
  g.strokeStyle='rgba(90,110,150,0.16)';g.lineWidth=1;
  for(i=0;i<4;i++){g.beginPath();g.moveTo(R(0,64),0);g.bezierCurveTo(R(0,64),20,R(0,64),40,R(0,64),64);g.stroke();}
  speckle(g,64,64,70,'rgba(80,40,30,A)',2);
  return toTex(c,1,1);
}
function buildHands(){
  hs=new THREE.Scene();hcam=new THREE.PerspectiveCamera(58,1,0.02,6);
  hs.add(new THREE.AmbientLight(0x9a8a80,0.8));
  var dl=new THREE.DirectionalLight(0xffeedd,0.75);dl.position.set(-0.4,1,1);hs.add(dl);
  renderer.autoClear=false;
  gunFlash=new THREE.PointLight(0xffd080,0,16,2);scene.add(gunFlash);
  var sk=new THREE.MeshPhongMaterial({map:skinTexture(),shininess:14,specular:0x332222});
  var sleeve=new THREE.MeshPhongMaterial({color:0x2a2a32,shininess:3});
  var nail=new THREE.MeshPhongMaterial({color:0xecd0be,shininess:60});
  function cylZ(r0,r1,len,mat){var m=new THREE.Mesh(new THREE.CylinderGeometry(r0,r1,len,10),mat);m.rotation.x=Math.PI/2;m.position.z=-len/2;return m;}
  function finger(g,x,z0,c1,c2,c3,sc,ry){
    var p1=pivot(x,0.004,z0);p1.rotation.x=-c1;if(ry)p1.rotation.y=ry;
    p1.add(cylZ(0.0115,0.0105,0.046*sc,sk));
    var p2=pivot(0,0,-0.046*sc);p2.rotation.x=-c2;p2.add(new THREE.Mesh(new THREE.SphereGeometry(0.0108,8,6),sk));p2.add(cylZ(0.0105,0.0095,0.033*sc,sk));
    var p3=pivot(0,0,-0.033*sc);p3.rotation.x=-c3;p3.add(new THREE.Mesh(new THREE.SphereGeometry(0.0096,8,6),sk));p3.add(cylZ(0.0095,0.0085,0.026*sc,sk));
    var nl=mk(new THREE.BoxGeometry(0.011,0.003,0.014),nail,0,0.0078,-0.016*sc);p3.add(nl);
    p2.add(p3);p1.add(p2);g.add(p1);return p1;
  }
  function hand(sign,pose){
    var g=new THREE.Group();
    var fore=new THREE.Mesh(new THREE.CylinderGeometry(0.036,0.047,0.5,14),sk);fore.rotation.x=Math.PI/2;fore.position.z=0.27;g.add(fore);
    var sl=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.058,0.3,14,1,true),sleeve);sl.rotation.x=Math.PI/2;sl.position.z=0.4;g.add(sl);
    var cuff=new THREE.Mesh(new THREE.TorusGeometry(0.052,0.008,6,16),matP(0x1c1c22,2));cuff.position.z=0.25;g.add(cuff);
    var palm=mk(new THREE.BoxGeometry(0.098,0.034,0.1),sk,0,0,-0.05);g.add(palm);
    g.add(mk(new THREE.SphereGeometry(0.047,10,8),sk,0,0,0));
    var xs=[-0.036,-0.012,0.012,0.036],sc=[0.92,1.05,1.0,0.82],cv=pose==='grip'?[1.15,1.2,1.2,1.1]:(pose==='fist'?[1.2,1.3,1.3,1.2]:[0.35,0.45,0.5,0.55]);
    for(var i=0;i<4;i++){
      if(pose==='gun'&&i===0){finger(g,xs[i]*sign*-1,-0.1,0.08,0.05,0.02,sc[i]);continue;}
      finger(g,xs[i]*sign*-1,-0.1,cv[i],cv[i]*1.05,cv[i]*0.7,sc[i]);
    }
    var th=finger(g,sign*0.052,-0.045,0.2,0.25,0.15,1.0,sign*0.7);
    return g;
  }
  var L=new THREE.Group(),Lh=hand(-1,'grip');L.add(Lh);
  var fl=new THREE.Group();
  var body=new THREE.Mesh(new THREE.CylinderGeometry(0.026,0.03,0.2,14),new THREE.MeshPhongMaterial({color:0x2a2a30,shininess:50,specular:0x666666}));body.rotation.x=Math.PI/2;fl.add(body);
  var head=new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.028,0.06,14),new THREE.MeshPhongMaterial({color:0x44444c,shininess:70,specular:0x888888}));head.rotation.x=Math.PI/2;head.position.z=-0.12;fl.add(head);
  var lens=new THREE.Mesh(new THREE.CircleGeometry(0.036,14),new THREE.MeshBasicMaterial({color:0xfff0c0}));lens.position.z=-0.151;lens.rotation.y=Math.PI;fl.add(lens);
  fl.position.set(0,-0.03,-0.1);Lh.add(fl);
  L.rotation.set(-0.1,0.25,0.5);hs.add(L);
  var R1=new THREE.Group(),Rf=hand(1,'relaxed');R1.add(Rf);
  HND.hammer=makeHammerTool();HND.hammer.position.set(0,-0.02,0.02);Rf.add(HND.hammer);HND.hammer.visible=false;
  HND.sdr=makeScrewdriver();HND.sdr.position.set(0,-0.02,0.02);Rf.add(HND.sdr);HND.sdr.visible=false;
  var R2=new THREE.Group(),Rg=hand(1,'gun');R2.add(Rg);
  var gun=makePistol();gun.position.set(0,0,0.03);
  Rg.add(gun);
  R1.rotation.set(-0.1,-0.25,-0.3);R2.rotation.set(-0.12,-0.12,-0.1);
  hs.add(R1);hs.add(R2);
  HND.L=L;HND.R1=R1;HND.R2=R2;HND.lens=lens;
  hcam.aspect=(cv.clientWidth||window.innerWidth)/(cv.clientHeight||window.innerHeight);hcam.updateProjectionMatrix();
  L.position.set(-0.2,-0.2,-0.42);R1.position.set(0.2,-0.2,-0.42);R2.position.set(0.2,-0.2,-0.42);
}
function handsVisible(){
  return !!hs&&P&&!P.hidden&&(game.state==='play'||game.state==='pad'||game.state==='paused');
}
function updateHands(dt){
  if(!hs||!HND.L)return;
  HND.t+=dt;
  var dy=P.yaw-(HND.py===undefined?P.yaw:HND.py),dp=P.pitch-(HND.pp===undefined?P.pitch:HND.pp);HND.py=P.yaw;HND.pp=P.pitch;
  while(dy>3.14159)dy-=6.28318;while(dy<-3.14159)dy+=6.28318;
  var k=Math.min(1,dt*8);
  HND.sx+=(Math.max(-0.07,Math.min(0.07,-dy*1.2))-HND.sx)*k;HND.sy+=(Math.max(-0.05,Math.min(0.05,dp*0.9))-HND.sy)*k;
  var mv=game.moving?1:0,bx=mv*Math.sin(P.bob*0.5)*0.012,by=mv*Math.abs(Math.sin(P.bob))*0.015+Math.sin(HND.t*1.7)*0.003;
  HND.rec=Math.max(0,HND.rec-dt*7);
  var cd=P.crouch?0.015:0;
  HND.L.position.set(-0.2+bx+HND.sx,-0.2-by+HND.sy-cd,-0.42);
  var rz=-0.42+HND.rec*0.06;
  HND.R1.position.set(0.2+bx+HND.sx,-0.2-by+HND.sy-cd,-0.42);
  HND.R2.position.set(0.2+bx+HND.sx,-0.2-by+HND.sy-cd,rz);
  HND.R2.rotation.x=-0.12+HND.rec*0.45;
  HND.R1.visible=!P.gun;HND.R2.visible=!!P.gun;
  if(HND.hammer){HND.hammer.visible=!P.gun&&!!game.ham;HND.sdr.visible=!P.gun&&!game.ham&&!!game.sd;}
  HND.lens.material.color.setHex(P.torch?0xfff0c0:0x303030);
}
function renderAll(){
  renderer.clear();
  renderer.render(scene,camera);
  if(handsVisible()){renderer.clearDepth();renderer.render(hs,hcam);}
}

/* ========== p9b: days, wake-up, multiplayer screen, monsters, house ========== */
var dayTok=0,BED={x:2.4,y:0.98,z:3.6};

function dayAnim(n,mode,cb){
  var el=$('day'),tok=++dayTok;
  game.state='day';game.dayDeath=(mode!=='start');
  $('hud').hidden=true;$('prompt').style.opacity=0;$('cross').hidden=true;
  function boxes(cur,gone){var h='';for(var i=1;i<=DAYS;i++)h+='<i class="'+(i<=gone?'gone':(i===cur?'cur':''))+'">'+AR_NUM(i)+'</i>';return h;}
  function paint(title,cur,gone,sub){el.className='show';el.innerHTML='<div class="dtxt">'+title+'</div><div class="dboxes">'+boxes(cur,gone)+'</div><div class="dsub">'+sub+'</div>';}
  function at(ms,fn){setTimeout(function(){if(dayTok===tok)fn();},ms);}
  function done(){el.className='';el.innerHTML='';cb();}
  if(mode==='start'){
    paint('اليوم '+AR_NUM(1)+' من '+AR_NUM(DAYS),1,0,'عندك '+AR_NUM(DAYS)+' أيام فقط… انجُ قبل أن تنتهي');
    at(2300,done);
  }else if(mode==='death'){
    paint('سقطتَ في اليوم '+AR_NUM(n),n,n-1,'');
    at(700,function(){el.classList.add('x');Snd.bang();});
    at(2300,function(){paint('اليوم '+AR_NUM(n+1)+' من '+AR_NUM(DAYS),n+1,n,'بقيت لك '+AR_NUM(DAYS-n)+(DAYS-n<=2?' يومان':' أيام'));if(DAYS-n===1)el.querySelector('.dsub').textContent='بقي لك يوم أخير';if(DAYS-n===2)el.querySelector('.dsub').textContent='بقي لك يومان فقط';});
    at(4100,done);
  }else{
    paint('سقطتَ في اليوم '+AR_NUM(n),n,n-1,'آخر الأيام الستة');
    at(700,function(){el.classList.add('x');Snd.bang();});
    at(2700,done);
  }
}
function dayDeath(){
  if(game.dayFinal)return false;
  var d=game.day;
  if(d<DAYS){game.day=d+1;dayAnim(d,'death',respawn);}
  else dayAnim(d,'final',function(){game.dayFinal=true;showDeath();game.dayFinal=false;});
  return true;
}
function respawn(){
  var g=P.gun,a=P.ammo;
  P=newPlayer();P.gun=g;P.ammo=a;
  if(!NET.room)resetMonsters();
  game.threat=0;game.deadT=0;game.msgShown=false;game.killer=null;game.pHa=0;game.pGa=0;game.shake=0;game.moving=false;game.repairing=false;
  $('hit').style.opacity=0;$('slits').hidden=true;$('danger').style.opacity=0;$('warn').style.opacity=0;
  beginWake();
}
function beginWake(){
  game.state='wake';game.wakeT=0;game.dayDeath=false;
  $('day').className='';$('hud').hidden=true;$('cross').hidden=true;$('prompt').style.opacity=0;
  $('lid').style.opacity=1;Snd.creak(0.1);
  game.last=performance.now();
}
function ease(t){t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);}
function updateWake(dt){
  var t=(game.wakeT+=dt),T=3.8;
  T0+=dt;
  if(NET.room)simBackground(dt);
  animateMonsters(dt);
  var yaw=P.yaw,eye=EYE,x,y,z,pitch,roll,lid,blur;
  if(t<1.0){
    x=BED.x;y=BED.y;z=BED.z;pitch=1.3;roll=0.05*Math.sin(t*3);
    lid=t<0.35?1:(t<0.7?1-0.75*((t-0.35)/0.35):0.25+0.35*((t-0.7)/0.3));
  }else if(t<2.5){
    var u=ease((t-1.0)/1.5);
    x=BED.x+(P.x-0.9-BED.x)*u;y=BED.y+(1.2-BED.y)*u;z=BED.z+(P.z-BED.z)*u*0.5+(BED.z-BED.z);
    pitch=1.3-0.8*u;roll=0.04*Math.sin(t*2)*(1-u);
    lid=t<1.6?0.6*(1-(t-1.0)/0.6):(t>1.85&&t<2.0?0.8:0);
    if(!game.wk1){game.wk1=1;Snd.creak(0.08);Snd.beat(0.3);}
  }else{
    var v=ease((t-2.5)/1.3),sx=P.x-0.9,sz=BED.z+(P.z-BED.z)*0.5;
    x=sx+(P.x-sx)*v;z=sz+(P.z-sz)*v;y=1.2+(eye-1.2)*v;pitch=0.5*(1-v);roll=0;lid=0;
    if(!game.wk2&&v>0.3){game.wk2=1;Snd.noise(0.05,0.07,500);}
  }
  blur=Math.max(0,3.2*(1-t/T));
  $('lid').style.opacity=lid.toFixed(2);
  cv.style.filter=blur>0.15?'blur('+blur.toFixed(1)+'px)':'';
  camera.position.set(x,y,z);camera.rotation.set(pitch,yaw,roll);
  if(t>=T){
    game.wk1=0;game.wk2=0;
    $('lid').style.opacity=0;cv.style.filter='';
    game.state='play';game.last=performance.now();
    $('hud').hidden=false;$('prompt').hidden=false;$('cross').hidden=false;
    HND.py=undefined;
    if(game.day===1)toast('ابحث عن '+AR_NUM(game.need)+' مفاتيح مخبأة في الصناديق وتحت الدرج',3800);
    else toast('اليوم '+AR_NUM(game.day)+' — ما زلت محبوسًا. الأشياء التي جمعتها ما زالت معك',3600);
  }
}
function updateDay(dt){
  T0+=dt;
  if(NET.room){simBackground(dt);}
}
function updatePad(dt){
  T0+=dt;game.time+=dt;
  simBackground(dt);checkKills();
  if(game.state!=='pad')return;
  animateMonsters(dt);extraUpdate(dt);updateCamera(dt);updateHUD();
}
function cleanupExtras(){
  dayTok++;
  var d=$('day');if(d){d.className='';d.innerHTML='';}
  var l=$('lid');if(l)l.style.opacity=0;
  cv.style.filter='';
  closePad(false);
}

/* ---- dedicated multiplayer screen ---- */
function showMP(){
  game.state='menu';
  showScreen('<h2>👥 اللعب الجماعي</h2><p class="lead">العبوا معًا ضد الرجل والعملاق: يتشارك الفريق المفاتيح والصناديق والباب والأدوات.</p><div id="mp">'+mpHTML()+'</div><div class="btns"><button class="btn alt" id="mpBack" type="button">رجوع للقائمة</button></div><p class="fine">تطوير: Asoma Okazi</p>');
  bindMP();
  $('mpBack').addEventListener('click',showMenu);
  if(NET.room)NET.room.presence({st:'lobby'}).catch(function(){});
}

/* ---- realistic monsters ---- */
function burlapTex(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#a8905c';g.fillRect(0,0,128,128);
  g.strokeStyle='rgba(60,40,15,0.35)';g.lineWidth=1;
  for(i=0;i<128;i+=3){g.beginPath();g.moveTo(i,0);g.lineTo(i+R(-1,1),128);g.stroke();g.beginPath();g.moveTo(0,i);g.lineTo(128,i+R(-1,1));g.stroke();}
  for(i=0;i<22;i++){g.fillStyle='rgba(110,10,8,'+R(0.2,0.6).toFixed(2)+')';g.beginPath();g.arc(R(0,128),R(0,128),R(3,12),0,6.28);g.fill();}
  speckle(g,128,128,200,'rgba(30,20,5,A)',3);
  return toTex(c,1,1);
}
function apronTex(){
  var c=cnv(64,96),g=c.getContext('2d'),i;
  g.fillStyle='#3a2a1e';g.fillRect(0,0,64,96);
  speckle(g,64,96,260,'rgba(0,0,0,A)',3);
  for(i=0;i<9;i++){var x=R(2,62),y=R(0,50),h=R(18,60);g.fillStyle='rgba('+(110+((Math.random()*40)|0))+',10,8,0.8)';g.fillRect(x,y,R(3,8),h);g.beginPath();g.arc(x+2,y+h,R(2,4),0,6.28);g.fill();}
  g.fillStyle='rgba(90,6,6,0.7)';g.beginPath();g.arc(32,60,22,0,6.28);g.fill();
  return toTex(c,1,1);
}
function giantSkinTex(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#7a7868';g.fillRect(0,0,128,128);
  for(i=0;i<90;i++){g.fillStyle='rgba('+(60+((Math.random()*50)|0))+','+(70+((Math.random()*40)|0))+',55,0.18)';g.beginPath();g.arc(R(0,128),R(0,128),R(4,16),0,6.28);g.fill();}
  g.strokeStyle='rgba(120,40,40,0.45)';g.lineWidth=1;
  for(i=0;i<14;i++){g.beginPath();g.moveTo(R(0,128),R(0,128));g.bezierCurveTo(R(0,128),R(0,128),R(0,128),R(0,128),R(0,128),R(0,128));g.stroke();}
  g.strokeStyle='rgba(40,10,10,0.7)';g.lineWidth=2;
  for(i=0;i<5;i++){var x=R(10,118),y=R(10,118);g.beginPath();g.moveTo(x,y);g.lineTo(x+R(-26,26),y+R(8,30));g.stroke();}
  speckle(g,128,128,400,'rgba(20,20,10,A)',2);
  return toTex(c,2,2);
}
/* ---- realistic house: door frames, rugs, paintings, windows ---- */
function rugTex(base,trim){
  var c=cnv(128,96),g=c.getContext('2d'),i;
  g.fillStyle=base;g.fillRect(0,0,128,96);
  g.strokeStyle=trim;g.lineWidth=4;g.strokeRect(6,6,116,84);g.lineWidth=2;g.strokeRect(14,14,100,68);
  g.fillStyle=trim;for(i=0;i<5;i++){g.beginPath();g.moveTo(24+i*20,48);g.lineTo(34+i*20,36);g.lineTo(44+i*20,48);g.lineTo(34+i*20,60);g.closePath();g.fill();}
  speckle(g,128,96,500,'rgba(0,0,0,A)',2);
  return toTex(c,1,1);
}
function paintingTex(seed){
  var c=cnv(96,128),g=c.getContext('2d'),i;
  g.fillStyle=['#2a2a22','#22262c','#2c2420'][seed%3];g.fillRect(0,0,96,128);
  speckle(g,96,128,300,'rgba(255,255,255,A)',2);
  g.fillStyle='#0c0a09';g.beginPath();g.ellipse(48,56,22,30,0,0,6.28);g.fill();
  g.fillRect(24,86,48,42);
  g.fillStyle='rgba(200,190,160,0.85)';g.beginPath();g.arc(40,52,3.5,0,6.28);g.fill();g.beginPath();g.arc(56,52,3.5,0,6.28);g.fill();
  g.fillStyle='rgba(120,10,10,0.7)';for(i=0;i<4;i++)g.fillRect(30+i*10,76,3,R(8,24));
  return toTex(c,1,1);
}
function windowTex(){
  var c=cnv(64,96),g=c.getContext('2d');
  var gr=g.createLinearGradient(0,0,0,96);gr.addColorStop(0,'#1a2848');gr.addColorStop(1,'#0c1220');g.fillStyle=gr;g.fillRect(0,0,64,96);
  g.fillStyle='rgba(220,230,255,0.9)';g.beginPath();g.arc(44,22,6,0,6.28);g.fill();
  g.fillStyle='rgba(0,0,0,0.6)';for(var i=0;i<4;i++){g.beginPath();g.moveTo(i*18,96);g.lineTo(i*18+8,60+R(0,10));g.lineTo(i*18+16,96);g.fill();}
  g.strokeStyle='#2a1c12';g.lineWidth=4;g.strokeRect(2,2,60,92);g.beginPath();g.moveTo(32,0);g.lineTo(32,96);g.moveTo(0,48);g.lineTo(64,48);g.stroke();
  return toTex(c,1,1);
}
function dressHouse(){
  var wood=matP(0x2e2016,4),i;
  doors.forEach(function(d){
    setBuild(d.fl);
    var hw=DOOR_W/2+0.05,ax=d.ax==='x';
    var p1=mk(new THREE.BoxGeometry(ax?0.14:0.26,2.9,ax?0.26:0.14),wood,ax?d.c-hw:d.fixed,1.45,ax?d.fixed:d.c-hw);
    var p2=mk(new THREE.BoxGeometry(ax?0.14:0.26,2.9,ax?0.26:0.14),wood,ax?d.c+hw:d.fixed,1.45,ax?d.fixed:d.c+hw);
    var hd=mk(new THREE.BoxGeometry(ax?DOOR_W+0.34:0.26,0.14,ax?0.26:DOOR_W+0.34),wood,ax?d.c:d.fixed,2.87,ax?d.fixed:d.c);
    CURG.add(p1);CURG.add(p2);CURG.add(hd);
  });
  var skip={bath:1,stor:1,cell:1,laun:1,exit:1};
  ROOMS.concat(ROOMS2).forEach(function(r,ri){
    setBuild(r.fl);
    var w=r.x2-r.x1,dp=r.z2-r.z1;
    if(!skip[r.id]){
      var rug=new THREE.Mesh(new THREE.PlaneGeometry(Math.min(4,w*0.4),Math.min(3,dp*0.3)),new THREE.MeshPhongMaterial({map:rugTex(['#4a1a1a','#1f2e3a','#3a3020','#2a1f33'][ri%4],'#b08a4a'),shininess:2}));
      rug.rotation.x=-Math.PI/2;rug.position.set(r.cx,0.014,r.cz);CURG.add(rug);
    }
    var north=r.z1<16,wz=north?r.z1+0.17:r.z2-0.17,ry=north?0:Math.PI;
    var pt=new THREE.Mesh(new THREE.PlaneGeometry(0.9,1.2),new THREE.MeshPhongMaterial({map:paintingTex(ri),shininess:25}));
    pt.position.set(r.x1+w*0.3,2.0,wz);pt.rotation.y=ry;CURG.add(pt);
    var fr=mk(new THREE.BoxGeometry(1.02,1.32,0.05),matP(0x5a4020,30),r.x1+w*0.3,2.0,wz+(north?-0.02:0.02));CURG.add(fr);
    if(north&&r.fl===0&&r.id!=='bath'){
      var wd=new THREE.Mesh(new THREE.PlaneGeometry(1.3,1.8),new THREE.MeshBasicMaterial({map:windowTex()}));
      wd.position.set(r.x1+w*0.72,1.9,wz);CURG.add(wd);
      CURG.add(mk(new THREE.BoxGeometry(1.46,1.96,0.05),wood,r.x1+w*0.72,1.9,wz-0.02));
    }
  });
  setBuild(0);
}

/* ========== p9c: rounded monsters, smooth gait, keys on tables, realistic tools ========== */
function lathe(pts,mat,seg){
  var v=[],i;for(i=0;i<pts.length;i++)v.push(new THREE.Vector2(pts[i][0],pts[i][1]));
  return new THREE.Mesh(new THREE.LatheGeometry(v,seg||14),mat);
}
function put(m,x,y,z){m.position.set(x,y,z);return m;}
function blob(r,sx,sy,sz,mat,seg){
  var m=new THREE.Mesh(new THREE.SphereGeometry(r,seg||14,(seg||14)*0.75),mat);m.scale.set(sx,sy,sz);return m;
}

/* outline with triangular spikes on both sides (mace / spiked head) */
function spikeOutline(hw,hh,n,sp){
  var p=[[-hw,-hh],[hw,-hh]],i,y0,y1,ym;
  for(i=0;i<n;i++){y0=-hh+2*hh*i/n;y1=-hh+2*hh*(i+1)/n;ym=(y0+y1)/2;p.push([hw+sp,ym],[hw,y1]);}
  p.push([-hw,hh]);
  for(i=n-1;i>=0;i--){y0=-hh+2*hh*i/n;y1=-hh+2*hh*(i+1)/n;ym=(y0+y1)/2;p.push([-hw-sp,ym],[-hw,y0]);}
  p.pop();
  return p;
}
function headGeo(hw,hh,n,sp,depth){
  var s=new THREE.Shape(),p=spikeOutline(hw,hh,n,sp),i;
  s.moveTo(p[0][0],p[0][1]);for(i=1;i<p.length;i++)s.lineTo(p[i][0],p[i][1]);
  var g=new THREE.ExtrudeGeometry(s,{depth:depth,bevelEnabled:true,bevelThickness:0.012,bevelSize:0.01,bevelSegments:2,curveSegments:1});
  g.translate(0,0,-depth/2);return g;
}

/* ---------- monsters ---------- */
function buildHammerMan(){
  var g=new THREE.Group(),A=HM;
  var cloth=new THREE.MeshPhongMaterial({color:0x3a312a,map:TEX.cloth,shininess:3});
  var trous=matP(0x2b2622,3),boot=matP(0x141010,20),leather=matP(0x2a1a10,12);
  var skin=new THREE.MeshPhongMaterial({color:0xb9a88f,shininess:6});
  var burlap=new THREE.MeshPhongMaterial({map:burlapTex(),shininess:2});
  var apron=new THREE.MeshPhongMaterial({map:apronTex(),shininess:10,side:THREE.DoubleSide});
  var dark=new THREE.MeshBasicMaterial({color:0x050303}),glow=new THREE.MeshBasicMaterial({color:0xff5a2a});
  var metal=new THREE.MeshPhongMaterial({color:0x8a8e96,shininess:80,specular:0xdddddd});
  var wood=new THREE.MeshPhongMaterial({color:0x4a3320,shininess:8});

  function leg(side){
    var hip=pivot(side*0.15,0.95,0),knee=pivot(0,-0.5,0);
    hip.add(lathe([[0,0.03],[0.135,0.02],[0.12,-0.2],[0.1,-0.38],[0,-0.5]],trous,14));
    knee.add(lathe([[0,0.03],[0.1,0.02],[0.085,-0.2],[0.075,-0.4],[0,-0.42]],trous,14));
    var f=blob(0.1,1,0.45,1.7,boot,12);put(f,0,-0.44,0.07);knee.add(f);
    hip.add(knee);g.add(hip);return {hip:hip,knee:knee};
  }
  var lL=leg(-1),lR=leg(1);
  A.legL=lL.hip;A.kneeL=lL.knee;A.legR=lR.hip;A.kneeR=lR.knee;

  var torso=lathe([[0,1.0],[0.22,1.02],[0.27,1.3],[0.27,1.62],[0.22,1.9],[0.12,1.96],[0,1.97]],cloth,16);
  torso.scale.set(1,1,0.66);g.add(torso);
  var belt=lathe([[0.25,1.05],[0.28,1.07],[0.28,1.13],[0.25,1.15]],leather,16);belt.scale.set(1,1,0.66);g.add(belt);
  var ap=new THREE.Mesh(new THREE.PlaneGeometry(0.44,0.78),apron);ap.position.set(0,1.36,0.16);g.add(ap);

  A.head=pivot(0,1.95,0);
  A.head.add(lathe([[0,-0.08],[0.09,-0.08],[0.1,0.04],[0,0.04]],dark,10));
  A.head.add(put(blob(0.25,1,1.12,0.98,burlap,18),0,0.13,0));
  A.head.add(put(lathe([[0,0],[0.1,0.02],[0.05,0.12],[0,0.2]],burlap,10),0,0.3,0));
  [-1,1].forEach(function(s){
    A.head.add(put(blob(0.05,1,1.2,0.5,dark,8),s*0.09,0.17,0.225));
    A.head.add(put(new THREE.Mesh(new THREE.SphereGeometry(0.016,8,8),glow),s*0.09,0.165,0.245));
  });
  var rope=new THREE.Mesh(new THREE.TorusGeometry(0.17,0.02,6,18),matP(0x6a5638,2));rope.rotation.x=Math.PI/2;rope.position.set(0,-0.03,0);A.head.add(rope);
  A.head.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.12,0.02,0.02),dark),0,0.02,0.24));
  g.add(A.head);

  function arm(side){
    var sh=pivot(side*0.31,1.78,0),el=pivot(0,-0.44,0);
    sh.add(lathe([[0,0.04],[0.08,0.02],[0.075,-0.22],[0.06,-0.4],[0,-0.44]],cloth,12));
    el.add(lathe([[0,0.03],[0.06,0.02],[0.055,-0.18],[0.04,-0.34],[0,-0.36]],skin,12));
    el.add(put(blob(0.06,1,1.3,0.7,skin,10),0,-0.38,0));
    sh.add(el);g.add(sh);return {sh:sh,el:el};
  }
  var aL=arm(-1),aR=arm(1);
  A.armL=aL.sh;A.elbowL=aL.el;A.armR=aR.sh;A.elbowR=aR.el;

  /* المطرقة بأشواك في يده */
  var hm=pivot(0,-0.38,0.03);hm.rotation.x=2.2;
  hm.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.04,1.1,12),wood),0,0.45,0));
  var hd=new THREE.Mesh(headGeo(0.2,0.12,4,0.09,0.2),metal);hd.position.set(0,1.0,0);hm.add(hd);
  hm.add(put(new THREE.Mesh(new THREE.ConeGeometry(0.05,0.12,10),metal),0,1.16,0));
  aR.el.add(hm);
  scene.add(g);return g;
}

function buildGiant(){
  var g=new THREE.Group(),A=GM;
  var skin=new THREE.MeshPhongMaterial({map:giantSkinTex(),shininess:6});
  var cloth=new THREE.MeshPhongMaterial({color:0x3a2a20,map:TEX.cloth,shininess:2});
  var dark=matP(0x2a2622,3),tusk=new THREE.MeshPhongMaterial({color:0xe8e0c0,shininess:30});
  var chain=new THREE.MeshPhongMaterial({color:0x6a6a72,shininess:60,specular:0xaaaaaa});
  var scar=new THREE.MeshBasicMaterial({color:0x3a0a0a});

  function leg(side){
    var hip=pivot(side*0.65,2.4,0),knee=pivot(0,-1.2,0);
    hip.add(lathe([[0,0.1],[0.5,0.06],[0.55,-0.5],[0.45,-1.0],[0.38,-1.2],[0,-1.22]],skin,16));
    knee.add(lathe([[0,0.05],[0.4,0.03],[0.36,-0.6],[0.26,-1.05],[0.2,-1.18],[0,-1.2]],skin,14));
    var f=blob(0.5,1,0.45,1.5,dark,14);put(f,0,-1.2,0.25);knee.add(f);
    hip.add(knee);g.add(hip);return {hip:hip,knee:knee};
  }
  var lL=leg(-1),lR=leg(1);
  A.legL=lL.hip;A.kneeL=lL.knee;A.legR=lR.hip;A.kneeR=lR.knee;

  A.body=pivot(0,2.4,0);
  var torso=lathe([[0,-0.2],[1.25,-0.1],[1.35,0.6],[1.28,1.4],[1.42,2.0],[1.3,2.5],[0.85,2.72],[0,2.76]],skin,20);
  torso.scale.set(1,1,0.72);A.body.add(torso);
  var loin=lathe([[0,-0.25],[1.38,-0.25],[1.42,0.42],[1.3,0.52],[0,0.52]],cloth,20);loin.scale.set(1,1,0.74);A.body.add(loin);
  for(var k=0;k<5;k++){var sc=blob(0.3,1,0.035,0.02,scar,8);put(sc,R(-0.7,0.7),0.6+k*0.4,0.98);sc.rotation.z=R(-0.4,0.4);A.body.add(sc);}

  A.head=pivot(0,2.9,0.45);
  A.head.add(put(blob(0.8,1,1.1,1.05,skin,18),0,0.25,0.05));
  A.head.add(put(blob(0.5,1.1,0.5,0.9,skin,14),0,-0.35,0.15));
  A.head.add(put(blob(0.3,0.9,0.15,0.1,dark,10),0,-0.1,0.78));
  var band=new THREE.Mesh(new THREE.TorusGeometry(0.82,0.07,8,28),new THREE.MeshPhongMaterial({color:0x2a1812,shininess:4}));
  band.rotation.x=Math.PI/2;band.position.set(0,0.35,0.05);A.head.add(band);
  A.head.add(put(blob(0.5,1.2,0.32,0.2,new THREE.MeshPhongMaterial({color:0x221512,shininess:3}),14),0,0.42,0.72));
  [-1,1].forEach(function(s){
    A.head.add(put(new THREE.Mesh(new THREE.SphereGeometry(0.04,8,8),new THREE.MeshBasicMaterial({color:0xffe14a})),s*0.28,0.3,0.76));
    var t=lathe([[0.1,0],[0.07,0.3],[0,0.5]],tusk,10);put(t,s*0.3,-0.2,0.6);t.rotation.x=0.7;A.head.add(t);
  });
  A.body.add(A.head);

  function garm(side){
    var sh=pivot(side*1.65,2.1,0),el=pivot(0,-1.7,0);
    sh.add(lathe([[0,0.05],[0.42,0.03],[0.4,-0.8],[0.33,-1.7],[0,-1.75]],skin,16));
    el.add(lathe([[0,0.05],[0.36,0.03],[0.3,-0.8],[0.25,-1.55],[0,-1.7]],skin,16));
    el.add(put(blob(0.58,1,0.9,1,skin,14),0,-1.7,0));
    var ring=new THREE.Mesh(new THREE.TorusGeometry(0.46,0.07,6,18),chain);ring.rotation.x=Math.PI/2;ring.position.set(0,-1.45,0);el.add(ring);
    sh.add(el);A.body.add(sh);return {sh:sh,el:el};
  }
  var aL=garm(-1),aR=garm(1);
  A.armL=aL.sh;A.elbowL=aL.el;A.armR=aR.sh;A.elbowR=aR.el;
  g.add(A.body);
  scene.add(g);return g;
}

function animateMonsters(dt){
  var A=HM,amp=Math.min(1,H.v/1.6),th=(H.phase=(H.phase||0)+dt*H.v*2.6);
  var w=Math.sin(th)*amp*0.75,stunned=H.stun>0;
  if(stunned){A.legL.rotation.x=-1.25;A.legR.rotation.x=-1.25;A.kneeL.rotation.x=1.45;A.kneeR.rotation.x=1.45;}
  else{
    A.legL.rotation.x=w;A.legR.rotation.x=-w;
    A.kneeL.rotation.x=0.65*amp*Math.max(0,-Math.sin(th+0.4));
    A.kneeR.rotation.x=0.65*amp*Math.max(0,Math.sin(th+0.4));
  }
  A.armL.rotation.x=-w*0.5;A.elbowL.rotation.x=-0.2-0.12*amp;
  var swing=H.atk>0?H.atkAnim:0;
  A.armR.rotation.x=H.atk>0?(swing<0.7?-2.6*(swing/0.7):-2.6+3.5*((swing-0.7)/0.3)):(0.15+w*0.25);
  A.elbowR.rotation.x=H.atk>0?-0.1:-0.45;
  if(stunned){A.armR.rotation.x=0.9;A.elbowR.rotation.x=-0.3;A.armL.rotation.x=0.4;}
  A.head.rotation.y=Math.sin(T0*1.3)*0.2*(H.state==='patrol'?1:0.3);
  A.head.rotation.x=(stunned?0.5:0.1)+w*0.03;
  hmGroup.position.set(H.x,(H.gy||0)+Math.abs(w)*0.05-(stunned?0.35:0),H.z);
  hmGroup.rotation.y=Math.atan2(H.dx,H.dz);
  redGlow.position.set(H.x,(H.gy||0)+1.6,H.z);

  var B=GM,gw=Math.sin(G.phase),gamp=Math.min(1,G.v/1.4),gst=G.stun>0;
  if(gst){B.legL.rotation.x=0;B.legR.rotation.x=0;B.kneeL.rotation.x=0;B.kneeR.rotation.x=0;}
  else{
    B.legL.rotation.x=gw*0.4;B.legR.rotation.x=-gw*0.4;
    B.kneeL.rotation.x=0.5*gamp*Math.max(0,-Math.sin(G.phase+0.4));
    B.kneeR.rotation.x=0.5*gamp*Math.max(0,Math.sin(G.phase+0.4));
  }
  B.body.rotation.z=gst?0:gw*0.035;B.body.rotation.x=gst?0.32:0.04;
  B.body.position.y=2.4+Math.abs(gw)*0.05-(gst?0.25:0);
  B.armL.rotation.x=-gw*0.22;B.elbowL.rotation.x=-0.2;
  B.armR.rotation.x=G.atk>0?(G.atkAnim<0.8?-2.5*(G.atkAnim/0.8):-2.5+3.3*((G.atkAnim-0.8)/0.2)):gw*0.2;
  B.elbowR.rotation.x=G.atk>0?0:-0.25;
  B.head.rotation.y=Math.sin(T0*0.4)*0.25;B.head.rotation.x=0.12;
  gGroup.position.set(G.x,0,G.z);gGroup.rotation.y=Math.atan2(G.dx,G.dz);
  greenGlow.position.set(G.x,3.5,G.z);
  exitDoorPivot.rotation.y+=((game.doorOpen?1.5:0)-exitDoorPivot.rotation.y)*Math.min(1,dt*2.5);
}

/* ---------- key spots: keys lie on small tables ---------- */
function makeKeyMesh(){
  var brass=new THREE.MeshPhongMaterial({color:0xc9a040,shininess:90,specular:0xffe9a0});
  var o=new THREE.Group(),k=new THREE.Group();
  var ring=new THREE.Mesh(new THREE.TorusGeometry(0.03,0.007,8,16),brass);ring.position.y=0.1;k.add(ring);
  k.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.012,0.2,0.006),brass),0,0,0));
  k.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.035,0.012,0.006),brass),0.012,-0.07,0));
  k.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.025,0.012,0.006),brass),0.01,-0.04,0));
  k.rotation.x=-Math.PI/2;k.scale.set(0.5,0.5,0.5);o.add(k);
  return o;
}
function makeClutter(){
  var o=new THREE.Group(),pick=Math.floor(Math.random()*3);
  if(pick===0){
    o.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.22,0.04,0.16),matP(0x5a1a14,20)),0,0.02,0));
    o.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.2,0.03,0.14),matP(0xd8cfae,3)),0.005,0.05,0));
  }else if(pick===1){
    o.add(lathe([[0,0],[0.035,0],[0.035,0.16],[0,0.17]],new THREE.MeshPhongMaterial({color:0xe8dcc0,shininess:10}),12));
    o.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.003,0.003,0.03,6),matP(0x111111)),0,0.18,0));
  }else{
    o.add(lathe([[0,0],[0.045,0],[0.05,0.1],[0,0.1]],new THREE.MeshPhongMaterial({color:0xd6cdbb,shininess:60}),14));
  }
  return o;
}
function addSpot(fl,x,z,label,col,kind){
  kind=kind||'table';
  var g=new THREE.Group(),mat,keyMesh=null,clut=null;
  if(kind==='chest'){
    mat=new THREE.MeshPhongMaterial({map:TEX.crate,color:col||0xc0b0a0,shininess:8});
    g.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.95,0.55,0.65),mat),0,0.275,0));
    g.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.98,0.1,0.68),matP(0x2a2a2a)),0,0.38,0));
  }else{
    mat=new THREE.MeshPhongMaterial({color:col||0x6a4a2c,shininess:18,specular:0x332211});
    g.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.42,0.42,0.05,24),mat),0,0.72,0));
    var lg=matP(0x2a1c10,6);
    for(var i=0;i<3;i++){var a=i*2.09+0.5;g.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.035,0.7,8),lg),Math.cos(a)*0.3,0.35,Math.sin(a)*0.3));}
    keyMesh=makeKeyMesh();keyMesh.position.set(0.05,0.76,0.02);keyMesh.visible=false;g.add(keyMesh);
    clut=makeClutter();clut.position.set(-0.15,0.745,0.1);g.add(clut);
  }
  g.position.set(x,0,z);g.rotation.y=R(0,6.28);FL[fl].g.add(g);
  spots.push({fl:fl,x:x,z:z,label:label,obj:g,mat:mat,col:col||0xc0b0a0,searched:false,key:false,item:null,special:false,hide:false,r:0,kind:kind,keyMesh:keyMesh,clut:clut});
}
function placeSpots(){
  ROOMS.concat(ROOMS2).forEach(function(r,ri){
    setBuild(r.fl);
    var cand=[[r.x1+1.1,r.z1+1.1],[r.x2-1.1,r.z1+1.1],[r.x1+1.1,r.z2-1.1],[r.x2-1.1,r.z2-1.1],[r.x1+1.1,r.cz],[r.x2-1.1,r.cz]];
    for(var i=0;i<cand.length;i++){
      var p=cand[(i+ri)%cand.length];
      if(freeAt(p[0],p[1],0.5,0.5,0.45)){addSpot(r.fl,p[0],p[1],'ابحث على الطاولة');break;}
    }
  });
  setBuild(0);
  addSpot(0,25.4,21.9,'ابحث على الطاولة تحت الدرج',0x5a4030);
}
function placeKeys(n,rnd){rnd=rnd||Math.random;
  spots.forEach(function(s){
    s.searched=false;s.key=false;s.mat.color.setHex(s.col);s.obj.visible=true;
    if(s.keyMesh)s.keyMesh.visible=false;if(s.clut)s.clut.visible=true;
  });
  var idx=[];spots.forEach(function(s,i){if(!s.special)idx.push(i);});
  for(var i=idx.length-1;i>0;i--){var j=(rnd()*(i+1))|0,t=idx[i];idx[i]=idx[j];idx[j]=t;}
  var cnt=Math.min(n,idx.length);
  for(var k=0;k<cnt;k++){
    var s2=spots[idx[k]];s2.key=true;
    if(s2.keyMesh){s2.keyMesh.visible=true;s2.clut.visible=false;}
  }
  return cnt;
}

/* ---------- realistic tools ---------- */
function makePistol(){
  var pts=[[0,0.035],[0,0.068],[0.19,0.068],[0.215,0.052],[0.205,0.035],[0.11,0.03],[0.105,-0.005],[0.088,-0.1],[0.04,-0.115],[0.03,-0.08],[0,0]];
  var s=new THREE.Shape(),i;s.moveTo(pts[0][0],pts[0][1]);for(i=1;i<pts.length;i++)s.lineTo(pts[i][0],pts[i][1]);
  var geo=new THREE.ExtrudeGeometry(s,{depth:0.034,bevelEnabled:true,bevelThickness:0.004,bevelSize:0.004,bevelSegments:2,curveSegments:2});
  geo.translate(0,0,-0.017);
  var o=new THREE.Group();
  o.add(new THREE.Mesh(geo,new THREE.MeshPhongMaterial({color:0x2a2c32,shininess:90,specular:0x9a9aa2})));
  o.rotation.y=Math.PI/2;return o;
}
function makeHammerTool(){
  var wood=new THREE.MeshPhongMaterial({color:0x6a4a2a,shininess:10}),metal=new THREE.MeshPhongMaterial({color:0x7d8088,shininess:80,specular:0xdddddd});
  var o=new THREE.Group();
  var h=lathe([[0,0],[0.018,0],[0.02,0.05],[0.015,0.3],[0.018,0.36],[0,0.37]],wood,12);h.rotation.z=-Math.PI/2;o.add(h);
  var hd=new THREE.Mesh(headGeo(0.1,0.05,3,0.04,0.09),metal);hd.rotation.y=Math.PI/2;hd.position.set(0.4,0,0);o.add(hd);
  var w=new THREE.Group();w.rotation.y=Math.PI/2;w.add(o);return w;
}
function makeScrewdriver(){
  var red=new THREE.MeshPhongMaterial({color:0xb02a1a,shininess:40}),metal=new THREE.MeshPhongMaterial({color:0xb8bcc4,shininess:90,specular:0xffffff});
  var o=new THREE.Group();
  var h=lathe([[0,0],[0.02,0],[0.026,0.02],[0.03,0.06],[0.024,0.1],[0.014,0.125],[0,0.13]],red,12);h.rotation.z=-Math.PI/2;o.add(h);
  var sh=new THREE.Mesh(new THREE.CylinderGeometry(0.0045,0.0045,0.16,8),metal);sh.rotation.z=Math.PI/2;sh.position.set(0.21,0,0);o.add(sh);
  o.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.02,0.012,0.004),metal),0.3,0,0));
  var w=new THREE.Group();w.rotation.y=Math.PI/2;w.add(o);return w;
}
})();
