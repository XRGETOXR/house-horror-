
/* ---------- second floor, stairs, key spots ---------- */
var ROOMS2=[], STAIR={x1:10.8,x2:24.4,z1:21.55,z2:23.65};
(function(){
  ['غرفة الضيوف','المكتب','غرفة الملابس','غرفة الألعاب','غرفة الصلاة','الشرفة المغلقة'].forEach(function(n,i){ROOMS2.push({id:'n'+i,name:n,x1:i*10,z1:0,x2:i*10+10,z2:16});});
  ['غرفة الخادمة','المكتبة العليا','غرفة الضيوف الثانية','المعمل القديم','الغرفة الحمراء'].forEach(function(n,i){ROOMS2.push({id:'a'+i,name:n,x1:i*12,z1:24,x2:i*12+12,z2:40});});
  ['العلّية','غرفة الأرشيف','غرفة الدمى','غرفة المرايا'].forEach(function(n,i){ROOMS2.push({id:'b'+i,name:n,x1:i*15,z1:40,x2:i*15+15,z2:56});});
  ROOMS2.forEach(function(r){r.fl=1;r.cx=(r.x1+r.x2)/2;r.cz=(r.z1+r.z2)/2;ROOM[r.id]=r;});
})();

function freeAt(x,z,hw,hd,m){
  var co=FL[CUR].co;
  for(var i=0;i<co.length;i++){
    var b=co[i];
    if(x+hw+m>b.x1&&x-hw-m<b.x2&&z+hd+m>b.z1&&z-hd-m<b.z2)return false;
  }
  return true;
}
function floorPiece(x1,z1,x2,z2){
  if(x2-x1<0.05||z2-z1<0.05)return;
  var t=TEX.floor.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set((x2-x1)/2,(z2-z1)/2);
  var m=new THREE.Mesh(new THREE.PlaneGeometry(x2-x1,z2-z1),new THREE.MeshPhongMaterial({map:t,shininess:6,specular:0x222222,side:THREE.DoubleSide}));
  m.rotation.x=-Math.PI/2;m.position.set((x1+x2)/2,0,(z1+z2)/2);CURG.add(m);
}
function buildFloor2(){
  setBuild(1);
  var s=STAIR;
  floorPiece(0,0,60,s.z1);floorPiece(0,s.z2,60,56);floorPiece(0,s.z1,s.x1,s.z2);floorPiece(s.x2,s.z1,60,s.z2);
  ROOMS2.forEach(function(r){
    var t=TEX.ceil.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set((r.x2-r.x1)/3,(r.z2-r.z1)/3);
    planeAt(r.x2-r.x1,r.z2-r.z1,r.cx,WALL_H,r.cz,Math.PI/2,new THREE.MeshPhongMaterial({map:t,shininess:1}));
  });
  var ht=TEX.ceil.clone();ht.needsUpdate=true;ht.wrapS=ht.wrapT=THREE.RepeatWrapping;ht.repeat.set(20,3);
  planeAt(60,8,30,HALL_H,20,Math.PI/2,new THREE.MeshPhongMaterial({map:ht,shininess:1}));
  var nd=ROOMS2.slice(0,6).map(function(r){return r.cx;}),ad=[6,30,42,54],bd=[7.5,22.5,37.5,52.5];
  wallDoors('x',16,0,60,nd,HALL_H);wallDoors('x',24,0,60,ad,HALL_H);
  wallSeg('z',0,16-T/2,24+T/2,HALL_H);wallSeg('z',60,16-T/2,24+T/2,HALL_H);
  wallDoors('x',0,0,60,[],WALL_H);wallDoors('x',40,0,60,bd,WALL_H);wallDoors('x',56,0,60,[],WALL_H);
  wallDoors('z',0,0,16,[],WALL_H);wallDoors('z',0,24,56,[],WALL_H);
  wallDoors('z',60,0,16,[],WALL_H);wallDoors('z',60,24,56,[],WALL_H);
  [10,20,30,40,50].forEach(function(x){wallDoors('z',x,0,16,[8],WALL_H);addDoor('z',x,8);});
  [12,24,36,48].forEach(function(x){wallDoors('z',x,24,40,[32],WALL_H);addDoor('z',x,32);});
  [15,30,45].forEach(function(x){wallDoors('z',x,40,56,[48],WALL_H);addDoor('z',x,48);});
  nd.forEach(function(c){addDoor('x',16,c);});
  ad.forEach(function(c){addDoor('x',24,c);});
  bd.forEach(function(c){addDoor('x',40,c);});
  /* حواجز فتحة الدرج في الطابق الثاني */
  box1(s.x1,s.x2,s.z1-0.15,s.z1);box1(s.x1,s.x2,s.z2,s.z2+0.2);box1(s.x1-0.15,s.x1,s.z1-0.15,s.z2+0.2);
  var rail=matP(0x2e2016,8);
  [[0.5],[1.0]].forEach(function(h){
    var a=new THREE.Mesh(new THREE.BoxGeometry(s.x2-s.x1,0.07,0.07),rail);a.position.set((s.x1+s.x2)/2,h[0],s.z1-0.07);CURG.add(a);
    var b=new THREE.Mesh(new THREE.BoxGeometry(0.07,0.07,s.z2-s.z1+0.3),rail);b.position.set(s.x1-0.07,h[0],(s.z1+s.z2)/2+0.07);CURG.add(b);
  });
  for(var px=s.x1;px<=s.x2;px+=2.2){var p=new THREE.Mesh(new THREE.BoxGeometry(0.09,1.0,0.09),rail);p.position.set(px,0.5,s.z1-0.07);CURG.add(p);}
  dressFloor2();
  addText('لا تنظر إلى الأسفل',48,2.5,15.81,0,3.8,1.2,'#8d0f0c');
  addText('اهرب',0.19,2.0,5,Math.PI/2,2.4,0.75,'#8d0f0c');
  addText('هو في الأسفل',30,2.4,24.19,Math.PI,3.2,1.0,'#8d0f0c');
}
function box1(x1,x2,z1,z2){FL[CUR].co.push({x1:x1,x2:x2,z1:z1,z2:z2});}
function dressFloor2(){
  var kinds=[
    function(x,z){F(x,z,2.0,3.0,0.7,0x4a3b38);deco(x,0.7,z,1.8,0.16,2.6,0x6a5a52);},
    function(x,z){F(x,z,1.7,1.1,0.8,0x4a3322);},
    function(x,z){F(x,z,2.6,0.6,2.2,0x2e2016);},
    function(x,z){F(x,z,2.2,0.9,0.8,0x3a2a30);},
    function(x,z){F(x,z,1.4,1.2,1.1,0x2a2a2a);}
  ];
  ROOMS2.forEach(function(r,i){
    var wide=r.x2-r.x1;
    var cc=[[r.x1+1.3,r.z2-0.75],[r.x2-1.3,r.z2-0.75],[r.x1+1.3,r.z1+0.75],[r.x2-1.3,r.z1+0.75]];
    for(var a=0;a<cc.length;a++){
      if(freeAt(cc[a][0],cc[a][1],1.0,0.55,0.5)){C(cc[a][0],cc[a][1],2.0,1.1,r.id);break;}
    }
    var cr=[[r.x2-1.2,r.z1+1.2],[r.x1+1.2,r.z1+1.2],[r.x2-1.2,r.z2-1.2],[r.x1+1.2,r.z2-1.2]];
    for(var b=0;b<cr.length;b++){
      if(freeAt(cr[b][0],cr[b][1],0.75,0.75,0.7)){CR(cr[b][0],cr[b][1],r.id);break;}
    }
    var fp=[[r.cx-wide*0.3,r.z1+2.0],[r.cx+wide*0.3,r.z1+2.0],[r.cx-wide*0.3,r.z2-2.4],[r.cx+wide*0.3,r.z2-2.4]];
    var placed=0;
    for(var c=0;c<fp.length&&placed<2;c++){
      var k=kinds[(i+c)%kinds.length];
      if(freeAt(fp[c][0],fp[c][1],1.4,1.5,0.9)){k(fp[c][0],fp[c][1]);placed++;}
    }
  });
}
function buildStairs(){
  var s=STAIR,dx=s.x2-s.x1,L=Math.hypot(dx,FY),ang=Math.atan2(FY,dx),cx=(s.x1+s.x2)/2,cz=(s.z1+s.z2)/2,w=s.z2-s.z1;
  var c=cnv(64,64),g=c.getContext('2d');
  g.fillStyle='#5a3d27';g.fillRect(0,0,64,64);g.fillStyle='#7a5636';g.fillRect(0,0,50,64);g.fillStyle='rgba(0,0,0,0.5)';g.fillRect(58,0,6,64);
  speckle(g,64,64,60,'rgba(0,0,0,A)',2);
  var t=toTex(c,L/0.85,1);
  var ramp=new THREE.Mesh(new THREE.BoxGeometry(L,0.22,w),new THREE.MeshPhongMaterial({map:t,shininess:6}));
  ramp.position.set(cx,FY/2-0.12,cz);ramp.rotation.z=ang;scene.add(ramp);
  var dark=matP(0x2a1c10,3),sh=new THREE.Shape();
  sh.moveTo(0,0);sh.lineTo(dx,0);sh.lineTo(dx,FY);sh.closePath();
  var geo=new THREE.ExtrudeGeometry(sh,{depth:0.12,bevelEnabled:false});
  var s1=new THREE.Mesh(geo,dark);s1.position.set(s.x1,0,s.z1-0.12);scene.add(s1);
  var s2=new THREE.Mesh(geo,dark);s2.position.set(s.x1,0,s.z2);scene.add(s2);
  var endw=new THREE.Mesh(new THREE.BoxGeometry(0.15,FY,w+0.24),dark);endw.position.set(s.x2+0.075,FY/2,cz);scene.add(endw);
  setBuild(0);
  box1(s.x1,s.x2,s.z1-0.2,s.z1);box1(s.x1,s.x2,s.z2,s.z2+0.2);box1(s.x2,s.x2+0.2,s.z1-0.2,s.z2+0.2);
  /* مصباح خافت عند أسفل الدرج */
  var lamp=new THREE.PointLight(0xffb060,0.7,10,2);lamp.position.set(s.x1+1.5,2.6,cz);scene.add(lamp);
}

/* ---------- key spots ---------- */
var spots=[];
