
/* ========== p9a: items, tools, safe, light switch, gun, hands ========== */
var DAYS=6,hs=null,hcam=null,HND={t:0,sx:0,sy:0,rec:0,flashT:0};
var gunFlash=null,lampLights=[],lampBulbs=[],lampOn=false,fogBase=0.05;
var SW={x:17.5,y:1.35,z:16.3},SAFE={x:35,z:0.5},NOTE={x:17,y:1.02,z:0.8};
var safeObj=null,padBuf='';

function markSearched(s){s.searched=true;if(s.keyMesh)s.keyMesh.visible=false;if(s.hide)s.obj.visible=false;else s.mat.color.setHex(0x5a5048);}

/* ---- special chests (deliberate corners) and table items ---- */
function placeSpecials(){
  function room(id){var r=null;ROOMS.concat(ROOMS2).forEach(function(q){if(q.id===id)r=q;});return r;}
  function corner(id,label,item,col){
    var r=room(id);if(!r)return;
    setBuild(r.fl);
    var cand=[[r.x2-1.1,r.z2-1.1],[r.x1+1.1,r.z2-1.1],[r.x2-1.1,r.z1+1.1],[r.x1+1.1,r.z1+1.1]],i,p,clash,spot=null;
    function ok(p,strict){
      if(strict)for(var k=0;k<spots.length;k++)if(spots[k].fl===r.fl&&Math.hypot(spots[k].x-p[0],spots[k].z-p[1])<1.8)return false;
      return freeAt(p[0],p[1],0.55,0.4,0.45);
    }
    for(i=0;i<cand.length&&!spot;i++)if(ok(cand[i],true))spot=cand[i];
    for(i=0;i<cand.length&&!spot;i++)if(ok(cand[i],false))spot=cand[i];
    if(!spot){for(var x=r.x1+1;x<r.x2-1&&!spot;x+=1)for(var z=r.z1+1;z<r.z2-1&&!spot;z+=1)if(ok([x,z],false))spot=[x,z];}
    if(!spot)return;
    addSpot(r.fl,spot[0],spot[1],label,col,'chest');
    var s=spots[spots.length-1];s.special=true;s.item=item;
  }
  corner('nur','افتح الصندوق الحديدي','gun',0x6a6a72);
  corner('laun','ابحث في الصندوق','ham',0x7a6a52);
  addTableItem(25.1,0.92,4.35,'خذ الرصاص من فوق الطاولة');
  addTableItem(27.6,0.92,37.0,'خذ الرصاص من فوق الطاولة');
  setBuild(0);
}
function addTableItem(x,y,z,label){
  setBuild(0);
  var g=new THREE.Group(),mat=new THREE.MeshPhongMaterial({color:0x4a5a34,shininess:20});
  g.add(mk(new THREE.BoxGeometry(0.3,0.12,0.2),mat,0,0.06,0));
  g.add(mk(new THREE.BoxGeometry(0.32,0.02,0.22),matP(0x2a3220),0,0.125,0));
  var bm=new THREE.MeshPhongMaterial({color:0xc8a040,shininess:80,specular:0xffffff});
  for(var i=0;i<3;i++){var b=mk(new THREE.CylinderGeometry(0.014,0.014,0.07,8),bm,-0.08+i*0.08,0.016+0.0,0.2);b.rotation.z=Math.PI/2;g.add(b);}
  var gl=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,color:0xffd070}));
  gl.scale.set(0.6,0.6,1);gl.position.y=0.15;g.add(gl);
  g.position.set(x,y,z);CURG.add(g);
  spots.push({fl:0,x:x,z:z,label:label,obj:g,mat:mat,col:0x4a5a34,searched:false,key:false,item:'ammo',n:3,special:true,hide:true,r:2.6});
}
function takeItem(sp){
  Snd.chime();
  if(sp.item==='gun'){P.gun=true;P.ammo+=2;toast('وجدت مسدسًا! فيه رصاصتان — اضغط Q أو النقر للإطلاق. ابحث عن بقية الرصاص فوق الطاولات.',4600);}
  else if(sp.item==='ammo'){P.ammo+=sp.n;toast('أخذت '+AR_NUM(sp.n)+' رصاصات (المجموع '+AR_NUM(P.ammo)+')',2400);}
  else if(sp.item==='ham'){game.ham=true;toast('وجدت مطرقة صغيرة — تفيد في إصلاح الباب الحديدي',3200);}
}
function syncTools(){spots.forEach(function(s){if(s.item==='ham'&&s.searched)game.ham=true;});if(game.safeOpen)game.sd=true;}

/* ---- scene extras: light switch, hall lamps, safe, note ---- */
function buildExtras(){
  setBuild(0);
  var sw=new THREE.Group();
  sw.add(mk(new THREE.BoxGeometry(0.17,0.26,0.05),matP(0xd8d0bc,30),0,0,0));
  sw.add(mk(new THREE.BoxGeometry(0.04,0.1,0.05),matP(0x2a2a2a),0,0.03,0.04));
  sw.add(mk(new THREE.SphereGeometry(0.018,8,8),new THREE.MeshBasicMaterial({color:0x44ff77}),0,-0.09,0.03));
  sw.position.set(SW.x,SW.y,SW.z);CURG.add(sw);
  var gl=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,color:0x66ff99}));
  gl.scale.set(0.5,0.5,1);gl.position.set(SW.x,SW.y-0.09,SW.z-0.05);CURG.add(gl);
  [8,24,40,54].forEach(function(x){
    var lp=new THREE.PointLight(0xffd9a0,0,26,1.6);lp.position.set(x,4.2,17.4);CURG.add(lp);lampLights.push(lp);
    var arm=mk(new THREE.BoxGeometry(0.1,0.1,0.35),matP(0x2a2018),x,3.55,16.35);CURG.add(arm);
    var bulb=mk(new THREE.SphereGeometry(0.17,10,8),new THREE.MeshBasicMaterial({color:0x2a2418}),x,3.62,16.55);CURG.add(bulb);lampBulbs.push(bulb);
    var sh=mk(new THREE.ConeGeometry(0.3,0.34,12,1,true),new THREE.MeshPhongMaterial({color:0x6a5238,side:THREE.DoubleSide,shininess:4}),x,3.78,16.55);CURG.add(sh);
  });
  /* الخزنة */
  var g=new THREE.Group(),steel=new THREE.MeshPhongMaterial({color:0x3c4048,shininess:60,specular:0x888888}),brass=new THREE.MeshPhongMaterial({color:0xb58a3a,shininess:60,specular:0xffffff});
  g.add(mk(new THREE.BoxGeometry(1.0,1.15,0.6),steel,0,0.575,0));
  var inner=mk(new THREE.BoxGeometry(0.84,0.99,0.5),matP(0x0e0e10),0,0.575,0.06);g.add(inner);
  var piv=pivot(-0.42,0,0.3);
  piv.add(mk(new THREE.BoxGeometry(0.86,1.0,0.06),new THREE.MeshPhongMaterial({color:0x4a4e58,shininess:80,specular:0xaaaaaa}),0.43,0.575,0.03));
  var dial=mk(new THREE.CylinderGeometry(0.1,0.1,0.05,20),brass,0.43,0.72,0.075);dial.rotation.x=Math.PI/2;piv.add(dial);
  piv.add(mk(new THREE.BoxGeometry(0.26,0.05,0.05),brass,0.43,0.42,0.08));
  var led=mk(new THREE.BoxGeometry(0.07,0.035,0.02),new THREE.MeshBasicMaterial({color:0xff2a1a}),0.7,0.95,0.065);piv.add(led);
  g.add(piv);
  var sd=new THREE.Group();
  var shaft=mk(new THREE.CylinderGeometry(0.012,0.012,0.22,8),new THREE.MeshPhongMaterial({color:0x9a9aa2,shininess:70}),0,0,0);shaft.rotation.z=Math.PI/2;sd.add(shaft);
  var hnd=mk(new THREE.CylinderGeometry(0.03,0.026,0.13,10),matP(0xc03020,20),-0.17,0,0);hnd.rotation.z=Math.PI/2;sd.add(hnd);
  sd.position.set(0.1,0.12,0.1);g.add(sd);
  g.position.set(SAFE.x,0,SAFE.z+0.3);CURG.add(g);
  box1(SAFE.x-0.6,SAFE.x+0.6,0,SAFE.z+0.65);
  safeObj={g:g,piv:piv,sd:sd,led:led};
  /* الورقة (رمز الخزنة) فوق طاولة المطبخ الجانبية */
  var note=new THREE.Group();
  note.add(mk(new THREE.BoxGeometry(0.28,0.006,0.2),new THREE.MeshPhongMaterial({color:0xd8cfae,shininess:2}),0,0,0));
  var ng=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,color:0xffe0a0}));ng.scale.set(0.5,0.5,1);ng.position.y=0.1;note.add(ng);
  note.position.set(NOTE.x,NOTE.y,NOTE.z);note.rotation.y=0.4;CURG.add(note);
  /* لوحة أرقام الخزنة */
  var grid=$('padGrid');
  if(grid&&!grid.children.length){
    ['1','2','3','4','5','6','7','8','9','⌫','0','✓'].forEach(function(k){
      var b=document.createElement('button');b.type='button';b.textContent=k;b.addEventListener('click',function(){padKey(k);});grid.appendChild(b);
    });
    $('padX').addEventListener('click',function(){closePad(true);});
    window.addEventListener('keydown',function(e){
      if(game.state!=='pad')return;
      if(e.code==='Escape'){closePad(true);e.preventDefault();return;}
      if(/^[0-9]$/.test(e.key))padKey(e.key);else if(e.code==='Backspace')padKey('⌫');
    });
  }
  setBuild(0);
}
function resetExtras(){
  game.day=1;game.dayFinal=false;game.dayDeath=false;
  game.fixed=false;game.safeOpen=false;game.ham=false;game.sd=false;game.codeKnown=false;
  game.lightT=0;game.hitSeq=0;game.hitType='h';game.fireCD=0;game.noiseT=0;game.extraNoise=0;game.repairing=false;game.fixT=0;
  game.code=100+Math.floor(rng((game.seed||1)^0x51ed)()*900);
  if(safeObj){safeObj.piv.rotation.y=0;safeObj.sd.visible=true;safeObj.led.material.color.setHex(0xff2a1a);}
  if(lampOn)scene.fog.density=fogBase;
  lampOn=false;lampLights.forEach(function(l){l.intensity=0;});lampBulbs.forEach(function(b){b.material.color.setHex(0x2a2418);});
  amb.intensity=0.7*S.bright;
  var inv=$('inv');if(inv)inv.hidden=true;
  closePad(false);
}

/* ---- interaction targets ---- */
function extraTarget(){
  if(P.fl!==0)return null;
  var x=P.x,z=P.z;
  if(Math.hypot(SW.x-x,SW.z-z)<2.0)return {type:'x',label:game.lightT>0?'الأضواء مضاءة':'تشغيل الضوء',run:toggleLight};
  if(!game.safeOpen&&Math.hypot(SAFE.x-x,SAFE.z+0.5-z)<2.1)return {type:'x',label:'الخزنة — إدخال الرمز',run:openPad};
  if(Math.hypot(NOTE.x-x,NOTE.z-z)<2.0)return {type:'x',label:'قراءة الورقة',run:readNote};
  if(exitBox&&exitBox.door&&!game.doorOpen&&!game.fixed&&distBox(x,z,exitBox)<2.2){
    if(game.ham&&game.sd)return {type:'x',label:game.repairing?'جارٍ الإصلاح…':'إصلاح قفل الباب بالمفك والمطرقة',run:startRepair};
    var need=[];if(!game.ham)need.push('مطرقة');if(!game.sd)need.push('مفك');
    return {type:'x',label:'قفل الباب محطّم — تحتاج '+need.join(' و'),run:function(){Snd.bang();toast('الباب الحديدي يحتاج إصلاحًا: '+need.join(' و')+'. المفك داخل الخزنة والمطرقة في صندوق.',3000);}};
  }
  return null;
}
function toggleLight(){
  if(game.lightT>0){toast('الضوء مضاء بالفعل',1200);return;}
  game.lightT=10;game.noiseT=0.5;Snd.tone('square',320,180,0.14,0.08);setTimeout(function(){Snd.tone('square',200,140,0.1,0.06);},70);
  toast('أُضيء الممر — عشر ثوانٍ فقط',2400);
}
function readNote(){
  game.codeKnown=true;toast('ورقة بخط مرتعش: «رمز الخزنة '+AR_NUM(game.code)+'»',4200);
  Snd.creak(0.06);
}
function openPad(){
  if(game.state!=='play')return;
  game.state='pad';padBuf='';
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  var p=$('pad');p.hidden=false;p.style.display='flex';p.className='screen';padRender();
}
function closePad(back){
  var p=$('pad');if(!p)return;
  p.hidden=true;p.style.display='none';
  if(game.state==='pad'){game.state='play';game.last=performance.now();if(back!==false)requestLock();}
}
function padRender(){
  var s='';for(var i=0;i<3;i++)s+=(i<padBuf.length?padBuf.charAt(i):'-')+(i<2?' ':'');
  $('padDisp').textContent=s;
}
function padKey(k){
  if(game.state!=='pad')return;
  if(k==='⌫'){padBuf=padBuf.slice(0,-1);padRender();return;}
  if(k==='✓'){if(padBuf.length<3)return;}
  else if(padBuf.length<3)padBuf+=k;
  padRender();Snd.tone('square',700+padBuf.length*80,700,0.06,0.05);
  if(padBuf.length===3){
    var p=$('pad'),good=(padBuf===String(game.code));
    setTimeout(function(){
      if(game.state!=='pad')return;
      if(good){
        p.className='screen ok';Snd.chime();game.safeOpen=true;syncTools();
        setTimeout(function(){closePad(true);toast('انفتحت الخزنة! وجدت مفكًّا',3200);},650);
      }else{
        p.className='screen bad';Snd.bang();padBuf='';
        setTimeout(function(){p.className='screen';padRender();},450);
      }
    },200);
  }
}
function startRepair(){
  if(game.repairing)return;
  game.repairing=true;game.fixT=0;toast('جارٍ إصلاح القفل… ابقَ قرب الباب (الضجيج قد يجذب الرجل)',3200);
}
function updateRepair(dt){
  if(!game.repairing)return;
  if(P.hidden||P.fl!==0||distBox(P.x,P.z,exitBox)>2.6){game.repairing=false;toast('توقف الإصلاح',1500);return;}
  game.fixT+=dt;
  game.rep2=(game.rep2||0)-dt;
  if(game.rep2<=0){game.rep2=0.55;Snd.tone('square',900,700,0.12,0.04);Snd.noise(0.2,0.06,1800);}
  if(game.fixT>=3){game.repairing=false;game.fixed=true;Snd.door();toast('تم إصلاح القفل! افتح الباب بالمفاتيح',3200);}
}

/* ---- gun ---- */
function applyHit(type){
  if(type==='g'){if(game.giantOn&&G)G.stun=3;}
  else if(D.monsters&&H){H.stun=6;}
}
function fire(){
  if(game.state!=='play'||!P.gun||P.hidden)return;
  if(game.fireCD>0)return;
  if(P.ammo<=0){game.fireCD=0.5;Snd.tone('square',1400,900,0.08,0.03);toast('لا توجد رصاصات — ابحث فوق الطاولات',1600);return;}
  P.ammo--;game.fireCD=0.6;HND.rec=1;HND.flashT=0.07;game.noiseT=0.7;game.shake+=0.25;
  Snd.shot();
  if(gunFlash){gunFlash.position.set(camera.position.x-Math.sin(P.yaw)*0.8,camera.position.y-0.1,camera.position.z-Math.cos(P.yaw)*0.8);}
  var dx=-Math.sin(P.yaw),dz=-Math.cos(P.yaw),hit=null;
  function test(M,rad,type){
    if(!M||M.x>150||(M.fl||0)!==P.fl)return;
    var vx=M.x-P.x,vz=M.z-P.z,al=vx*dx+vz*dz;
    if(al<0.4||al>34)return;
    if(Math.abs(vx*dz-vz*dx)>rad)return;
    if(blocked(P.x,P.z,M.x,M.z,P.fl))return;
    if(!hit||al<hit.al)hit={type:type,al:al};
  }
  if(D.monsters&&hmGroup.visible)test(H,0.75,'h');
  if(game.giantOn)test(G,1.3,'g');
  if(hit){
    if(!NET.room||isHost())applyHit(hit.type);
    else{game.hitSeq++;game.hitType=hit.type;}
    toast(hit.type==='g'?'أصبت العملاق! توقف لثوانٍ':'أصبته! سقط على ركبتيه لثوانٍ',1800);
    $('hit').style.opacity=0.25;setTimeout(function(){if(game.state==='play')$('hit').style.opacity=0;},90);
  }
  if(!NET.room||isHost()){if(D.monsters&&H.state!=='chase'&&dist2(H,P)<26&&H.stun<=0){H.state='investigate';setGoal(H,P.x,P.z,P.fl);H.wait=0;}}
}
Snd.shot=function(){Snd.noise(0.9,0.3,3000);Snd.tone('square',220,40,0.4,0.22);Snd.noise(0.5,0.7,350);};

/* ---- lights ---- */
function updateLights(dt){
  var f=0;
  if(game.lightT>0){
    game.lightT-=dt;
    if(!lampOn){lampOn=true;fogBase=scene.fog.density;}
    f=game.lightT>2?1:(Math.random()<0.55?1:0.08);
    if(game.lightT<=0){game.lightT=0;f=0;Snd.tone('square',200,120,0.12,0.1);}
  }
  if(game.lightT>0||lampOn){
    lampLights.forEach(function(l){l.intensity=2.3*f*S.bright;});
    lampBulbs.forEach(function(b){b.material.color.setHex(f>0.5?0xffe6aa:0x2a2418);});
    amb.intensity=(0.7+0.5*f)*S.bright;
    scene.fog.density=fogBase*(1-0.5*f);
    if(game.lightT<=0){lampOn=false;scene.fog.density=fogBase;amb.intensity=0.7*S.bright;}
  }
}
function updateSafe(dt){
  if(!safeObj)return;
  var tg=game.safeOpen?-1.8:0;
  safeObj.piv.rotation.y+=(tg-safeObj.piv.rotation.y)*Math.min(1,dt*4);
  safeObj.sd.visible=!game.safeOpen||safeObj.piv.rotation.y>-1.0;
  safeObj.led.material.color.setHex(game.safeOpen?0x30ff60:0xff2a1a);
  if(game.safeOpen&&safeObj.piv.rotation.y<-1.0)safeObj.sd.visible=false;
}
function extraUpdate(dt){
  game.fireCD=Math.max(0,(game.fireCD||0)-dt);
  game.noiseT=Math.max(0,(game.noiseT||0)-dt);
  game.extraNoise=Math.max(game.noiseT>0?20:0,game.repairing?9:0);
  if(gunFlash){gunFlash.intensity=HND.flashT>0?5*HND.flashT/0.07:0;}
  HND.flashT=Math.max(0,HND.flashT-dt);
  updateLights(dt);updateSafe(dt);updateRepair(dt);updateHands(dt);syncTools();
  var inv=$('inv'),t=[];
  if(P.gun)t.push('🔫 '+AR_NUM(P.ammo));else if(P.ammo>0)t.push('رصاص '+AR_NUM(P.ammo));
  if(game.ham)t.push('🔨');if(game.sd)t.push('🪛');
  if(game.codeKnown&&!game.safeOpen)t.push('🔢 '+AR_NUM(game.code));
  if(game.fixed)t.push('✔ الباب');
  var txt=t.join('  ');
  if(inv){inv.hidden=!txt;if(inv.textContent!==txt)inv.textContent=txt;}
  var fb=$('bFire');if(fb)fb.style.display=(touch.on&&P.gun)?'':'none';
}

/* ---- first-person hands ---- */
function skinTexture(){
  var c=cnv(64,64),g=c.getContext('2d'),i;
  g.fillStyle='#d6a07a';g.fillRect(0,0,64,64);
  for(i=0;i<46;i++){g.fillStyle='rgba('+(150+((Math.random()*40)|0))+',92,70,0.10)';g.fillRect(R(0,64),R(0,64),R(2,12),R(1,3));}
  g.strokeStyle='rgba(90,110,150,0.16)';g.lineWidth=1;
  for(i=0;i<4;i++){g.beginPath();g.moveTo(R(0,64),0);g.bezierCurveTo(R(0,64),20,R(0,64),40,R(0,64),64);g.stroke();}
  speckle(g,64,64,70,'rgba(80,40,30,A)',2);
  return toTex(c,1,1);
}
function buildHands(){
  hs=new THREE.Scene();hcam=new THREE.PerspectiveCamera(58,1,0.02,6);
  hs.add(new THREE.AmbientLight(0x9a8a80,0.8));
  var dl=new THREE.DirectionalLight(0xffeedd,0.75);dl.position.set(-0.4,1,1);hs.add(dl);
  renderer.autoClear=false;
  gunFlash=new THREE.PointLight(0xffd080,0,16,2);scene.add(gunFlash);
  var sk=new THREE.MeshPhongMaterial({map:skinTexture(),shininess:14,specular:0x332222});
  var sleeve=new THREE.MeshPhongMaterial({color:0x2a2a32,shininess:3});
  var nail=new THREE.MeshPhongMaterial({color:0xecd0be,shininess:60});
  function cylZ(r0,r1,len,mat){var m=new THREE.Mesh(new THREE.CylinderGeometry(r0,r1,len,10),mat);m.rotation.x=Math.PI/2;m.position.z=-len/2;return m;}
  function finger(g,x,z0,c1,c2,c3,sc,ry){
    var p1=pivot(x,0.004,z0);p1.rotation.x=-c1;if(ry)p1.rotation.y=ry;
    p1.add(cylZ(0.0115,0.0105,0.046*sc,sk));
    var p2=pivot(0,0,-0.046*sc);p2.rotation.x=-c2;p2.add(new THREE.Mesh(new THREE.SphereGeometry(0.0108,8,6),sk));p2.add(cylZ(0.0105,0.0095,0.033*sc,sk));
    var p3=pivot(0,0,-0.033*sc);p3.rotation.x=-c3;p3.add(new THREE.Mesh(new THREE.SphereGeometry(0.0096,8,6),sk));p3.add(cylZ(0.0095,0.0085,0.026*sc,sk));
    var nl=mk(new THREE.BoxGeometry(0.011,0.003,0.014),nail,0,0.0078,-0.016*sc);p3.add(nl);
    p2.add(p3);p1.add(p2);g.add(p1);return p1;
  }
  function hand(sign,pose){
    var g=new THREE.Group();
    var fore=new THREE.Mesh(new THREE.CylinderGeometry(0.036,0.047,0.5,14),sk);fore.rotation.x=Math.PI/2;fore.position.z=0.27;g.add(fore);
    var sl=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.058,0.3,14,1,true),sleeve);sl.rotation.x=Math.PI/2;sl.position.z=0.4;g.add(sl);
    var cuff=new THREE.Mesh(new THREE.TorusGeometry(0.052,0.008,6,16),matP(0x1c1c22,2));cuff.position.z=0.25;g.add(cuff);
    var palm=mk(new THREE.BoxGeometry(0.098,0.034,0.1),sk,0,0,-0.05);g.add(palm);
    g.add(mk(new THREE.SphereGeometry(0.047,10,8),sk,0,0,0));
    var xs=[-0.036,-0.012,0.012,0.036],sc=[0.92,1.05,1.0,0.82],cv=pose==='grip'?[1.15,1.2,1.2,1.1]:(pose==='fist'?[1.2,1.3,1.3,1.2]:[0.35,0.45,0.5,0.55]);
    for(var i=0;i<4;i++){
      if(pose==='gun'&&i===0){finger(g,xs[i]*sign*-1,-0.1,0.08,0.05,0.02,sc[i]);continue;}
      finger(g,xs[i]*sign*-1,-0.1,cv[i],cv[i]*1.05,cv[i]*0.7,sc[i]);
    }
    var th=finger(g,sign*0.052,-0.045,0.2,0.25,0.15,1.0,sign*0.7);
    return g;
  }
  var L=new THREE.Group(),Lh=hand(-1,'grip');L.add(Lh);
  var fl=new THREE.Group();
  var body=new THREE.Mesh(new THREE.CylinderGeometry(0.026,0.03,0.2,14),new THREE.MeshPhongMaterial({color:0x2a2a30,shininess:50,specular:0x666666}));body.rotation.x=Math.PI/2;fl.add(body);
  var head=new THREE.Mesh(new THREE.CylinderGeometry(0.04,0.028,0.06,14),new THREE.MeshPhongMaterial({color:0x44444c,shininess:70,specular:0x888888}));head.rotation.x=Math.PI/2;head.position.z=-0.12;fl.add(head);
  var lens=new THREE.Mesh(new THREE.CircleGeometry(0.036,14),new THREE.MeshBasicMaterial({color:0xfff0c0}));lens.position.z=-0.151;lens.rotation.y=Math.PI;fl.add(lens);
  fl.position.set(0,-0.03,-0.1);Lh.add(fl);
  L.rotation.set(-0.1,0.25,0.5);hs.add(L);
  var R1=new THREE.Group(),Rf=hand(1,'relaxed');R1.add(Rf);
  HND.hammer=makeHammerTool();HND.hammer.position.set(0,-0.02,0.02);Rf.add(HND.hammer);HND.hammer.visible=false;
  HND.sdr=makeScrewdriver();HND.sdr.position.set(0,-0.02,0.02);Rf.add(HND.sdr);HND.sdr.visible=false;
  var R2=new THREE.Group(),Rg=hand(1,'gun');R2.add(Rg);
  var gun=makePistol();gun.position.set(0,0,0.03);
  Rg.add(gun);
  R1.rotation.set(-0.1,-0.25,-0.3);R2.rotation.set(-0.12,-0.12,-0.1);
  hs.add(R1);hs.add(R2);
  HND.L=L;HND.R1=R1;HND.R2=R2;HND.lens=lens;
  hcam.aspect=(cv.clientWidth||window.innerWidth)/(cv.clientHeight||window.innerHeight);hcam.updateProjectionMatrix();
  L.position.set(-0.2,-0.2,-0.42);R1.position.set(0.2,-0.2,-0.42);R2.position.set(0.2,-0.2,-0.42);
}
function handsVisible(){
  return !!hs&&P&&!P.hidden&&(game.state==='play'||game.state==='pad'||game.state==='paused');
}
function updateHands(dt){
  if(!hs||!HND.L)return;
  HND.t+=dt;
  var dy=P.yaw-(HND.py===undefined?P.yaw:HND.py),dp=P.pitch-(HND.pp===undefined?P.pitch:HND.pp);HND.py=P.yaw;HND.pp=P.pitch;
  while(dy>3.14159)dy-=6.28318;while(dy<-3.14159)dy+=6.28318;
  var k=Math.min(1,dt*8);
  HND.sx+=(Math.max(-0.07,Math.min(0.07,-dy*1.2))-HND.sx)*k;HND.sy+=(Math.max(-0.05,Math.min(0.05,dp*0.9))-HND.sy)*k;
  var mv=game.moving?1:0,bx=mv*Math.sin(P.bob*0.5)*0.012,by=mv*Math.abs(Math.sin(P.bob))*0.015+Math.sin(HND.t*1.7)*0.003;
  HND.rec=Math.max(0,HND.rec-dt*7);
  var cd=P.crouch?0.015:0;
  HND.L.position.set(-0.2+bx+HND.sx,-0.2-by+HND.sy-cd,-0.42);
  var rz=-0.42+HND.rec*0.06;
  HND.R1.position.set(0.2+bx+HND.sx,-0.2-by+HND.sy-cd,-0.42);
  HND.R2.position.set(0.2+bx+HND.sx,-0.2-by+HND.sy-cd,rz);
  HND.R2.rotation.x=-0.12+HND.rec*0.45;
  HND.R1.visible=!P.gun;HND.R2.visible=!!P.gun;
  if(HND.hammer){HND.hammer.visible=!P.gun&&!!game.ham;HND.sdr.visible=!P.gun&&!game.ham&&!!game.sd;}
  HND.lens.material.color.setHex(P.torch?0xfff0c0:0x303030);
}
function renderAll(){
  renderer.clear();
  renderer.render(scene,camera);
  if(handsVisible()){renderer.clearDepth();renderer.render(hs,hcam);}
}
