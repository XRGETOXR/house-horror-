
/* ========== p9b: days, wake-up, multiplayer screen, monsters, house ========== */
var dayTok=0,BED={x:2.4,y:0.98,z:3.6};

function dayAnim(n,mode,cb){
  var el=$('day'),tok=++dayTok;
  game.state='day';game.dayDeath=(mode!=='start');
  $('hud').hidden=true;$('prompt').style.opacity=0;$('cross').hidden=true;
  function boxes(cur,gone){var h='';for(var i=1;i<=DAYS;i++)h+='<i class="'+(i<=gone?'gone':(i===cur?'cur':''))+'">'+AR_NUM(i)+'</i>';return h;}
  function paint(title,cur,gone,sub){el.className='show';el.innerHTML='<div class="dtxt">'+title+'</div><div class="dboxes">'+boxes(cur,gone)+'</div><div class="dsub">'+sub+'</div>';}
  function at(ms,fn){setTimeout(function(){if(dayTok===tok)fn();},ms);}
  function done(){el.className='';el.innerHTML='';cb();}
  if(mode==='start'){
    paint('اليوم '+AR_NUM(1)+' من '+AR_NUM(DAYS),1,0,'عندك '+AR_NUM(DAYS)+' أيام فقط… انجُ قبل أن تنتهي');
    at(2300,done);
  }else if(mode==='death'){
    paint('سقطتَ في اليوم '+AR_NUM(n),n,n-1,'');
    at(700,function(){el.classList.add('x');Snd.bang();});
    at(2300,function(){paint('اليوم '+AR_NUM(n+1)+' من '+AR_NUM(DAYS),n+1,n,'بقيت لك '+AR_NUM(DAYS-n)+(DAYS-n<=2?' يومان':' أيام'));if(DAYS-n===1)el.querySelector('.dsub').textContent='بقي لك يوم أخير';if(DAYS-n===2)el.querySelector('.dsub').textContent='بقي لك يومان فقط';});
    at(4100,done);
  }else{
    paint('سقطتَ في اليوم '+AR_NUM(n),n,n-1,'آخر الأيام الستة');
    at(700,function(){el.classList.add('x');Snd.bang();});
    at(2700,done);
  }
}
function dayDeath(){
  if(game.dayFinal)return false;
  var d=game.day;
  if(d<DAYS){game.day=d+1;dayAnim(d,'death',respawn);}
  else dayAnim(d,'final',function(){game.dayFinal=true;showDeath();game.dayFinal=false;});
  return true;
}
function respawn(){
  var g=P.gun,a=P.ammo;
  P=newPlayer();P.gun=g;P.ammo=a;
  if(!NET.room)resetMonsters();
  game.threat=0;game.deadT=0;game.msgShown=false;game.killer=null;game.pHa=0;game.pGa=0;game.shake=0;game.moving=false;game.repairing=false;
  $('hit').style.opacity=0;$('slits').hidden=true;$('danger').style.opacity=0;$('warn').style.opacity=0;
  beginWake();
}
function beginWake(){
  game.state='wake';game.wakeT=0;game.dayDeath=false;
  $('day').className='';$('hud').hidden=true;$('cross').hidden=true;$('prompt').style.opacity=0;
  $('lid').style.opacity=1;Snd.creak(0.1);
  game.last=performance.now();
}
function ease(t){t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);}
function updateWake(dt){
  var t=(game.wakeT+=dt),T=3.8;
  T0+=dt;
  if(NET.room)simBackground(dt);
  animateMonsters(dt);
  var yaw=P.yaw,eye=EYE,x,y,z,pitch,roll,lid,blur;
  if(t<1.0){
    x=BED.x;y=BED.y;z=BED.z;pitch=1.3;roll=0.05*Math.sin(t*3);
    lid=t<0.35?1:(t<0.7?1-0.75*((t-0.35)/0.35):0.25+0.35*((t-0.7)/0.3));
  }else if(t<2.5){
    var u=ease((t-1.0)/1.5);
    x=BED.x+(P.x-0.9-BED.x)*u;y=BED.y+(1.2-BED.y)*u;z=BED.z+(P.z-BED.z)*u*0.5+(BED.z-BED.z);
    pitch=1.3-0.8*u;roll=0.04*Math.sin(t*2)*(1-u);
    lid=t<1.6?0.6*(1-(t-1.0)/0.6):(t>1.85&&t<2.0?0.8:0);
    if(!game.wk1){game.wk1=1;Snd.creak(0.08);Snd.beat(0.3);}
  }else{
    var v=ease((t-2.5)/1.3),sx=P.x-0.9,sz=BED.z+(P.z-BED.z)*0.5;
    x=sx+(P.x-sx)*v;z=sz+(P.z-sz)*v;y=1.2+(eye-1.2)*v;pitch=0.5*(1-v);roll=0;lid=0;
    if(!game.wk2&&v>0.3){game.wk2=1;Snd.noise(0.05,0.07,500);}
  }
  blur=Math.max(0,3.2*(1-t/T));
  $('lid').style.opacity=lid.toFixed(2);
  cv.style.filter=blur>0.15?'blur('+blur.toFixed(1)+'px)':'';
  camera.position.set(x,y,z);camera.rotation.set(pitch,yaw,roll);
  if(t>=T){
    game.wk1=0;game.wk2=0;
    $('lid').style.opacity=0;cv.style.filter='';
    game.state='play';game.last=performance.now();
    $('hud').hidden=false;$('prompt').hidden=false;$('cross').hidden=false;
    HND.py=undefined;
    if(game.day===1)toast('ابحث عن '+AR_NUM(game.need)+' مفاتيح مخبأة في الصناديق وتحت الدرج',3800);
    else toast('اليوم '+AR_NUM(game.day)+' — ما زلت محبوسًا. الأشياء التي جمعتها ما زالت معك',3600);
  }
}
function updateDay(dt){
  T0+=dt;
  if(NET.room){simBackground(dt);}
}
function updatePad(dt){
  T0+=dt;game.time+=dt;
  simBackground(dt);checkKills();
  if(game.state!=='pad')return;
  animateMonsters(dt);extraUpdate(dt);updateCamera(dt);updateHUD();
}
function cleanupExtras(){
  dayTok++;
  var d=$('day');if(d){d.className='';d.innerHTML='';}
  var l=$('lid');if(l)l.style.opacity=0;
  cv.style.filter='';
  closePad(false);
}

/* ---- dedicated multiplayer screen ---- */
function showMP(){
  game.state='menu';
  showScreen('<h2>👥 اللعب الجماعي</h2><p class="lead">العبوا معًا ضد الرجل والعملاق: يتشارك الفريق المفاتيح والصناديق والباب والأدوات.</p><div id="mp">'+mpHTML()+'</div><div class="btns"><button class="btn alt" id="mpBack" type="button">رجوع للقائمة</button></div><p class="fine">تطوير: Asoma Okazi</p>');
  bindMP();
  $('mpBack').addEventListener('click',showMenu);
  if(NET.room)NET.room.presence({st:'lobby'}).catch(function(){});
}

/* ---- realistic monsters ---- */
function burlapTex(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#a8905c';g.fillRect(0,0,128,128);
  g.strokeStyle='rgba(60,40,15,0.35)';g.lineWidth=1;
  for(i=0;i<128;i+=3){g.beginPath();g.moveTo(i,0);g.lineTo(i+R(-1,1),128);g.stroke();g.beginPath();g.moveTo(0,i);g.lineTo(128,i+R(-1,1));g.stroke();}
  for(i=0;i<22;i++){g.fillStyle='rgba(110,10,8,'+R(0.2,0.6).toFixed(2)+')';g.beginPath();g.arc(R(0,128),R(0,128),R(3,12),0,6.28);g.fill();}
  speckle(g,128,128,200,'rgba(30,20,5,A)',3);
  return toTex(c,1,1);
}
function apronTex(){
  var c=cnv(64,96),g=c.getContext('2d'),i;
  g.fillStyle='#3a2a1e';g.fillRect(0,0,64,96);
  speckle(g,64,96,260,'rgba(0,0,0,A)',3);
  for(i=0;i<9;i++){var x=R(2,62),y=R(0,50),h=R(18,60);g.fillStyle='rgba('+(110+((Math.random()*40)|0))+',10,8,0.8)';g.fillRect(x,y,R(3,8),h);g.beginPath();g.arc(x+2,y+h,R(2,4),0,6.28);g.fill();}
  g.fillStyle='rgba(90,6,6,0.7)';g.beginPath();g.arc(32,60,22,0,6.28);g.fill();
  return toTex(c,1,1);
}
function giantSkinTex(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#7a7868';g.fillRect(0,0,128,128);
  for(i=0;i<90;i++){g.fillStyle='rgba('+(60+((Math.random()*50)|0))+','+(70+((Math.random()*40)|0))+',55,0.18)';g.beginPath();g.arc(R(0,128),R(0,128),R(4,16),0,6.28);g.fill();}
  g.strokeStyle='rgba(120,40,40,0.45)';g.lineWidth=1;
  for(i=0;i<14;i++){g.beginPath();g.moveTo(R(0,128),R(0,128));g.bezierCurveTo(R(0,128),R(0,128),R(0,128),R(0,128),R(0,128),R(0,128));g.stroke();}
  g.strokeStyle='rgba(40,10,10,0.7)';g.lineWidth=2;
  for(i=0;i<5;i++){var x=R(10,118),y=R(10,118);g.beginPath();g.moveTo(x,y);g.lineTo(x+R(-26,26),y+R(8,30));g.stroke();}
  speckle(g,128,128,400,'rgba(20,20,10,A)',2);
  return toTex(c,2,2);
}
/* ---- realistic house: door frames, rugs, paintings, windows ---- */
function rugTex(base,trim){
  var c=cnv(128,96),g=c.getContext('2d'),i;
  g.fillStyle=base;g.fillRect(0,0,128,96);
  g.strokeStyle=trim;g.lineWidth=4;g.strokeRect(6,6,116,84);g.lineWidth=2;g.strokeRect(14,14,100,68);
  g.fillStyle=trim;for(i=0;i<5;i++){g.beginPath();g.moveTo(24+i*20,48);g.lineTo(34+i*20,36);g.lineTo(44+i*20,48);g.lineTo(34+i*20,60);g.closePath();g.fill();}
  speckle(g,128,96,500,'rgba(0,0,0,A)',2);
  return toTex(c,1,1);
}
function paintingTex(seed){
  var c=cnv(96,128),g=c.getContext('2d'),i;
  g.fillStyle=['#2a2a22','#22262c','#2c2420'][seed%3];g.fillRect(0,0,96,128);
  speckle(g,96,128,300,'rgba(255,255,255,A)',2);
  g.fillStyle='#0c0a09';g.beginPath();g.ellipse(48,56,22,30,0,0,6.28);g.fill();
  g.fillRect(24,86,48,42);
  g.fillStyle='rgba(200,190,160,0.85)';g.beginPath();g.arc(40,52,3.5,0,6.28);g.fill();g.beginPath();g.arc(56,52,3.5,0,6.28);g.fill();
  g.fillStyle='rgba(120,10,10,0.7)';for(i=0;i<4;i++)g.fillRect(30+i*10,76,3,R(8,24));
  return toTex(c,1,1);
}
function windowTex(){
  var c=cnv(64,96),g=c.getContext('2d');
  var gr=g.createLinearGradient(0,0,0,96);gr.addColorStop(0,'#1a2848');gr.addColorStop(1,'#0c1220');g.fillStyle=gr;g.fillRect(0,0,64,96);
  g.fillStyle='rgba(220,230,255,0.9)';g.beginPath();g.arc(44,22,6,0,6.28);g.fill();
  g.fillStyle='rgba(0,0,0,0.6)';for(var i=0;i<4;i++){g.beginPath();g.moveTo(i*18,96);g.lineTo(i*18+8,60+R(0,10));g.lineTo(i*18+16,96);g.fill();}
  g.strokeStyle='#2a1c12';g.lineWidth=4;g.strokeRect(2,2,60,92);g.beginPath();g.moveTo(32,0);g.lineTo(32,96);g.moveTo(0,48);g.lineTo(64,48);g.stroke();
  return toTex(c,1,1);
}
function dressHouse(){
  var wood=matP(0x2e2016,4),i;
  doors.forEach(function(d){
    setBuild(d.fl);
    var hw=DOOR_W/2+0.05,ax=d.ax==='x';
    var p1=mk(new THREE.BoxGeometry(ax?0.14:0.26,2.9,ax?0.26:0.14),wood,ax?d.c-hw:d.fixed,1.45,ax?d.fixed:d.c-hw);
    var p2=mk(new THREE.BoxGeometry(ax?0.14:0.26,2.9,ax?0.26:0.14),wood,ax?d.c+hw:d.fixed,1.45,ax?d.fixed:d.c+hw);
    var hd=mk(new THREE.BoxGeometry(ax?DOOR_W+0.34:0.26,0.14,ax?0.26:DOOR_W+0.34),wood,ax?d.c:d.fixed,2.87,ax?d.fixed:d.c);
    CURG.add(p1);CURG.add(p2);CURG.add(hd);
  });
  var skip={bath:1,stor:1,cell:1,laun:1,exit:1};
  ROOMS.concat(ROOMS2).forEach(function(r,ri){
    setBuild(r.fl);
    var w=r.x2-r.x1,dp=r.z2-r.z1;
    if(!skip[r.id]){
      var rug=new THREE.Mesh(new THREE.PlaneGeometry(Math.min(4,w*0.4),Math.min(3,dp*0.3)),new THREE.MeshPhongMaterial({map:rugTex(['#4a1a1a','#1f2e3a','#3a3020','#2a1f33'][ri%4],'#b08a4a'),shininess:2}));
      rug.rotation.x=-Math.PI/2;rug.position.set(r.cx,0.014,r.cz);CURG.add(rug);
    }
    var north=r.z1<16,wz=north?r.z1+0.17:r.z2-0.17,ry=north?0:Math.PI;
    var pt=new THREE.Mesh(new THREE.PlaneGeometry(0.9,1.2),new THREE.MeshPhongMaterial({map:paintingTex(ri),shininess:25}));
    pt.position.set(r.x1+w*0.3,2.0,wz);pt.rotation.y=ry;CURG.add(pt);
    var fr=mk(new THREE.BoxGeometry(1.02,1.32,0.05),matP(0x5a4020,30),r.x1+w*0.3,2.0,wz+(north?-0.02:0.02));CURG.add(fr);
    if(north&&r.fl===0&&r.id!=='bath'){
      var wd=new THREE.Mesh(new THREE.PlaneGeometry(1.3,1.8),new THREE.MeshBasicMaterial({map:windowTex()}));
      wd.position.set(r.x1+w*0.72,1.9,wz);CURG.add(wd);
      CURG.add(mk(new THREE.BoxGeometry(1.46,1.96,0.05),wood,r.x1+w*0.72,1.9,wz-0.02));
    }
  });
  setBuild(0);
}
