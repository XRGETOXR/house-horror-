
/* ---------- cinematic ending ---------- */
var outPane=null, OUT=null, sunLight=null, sunSprite=null, CIN=null;
var cA=new THREE.Color(), cB=new THREE.Color();
var SKYS=[[0,0x04060c],[0.35,0x3a2a55],[0.7,0xff9a55],[1,0x8fb4d8]];
function skyAt(k,col){
  k=Math.max(0,Math.min(1,k));
  for(var i=0;i<SKYS.length-1;i++){
    if(k<=SKYS[i+1][0]){var f=(k-SKYS[i][0])/(SKYS[i+1][0]-SKYS[i][0]);cA.setHex(SKYS[i][1]);cB.setHex(SKYS[i+1][1]);col.copy(cA).lerp(cB,f);return;}
  }
  col.setHex(SKYS[SKYS.length-1][1]);
}
function ease(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
function lerp(a,b,k){return a+(b-a)*k;}
Snd.pad=function(freqs,dur,vol){
  if(!AC)return;var t=AC.currentTime;
  freqs.forEach(function(f){
    var o=AC.createOscillator(),g=AC.createGain();o.type='triangle';o.frequency.value=f;
    g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(vol,t+dur*0.4);g.gain.linearRampToValueAtTime(0.0001,t+dur);
    o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+0.1);
  });
};
Snd.kick=function(v){Snd.tone('sine',130,38,v,0.24);};
Snd.whoosh=function(){Snd.noise(0.28,0.45,2400);};

function buildOutdoor(){
  if(OUT)return;
  OUT=new THREE.Group();OUT.visible=false;scene.add(OUT);
  var gc=cnv(128,128),g=gc.getContext('2d');
  g.fillStyle='#34522d';g.fillRect(0,0,128,128);speckle(g,128,128,900,'rgba(0,25,0,A)',3);speckle(g,128,128,300,'rgba(130,170,90,A)',2);
  var gm=new THREE.Mesh(new THREE.PlaneGeometry(420,420),new THREE.MeshPhongMaterial({map:toTex(gc,90,90),shininess:1}));
  gm.rotation.x=-Math.PI/2;gm.position.set(30,-0.03,28);OUT.add(gm);
  var pm=new THREE.Mesh(new THREE.PlaneGeometry(70,3.4),matP(0x7a6a52));
  pm.rotation.x=-Math.PI/2;pm.position.set(95,0.02,ROOM.exit.cz);OUT.add(pm);
  var tg=new THREE.CylinderGeometry(0.25,0.32,2.6,6),cg=new THREE.ConeGeometry(1.7,3.4,7);
  var tm=matP(0x3a2a1c),c1=matP(0x1f3a22),c2=matP(0x2a4a2a);
  for(var i=0;i<90;i++){
    var x,z,tries=0;
    do{x=R(-110,150);z=R(-110,140);tries++;}while(tries<20&&((x>-9&&x<71&&z>-9&&z<65)||(x>58&&Math.abs(z-ROOM.exit.cz)<5)));
    var s=R(0.8,1.7),tr=new THREE.Group();
    var tk=new THREE.Mesh(tg,tm);tk.position.y=1.3;tr.add(tk);
    var a=new THREE.Mesh(cg,c1);a.position.y=3.6;tr.add(a);
    var b=new THREE.Mesh(cg,c2);b.position.y=5.0;b.scale.set(0.75,0.75,0.75);tr.add(b);
    tr.position.set(x,0,z);tr.scale.set(s,s,s);OUT.add(tr);
  }
  var wm=new THREE.MeshPhongMaterial({color:0x7d6c5a,shininess:2});
  function panel(w,h,d,x,y,z){var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),wm);m.position.set(x,y,z);OUT.add(m);}
  var H2=FY*2;
  panel(61,H2,0.1,30,H2/2,-0.25);panel(61,H2,0.1,30,H2/2,56.25);panel(0.1,H2,57,-0.25,H2/2,28);
  var dz=ROOM.exit.cz,hw=DOOR_W/2;
  panel(0.1,H2,dz-hw+0.25,60.3,H2/2,(dz-hw-0.25)/2);
  panel(0.1,H2,56.25-(dz+hw),60.3,H2/2,(dz+hw+56.25)/2);
  panel(0.1,H2-2.8,DOOR_W,60.3,2.8+(H2-2.8)/2,dz);
  var roof=new THREE.Mesh(new THREE.BoxGeometry(62,0.5,58),matP(0x2a2220));roof.position.set(30,H2+0.1,28);OUT.add(roof);
  sunSprite=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,color:0xffd29a,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,fog:false}));
  sunSprite.scale.set(110,110,1);sunSprite.position.set(260,-10,ROOM.exit.cz);OUT.add(sunSprite);
  sunLight=new THREE.DirectionalLight(0xffc890,0);sunLight.position.set(200,40,32);scene.add(sunLight);
}
function setCap(html,cls){var c=$('cap');c.innerHTML=html;c.className=cls||'';c.style.opacity=html?1:0;}
function flash(v){$('flash').style.opacity=v;}
function startCinema(){
  game.state='cinema';
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  $('hud').hidden=true;$('prompt').style.opacity=0;$('cross').hidden=true;$('mapwrap').style.display='none';
  $('danger').style.opacity=0;$('slits').hidden=true;$('hit').style.opacity=0;
  buildOutdoor();OUT.visible=true;if(outPane)outPane.visible=false;
  CIN={t:0,fired:{},cap:-1,cut:-1};
  if(NET.room){hmGroup.visible=false;gGroup.visible=false;}
  else{
  H.x=58.8;H.z=ROOM.exit.cz;H.fl=0;H.gy=0;H.dx=1;H.dz=0;H.v=0;H.atk=0;H.state='patrol';hmGroup.visible=true;
  if(game.giantOn||!D.monsters){G.x=30;G.z=-14;G.dx=0;G.dz=1;G.v=0;gGroup.visible=D.monsters;}
  }
  redGlow.intensity=0;greenGlow.intensity=0;torch.intensity=0;
  scene.fog.density=0.004;
  $('bars').classList.add('on');$('skip').style.display='block';
  Snd.pad([220,261.6,329.6],5,0.05);
}
function skipCinema(){if(CIN&&CIN.t<26)CIN.t=26;}
function cinemaCleanup(){
  if(!OUT)return;
  OUT.visible=false;if(outPane)outPane.visible=true;
  if(sunLight)sunLight.intensity=0;
  scene.background.setHex(0x020202);scene.fog.color.setHex(0x030303);
  camera.fov=74;camera.updateProjectionMatrix();
  $('bars').classList.remove('on');$('skip').style.display='none';setCap('');flash(0);
  redGlow.intensity=D.monsters?0.9:0;
  applyGfx();
}
function stat(label,val){return label+'<small>'+val+'</small>';}
function updateCinema(dt){
  var C=CIN;if(!C)return;C.t+=dt;if(NET.room)simBackground(dt);var t=C.t,fov=74,u,k,ci;
  var cp=camera.position,cy=ROOM.exit.cz;
  if(t<4.5){
    u=t/4.5;k=ease(u);cp.set(lerp(57,74,k),1.6+Math.sin(t*9)*0.05,cy+Math.sin(t*4.5)*0.06);
    camera.lookAt(cp.x+8,1.5,cy);fov=lerp(74,100,u);flash(u>0.7?(u-0.7)/0.3:0);
    if(!C.fired.a){C.fired.a=1;Snd.kick(0.5);}
    if(u>0.15)setCap(u<0.9?stat('ركض إلى النور','الباب خلفك مفتوح'):'','');
  }else if(t<9){
    u=(t-4.5)/4.5;cp.set(lerp(66,72,u),lerp(0.35,0.6,u),lerp(36,34,u));
    camera.lookAt(58.6,1.5,cy);fov=lerp(62,50,u);flash(Math.max(0,1-(t-4.5)*2.5));
    if(!C.fired.b){C.fired.b=1;Snd.pad([174.6,220,261.6],5,0.05);Snd.tone('sawtooth',90,45,0.14,1.4);}
    if(t>6.6&&!NET.room){H.dx=-1;H.dz=0;H.v=Math.min(1.1,(t-6.6)*0.8);H.x-=H.v*dt;}
    setCap('لم يلحق بك','');
  }else if(t<14.5){
    u=(t-9)/5.5;k=ease(u);cp.set(lerp(74,100,k),lerp(1.2,30,k),lerp(32,18,k));
    camera.lookAt(58,lerp(2,6,k),30);fov=lerp(55,50,u);if(!NET.room)H.v=0;
    skyAt((t-9)/8,scene.background);scene.fog.color.copy(scene.background);
    var sk=ease((t-9)/8);sunSprite.position.y=lerp(-10,45,sk);sunLight.intensity=sk*1.2;amb.intensity=0.7+sk*0.9;
    if(!C.fired.c){C.fired.c=1;Snd.pad([261.6,329.6,392,523.3],6,0.06);}
    setCap(t>10?'الفجر':'','');
  }else if(t<20){
    var uu=(t-14.5)/1.1;ci=Math.min(4,Math.floor(uu));u=uu-ci;
    skyAt(0.9,scene.background);scene.fog.color.copy(scene.background);sunSprite.position.y=45;
    var shots=[[100,22,8,94,18,6,30,6,28],[30,48,-46,30,44,-40,30,4,28],[30,95,34,30,85,34,30,0,28],[66,2.4,26,64,2,28,60,1.8,cy],[-34,10,36,-30,10,30,30,5,28]];
    var s=shots[ci];cp.set(lerp(s[0],s[3],u),lerp(s[1],s[4],u),lerp(s[2],s[5],u));camera.lookAt(s[6],s[7],s[8]);
    fov=ci===3?60:64;
    if(C.cut!==ci){
      C.cut=ci;Snd.whoosh();Snd.kick(0.55);flash(0.7);
      var cards=[stat('⏱ الوقت',fmtTime(game.time)),stat('🔑 المفاتيح',AR_NUM(game.keys)+'/'+AR_NUM(game.need)),stat('🕳 اختبأت',AR_NUM(game.stats.hides)+' مرة'),stat('😱 طاردك الوحش',AR_NUM(game.stats.chases)+' مرة'),stat('🏠 بيت المطرقة','٢٧ غرفة · طابقان')];
      setCap(cards[ci],'');
    }
    flash(Math.max(0,0.7-u*2.2));
  }else{
    var a=0.6+(t-20)*0.12,kk=Math.min(1,(t-20)/8);
    skyAt(1,scene.background);scene.fog.color.copy(scene.background);
    cp.set(30+Math.cos(a)*95,lerp(22,36,kk),28+Math.sin(a)*95);camera.lookAt(30,6,28);fov=52;
    if(!C.fired.d){C.fired.d=1;Snd.pad([261.6,329.6,392,523.3,659.3],8,0.07);Snd.kick(0.7);flash(0.8);}
    if(t<24)setCap('نجوت<small>بيت المطرقة</small>','big');
    else if(t<26.5)setCap('تطوير Asoma Okazi','');
    else if(!C.fired.e){C.fired.e=1;setCap('');showEnd();}
    if(t<24.5)flash(Math.max(0,0.8-(t-20)*2));
  }
  if(camera.fov!==fov){camera.fov=fov;camera.updateProjectionMatrix();}
  H.phase=(H.phase||0);
  animateMonsters(dt);
}
function showEnd(){
  var sc=$('scr');
  showScreen('<h2 style="color:#6fbf73">هربت من البيت</h2><p class="lead">الوقت '+fmtTime(game.time)+' · المفاتيح '+AR_NUM(game.keys)+'/'+AR_NUM(game.need)+' · الاختباء '+AR_NUM(game.stats.hides)+' مرة</p><div class="btns"><button class="btn" id="go" type="button">العب مجددًا</button><button class="btn alt" id="menub" type="button">القائمة</button></div><p class="fine">تطوير: Asoma Okazi</p>');
  sc.style.background='linear-gradient(transparent,rgba(2,1,1,.85))';sc.style.alignItems='flex-end';
  bindGo(startGame);
}

$('skip').addEventListener('click',skipCinema);
