
var DIFF={
  easy:{name:'سهل',keys:3,hs:0.85,gs:0.85,see:0.8,monsters:true,giant:0.5,info:'٣ مفاتيح · وحوش أبطأ وأقل يقظة · قد لا يظهر العملاق'},
  med:{name:'متوسط',keys:5,hs:1,gs:1,see:1,monsters:true,giant:0.7,info:'٥ مفاتيح · وحوش بسرعة عادية · قد لا يظهر العملاق'},
  hard:{name:'صعب',keys:10,hs:1.15,gs:1.1,see:1.2,monsters:true,giant:0.9,info:'١٠ مفاتيح · وحوش أسرع وأكثر يقظة'},
  none:{name:'بلا وحوش',keys:20,hs:1,gs:1,see:1,monsters:false,giant:0,info:'٢٠ مفتاحًا · بلا وحوش إطلاقًا، استكشف بهدوء'}
};
var D=DIFF.med;
function updFloor(e){
  var s=STAIR;
  if(e.x>s.x1&&e.x<s.x2&&e.z>s.z1&&e.z<s.z2){var u=(e.x-s.x1)/(s.x2-s.x1);e.gy=u*FY;e.fl=u>0.5?1:0;}
  else e.gy=(e.fl||0)*FY;
}

/* ---------- monsters: models ---------- */
function mk(geo,mat,x,y,z){var m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);return m;}
function pivot(x,y,z){var g=new THREE.Group();g.position.set(x,y,z);return g;}
var HM={}, GM={};
/* ---------- monsters: state ---------- */
var P,H,G,hmGroup,gGroup,T0=0,game={};
function dist2(a,b){return Math.hypot(a.x-b.x,a.z-b.z);}
function stepTo(M,tx,tz,sp,dt,r,turn){
  var dx=tx-M.x,dz=tz-M.z,d=Math.hypot(dx,dz);
  if(d<0.001){M.v=0;return 0;}
  var k=Math.min(1,dt*(turn||7));
  M.dx+=(dx/d-M.dx)*k;M.dz+=(dz/d-M.dz)*k;
  var l=Math.hypot(M.dx,M.dz)||1;M.dx/=l;M.dz/=l;
  var st=Math.min(sp*dt,d);M.x+=M.dx*st;M.z+=M.dz*st;pushOut(M,r);M.v=st/dt;
  return Math.hypot(tx-M.x,tz-M.z);
}
function setGoal(M,x,z,fl){
  if(fl===undefined)fl=M.fl||0;
  var a=nearestNode(M.x,M.z,M.fl||0),b=nearestNode(x,z,fl),ids=route(a,b);
  var p=ids.map(function(k){return {x:nodes[k].x,z:nodes[k].z,fl:nodes[k].fl};});
  if(nodes[b].fl===fl&&!blocked(nodes[b].x,nodes[b].z,x,z,fl))p.push({x:x,z:z,fl:fl});
  while(p.length>1&&p[0].fl===(M.fl||0)&&p[1].fl===(M.fl||0)&&!blocked(M.x,M.z,p[1].x,p[1].z,M.fl||0))p.shift();
  M.path=p;
}
function follow(M,dt,sp){
  if(!M.path.length){M.v=0;return true;}
  var w=M.path[0],rem=stepTo(M,w.x,w.z,sp,dt,0.45);
  if(rem<0.55)M.path.shift();
  return M.path.length===0;
}
function pickPatrol(){
  var all=ROOMS.concat(ROOMS2),cur=nearestNode(H.x,H.z,H.fl||0),tries=0,r;
  do{r=all[(Math.random()*all.length)|0];tries++;}while(roomNode[r.id]===cur&&tries<6);
  setGoal(H,r.cx,r.cz,r.fl);
}
var TG=null;
function hmCanSee(e){
  if(e.hidden||e.fl!==H.fl)return false;
  var d=dist2(H,e),range=(e.torch?17:10)*D.see;
  if(e.crouch)range*=0.65;
  if(d>range)return false;
  if(d>3.2){var dot=((e.x-H.x)*H.dx+(e.z-H.z)*H.dz)/d;if(dot<0.3)return false;}
  return !blocked(H.x,H.z,e.x,e.z,H.fl);
}
function pickTarget(){
  var l=mpPlayers(),best=null,bd=1e9,i,e,d;
  if(H.state==='hideCheck'&&TG&&l.indexOf(TG)>=0)return;
  for(i=0;i<l.length;i++){
    e=l[i];d=dist2(H,e)+(e.fl!==H.fl?9:0);
    if(hmCanSee(e))d-=1000;
    if(e===TG&&H.state==='chase')d-=6;
    if(d<bd){bd=d;best=e;}
  }
  TG=best||P;
}
function hearNoise(){
  var l=mpPlayers(),i,e;
  for(i=0;i<l.length;i++){e=l[i];if(e.noise>0&&!e.hidden&&dist2(H,e)+(e.fl!==H.fl?8:0)<e.noise)return e;}
  return null;
}
function startChase(e){
  if(H.state!=='chase'){
    H.state='chase';H.lose=0;H.stateT=0;
    if(e===P){game.stats.chases++;toast('الرجل رآك! اهرب!',1800);}
    if(dist2(H,P)<25)Snd.sting();
  }
}
function updateHammerMan(dt){
  updFloor(H);
  if(H.stun>0){H.stun-=dt;H.v=0;H.atk=0;H.atkAnim=0;return;}
  var d=dist2(H,TG),see=hmCanSee(TG);
  H.stateT+=dt;H.noiseCD-=dt;H.v=0;
  if(H.catchT>0){H.catchT-=dt;if(H.catchT<=0)H.catch=-1;}
  if(H.atk>0){
    H.atk-=dt;H.atkAnim=1-Math.max(0,H.atk)/0.55;
    if(H.atk<=0){H.atkAnim=0;H.cool=1.2;}
    return;
  }
  H.cool-=dt;
  if(H.state==='patrol'||H.state==='search'||H.state==='investigate'){
    if(see){startChase(TG);}
    else{
      var sp=(H.state==='patrol'?1.35:2.0)*D.hs;
      if(follow(H,dt,sp)){
        if(H.state==='patrol'||H.wait<=0){
          if(H.wait<=0){H.wait=H.state==='patrol'?R(1,2.6):R(2.5,4);}
        }
        H.wait-=dt;
        if(H.wait<=0){H.state='patrol';pickPatrol();}
      }
      var hn=H.noiseCD<=0?hearNoise():null;
      if(hn){H.noiseCD=3;H.state='investigate';setGoal(H,hn.x,hn.z,hn.fl);H.wait=0;}
    }
  }else if(H.state==='chase'){
    if(see){
      H.lose=0;H.last={x:TG.x,z:TG.z,fl:TG.fl};
      stepTo(H,TG.x,TG.z,2.9*D.hs,dt,0.45,9);
      if(d<1.9&&H.cool<=0){H.atk=0.55;Snd.swing();}
    }else if(TG.hidden&&dist2(H,TG)<18&&H.fl===TG.fl){
      H.state='hideCheck';H.closet=TG.hidden;H.stateT=0;setGoal(H,H.closet.exit.x,H.closet.exit.z,H.closet.fl);
    }else{
      H.lose+=dt;
      if(H.lose<0.3||!H.path.length){if(H.last)setGoal(H,H.last.x,H.last.z,H.last.fl);}
      follow(H,dt,2.7*D.hs);
      if(H.lose>5.5){H.state='search';H.wait=0;}
    }
  }else if(H.state==='hideCheck'){
    if(see){startChase(TG);}
    else{
      var cl=H.closet,dc=Math.hypot(H.x-cl.exit.x,H.z-cl.exit.z);
      if(dc>1.2||H.fl!==cl.fl){follow(H,dt,2.5*D.hs);H.stateT=0;}
      else{
        H.v=0;
        if(H.stateT>1.7){
          if(TG.hidden===cl){H.catch=closets.indexOf(cl);H.catchT=1.2;}
          H.state='search';H.wait=0;
        }
      }
    }
  }
  H.stuckT+=dt;
  if(H.stuckT>1.2){
    if(H.v>0.2&&Math.hypot(H.x-H.sx,H.z-H.sz)<0.2&&H.path.length){H.path.shift();}
    H.sx=H.x;H.sz=H.z;H.stuckT=0;
  }
}
function giantTarget(){
  var l=mpPlayers(),best=null,bd=1e9,i,e,d;
  for(i=0;i<l.length;i++){
    e=l[i];
    if(e.hidden||e.fl!==0||(e.gy||0)>=1.5||!(e.z>14.5&&e.z<25.5&&e.x>0&&e.x<60))continue;
    d=dist2(G,e);if(d<48&&d<bd){bd=d;best=e;}
  }
  return best;
}
function updateGiant(dt){
  if(G.stun>0){G.stun-=dt;G.v=0;G.atk=0;G.atkAnim=0;return;}
  var GT=giantTarget(),d=GT?dist2(G,GT):1e9,inHall=!!GT,tx,tz,sp;
  if(G.atk>0){
    G.atk-=dt;G.atkAnim=1-Math.max(0,G.atk)/1.4;G.v=0;
    if(G.atk<=0){G.atkAnim=0;G.cool=1.6;}
  }else{
    G.cool-=dt;
    if(inHall){
      tx=GT.x;tz=Math.max(19.4,Math.min(20.6,GT.z));sp=0.65*D.gs;
      if(d<2.9&&G.cool<=0){G.atk=1.4;Snd.groan();}
    }else{
      if(!G.goal||Math.abs(G.x-G.goal)<1){G.goal=R(5,55);}
      tx=G.goal;tz=20+Math.sin(T0*0.1)*0.5;sp=0.5*D.gs;
    }
    if(G.atk<=0&&!(inHall&&d<2.4))stepTo(G,tx,tz,sp,dt,1.2,1.4);else G.v=0;
    G.x=Math.max(2.2,Math.min(57.8,G.x));G.z=Math.max(19.3,Math.min(20.7,G.z));
  }
  G.phase+=dt*G.v*1.9;
  giantSteps();
}
function giantSteps(){
  var s=Math.sin(G.phase),dl=dist2(G,P);
  if(G.v>0.05&&(s>0)!==G.stepSign){G.stepSign=(s>0);if(dl<40){Snd.gstep(dl);if(dl<14)game.shake=Math.max(game.shake,0.05*(1-dl/14)+0.012);}}
}
function checkKills(){
  if(game.state!=='play')return;
  var ha=game.pHa||0,ga=game.pGa||0;
  if(D.monsters){
    if(ha>0&&H.atk<=0&&!P.hidden&&dist2(H,P)<2.6&&P.fl===H.fl)kill('hammer');
    if(game.state==='play'&&H.catch>=0&&P.hidden&&closets.indexOf(P.hidden)===H.catch)kill('closet');
  }
  if(game.state==='play'&&game.giantOn&&ga>0&&G.atk<=0&&!P.hidden&&dist2(G,P)<3.4&&P.fl===0)kill('giant');
  game.pHa=H.atk;game.pGa=G.atk;
}
