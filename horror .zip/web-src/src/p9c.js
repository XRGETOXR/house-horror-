
/* ========== p9c: rounded monsters, smooth gait, keys on tables, realistic tools ========== */
function lathe(pts,mat,seg){
  var v=[],i;for(i=0;i<pts.length;i++)v.push(new THREE.Vector2(pts[i][0],pts[i][1]));
  return new THREE.Mesh(new THREE.LatheGeometry(v,seg||14),mat);
}
function put(m,x,y,z){m.position.set(x,y,z);return m;}
function blob(r,sx,sy,sz,mat,seg){
  var m=new THREE.Mesh(new THREE.SphereGeometry(r,seg||14,(seg||14)*0.75),mat);m.scale.set(sx,sy,sz);return m;
}

/* outline with triangular spikes on both sides (mace / spiked head) */
function spikeOutline(hw,hh,n,sp){
  var p=[[-hw,-hh],[hw,-hh]],i,y0,y1,ym;
  for(i=0;i<n;i++){y0=-hh+2*hh*i/n;y1=-hh+2*hh*(i+1)/n;ym=(y0+y1)/2;p.push([hw+sp,ym],[hw,y1]);}
  p.push([-hw,hh]);
  for(i=n-1;i>=0;i--){y0=-hh+2*hh*i/n;y1=-hh+2*hh*(i+1)/n;ym=(y0+y1)/2;p.push([-hw-sp,ym],[-hw,y0]);}
  p.pop();
  return p;
}
function headGeo(hw,hh,n,sp,depth){
  var s=new THREE.Shape(),p=spikeOutline(hw,hh,n,sp),i;
  s.moveTo(p[0][0],p[0][1]);for(i=1;i<p.length;i++)s.lineTo(p[i][0],p[i][1]);
  var g=new THREE.ExtrudeGeometry(s,{depth:depth,bevelEnabled:true,bevelThickness:0.012,bevelSize:0.01,bevelSegments:2,curveSegments:1});
  g.translate(0,0,-depth/2);return g;
}

/* ---------- monsters ---------- */
function buildHammerMan(){
  var g=new THREE.Group(),A=HM;
  var cloth=new THREE.MeshPhongMaterial({color:0x3a312a,map:TEX.cloth,shininess:3});
  var trous=matP(0x2b2622,3),boot=matP(0x141010,20),leather=matP(0x2a1a10,12);
  var skin=new THREE.MeshPhongMaterial({color:0xb9a88f,shininess:6});
  var burlap=new THREE.MeshPhongMaterial({map:burlapTex(),shininess:2});
  var apron=new THREE.MeshPhongMaterial({map:apronTex(),shininess:10,side:THREE.DoubleSide});
  var dark=new THREE.MeshBasicMaterial({color:0x050303}),glow=new THREE.MeshBasicMaterial({color:0xff5a2a});
  var metal=new THREE.MeshPhongMaterial({color:0x8a8e96,shininess:80,specular:0xdddddd});
  var wood=new THREE.MeshPhongMaterial({color:0x4a3320,shininess:8});

  function leg(side){
    var hip=pivot(side*0.15,0.95,0),knee=pivot(0,-0.5,0);
    hip.add(lathe([[0,0.03],[0.135,0.02],[0.12,-0.2],[0.1,-0.38],[0,-0.5]],trous,14));
    knee.add(lathe([[0,0.03],[0.1,0.02],[0.085,-0.2],[0.075,-0.4],[0,-0.42]],trous,14));
    var f=blob(0.1,1,0.45,1.7,boot,12);put(f,0,-0.44,0.07);knee.add(f);
    hip.add(knee);g.add(hip);return {hip:hip,knee:knee};
  }
  var lL=leg(-1),lR=leg(1);
  A.legL=lL.hip;A.kneeL=lL.knee;A.legR=lR.hip;A.kneeR=lR.knee;

  var torso=lathe([[0,1.0],[0.22,1.02],[0.27,1.3],[0.27,1.62],[0.22,1.9],[0.12,1.96],[0,1.97]],cloth,16);
  torso.scale.set(1,1,0.66);g.add(torso);
  var belt=lathe([[0.25,1.05],[0.28,1.07],[0.28,1.13],[0.25,1.15]],leather,16);belt.scale.set(1,1,0.66);g.add(belt);
  var ap=new THREE.Mesh(new THREE.PlaneGeometry(0.44,0.78),apron);ap.position.set(0,1.36,0.16);g.add(ap);

  A.head=pivot(0,1.95,0);
  A.head.add(lathe([[0,-0.08],[0.09,-0.08],[0.1,0.04],[0,0.04]],dark,10));
  A.head.add(put(blob(0.25,1,1.12,0.98,burlap,18),0,0.13,0));
  A.head.add(put(lathe([[0,0],[0.1,0.02],[0.05,0.12],[0,0.2]],burlap,10),0,0.3,0));
  [-1,1].forEach(function(s){
    A.head.add(put(blob(0.05,1,1.2,0.5,dark,8),s*0.09,0.17,0.225));
    A.head.add(put(new THREE.Mesh(new THREE.SphereGeometry(0.016,8,8),glow),s*0.09,0.165,0.245));
  });
  var rope=new THREE.Mesh(new THREE.TorusGeometry(0.17,0.02,6,18),matP(0x6a5638,2));rope.rotation.x=Math.PI/2;rope.position.set(0,-0.03,0);A.head.add(rope);
  A.head.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.12,0.02,0.02),dark),0,0.02,0.24));
  g.add(A.head);

  function arm(side){
    var sh=pivot(side*0.31,1.78,0),el=pivot(0,-0.44,0);
    sh.add(lathe([[0,0.04],[0.08,0.02],[0.075,-0.22],[0.06,-0.4],[0,-0.44]],cloth,12));
    el.add(lathe([[0,0.03],[0.06,0.02],[0.055,-0.18],[0.04,-0.34],[0,-0.36]],skin,12));
    el.add(put(blob(0.06,1,1.3,0.7,skin,10),0,-0.38,0));
    sh.add(el);g.add(sh);return {sh:sh,el:el};
  }
  var aL=arm(-1),aR=arm(1);
  A.armL=aL.sh;A.elbowL=aL.el;A.armR=aR.sh;A.elbowR=aR.el;

  /* المطرقة بأشواك في يده */
  var hm=pivot(0,-0.38,0.03);hm.rotation.x=2.2;
  hm.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.04,1.1,12),wood),0,0.45,0));
  var hd=new THREE.Mesh(headGeo(0.2,0.12,4,0.09,0.2),metal);hd.position.set(0,1.0,0);hm.add(hd);
  hm.add(put(new THREE.Mesh(new THREE.ConeGeometry(0.05,0.12,10),metal),0,1.16,0));
  aR.el.add(hm);
  scene.add(g);return g;
}

function buildGiant(){
  var g=new THREE.Group(),A=GM;
  var skin=new THREE.MeshPhongMaterial({map:giantSkinTex(),shininess:6});
  var cloth=new THREE.MeshPhongMaterial({color:0x3a2a20,map:TEX.cloth,shininess:2});
  var dark=matP(0x2a2622,3),tusk=new THREE.MeshPhongMaterial({color:0xe8e0c0,shininess:30});
  var chain=new THREE.MeshPhongMaterial({color:0x6a6a72,shininess:60,specular:0xaaaaaa});
  var scar=new THREE.MeshBasicMaterial({color:0x3a0a0a});

  function leg(side){
    var hip=pivot(side*0.65,2.4,0),knee=pivot(0,-1.2,0);
    hip.add(lathe([[0,0.1],[0.5,0.06],[0.55,-0.5],[0.45,-1.0],[0.38,-1.2],[0,-1.22]],skin,16));
    knee.add(lathe([[0,0.05],[0.4,0.03],[0.36,-0.6],[0.26,-1.05],[0.2,-1.18],[0,-1.2]],skin,14));
    var f=blob(0.5,1,0.45,1.5,dark,14);put(f,0,-1.2,0.25);knee.add(f);
    hip.add(knee);g.add(hip);return {hip:hip,knee:knee};
  }
  var lL=leg(-1),lR=leg(1);
  A.legL=lL.hip;A.kneeL=lL.knee;A.legR=lR.hip;A.kneeR=lR.knee;

  A.body=pivot(0,2.4,0);
  var torso=lathe([[0,-0.2],[1.25,-0.1],[1.35,0.6],[1.28,1.4],[1.42,2.0],[1.3,2.5],[0.85,2.72],[0,2.76]],skin,20);
  torso.scale.set(1,1,0.72);A.body.add(torso);
  var loin=lathe([[0,-0.25],[1.38,-0.25],[1.42,0.42],[1.3,0.52],[0,0.52]],cloth,20);loin.scale.set(1,1,0.74);A.body.add(loin);
  for(var k=0;k<5;k++){var sc=blob(0.3,1,0.035,0.02,scar,8);put(sc,R(-0.7,0.7),0.6+k*0.4,0.98);sc.rotation.z=R(-0.4,0.4);A.body.add(sc);}

  A.head=pivot(0,2.9,0.45);
  A.head.add(put(blob(0.8,1,1.1,1.05,skin,18),0,0.25,0.05));
  A.head.add(put(blob(0.5,1.1,0.5,0.9,skin,14),0,-0.35,0.15));
  A.head.add(put(blob(0.3,0.9,0.15,0.1,dark,10),0,-0.1,0.78));
  var band=new THREE.Mesh(new THREE.TorusGeometry(0.82,0.07,8,28),new THREE.MeshPhongMaterial({color:0x2a1812,shininess:4}));
  band.rotation.x=Math.PI/2;band.position.set(0,0.35,0.05);A.head.add(band);
  A.head.add(put(blob(0.5,1.2,0.32,0.2,new THREE.MeshPhongMaterial({color:0x221512,shininess:3}),14),0,0.42,0.72));
  [-1,1].forEach(function(s){
    A.head.add(put(new THREE.Mesh(new THREE.SphereGeometry(0.04,8,8),new THREE.MeshBasicMaterial({color:0xffe14a})),s*0.28,0.3,0.76));
    var t=lathe([[0.1,0],[0.07,0.3],[0,0.5]],tusk,10);put(t,s*0.3,-0.2,0.6);t.rotation.x=0.7;A.head.add(t);
  });
  A.body.add(A.head);

  function garm(side){
    var sh=pivot(side*1.65,2.1,0),el=pivot(0,-1.7,0);
    sh.add(lathe([[0,0.05],[0.42,0.03],[0.4,-0.8],[0.33,-1.7],[0,-1.75]],skin,16));
    el.add(lathe([[0,0.05],[0.36,0.03],[0.3,-0.8],[0.25,-1.55],[0,-1.7]],skin,16));
    el.add(put(blob(0.58,1,0.9,1,skin,14),0,-1.7,0));
    var ring=new THREE.Mesh(new THREE.TorusGeometry(0.46,0.07,6,18),chain);ring.rotation.x=Math.PI/2;ring.position.set(0,-1.45,0);el.add(ring);
    sh.add(el);A.body.add(sh);return {sh:sh,el:el};
  }
  var aL=garm(-1),aR=garm(1);
  A.armL=aL.sh;A.elbowL=aL.el;A.armR=aR.sh;A.elbowR=aR.el;
  g.add(A.body);
  scene.add(g);return g;
}

function animateMonsters(dt){
  var A=HM,amp=Math.min(1,H.v/1.6),th=(H.phase=(H.phase||0)+dt*H.v*2.6);
  var w=Math.sin(th)*amp*0.75,stunned=H.stun>0;
  if(stunned){A.legL.rotation.x=-1.25;A.legR.rotation.x=-1.25;A.kneeL.rotation.x=1.45;A.kneeR.rotation.x=1.45;}
  else{
    A.legL.rotation.x=w;A.legR.rotation.x=-w;
    A.kneeL.rotation.x=0.65*amp*Math.max(0,-Math.sin(th+0.4));
    A.kneeR.rotation.x=0.65*amp*Math.max(0,Math.sin(th+0.4));
  }
  A.armL.rotation.x=-w*0.5;A.elbowL.rotation.x=-0.2-0.12*amp;
  var swing=H.atk>0?H.atkAnim:0;
  A.armR.rotation.x=H.atk>0?(swing<0.7?-2.6*(swing/0.7):-2.6+3.5*((swing-0.7)/0.3)):(0.15+w*0.25);
  A.elbowR.rotation.x=H.atk>0?-0.1:-0.45;
  if(stunned){A.armR.rotation.x=0.9;A.elbowR.rotation.x=-0.3;A.armL.rotation.x=0.4;}
  A.head.rotation.y=Math.sin(T0*1.3)*0.2*(H.state==='patrol'?1:0.3);
  A.head.rotation.x=(stunned?0.5:0.1)+w*0.03;
  hmGroup.position.set(H.x,(H.gy||0)+Math.abs(w)*0.05-(stunned?0.35:0),H.z);
  hmGroup.rotation.y=Math.atan2(H.dx,H.dz);
  redGlow.position.set(H.x,(H.gy||0)+1.6,H.z);

  var B=GM,gw=Math.sin(G.phase),gamp=Math.min(1,G.v/1.4),gst=G.stun>0;
  if(gst){B.legL.rotation.x=0;B.legR.rotation.x=0;B.kneeL.rotation.x=0;B.kneeR.rotation.x=0;}
  else{
    B.legL.rotation.x=gw*0.4;B.legR.rotation.x=-gw*0.4;
    B.kneeL.rotation.x=0.5*gamp*Math.max(0,-Math.sin(G.phase+0.4));
    B.kneeR.rotation.x=0.5*gamp*Math.max(0,Math.sin(G.phase+0.4));
  }
  B.body.rotation.z=gst?0:gw*0.035;B.body.rotation.x=gst?0.32:0.04;
  B.body.position.y=2.4+Math.abs(gw)*0.05-(gst?0.25:0);
  B.armL.rotation.x=-gw*0.22;B.elbowL.rotation.x=-0.2;
  B.armR.rotation.x=G.atk>0?(G.atkAnim<0.8?-2.5*(G.atkAnim/0.8):-2.5+3.3*((G.atkAnim-0.8)/0.2)):gw*0.2;
  B.elbowR.rotation.x=G.atk>0?0:-0.25;
  B.head.rotation.y=Math.sin(T0*0.4)*0.25;B.head.rotation.x=0.12;
  gGroup.position.set(G.x,0,G.z);gGroup.rotation.y=Math.atan2(G.dx,G.dz);
  greenGlow.position.set(G.x,3.5,G.z);
  exitDoorPivot.rotation.y+=((game.doorOpen?1.5:0)-exitDoorPivot.rotation.y)*Math.min(1,dt*2.5);
}

/* ---------- key spots: keys lie on small tables ---------- */
function makeKeyMesh(){
  var brass=new THREE.MeshPhongMaterial({color:0xc9a040,shininess:90,specular:0xffe9a0});
  var o=new THREE.Group(),k=new THREE.Group();
  var ring=new THREE.Mesh(new THREE.TorusGeometry(0.03,0.007,8,16),brass);ring.position.y=0.1;k.add(ring);
  k.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.012,0.2,0.006),brass),0,0,0));
  k.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.035,0.012,0.006),brass),0.012,-0.07,0));
  k.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.025,0.012,0.006),brass),0.01,-0.04,0));
  k.rotation.x=-Math.PI/2;k.scale.set(0.5,0.5,0.5);o.add(k);
  return o;
}
function makeClutter(){
  var o=new THREE.Group(),pick=Math.floor(Math.random()*3);
  if(pick===0){
    o.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.22,0.04,0.16),matP(0x5a1a14,20)),0,0.02,0));
    o.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.2,0.03,0.14),matP(0xd8cfae,3)),0.005,0.05,0));
  }else if(pick===1){
    o.add(lathe([[0,0],[0.035,0],[0.035,0.16],[0,0.17]],new THREE.MeshPhongMaterial({color:0xe8dcc0,shininess:10}),12));
    o.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.003,0.003,0.03,6),matP(0x111111)),0,0.18,0));
  }else{
    o.add(lathe([[0,0],[0.045,0],[0.05,0.1],[0,0.1]],new THREE.MeshPhongMaterial({color:0xd6cdbb,shininess:60}),14));
  }
  return o;
}
function addSpot(fl,x,z,label,col,kind){
  kind=kind||'table';
  var g=new THREE.Group(),mat,keyMesh=null,clut=null;
  if(kind==='chest'){
    mat=new THREE.MeshPhongMaterial({map:TEX.crate,color:col||0xc0b0a0,shininess:8});
    g.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.95,0.55,0.65),mat),0,0.275,0));
    g.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.98,0.1,0.68),matP(0x2a2a2a)),0,0.38,0));
  }else{
    mat=new THREE.MeshPhongMaterial({color:col||0x6a4a2c,shininess:18,specular:0x332211});
    g.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.42,0.42,0.05,24),mat),0,0.72,0));
    var lg=matP(0x2a1c10,6);
    for(var i=0;i<3;i++){var a=i*2.09+0.5;g.add(put(new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.035,0.7,8),lg),Math.cos(a)*0.3,0.35,Math.sin(a)*0.3));}
    keyMesh=makeKeyMesh();keyMesh.position.set(0.05,0.76,0.02);keyMesh.visible=false;g.add(keyMesh);
    clut=makeClutter();clut.position.set(-0.15,0.745,0.1);g.add(clut);
  }
  g.position.set(x,0,z);g.rotation.y=R(0,6.28);FL[fl].g.add(g);
  spots.push({fl:fl,x:x,z:z,label:label,obj:g,mat:mat,col:col||0xc0b0a0,searched:false,key:false,item:null,special:false,hide:false,r:0,kind:kind,keyMesh:keyMesh,clut:clut});
}
function placeSpots(){
  ROOMS.concat(ROOMS2).forEach(function(r,ri){
    setBuild(r.fl);
    var cand=[[r.x1+1.1,r.z1+1.1],[r.x2-1.1,r.z1+1.1],[r.x1+1.1,r.z2-1.1],[r.x2-1.1,r.z2-1.1],[r.x1+1.1,r.cz],[r.x2-1.1,r.cz]];
    for(var i=0;i<cand.length;i++){
      var p=cand[(i+ri)%cand.length];
      if(freeAt(p[0],p[1],0.5,0.5,0.45)){addSpot(r.fl,p[0],p[1],'ابحث على الطاولة');break;}
    }
  });
  setBuild(0);
  addSpot(0,25.4,21.9,'ابحث على الطاولة تحت الدرج',0x5a4030);
}
function placeKeys(n,rnd){rnd=rnd||Math.random;
  spots.forEach(function(s){
    s.searched=false;s.key=false;s.mat.color.setHex(s.col);s.obj.visible=true;
    if(s.keyMesh)s.keyMesh.visible=false;if(s.clut)s.clut.visible=true;
  });
  var idx=[];spots.forEach(function(s,i){if(!s.special)idx.push(i);});
  for(var i=idx.length-1;i>0;i--){var j=(rnd()*(i+1))|0,t=idx[i];idx[i]=idx[j];idx[j]=t;}
  var cnt=Math.min(n,idx.length);
  for(var k=0;k<cnt;k++){
    var s2=spots[idx[k]];s2.key=true;
    if(s2.keyMesh){s2.keyMesh.visible=true;s2.clut.visible=false;}
  }
  return cnt;
}

/* ---------- realistic tools ---------- */
function makePistol(){
  var pts=[[0,0.035],[0,0.068],[0.19,0.068],[0.215,0.052],[0.205,0.035],[0.11,0.03],[0.105,-0.005],[0.088,-0.1],[0.04,-0.115],[0.03,-0.08],[0,0]];
  var s=new THREE.Shape(),i;s.moveTo(pts[0][0],pts[0][1]);for(i=1;i<pts.length;i++)s.lineTo(pts[i][0],pts[i][1]);
  var geo=new THREE.ExtrudeGeometry(s,{depth:0.034,bevelEnabled:true,bevelThickness:0.004,bevelSize:0.004,bevelSegments:2,curveSegments:2});
  geo.translate(0,0,-0.017);
  var o=new THREE.Group();
  o.add(new THREE.Mesh(geo,new THREE.MeshPhongMaterial({color:0x2a2c32,shininess:90,specular:0x9a9aa2})));
  o.rotation.y=Math.PI/2;return o;
}
function makeHammerTool(){
  var wood=new THREE.MeshPhongMaterial({color:0x6a4a2a,shininess:10}),metal=new THREE.MeshPhongMaterial({color:0x7d8088,shininess:80,specular:0xdddddd});
  var o=new THREE.Group();
  var h=lathe([[0,0],[0.018,0],[0.02,0.05],[0.015,0.3],[0.018,0.36],[0,0.37]],wood,12);h.rotation.z=-Math.PI/2;o.add(h);
  var hd=new THREE.Mesh(headGeo(0.1,0.05,3,0.04,0.09),metal);hd.rotation.y=Math.PI/2;hd.position.set(0.4,0,0);o.add(hd);
  var w=new THREE.Group();w.rotation.y=Math.PI/2;w.add(o);return w;
}
function makeScrewdriver(){
  var red=new THREE.MeshPhongMaterial({color:0xb02a1a,shininess:40}),metal=new THREE.MeshPhongMaterial({color:0xb8bcc4,shininess:90,specular:0xffffff});
  var o=new THREE.Group();
  var h=lathe([[0,0],[0.02,0],[0.026,0.02],[0.03,0.06],[0.024,0.1],[0.014,0.125],[0,0.13]],red,12);h.rotation.z=-Math.PI/2;o.add(h);
  var sh=new THREE.Mesh(new THREE.CylinderGeometry(0.0045,0.0045,0.16,8),metal);sh.rotation.z=Math.PI/2;sh.position.set(0.21,0,0);o.add(sh);
  o.add(put(new THREE.Mesh(new THREE.BoxGeometry(0.02,0.012,0.004),metal),0.3,0,0));
  var w=new THREE.Group();w.rotation.y=Math.PI/2;w.add(o);return w;
}
