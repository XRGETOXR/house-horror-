
/* ---------- game flow ---------- */
var START={x:4.8,z:3.8,yaw:-Math.PI/2};
function newPlayer(){return {fl:0,gy:0,x:START.x,z:START.z,yaw:START.yaw,pitch:0,eye:EYE,crouch:false,stamina:1,exhausted:false,hidden:null,bob:0,torch:true,noise:0,roll:0,stepSign:false,gun:false,ammo:0};}
function resetMonsters(){
  H={catch:-1,catchT:0,fl:0,gy:0,x:56,z:8,dx:-1,dz:0,v:0,state:'patrol',path:[],wait:0,stateT:0,lose:0,last:null,atk:0,atkAnim:0,cool:0,noiseCD:0,stuckT:0,sx:56,sz:8,phase:0,closet:null,hstep:false,stun:0};
  G={fl:0,gy:0,x:40,z:20,dx:-1,dz:0,v:0,atk:0,atkAnim:0,cool:0,phase:0,stepSign:false,goal:0,stun:0};
  hmGroup.visible=D.monsters;gGroup.visible=game.giantOn;
  if(!D.monsters){H.x=200;H.z=200;}
  if(!game.giantOn){G.x=200;G.z=200;}
  if(D.monsters)pickPatrol();
}
function reset(){
  P=newPlayer();
  game.stats={hides:0,chases:0};cinemaCleanup();
  game.keys=0;game.doorOpen=false;game.time=0;game.shake=0;game.threat=0;game.hbT=1;game.bangT=R(20,40);game.moving=false;
  game.rnd=game.rnd||0;game.pHa=0;game.pGa=0;game.specEnd=false;game.need=placeKeys(D.keys,rng(game.seed||1));
  if(FL[0].co.indexOf(exitBox)<0){FL[0].co.push(exitBox);FL[0].bl.push(exitBox);}
  game.giantOn=D.monsters&&rng((game.seed||1)^0x9e3779b9)()<D.giant;
  resetMonsters();
  redGlow.intensity=D.monsters?0.9:0;greenGlow.intensity=game.giantOn?0.6:0;
  exitDoorPivot.rotation.y=0;
  $('hit').style.opacity=0;$('slits').hidden=true;$('danger').style.opacity=0;$('warn').style.opacity=0;
  mapOn=false;$('mapwrap').style.display='none';
  resetDoors();$('exitHint').hidden=true;
  resetExtras();
}
function startGame(){
  if(!mpPrepare())return;Snd.init();reset();hideScreen();
  $('hud').hidden=true;$('prompt').hidden=false;$('cross').hidden=true;
  dayAnim(1,'start',beginWake);
  requestLock();
}
function win(){startCinema();}
function showDeath(){
  if(dayDeath())return;
  if(showDeathMP())return;
  var msg={hammer:'حطّمتك المطرقة',giant:'سحقك العملاق',closet:'اكتشف مخبأك'}[game.killer]||'انتهت اللعبة';
  $('hud').hidden=true;$('prompt').style.opacity=0;$('slits').hidden=true;
  showScreen('<h2>'+msg+'</h2><p class="lead">صمدت '+fmtTime(game.time)+' وجمعت '+AR_NUM(game.keys)+' من '+AR_NUM(game.need)+' مفاتيح.</p><div class="btns"><button class="btn" id="go" type="button">حاول مرة أخرى</button><button class="btn alt" id="menub" type="button">القائمة</button></div>');
  bindGo(startGame);
}

/* ---------- per-frame ---------- */
function update(dt){
  T0+=dt;game.time+=dt;
  var ix=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+touch.mx;
  var iz=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)+touch.mz;
  var moving=false,sprint=false;
  if(!P.hidden){
    var len=Math.hypot(ix,iz);if(len>1){ix/=len;iz/=len;len=1;}
    moving=len>0.1;
    sprint=moving&&(keys.ShiftLeft||keys.ShiftRight||touch.run)&&!P.crouch&&!P.exhausted&&P.stamina>0;
    var sp=P.crouch?1.5:(sprint?5.4:3.1),s=Math.sin(P.yaw),c=Math.cos(P.yaw);
    P.x+=(-s*iz+c*ix)*sp*dt;P.z+=(-c*iz-s*ix)*sp*dt;
    pushOut(P,PR);updFloor(P);
    if(moving)P.bob+=dt*(sprint?11:(P.crouch?6:8));
    if(moving){var ss=Math.sin(P.bob)>0;if(ss!==P.stepSign){P.stepSign=ss;if(!P.crouch)Snd.noise(sprint?0.12:0.06,0.07,700);}}
  }
  game.moving=moving;
  if(sprint){P.stamina-=0.2*dt;if(P.stamina<=0){P.stamina=0;P.exhausted=true;}}
  else P.stamina=Math.min(1,P.stamina+0.14*dt);
  if(P.exhausted&&P.stamina>0.3)P.exhausted=false;
  P.noise=Math.max(game.extraNoise||0,(moving&&!P.hidden)?(sprint?14:(P.crouch?2.5:7)):0);

  simBackground(dt);
  checkKills();
  if(game.state!=='play'){return;}
  extraUpdate(dt);
  var hs=Math.sin(H.phase||0)>0,dh=dist2(H,P)+(H.fl!==P.fl?9:0),dg=dist2(G,P)+(P.fl!==0?12:0);
  if(H.v>0.3&&hs!==H.hstep){H.hstep=hs;if(dh<14)Snd.hstep(dh);}

  var th=0;
  if(H.state==='chase')th=0.55+0.45*Math.max(0,1-dh/16);else th=Math.max(0,1-dh/9)*0.45;
  th=Math.max(th,Math.max(0,1-dg/10)*0.6);
  game.threat+=(th-game.threat)*Math.min(1,dt*3);
  game.hbT-=dt;
  if(game.threat>0.12&&game.hbT<=0){Snd.beat(0.15+0.5*game.threat);game.hbT=1.15-0.7*game.threat;}
  game.bangT-=dt;if(game.bangT<=0){Snd.bang();game.bangT=R(25,50);}

  var fl=1;if(game.threat>0.45&&Math.random()<0.12)fl=R(0.05,0.6);
  torch.intensity=P.torch?TORCH_I*S.bright*fl:0;

  if(P.x>61.2)win();
  animateMonsters(dt);
  updateCamera(dt);
  updateHUD();
}
function updateCamera(dt){
  if(P.hidden)P.eye=P.hidden.eye||1.5;else P.eye+=((P.crouch?EYE_C:EYE)-P.eye)*Math.min(1,dt*10);
  var by=game.moving?Math.sin(P.bob)*0.045:0;
  game.shake*=Math.max(0,1-dt*4);
  var sh=game.shake;
  camera.position.set(P.x+(Math.random()-0.5)*sh,(P.gy||0)+P.eye+by+(Math.random()-0.5)*sh,P.z+(Math.random()-0.5)*sh);
  camera.rotation.set(P.pitch,P.yaw,P.roll);
}
function updateDead(dt){
  game.deadT+=dt;
  var M=game.killer==='giant'?G:H;
  var tgt=Math.atan2(-(M.x-P.x),-(M.z-P.z)),df=tgt-P.yaw;
  while(df>Math.PI)df-=6.2832;while(df<-Math.PI)df+=6.2832;
  P.yaw+=df*Math.min(1,dt*6);
  P.pitch+=(0.25-P.pitch)*Math.min(1,dt*3);
  P.eye+=(0.4-P.eye)*Math.min(1,dt*2.5);
  P.roll+=(0.9-P.roll)*Math.min(1,dt*2);
  $('hit').style.opacity=Math.max(0.35,0.85-game.deadT*0.3);
  if(NET.room)simBackground(dt);else{H.v=0;G.v=0;}
  animateMonsters(dt);updateCamera(dt);
  if(game.deadT>1.8&&!game.msgShown){game.msgShown=true;showDeath();}
}
var lastPrompt='';
function updateHUD(){
  $('kc').textContent=AR_NUM(game.keys)+'/'+AR_NUM(game.need);
  var bar=$('stam');bar.firstElementChild.style.transform='scaleX('+P.stamina.toFixed(3)+')';
  bar.className=P.exhausted?'bar low':'bar';
  var rn=roomAt(P.x,P.z,P.fl);if($('room').textContent!==rn)$('room').textContent=rn;
  $('danger').style.opacity=Math.min(0.9,game.threat*0.9).toFixed(2);
  $('warn').style.opacity=H.state==='chase'?1:0;
  $('slits').hidden=!P.hidden;
  var t=nearTarget(),txt=t?((touch.on?'':'<b>E</b>')+t.label):'';
  if(txt!==lastPrompt){lastPrompt=txt;var pe=$('prompt');pe.innerHTML=txt;pe.style.opacity=txt?1:0;}
  var eh=$('exitHint');
  if(game.keys>=game.need){
    var gx=60,gz=ROOM.exit.cz,lab=game.doorOpen?'اهرب إلى الخارج':'الباب الحديدي';
    if(P.fl===1){gx=STAIR.x2;gz=(STAIR.z1+STAIR.z2)/2;lab='انزل إلى الطابق الأرضي';}
    var tx=gx-P.x,tz=gz-P.z,sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);
    var a=Math.atan2(tx*cy-tz*sy,-tx*sy-tz*cy);
    eh.hidden=false;$('arrow').style.transform='rotate('+a.toFixed(3)+'rad)';
    $('exitTxt').textContent=lab+' · '+AR_NUM(Math.round(Math.hypot(tx,tz)))+' م';
  }else eh.hidden=true;
  if(mapOn)drawMap();
}
function resetDoors(){
  doors.forEach(function(d){
    d.ang=0;d.target=0;d.piv.rotation.y=0;
    if(!d.solid){FL[d.fl].co.push(d.box);FL[d.fl].bl.push(d.box);d.solid=true;}
  });
}
function updateDoors(dt){
  for(var i=0;i<doors.length;i++){
    var d=doors[i],dp=(P.hidden||P.fl!==d.fl)?99:Math.hypot(P.x-d.cx,P.z-d.cz),dh=(H.fl!==d.fl)?99:Math.hypot(H.x-d.cx,H.z-d.cz);
    var dm=Math.min(dp,dh);
    if(d.target===0&&dm<2.8){
      d.target=1;
      var sx=dp<=dh?P:H;
      d.side=(d.ax==='x'?Math.sign(sx.z-d.fixed):Math.sign(sx.x-d.fixed))||1;
      if(dp<14)Snd.creak(Math.max(0.03,0.16*(1-dp/14)));
    }else if(d.target===1&&dm>3.8){d.target=0;}
    var goal=d.target?1.45:0,df=goal-d.ang;
    d.ang+=Math.max(-dt*5,Math.min(dt*5,df));
    d.piv.rotation.y=d.ax==='x'?d.side*d.ang:-d.side*d.ang;
    var shut=d.ang<0.55;
    if(shut&&!d.solid){FL[d.fl].co.push(d.box);FL[d.fl].bl.push(d.box);d.solid=true;}
    else if(!shut&&d.solid){var a=FL[d.fl].co.indexOf(d.box);if(a>=0)FL[d.fl].co.splice(a,1);var b=FL[d.fl].bl.indexOf(d.box);if(b>=0)FL[d.fl].bl.splice(b,1);d.solid=false;}
  }
}
function roomAt(x,z,fl){
  if(x>60)return 'الخارج';
  if(x>STAIR.x1&&x<STAIR.x2&&z>STAIR.z1&&z<STAIR.z2)return 'الدرج';
  if(z>=16&&z<=24)return fl?'الطابق الثاني · الصالة العليا':'الممر الطويل';
  var list=fl?ROOMS2:ROOMS;
  for(var i=0;i<list.length;i++){var r=list[i];if(x>=r.x1&&x<=r.x2&&z>=r.z1&&z<=r.z2)return fl?'الطابق الثاني · '+r.name:r.name;}
  return '—';
}
function drawMap(){
  var c=$('map'),g=c.getContext('2d'),Z=5,list=P.fl?ROOMS2:ROOMS;
  g.clearRect(0,0,300,290);g.fillStyle='rgba(0,0,0,0.5)';g.fillRect(0,0,300,290);
  g.lineWidth=1;g.strokeStyle='rgba(235,227,214,0.55)';g.fillStyle='rgba(235,227,214,0.7)';g.font='9px Tajawal, sans-serif';g.textAlign='center';
  list.forEach(function(r){g.strokeRect(r.x1*Z+0.5,r.z1*Z+0.5,(r.x2-r.x1)*Z,(r.z2-r.z1)*Z);g.fillText(r.name,r.cx*Z,r.cz*Z);});
  g.strokeRect(0.5,16*Z+0.5,60*Z,8*Z);g.fillText(P.fl?'الصالة العليا':'الممر الطويل',40*Z,19*Z);
  g.fillStyle='rgba(226,179,74,0.45)';g.fillRect(STAIR.x1*Z,STAIR.z1*Z,(STAIR.x2-STAIR.x1)*Z,(STAIR.z2-STAIR.z1)*Z);
  g.fillStyle='rgba(235,227,214,0.85)';g.fillText('الدرج',17.6*Z,STAIR.z1*Z-3);
  if(!P.fl){g.fillStyle='#46ff82';g.fillRect(59*Z,(ROOM.exit.cz-1.4)*Z,4,2.8*Z);}
  g.fillStyle='rgba(235,227,214,0.85)';g.textAlign='start';g.fillText(P.fl?'الطابق الثاني':'الطابق الأرضي',6,12);
  g.save();g.translate(P.x*Z,P.z*Z);g.rotate(-P.yaw+Math.PI);
  g.fillStyle='#ff6a4a';g.beginPath();g.moveTo(0,-7);g.lineTo(5,5);g.lineTo(-5,5);g.closePath();g.fill();g.restore();
}
function toMenu(){
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  $('hud').hidden=true;$('prompt').style.opacity=0;$('hit').style.opacity=0;$('slits').hidden=true;$('danger').style.opacity=0;
  cleanupExtras();game.state='menu';reset();showMenu();
}

/* ---------- main loop & boot ---------- */
function frame(now){
  requestAnimationFrame(frame);
  var dt=Math.min(0.05,Math.max(0,(now-game.last)/1000));game.last=now;
  if(game.state==='play')update(dt);
  else if(game.state==='dead')updateDead(dt);
  else if(game.state==='spec'){updateSpec(dt);}
  else if(game.state==='cinema'){updateCinema(dt);}
  else if(game.state==='wake'){updateWake(dt);}
  else if(game.state==='day'){updateDay(dt);}
  else if(game.state==='pad'){updatePad(dt);}
  else{
    if(game.state==='menu'){
      camera.position.set(24,1.7,20);camera.rotation.set(0,-Math.PI/2,0);
      torch.intensity=TORCH_I*S.bright*(0.85+0.15*Math.sin(now*0.003));
    }
    T0+=dt;animateMonsters(dt);
  }
  renderAll();
}
document.addEventListener('pointerlockerror',function(){toast('اسحب بالفأرة للنظر حولك',3000);});

function init(){
  makeTextures();buildShell();buildWalls();buildFurniture();buildDecor();buildStairs();buildFloor2();placeSpots();setBuild(0);buildGraph();
  hmGroup=buildHammerMan();gGroup=buildGiant();
  placeSpecials();buildExtras();dressHouse();buildHands();
  applyGfx();reset();
  game.last=performance.now();showMenu();
  requestAnimationFrame(frame);
}
var fontJob=Promise.resolve();
try{
  if(document.fonts&&document.fonts.load){
    fontJob=Promise.all([document.fonts.load('bold 96px Lalezar','اهرب'),document.fonts.load('16px Tajawal','ا')]);
  }
}catch(e){}
Promise.race([fontJob,new Promise(function(r){setTimeout(r,2000);})]).then(function(){
  try{init();}catch(err){fail('حدث خطأ أثناء تجهيز اللعبة: '+(err&&err.message));}
},function(){
  try{init();}catch(err){fail('حدث خطأ أثناء تجهيز اللعبة: '+(err&&err.message));}
});
/* boot fallback: if the loader is still shown after 6 s, offer a retry button */
(function(){var r=document.getElementById('ldRetry');if(r)r.addEventListener('click',function(){location.reload();});})();
