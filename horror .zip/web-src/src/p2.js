(function(){
'use strict';
var $=function(id){return document.getElementById(id);};
var cv=$('view'), panel=$('panel');
function fail(msg){panel.innerHTML='<p class="lead">'+msg+'</p>';}
if(!window.THREE){fail('تعذّر تحميل محرّك الرسوم ثلاثية الأبعاد. تحقق من الاتصال ثم أعد تحميل الصفحة.');return;}
var THREE=window.THREE, renderer;
try{renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true});}catch(err){fail('متصفحك أو جهازك لا يدعم WebGL المطلوب لتشغيل اللعبة.');return;}
var S={name:'',gfx:'med',sens:1,vol:0.75,bright:1,diff:'med'};
try{var _s=JSON.parse(localStorage.getItem('hh_set')||'null');if(_s)for(var _k in _s)if(_k in S)S[_k]=_s[_k];}catch(e){}
function saveS(){try{localStorage.setItem('hh_set',JSON.stringify(S));}catch(e){}}
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.25));

/* ---------- constants ---------- */
var WALL_H=3.3, HALL_H=7.1, FY=7.1, T=0.3, DOOR_W=2.8, EYE=1.65, EYE_C=1.05, PR=0.38;

/* ---------- scene ---------- */
var scene=new THREE.Scene();
scene.background=new THREE.Color(0x020202);
scene.fog=new THREE.FogExp2(0x030303,0.05);
var camera=new THREE.PerspectiveCamera(74,1,0.08,140);
camera.rotation.order='YXZ';
scene.add(camera);
var amb=new THREE.AmbientLight(0x4a4a5c,0.7);scene.add(amb);
var TORCH_I=1.9;
var torch=new THREE.SpotLight(0xffeccc,TORCH_I,32,0.56,0.5,1.2);
camera.add(torch); torch.position.set(0.12,-0.1,0);
camera.add(torch.target); torch.target.position.set(0,0,-3);
var redGlow=new THREE.PointLight(0xff2a1a,0.9,9,2); scene.add(redGlow);
var greenGlow=new THREE.PointLight(0x7cff9a,0.6,13,2); scene.add(greenGlow);

function applyGfx(){
  var dpr=window.devicePixelRatio||1,q=S.gfx;
  renderer.setPixelRatio(q==='low'?Math.min(dpr,0.75):(q==='high'?Math.min(dpr,2):Math.min(dpr,1.25)));
  scene.fog.density=q==='low'?0.075:(q==='high'?0.042:0.052);
  camera.far=q==='low'?45:140;camera.updateProjectionMatrix();
  amb.intensity=0.7*S.bright;resize();
}
function resize(){
  var w=cv.clientWidth||window.innerWidth, h=cv.clientHeight||window.innerHeight;
  renderer.setSize(w,h,false); camera.aspect=w/h; camera.updateProjectionMatrix();
  if(hcam){hcam.aspect=w/h;hcam.updateProjectionMatrix();}
}
window.addEventListener('resize',resize); resize();

/* ---------- procedural textures ---------- */
function cnv(w,h){var c=document.createElement('canvas');c.width=w;c.height=h;return c;}
function R(a,b){return a+Math.random()*(b-a);}
function toTex(c,rx,ry){var t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;if(rx)t.repeat.set(rx,ry);t.anisotropy=4;return t;}
function speckle(g,w,h,n,tpl,smax){for(var i=0;i<n;i++){g.fillStyle=tpl.replace('A',(Math.random()*0.5).toFixed(2));var s=R(1,smax||3);g.fillRect(Math.random()*w,Math.random()*h,s,s);}}
function wallCanvas(){
  var c=cnv(256,256),g=c.getContext('2d'),i;
  g.fillStyle='#6b5a4c';g.fillRect(0,0,256,256);
  for(var x=0;x<256;x+=32){g.fillStyle='rgba(255,235,210,0.06)';g.fillRect(x,0,16,256);}
  for(var y=12;y<256;y+=40){for(var x2=16;x2<256;x2+=32){g.fillStyle='rgba(0,0,0,0.12)';g.beginPath();g.arc(x2,y+(((x2/32)|0)%2?10:0),3,0,6.3);g.fill();}}
  for(i=0;i<6;i++){var gx=R(0,256),gy=R(0,200),gr=g.createRadialGradient(gx,gy,2,gx,gy,R(20,55));gr.addColorStop(0,'rgba(40,25,10,0.4)');gr.addColorStop(1,'rgba(40,25,10,0)');g.fillStyle=gr;g.fillRect(0,0,256,256);}
  var mold=g.createLinearGradient(0,150,0,256);mold.addColorStop(0,'rgba(0,0,0,0)');mold.addColorStop(1,'rgba(0,0,0,0.5)');g.fillStyle=mold;g.fillRect(0,150,256,106);
  speckle(g,256,256,900,'rgba(0,0,0,A)',2);
  return c;
}
function floorCanvas(){
  var c=cnv(256,256),g=c.getContext('2d'),cols=['#5a3d27','#4d3321','#63452d','#563a25'];
  for(var r=0;r<8;r++){
    g.fillStyle=cols[r%4];g.fillRect(0,r*32,256,32);
    g.fillStyle='rgba(0,0,0,0.55)';g.fillRect(0,r*32,256,2);
    var j=R(30,226);g.fillRect(j,r*32,2,32);
    for(var k=0;k<5;k++){g.strokeStyle='rgba(0,0,0,0.18)';g.beginPath();g.moveTo(0,r*32+R(4,28));g.lineTo(256,r*32+R(4,28));g.stroke();}
  }
  speckle(g,256,256,700,'rgba(0,0,0,A)',2);
  return c;
}
function ceilCanvas(){
  var c=cnv(128,128),g=c.getContext('2d');g.fillStyle='#3b3430';g.fillRect(0,0,128,128);
  speckle(g,128,128,400,'rgba(0,0,0,A)',2);
  var gr=g.createRadialGradient(64,64,2,64,64,50);gr.addColorStop(0,'rgba(20,10,0,0.45)');gr.addColorStop(1,'rgba(20,10,0,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);
  return c;
}
function bloodCanvas(){
  var c=cnv(256,256),g=c.getContext('2d'),i;
  g.fillStyle='rgba(105,8,8,0.92)';
  for(i=0;i<14;i++){g.beginPath();g.ellipse(128+R(-60,60),128+R(-60,60),R(6,26),R(5,22),R(0,3),0,6.3);g.fill();}
  for(i=0;i<40;i++){var a=R(0,6.28),d=R(40,120);g.beginPath();g.arc(128+Math.cos(a)*d,128+Math.sin(a)*d,R(1.5,6),0,6.3);g.fill();}
  g.strokeStyle='rgba(90,6,6,0.85)';g.lineWidth=R(6,14);g.lineCap='round';g.beginPath();g.moveTo(128,128);g.quadraticCurveTo(R(60,200),R(60,200),R(20,236),R(20,236));g.stroke();
  return c;
}
function clothCanvas(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#3a312c';g.fillRect(0,0,128,128);
  for(i=0;i<16;i++){g.fillStyle='rgba(135,16,14,'+R(0.5,0.9).toFixed(2)+')';g.beginPath();g.arc(R(0,128),R(0,128),R(4,20),0,6.3);g.fill();}
  g.strokeStyle='rgba(120,12,10,0.8)';g.lineWidth=3;for(i=0;i<8;i++){var x=R(0,128);g.beginPath();g.moveTo(x,R(0,30));g.lineTo(x+R(-4,4),R(70,128));g.stroke();}
  speckle(g,128,128,200,'rgba(0,0,0,A)',2);
  return c;
}
function faceCanvas(){
  var c=cnv(128,128),g=c.getContext('2d'),i;
  g.fillStyle='#b3a99b';g.fillRect(0,0,128,128);
  g.strokeStyle='rgba(140,14,12,0.9)';g.lineCap='round';
  for(i=0;i<9;i++){g.lineWidth=R(3,9);var x=R(0,128);g.beginPath();g.moveTo(x,R(0,40));g.lineTo(x+R(-8,8),R(60,128));g.stroke();}
  for(i=0;i<12;i++){g.fillStyle='rgba(120,10,10,0.8)';g.beginPath();g.arc(R(0,128),R(0,128),R(2,9),0,6.3);g.fill();}
  return c;
}
function closetCanvas(){
  var c=cnv(128,256),g=c.getContext('2d');
  g.fillStyle='#4a3322';g.fillRect(0,0,128,256);
  g.strokeStyle='rgba(0,0,0,0.6)';g.lineWidth=3;g.strokeRect(8,10,52,236);g.strokeRect(68,10,52,236);
  g.fillStyle='rgba(0,0,0,0.75)';for(var i=0;i<5;i++){g.fillRect(16,26+i*9,36,3);g.fillRect(76,26+i*9,36,3);}
  g.fillStyle='#8a7a55';g.fillRect(54,120,4,16);g.fillRect(70,120,4,16);
  speckle(g,128,256,300,'rgba(0,0,0,A)',2);
  return c;
}
function crateCanvas(){
  var c=cnv(128,128),g=c.getContext('2d');
  g.fillStyle='#6b4e2e';g.fillRect(0,0,128,128);
  for(var i=0;i<8;i++){g.fillStyle=i%2?'rgba(0,0,0,0.12)':'rgba(255,220,160,0.06)';g.fillRect(0,i*16,128,16);g.fillStyle='rgba(0,0,0,0.5)';g.fillRect(0,i*16,128,2);}
  g.strokeStyle='rgba(30,18,8,0.9)';g.lineWidth=10;g.strokeRect(5,5,118,118);
  g.lineWidth=8;g.beginPath();g.moveTo(8,8);g.lineTo(120,120);g.moveTo(120,8);g.lineTo(8,120);g.stroke();
  speckle(g,128,128,300,'rgba(0,0,0,A)',2);
  return c;
}
function glowCanvas(){
  var c=cnv(64,64),g=c.getContext('2d'),gr=g.createRadialGradient(32,32,1,32,32,31);
  gr.addColorStop(0,'rgba(255,220,120,0.9)');gr.addColorStop(1,'rgba(255,200,80,0)');g.fillStyle=gr;g.fillRect(0,0,64,64);
  return c;
}
function textTex(txt,font,col){
  var c=cnv(512,160),g=c.getContext('2d');
  g.font=font;g.fillStyle=col;g.textAlign='center';g.textBaseline='middle';g.shadowColor=col;g.shadowBlur=10;
  try{g.direction='rtl';}catch(e){}
  g.fillText(txt,256,84);
  return new THREE.CanvasTexture(c);
}

var TEX={};
function makeTextures(){
  TEX.wall=toTex(wallCanvas(),1,1);
  TEX.floor=toTex(floorCanvas(),30,28);
  TEX.ceil=toTex(ceilCanvas(),1,1);
  TEX.blood=toTex(bloodCanvas(),1,1);
  TEX.cloth=toTex(clothCanvas(),1,1);
  TEX.face=toTex(faceCanvas(),1,1);
  TEX.closet=toTex(closetCanvas(),1,1);
  TEX.crate=toTex(crateCanvas(),1,1);
  TEX.glow=new THREE.CanvasTexture(glowCanvas());
}

/* ---------- geometry helpers & colliders ---------- */
var FL=[{co:[],bl:[],g:new THREE.Group()},{co:[],bl:[],g:new THREE.Group()}];
FL[1].g.position.y=FY;scene.add(FL[0].g);scene.add(FL[1].g);
var colliders=FL[0].co, blockers=FL[0].bl, CURG=FL[0].g, CUR=0, wallMatCache={};
function setBuild(f){CUR=f;colliders=FL[f].co;blockers=FL[f].bl;CURG=FL[f].g;}
function wallMat(len,h){
  var k=Math.round(len*2)+'_'+Math.round(h*2);
  if(!wallMatCache[k]){
    var t=TEX.wall.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;
    t.repeat.set(Math.max(1,len/3),Math.max(1,h/3));
    wallMatCache[k]=new THREE.MeshPhongMaterial({map:t,shininess:4,specular:0x111111});
  }
  return wallMatCache[k];
}
function wallSeg(ax,fixed,a,b,h){
  var len=b-a; if(len<0.02)return;
  var cx,cz,w,d;
  if(ax==='x'){cx=(a+b)/2;cz=fixed;w=len;d=T;}else{cx=fixed;cz=(a+b)/2;w=T;d=len;}
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),wallMat(len,h));
  m.position.set(cx,h/2,cz);CURG.add(m);
  var box={x1:cx-w/2,x2:cx+w/2,z1:cz-d/2,z2:cz+d/2};
  colliders.push(box);blockers.push(box);
}
function wallDoors(ax,fixed,from,to,doors,h){
  var pts=doors.slice().sort(function(p,q){return p-q;}),cur=from-T/2;
  pts.forEach(function(c){
    var a=c-DOOR_W/2,b=c+DOOR_W/2;
    wallSeg(ax,fixed,cur,a,h);
    if(h>2.8){
      var lh=h-2.8,lm=new THREE.Mesh(new THREE.BoxGeometry(ax==='x'?DOOR_W:T,lh,ax==='x'?T:DOOR_W),wallMat(DOOR_W,lh));
      lm.position.set(ax==='x'?c:fixed,2.8+lh/2,ax==='x'?fixed:c);CURG.add(lm);
    }
    cur=b;
  });
  wallSeg(ax,fixed,cur,to+T/2,h);
}
function matP(col,sh){return new THREE.MeshPhongMaterial({color:col,shininess:sh||5,specular:0x111111});}
function F(x,z,w,d,h,col,o){
  o=o||{};
  var mat=o.map?new THREE.MeshPhongMaterial({map:o.map,shininess:5}):matP(col);
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
  m.position.set(x,(o.y||0)+h/2,z);CURG.add(m);
  var b={x1:x-w/2,x2:x+w/2,z1:z-d/2,z2:z+d/2};
  if(!o.nocol){colliders.push(b);if(h>=1.8)blockers.push(b);}
  return {mesh:m,box:b};
}
function deco(x,y,z,w,h,d,col){
  var m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),matP(col));
  m.position.set(x,y+h/2,z);CURG.add(m);return m;
}
function planeAt(w,d,x,y,z,rx,mat){
  var m=new THREE.Mesh(new THREE.PlaneGeometry(w,d),mat);
  m.rotation.x=rx;m.position.set(x,y,z);CURG.add(m);return m;
}
function addText(txt,x,y,z,ry,w,h,col,basic){
  var t=textTex(txt,'bold 96px Lalezar, Tajawal, sans-serif',col);
  var mat=basic?new THREE.MeshBasicMaterial({map:t,transparent:true,depthWrite:false}):
    new THREE.MeshPhongMaterial({map:t,transparent:true,depthWrite:false,shininess:1});
  var m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),mat);
  m.position.set(x,y,z);m.rotation.y=ry;CURG.add(m);return m;
}

/* ---------- house plan ---------- */
var ROOMS=[
  {id:'bed',name:'غرفة النوم',x1:0,z1:0,x2:14,z2:16},
  {id:'kit',name:'المطبخ',x1:14,z1:0,x2:28,z2:16},
  {id:'lib',name:'المكتبة',x1:28,z1:0,x2:42,z2:16},
  {id:'bath',name:'الحمّام',x1:42,z1:0,x2:52,z2:16},
  {id:'stor',name:'المخزن',x1:52,z1:0,x2:60,z2:16},
  {id:'liv',name:'غرفة المعيشة',x1:0,z1:24,x2:18,z2:40},
  {id:'din',name:'غرفة الطعام',x1:18,z1:24,x2:34,z2:40},
  {id:'nur',name:'غرفة الأطفال',x1:34,z1:24,x2:46,z2:40},
  {id:'exit',name:'قاعة الخروج',x1:46,z1:24,x2:60,z2:40},
  {id:'laun',name:'غرفة الغسيل',x1:0,z1:40,x2:20,z2:56},
  {id:'stu',name:'المرسم',x1:20,z1:40,x2:40,z2:56},
  {id:'cell',name:'القبو',x1:40,z1:40,x2:60,z2:56}
];
var ROOM={};
ROOMS.forEach(function(r){r.cx=(r.x1+r.x2)/2;r.cz=(r.z1+r.z2)/2;r.fl=0;ROOM[r.id]=r;});
var closets=[], keyItems=[], exitDoor=null, exitDoorPivot=null, exitBox=null;

var doors=[], NEWDOORS=[10,31,52];
var doorMat=null, brassMat=null;
function addDoor(ax,fixed,c){
  if(!doorMat){doorMat=matP(0x4a3322,6);brassMat=new THREE.MeshPhongMaterial({color:0xb58a3a,shininess:60,specular:0xffffff});}
  var w=DOOR_W-0.06,piv=new THREE.Group(),hinge=c-DOOR_W/2+0.03;
  if(ax==='x')piv.position.set(hinge,0,fixed);else piv.position.set(fixed,0,hinge);
  var leaf=new THREE.Mesh(new THREE.BoxGeometry(ax==='x'?w:0.12,2.78,ax==='x'?0.12:w),doorMat);
  leaf.position.set(ax==='x'?w/2:0,1.39,ax==='x'?0:w/2);piv.add(leaf);
  var kn=new THREE.Mesh(new THREE.SphereGeometry(0.07,8,8),brassMat);
  kn.position.set(ax==='x'?w-0.25:0,1.05,ax==='x'?0:w-0.25);
  var kb=kn.clone();
  if(ax==='x'){kn.position.z=0.09;kb.position.z=-0.09;}else{kn.position.x=0.09;kb.position.x=-0.09;}
  piv.add(kn);piv.add(kb);CURG.add(piv);
  var box=ax==='x'?{x1:c-DOOR_W/2,x2:c+DOOR_W/2,z1:fixed-0.07,z2:fixed+0.07}:{x1:fixed-0.07,x2:fixed+0.07,z1:c-DOOR_W/2,z2:c+DOOR_W/2};
  colliders.push(box);blockers.push(box);
  doors.push({fl:CUR,ax:ax,fixed:fixed,c:c,piv:piv,box:box,ang:0,target:0,side:1,solid:true,cx:ax==='x'?c:fixed,cz:ax==='x'?fixed:c});
}
function buildWalls(){
  var north=ROOMS.slice(0,5).map(function(r){return r.cx;});
  var south=ROOMS.slice(5,9).map(function(r){return r.cx;});
  wallDoors('x',16,0,60,north,HALL_H);
  wallDoors('x',24,0,60,south,HALL_H);
  wallSeg('z',0,16-T/2,24+T/2,HALL_H);
  wallSeg('z',60,16-T/2,24+T/2,HALL_H);
  wallDoors('x',0,0,60,[],WALL_H);
  wallDoors('x',40,0,60,NEWDOORS,WALL_H);
  wallDoors('x',56,0,60,[],WALL_H);
  wallDoors('z',0,0,16,[],WALL_H);
  wallDoors('z',0,24,56,[],WALL_H);
  wallDoors('z',60,0,16,[],WALL_H);
  wallDoors('z',60,24,56,[ROOM.exit.cz],WALL_H);
  [14,28,42,52].forEach(function(x){wallDoors('z',x,0,16,[8],WALL_H);addDoor('z',x,8);});
  [18,34,46].forEach(function(x){wallDoors('z',x,24,40,[32],WALL_H);addDoor('z',x,32);});
  [20,40].forEach(function(x){wallDoors('z',x,40,56,[48],WALL_H);addDoor('z',x,48);});
  north.forEach(function(c){addDoor('x',16,c);});
  south.forEach(function(c){addDoor('x',24,c);});
  NEWDOORS.forEach(function(c){addDoor('x',40,c);});
}
function buildShell(){
  setBuild(0);
  var fm=new THREE.MeshPhongMaterial({map:TEX.floor,shininess:6,specular:0x222222});
  planeAt(60,56,30,0,28,-Math.PI/2,fm);
  ROOMS.forEach(function(r){
    var t=TEX.ceil.clone();t.needsUpdate=true;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set((r.x2-r.x1)/3,(r.z2-r.z1)/3);
    planeAt(r.x2-r.x1,r.z2-r.z1,r.cx,WALL_H,r.cz,Math.PI/2,new THREE.MeshPhongMaterial({map:t,shininess:1}));
  });
  planeAt(56,2.4,30,0.012,20,-Math.PI/2,new THREE.MeshPhongMaterial({color:0x4a1210,shininess:2}));
}
