
function C(x,z,w,d,room){
  var o=F(x,z,w,d,2.3,0,{map:TEX.closet});
  var r=ROOM[room],ex=x,ez=z,rdx=r.cx-x,rdz=r.cz-z;
  if(Math.abs(rdx)>Math.abs(rdz))ex=x+(rdx>0?1:-1)*(w/2+0.9);else ez=z+(rdz>0?1:-1)*(d/2+0.9);
  closets.push({x:x,z:z,w:w,d:d,box:o.box,exit:{x:ex,z:ez},room:room,kind:'closet',eye:1.5,fl:CUR});
}
function CR(x,z,room){
  var o=F(x,z,1.5,1.5,1.5,0,{map:TEX.crate});
  var r=ROOM[room],ex=x,ez=z,rdx=r.cx-x,rdz=r.cz-z;
  if(Math.abs(rdx)>Math.abs(rdz))ex=x+(rdx>0?1:-1)*1.65;else ez=z+(rdz>0?1:-1)*1.65;
  closets.push({x:x,z:z,w:1.5,d:1.5,box:o.box,exit:{x:ex,z:ez},room:room,kind:'crate',eye:0.95,fl:CUR});
}
function buildKey(x,y,z){
  var g=new THREE.Group(),m=new THREE.MeshPhongMaterial({color:0xe2b34a,emissive:0x6b4a10,shininess:70,specular:0xffffff});
  var ring=new THREE.Mesh(new THREE.TorusGeometry(0.11,0.035,8,16),m);ring.position.y=0.2;g.add(ring);
  var shaft=new THREE.Mesh(new THREE.BoxGeometry(0.06,0.38,0.05),m);shaft.position.y=-0.05;g.add(shaft);
  var t1=new THREE.Mesh(new THREE.BoxGeometry(0.14,0.05,0.05),m);t1.position.set(0.07,-0.17,0);g.add(t1);
  var t2=new THREE.Mesh(new THREE.BoxGeometry(0.1,0.05,0.05),m);t2.position.set(0.05,-0.07,0);g.add(t2);
  var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:TEX.glow,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false}));
  sp.scale.set(1.1,1.1,1);g.add(sp);
  g.scale.set(1.3,1.3,1.3);g.position.set(x,y,z);CURG.add(g);
  keyItems.push({obj:g,x:x,z:z,y:y,taken:false});
}
function buildFurniture(){
  /* غرفة النوم */
  F(2.4,3.6,2.4,3.4,0.7,0x4a3b38);deco(2.4,0.7,2.4,2.2,0.18,0.7,0x6a5a52);deco(2.4,0.7,4.6,2.2,0.08,2.0,0x5a2220);
  F(5.0,0.8,0.9,0.9,0.6,0x3b2a1e);F(1.2,13.4,1.2,2.4,1.0,0x3b2a1e);F(12.2,13.2,0.8,0.8,0.9,0x4a3322);
  C(11.5,0.9,2.0,1.1,'bed');
  /* المطبخ */
  F(19,0.7,6,1.2,1.0,0x555048);F(25,4,2.2,1.6,0.9,0x4a3a2a);F(27.2,12.5,1.2,1.2,2.0,0x8a8a84);
  deco(24.2,0.9,3.6,0.4,0.4,0.4,0x606060);C(15.2,13.5,1.2,2.0,'kit');
  /* المكتبة */
  F(31.5,0.7,5,0.6,2.6,0x2e2016);F(38.5,0.7,5,0.6,2.6,0x2e2016);
  F(40.2,11.5,2.4,1.2,0.85,0x4a3322);F(30.5,4,0.9,0.9,0.9,0x5a2a2a);
  C(29.2,13.6,1.2,2.0,'lib');
  /* الحمّام */
  F(44.5,1.0,2.2,1.0,0.7,0x9a9a92);deco(44.5,0.7,1.0,2.0,0.1,0.8,0x5a0d0d);
  F(50.6,0.8,0.7,0.8,0.5,0xa8a8a0);F(48.4,0.5,1.0,0.6,0.9,0x9a9a92);C(43.2,13.8,1.0,1.8,'bath');
  /* المخزن */
  F(59.2,3.5,0.8,4,2.2,0x3a2a1c);F(53.4,13.5,1.0,1.0,1.0,0x6a5030);F(54.6,13.8,1.0,1.0,1.0,0x5a4228);
  F(58.5,13.5,0.9,0.9,1.0,0x3a3a3a);
  /* غرفة المعيشة */
  F(1.2,27,1.0,2.6,0.8,0x3a2a30);F(14,39.4,2.4,0.8,0.9,0x2a2a2a);F(4,38.8,0.8,0.6,2.2,0x3b2a1e);
  F(13.5,27.5,2.0,1.4,0.7,0x4a3322);C(17.3,37.5,1.0,2.0,'liv');
  /* غرفة الطعام */
  F(26,37,5,1.6,0.9,0x4a3322);F(32.8,26,0.8,3.0,2.0,0x3b2a1e);F(23.4,35.6,0.5,0.5,0.9,0x3a2a1c);F(28.6,35.6,0.5,0.5,0.9,0x3a2a1c);
  C(19.3,37.5,0.9,1.8,'din');
  /* غرفة الأطفال */
  F(36.5,38,1.2,2.0,1.0,0x7a6a5a);
  F(44.5,26.5,1.2,0.8,0.6,0x5a3a2a);F(43.5,37,0.8,0.9,0.9,0x4a3322);C(35.0,26.5,1.2,2.0,'nur');
  /* قاعة الخروج */
  F(55.5,27,0.9,0.9,3.3,0x4a4640);F(55.5,37,0.9,0.9,3.3,0x4a4640);F(48,26.5,1.2,1.2,1.0,0x4a3a2a);
  C(47.1,37.8,1.0,2.0,'exit');
  /* صناديق كبيرة للاختباء */
  CR(12.9,14.6,'bed');CR(16.2,3.5,'kit');CR(40.6,3.6,'lib');CR(50.6,13.6,'bath');CR(55.0,2.4,'stor');
  CR(1.6,35.0,'liv');CR(20.2,26.5,'din');CR(44.8,38.6,'nur');CR(58.5,26.5,'exit');
  /* غرفة الغسيل */
  F(1.8,42.2,1.6,1.4,1.0,0xb0b0a8);F(4.2,42.2,1.6,1.4,1.0,0xa8a8a0);F(2.0,53.8,2.6,1.4,0.9,0x5a4a3a);F(17.6,54.2,2.0,1.2,0.9,0x6a6a66);
  C(18.8,42.5,1.0,2.0,'laun');CR(14.5,52.5,'laun');deco(8.0,0,53.6,0.9,0.5,0.9,0x6a5a40);
  /* المرسم */
  F(23.5,42,0.6,3,2.0,0x3a2a1c);F(36,53.5,3,1.2,0.9,0x4a3a2a);F(21.5,53.8,1.0,1.0,1.0,0x5a4a3a);
  C(38.8,42.6,1.0,2.0,'stu');CR(25.5,54,'stu');deco(30,0,54.2,0.12,1.9,0.12,0x2a1c10);deco(30,1.0,54.2,1.0,0.8,0.08,0x6a5a4a);
  /* القبو */
  F(58.3,42.2,1.0,1.0,1.1,0x3a3a3a);F(55,41.8,0.9,0.9,1.1,0x3a3a3a);F(56.8,53.8,1.4,1.4,1.0,0x6a5030);
  F(44,54.2,2.2,1.2,1.0,0x5a4228);C(41.2,42.6,1.0,2.0,'cell');CR(58.6,50.5,'cell');
  /* الباب الحديدي */
  exitDoorPivot=new THREE.Group();exitDoorPivot.position.set(60,0,ROOM.exit.cz-DOOR_W/2+0.02);
  var dm=new THREE.Mesh(new THREE.BoxGeometry(0.22,2.78,DOOR_W-0.05),new THREE.MeshPhongMaterial({color:0x2a2c30,shininess:30,specular:0x555555}));
  dm.position.set(0,1.39,(DOOR_W-0.05)/2);exitDoorPivot.add(dm);
  var bar=new THREE.Mesh(new THREE.BoxGeometry(0.3,0.16,DOOR_W-0.1),new THREE.MeshPhongMaterial({color:0x5a1010}));
  bar.position.set(-0.05,1.4,(DOOR_W-0.05)/2);exitDoorPivot.add(bar);
  CURG.add(exitDoorPivot);
  exitBox={x1:59.8,x2:60.2,z1:ROOM.exit.cz-DOOR_W/2,z2:ROOM.exit.cz+DOOR_W/2,door:true};
  colliders.push(exitBox);blockers.push(exitBox);
  var out=outPane=new THREE.Mesh(new THREE.PlaneGeometry(14,8),new THREE.MeshBasicMaterial({color:0x8fa4b8}));
  out.position.set(64,3,ROOM.exit.cz);out.rotation.y=-Math.PI/2;CURG.add(out);
  planeAt(14,14,67,0.01,ROOM.exit.cz,-Math.PI/2,new THREE.MeshBasicMaterial({color:0x56626e}));
}
function buildDecor(){
  var bm=new THREE.MeshPhongMaterial({map:TEX.blood,transparent:true,depthWrite:false,shininess:30,specular:0x331111,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  function splat(x,z,s){var m=new THREE.Mesh(new THREE.PlaneGeometry(s,s),bm);m.rotation.x=-Math.PI/2;m.rotation.z=R(0,6.28);m.position.set(x,0.02,z);CURG.add(m);}
  ROOMS.forEach(function(r){for(var i=0;i<4;i++)splat(R(r.x1+1.5,r.x2-1.5),R(r.z1+1.5,r.z2-1.5),R(1.2,3));});
  for(var j=0;j<9;j++)splat(R(4,56),R(17.2,22.8),R(1.5,3.4));
  addText('اهرب',15,2.4,16.19,0,3.6,1.12,'#8d0f0c');
  addText('لا تنظر خلفك',45,2.4,23.81,Math.PI,4.4,1.38,'#8d0f0c');
  addText('ابقَ هادئًا',0.19,1.9,8,Math.PI/2,3.2,1.0,'#8d0f0c');
  addText('هو يسمعك',40,2.2,39.81,Math.PI,3.2,1.0,'#8d0f0c');
  addText('ثلاثة مفاتيح',48.4,2.4,39.81,Math.PI,3.2,1.0,'#8d0f0c');
  addText('مخرج',59.83,3.05,ROOM.exit.cz,-Math.PI/2,1.5,0.47,'#46ff82',true);
}

/* ---------- navigation graph (hammer man) ---------- */
var nodes=[], roomNode={};
function addNode(x,z,fl){nodes.push({x:x,z:z,fl:fl,adj:[]});return nodes.length-1;}
function link(a,b){var d=Math.hypot(nodes[a].x-nodes[b].x,nodes[a].z-nodes[b].z);nodes[a].adj.push({n:b,d:d});nodes[b].adj.push({n:a,d:d});}
function hallChain(xs,fl){
  xs=xs.slice().sort(function(a,b){return a-b;});
  var map={},prev=-1;
  xs.forEach(function(x){var n=addNode(x,20,fl);map[x]=n;if(prev>=0)link(prev,n);prev=n;});
  return map;
}
function seqLink(ids){for(var i=0;i<ids.length-1;i++)link(roomNode[ids[i]],roomNode[ids[i+1]]);}
function buildGraph(){
  ROOMS.concat(ROOMS2).forEach(function(r){roomNode[r.id]=addNode(r.cx,r.cz,r.fl);});
  var main=ROOMS.slice(0,9),m0=hallChain(main.map(function(r){return r.cx;}),0);
  main.forEach(function(r){link(roomNode[r.id],m0[r.cx]);});
  seqLink(['bed','kit','lib','bath','stor']);seqLink(['liv','din','nur','exit']);seqLink(['laun','stu','cell']);
  [['liv','laun',10],['din','stu',31],['exit','cell',52]].forEach(function(p){
    var d=addNode(p[2],40,0);link(roomNode[p[0]],d);link(d,roomNode[p[1]]);
  });
  var nx=ROOMS2.slice(0,6).map(function(r){return r.cx;}),m1=hallChain(nx.concat([6,30,42,54]),1);
  ROOMS2.slice(0,6).forEach(function(r){link(roomNode[r.id],m1[r.cx]);});
  [['a0',6],['a2',30],['a3',42],['a4',54]].forEach(function(p){link(roomNode[p[0]],m1[p[1]]);});
  seqLink(['n0','n1','n2','n3','n4','n5']);seqLink(['a0','a1','a2','a3','a4']);seqLink(['b0','b1','b2','b3']);
  [['a0','b0',7.5],['a1','b1',22.5],['a3','b2',37.5],['a4','b3',52.5]].forEach(function(p){
    var d=addNode(p[2],40,1);link(roomNode[p[0]],d);link(d,roomNode[p[1]]);
  });
  var sb=addNode(9.6,22.6,0),st=addNode(25.6,22.6,1);
  link(sb,m0[9]);link(st,m1[30]);link(st,m1[25]);link(sb,st);
}
function route(a,b){
  var n=nodes.length,dist=[],prev=[],done=[],i;
  for(i=0;i<n;i++){dist[i]=1e9;prev[i]=-1;done[i]=false;}
  dist[a]=0;
  for(var it=0;it<n;it++){
    var u=-1,best=1e9;
    for(i=0;i<n;i++)if(!done[i]&&dist[i]<best){best=dist[i];u=i;}
    if(u<0||u===b)break;
    done[u]=true;
    for(var k=0;k<nodes[u].adj.length;k++){var e=nodes[u].adj[k],nd=dist[u]+e.d;if(nd<dist[e.n]){dist[e.n]=nd;prev[e.n]=u;}}
  }
  var path=[],c=b;
  if(prev[c]===-1&&c!==a)return [a];
  while(c!==-1){path.unshift(c);c=prev[c];}
  return path;
}

/* ---------- collision / line of sight ---------- */
function pushOut(p,r){
  var colliders=FL[p.fl||0].co;
  for(var pass=0;pass<2;pass++){
    for(var i=0;i<colliders.length;i++){
      var b=colliders[i],cx=Math.max(b.x1,Math.min(p.x,b.x2)),cz=Math.max(b.z1,Math.min(p.z,b.z2));
      var dx=p.x-cx,dz=p.z-cz,d2=dx*dx+dz*dz;
      if(d2<r*r){
        if(d2>1e-8){var d=Math.sqrt(d2),k=(r-d)/d;p.x+=dx*k;p.z+=dz*k;}
        else{
          var l=p.x-b.x1,rr=b.x2-p.x,t=p.z-b.z1,bt=b.z2-p.z,m=Math.min(l,rr,t,bt);
          if(m===l)p.x=b.x1-r;else if(m===rr)p.x=b.x2+r;else if(m===t)p.z=b.z1-r;else p.z=b.z2+r;
        }
      }
    }
  }
}
function segHits(ax,az,bx,bz,b){
  var dx=bx-ax,dz=bz-az,t0=0,t1=1,p=[-dx,dx,-dz,dz],q=[ax-b.x1,b.x2-ax,az-b.z1,b.z2-az];
  for(var i=0;i<4;i++){
    if(p[i]===0){if(q[i]<0)return false;}
    else{var t=q[i]/p[i];if(p[i]<0){if(t>t1)return false;if(t>t0)t0=t;}else{if(t<t0)return false;if(t<t1)t1=t;}}
  }
  return true;
}
function blocked(ax,az,bx,bz,fl){var blockers=FL[fl||0].bl;for(var i=0;i<blockers.length;i++)if(segHits(ax,az,bx,bz,blockers[i]))return true;return false;}
function nearestNode(x,z,fl){
  var best=-1,bd=1e9,bv=-1,bvd=1e9;
  for(var i=0;i<nodes.length;i++){
    if(nodes[i].fl!==fl)continue;
    var d=Math.hypot(nodes[i].x-x,nodes[i].z-z);
    if(d<bd){bd=d;best=i;}
    if(d<bvd&&!blocked(x,z,nodes[i].x,nodes[i].z,fl)){bvd=d;bv=i;}
  }
  return bv>=0?bv:best;
}
function distBox(x,z,b){var dx=Math.max(b.x1-x,0,x-b.x2),dz=Math.max(b.z1-z,0,z-b.z2);return Math.hypot(dx,dz);}
