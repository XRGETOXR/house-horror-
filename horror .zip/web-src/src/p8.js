
/* ---------- multiplayer (room capability) ---------- */
var ROOMAPI=null;
var NET={hz:{},room:null,code:'',cfg:null,lastRnd:0,acc:0,ents:{},spec:0,unsub:null};
var STC=['patrol','search','investigate','chase','hideCheck'];
try{
  if(window.claude&&window.claude.use){
    window.claude.use('room').then(function(r){ROOMAPI=r||null;if(game.state==='menu'&&$('mp'))refreshMP();}).catch(function(){});
  }
}catch(e){}
function rng(seed){
  var a=seed>>>0;
  return function(){a=(a+0x6D2B79F5)>>>0;var t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};
}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function cleanName(n){n=String(n||'').replace(/[^\p{L}\p{N} _-]/gu,'').trim().slice(0,14);return n||'لاعب';}
function r2(v){return Math.round((v||0)*100)/100;}

function netPlayers(){
  var a=[];if(!NET.room)return a;
  NET.room.peers().forEach(function(p){if(p.kind==='viewer'&&p.presence&&p.presence.v===1)a.push(p);});
  return a;
}
function hostPeer(){
  var ps=netPlayers(),rd=ps.filter(function(p){var s=p.presence.st;return s==='play'||s==='dead'||s==='win';});
  var use=(rd.length&&game.state!=='menu')?rd:ps,h=null;
  use.forEach(function(p){if(!h||p.peer<h.peer)h=p;});
  return h;
}
function isHost(){if(!NET.room)return true;var h=hostPeer();return !h||(h.isMe&&h.sameTab);}
function mpPlayers(){
  var a=[];
  if(game.state==='play'||game.state==='pad')a.push(P);
  var k;for(k in NET.ents){if(NET.ents[k].alive)a.push(NET.ents[k]);}
  return a;
}

/* avatars */
function labelSprite(txt){
  var c=cnv(256,64),g=c.getContext('2d');
  g.font='bold 30px Tajawal, sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#fff';g.shadowColor='#000';g.shadowBlur=6;g.fillText(txt,128,34);
  var sp=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true}));
  sp.scale.set(1.8,0.45,1);sp.position.y=2.25;return sp;
}
function makeAvatar(id,name){
  var g=new THREE.Group(),h=0,i;
  for(i=0;i<id.length;i++)h=(h*31+id.charCodeAt(i))%360;
  var shirt=new THREE.MeshPhongMaterial({color:new THREE.Color().setHSL(h/360,0.5,0.42),shininess:6});
  var pants=matP(0x2b2f3a),skin=matP(0xd8c0a8),hair=matP(0x221a14);
  function limb(x,y,len,w,mat){var p=new THREE.Group();p.position.set(x,y,0);var m=new THREE.Mesh(new THREE.BoxGeometry(w,len,w*1.1),mat);m.position.y=-len/2;p.add(m);return p;}
  var rig={legL:limb(-0.12,0.85,0.85,0.2,pants),legR:limb(0.12,0.85,0.85,0.2,pants),armL:limb(-0.33,1.42,0.62,0.16,shirt),armR:limb(0.33,1.42,0.62,0.16,shirt)};
  rig.torso=new THREE.Mesh(new THREE.BoxGeometry(0.5,0.62,0.28),shirt);rig.torso.position.y=1.16;
  var head=new THREE.Mesh(new THREE.SphereGeometry(0.2,14,10),skin);head.position.y=1.74;
  var hr=new THREE.Mesh(new THREE.SphereGeometry(0.215,14,8,0,Math.PI*2,0,Math.PI*0.55),hair);hr.position.y=1.76;
  g.add(rig.legL,rig.legR,rig.armL,rig.armR,rig.torso,head,hr);
  var lamp=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.06,0.2,8),matP(0x333333));lamp.position.y=-0.62;rig.armR.add(lamp);
  var beam=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.9,5,14,1,true),new THREE.MeshBasicMaterial({color:0xffe9b0,transparent:true,opacity:0.14,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide}));
  beam.position.y=-0.62-2.5;rig.armR.add(beam);beam.visible=false;
  var lbl=labelSprite(name);g.add(lbl);
  g.userData={name:name,lbl:lbl,rig:rig,beam:beam,ph:0};
  scene.add(g);return g;
}
function animAvatar(av,dt,e){
  var u=av.userData,r=u.rig;if(!r)return;
  var moving=e.spd>0.4;
  u.ph+=dt*(moving?(e.spd>4.2?9:7):0);
  var sw=moving?Math.sin(u.ph)*0.55:0;
  r.legL.rotation.x=sw;r.legR.rotation.x=-sw;
  r.armL.rotation.x=-sw*0.6;
  r.armR.rotation.x=e.torch?-1.25:sw*0.6;
  r.torso.position.y=e.crouch?0.9:1.16;
  av.scale.y=e.crouch?0.72:1;
  u.beam.visible=!!e.torch&&e.alive&&!e.hidden;
}
/* search markers: ring on the table a teammate is searching (shown ~2.5 s) */
function updateMarks(now){
  NET.marks=NET.marks||{};
  spots.forEach(function(s,i){
    if(!s.ring){
      var rg=new THREE.Mesh(new THREE.RingGeometry(0.32,0.42,28),new THREE.MeshBasicMaterial({color:0xffb347,transparent:true,opacity:0.9,depthWrite:false,side:THREE.DoubleSide}));
      rg.rotation.x=-Math.PI/2;scene.add(rg);s.ring=rg;
    }
    var on=!!NET.room&&(NET.marks[i]||0)>now;
    s.ring.visible=on;
    if(on)s.ring.position.set(s.x,(s.fl?FY:0)+0.98,s.z);
  });
}
function relabel(av,name){
  av.remove(av.userData.lbl);var l=labelSprite(name);av.add(l);av.userData.lbl=l;av.userData.name=name;
}
function clearNet(){
  var k;for(k in NET.ents){if(NET.ents[k].av)scene.remove(NET.ents[k].av);}
  NET.ents={};
}

/* per-frame sync */
function netSync(dt){
  if(!NET.room)return;
  var seen={},now=Date.now(),anyDoor=false,found={};
  NET.room.peers().forEach(function(p){
    var pr=p.presence;
    if(!pr||pr.v!==1||p.kind!=='viewer')return;
    if(pr.rd===game.rnd){
      if(pr.sr)pr.sr.forEach(function(i){found[i]=1;});
      if(pr.dr)anyDoor=true;
      if(pr.fx)game.fixed=true;
      if(pr.so)game.safeOpen=true;
      if(!(p.isMe&&p.sameTab)){
        var hk=NET.hz[p.peer];
        if(!hk||hk.rd!==pr.rd){NET.hz[p.peer]={rd:pr.rd,n:pr.hz||0};}
        else if((pr.hz||0)>hk.n){hk.n=pr.hz;if(isHost())applyHit(pr.ht);}
      }
    }
    if(p.isMe&&p.sameTab)return;
    if(pr.sg!==undefined&&pr.sg>=0&&pr.rd===game.rnd&&spots[pr.sg]){NET.marks=NET.marks||{};var wasOn=NET.marks[pr.sg]>now;NET.marks[pr.sg]=now+2500;if(!wasOn&&game.state==='play'&&!spots[pr.sg].searched)toast('زميلك يفتّش على الطاولة المحددة',2000);}
    var id=p.peer;seen[id]=1;
    var e=NET.ents[id];
    if(!e)e=NET.ents[id]={x:pr.x||0,z:pr.z||0,fl:pr.fl||0,gy:pr.y||0,hidden:null,crouch:false,torch:true,noise:0,alive:false,st:'lobby',yaw:0,px:pr.x||0,pz:pr.z||0,pt:now,last:null,name:'',av:null,spd:0};
    if(e.last!==pr){
      var dtp=(now-e.pt)/1000;
      if(dtp>0.04){var sp=Math.hypot((pr.x||0)-e.px,(pr.z||0)-e.pz)/dtp;e.noise=sp>0.4?(sp>4.2?14:(pr.c?2.5:7)):0;e.spd=sp;e.px=pr.x||0;e.pz=pr.z||0;e.pt=now;}
      e.last=pr;
    }
    var k=Math.min(1,dt*12),tx=pr.x||0,tz=pr.z||0;
    if(Math.hypot(tx-e.x,tz-e.z)>5){e.x=tx;e.z=tz;}else{e.x+=(tx-e.x)*k;e.z+=(tz-e.z)*k;}
    e.fl=pr.fl||0;e.gy=pr.y||0;e.yaw=pr.a||0;
    e.hidden=(pr.h>=0&&closets[pr.h])?closets[pr.h]:null;
    e.crouch=!!pr.c;e.torch=!!pr.t;e.st=pr.st||'lobby';e.alive=(e.st==='play');e.name=pr.n||'لاعب';
    if(now-e.pt>700)e.noise=0;
    if(!e.av)e.av=makeAvatar(id,e.name);
    if(e.av.userData.name!==e.name)relabel(e.av,e.name);
    e.av.position.set(e.x,e.gy,e.z);e.av.rotation.y=e.yaw+Math.PI;e.av.visible=e.alive&&!e.hidden;animAvatar(e.av,dt,e);
  });
  Object.keys(NET.ents).forEach(function(id){
    if(!seen[id]){var e=NET.ents[id];if(e.av)scene.remove(e.av);delete NET.ents[id];}
  });
  spots.forEach(function(s,i){if(found[i]&&!s.searched)markSearched(s);});
  updateMarks(now);
  syncTools();
  var kc=0;spots.forEach(function(s){if(s.key&&s.searched)kc++;});
  if(kc>game.keys&&(game.state==='play'||game.state==='spec'))toast('زميلك وجد مفتاحًا ('+AR_NUM(kc)+'/'+AR_NUM(game.need)+')',2200);
  game.keys=kc;
  if(anyDoor&&!game.doorOpen){openExit();if(game.state==='play')toast('زميلك فتح الباب الحديدي!',2500);}
}
function packMon(){
  var sc=STC.indexOf(H.state);
  return {
    h:[r2(H.x),r2(H.z),H.fl||0,r2(H.dx),r2(H.dz),r2(H.v),sc<0?0:sc,r2(Math.max(0,H.atk)),r2(H.atkAnim),H.catch===undefined?-1:H.catch],
    g:[r2(G.x),r2(G.z),r2(G.dx),r2(G.dz),r2(G.v),r2(Math.max(0,G.atk)),r2(G.atkAnim)]
  };
}
function netTick(dt){
  if(!NET.room)return;
  NET.acc+=dt;if(NET.acc<0.1)return;NET.acc=0;
  var sr=[];spots.forEach(function(s,i){if(s.searched)sr.push(i);});
  var gs=game.state,st=(gs==='play'||gs==='pad'||gs==='wake'||(gs==='day'&&!game.dayDeath))?'play':((gs==='dead'||gs==='spec'||gs==='day')?'dead':(gs==='cinema'?'win':'lobby'));
  var pr={v:1,n:S.name||'لاعب',st:st,rd:game.rnd||0,x:r2(P.x),z:r2(P.z),y:r2(P.gy),a:r2(P.yaw),fl:P.fl||0,
    h:P.hidden?closets.indexOf(P.hidden):-1,c:P.crouch?1:0,t:P.torch?1:0,sr:sr,dr:game.doorOpen?1:0,fx:game.fixed?1:0,so:game.safeOpen?1:0,hz:game.hitSeq||0,ht:game.hitType||'h',sg:(game.lastSearchT&&Date.now()-game.lastSearchT<2500)?game.lastSearchI:-1};
  if(D.monsters&&isHost()){var m=packMon();pr.m=m;}
  NET.room.presence(pr).catch(function(){});
}
function netApplyMon(dt){
  var hp=hostPeer();if(!hp||(hp.isMe&&hp.sameTab))return;
  var m=hp.presence.m;if(!m)return;
  var k=Math.min(1,dt*10),h=m.h,g=m.g;
  if(h&&D.monsters){
    if(Math.hypot(h[0]-H.x,h[1]-H.z)>6){H.x=h[0];H.z=h[1];}else{H.x+=(h[0]-H.x)*k;H.z+=(h[1]-H.z)*k;}
    H.fl=h[2];H.dx=h[3];H.dz=h[4];H.v=h[5];
    var ns=STC[h[6]]||'patrol';
    if(ns==='chase'&&H.state!=='chase'&&dist2(H,P)<25&&game.state==='play')Snd.sting();
    H.state=ns;H.atk=h[7];H.atkAnim=h[8];H.catch=h[9];updFloor(H);
  }
  if(g&&game.giantOn){
    if(Math.hypot(g[0]-G.x,g[1]-G.z)>6){G.x=g[0];G.z=g[1];}else{G.x+=(g[0]-G.x)*k;G.z+=(g[1]-G.z)*k;}
    G.dx=g[2];G.dz=g[3];G.v=g[4];G.atk=g[5];G.atkAnim=g[6];
    G.phase+=dt*G.v*1.9;giantSteps();
  }
}
function simBackground(dt){
  updateDoors(dt);
  netSync(dt);
  var host=isHost();
  if(D.monsters){if(host){pickTarget();updateHammerMan(dt);}else netApplyMon(dt);}
  if(game.giantOn){if(host)updateGiant(dt);else if(!D.monsters)netApplyMon(dt);}
  netTick(dt);
}
function openExit(){
  game.doorOpen=true;
  var i=FL[0].co.indexOf(exitBox);if(i>=0)FL[0].co.splice(i,1);
  var j=FL[0].bl.indexOf(exitBox);if(j>=0)FL[0].bl.splice(j,1);
  Snd.door();
  if(D.monsters&&H.state!=='chase'&&isHost()&&game.state==='play'){H.state='investigate';setGoal(H,P.x,P.z,P.fl);H.wait=0;}
}

/* spectating and round end */
function specTarget(){
  var l=mpPlayers().filter(function(e){return e!==P;});
  if(!l.length)return null;
  return l[((NET.spec%l.length)+l.length)%l.length];
}
function updateSpec(dt){
  T0+=dt;game.time+=dt;
  simBackground(dt);
  var t=specTarget();
  if(t){
    camera.position.set(t.x,(t.gy||0)+1.6,t.z);camera.rotation.set(0,t.yaw||0,0);
    var pe=$('prompt');pe.innerHTML='<b>E</b>تتابع: '+esc(t.name||'لاعب');pe.style.opacity=1;
  }else if(!game.specEnd){game.specEnd=true;showRoundEnd();}
  animateMonsters(dt);
}
function goSpec(){
  hideScreen();game.state='spec';game.specEnd=false;NET.spec=0;
  $('hit').style.opacity=0;$('hud').hidden=true;$('prompt').hidden=false;
}
function showDeathMP(){
  if(!NET.room)return false;
  var alive=mpPlayers().filter(function(e){return e!==P;}).length;
  if(alive===0)return false;
  var msg={hammer:'حطّمتك المطرقة',giant:'سحقك العملاق',closet:'اكتشف مخبأك'}[game.killer]||'سقطت';
  $('hud').hidden=true;$('prompt').style.opacity=0;$('slits').hidden=true;
  showScreen('<h2>'+msg+'</h2><p class="lead">سقطت، لكن زملاءك ما زالوا يقاتلون ('+AR_NUM(alive)+').</p><div class="btns"><button class="btn" id="spec" type="button">تابع زملاءك</button><button class="btn alt" id="menub" type="button">القائمة</button></div>');
  $('spec').addEventListener('click',goSpec);bindGo(function(){});
  return true;
}
function showRoundEnd(){
  var ps=netPlayers(),won=ps.filter(function(p){return p.presence.st==='win';}).length;
  $('prompt').style.opacity=0;
  showScreen('<h2>انتهت الجولة</h2><p class="lead">نجا '+AR_NUM(won)+' من '+AR_NUM(ps.length)+' لاعبين.</p><div class="btns"><button class="btn" id="go" type="button">جولة جديدة</button><button class="btn alt" id="menub" type="button">القائمة</button></div>');
  bindGo(startGame);
}

/* menu */
function playerNames(){
  return netPlayers().map(function(p){return esc(p.presence.n||'لاعب')+((p.isMe&&p.sameTab)?' (أنت)':'');}).join('، ');
}
function mpBadge(){
  if(NET.room)return '<p class="fine">👥 أنت في غرفة <b>'+esc(NET.code)+'</b> ('+AR_NUM(netPlayers().length)+' لاعبين)</p>';
  return '';
}
function mpHTML(){
  if(window.LANMODE&&!NET.room)return window.lanHTML();
  if(!ROOMAPI)return '<div class="mpst bad"><b>اللعب الجماعي غير متاح الآن</b><span>يعمل فقط عند فتح اللعبة من حساب مدعو: اضغط «Share» (مشاركة) أعلى الصفحة، أرسل الرابط لأصدقائك، ثم افتحوه جميعًا.</span></div><button class="btn" id="mpGo" type="button">العب منفردًا</button>';
  if(NET.room){
    var hint=window.lanRoomHint?window.lanRoomHint():'';
    var hp=hostPeer(),list=netPlayers().map(function(p){
      return '<li>'+esc(p.presence.n||'لاعب')+((p.isMe&&p.sameTab)?' <small>(أنت)</small>':'')+((hp&&hp.peer===p.peer)?' <small class="host">منشئ الجولة</small>':'')+'</li>';}).join('');
    return hint+'<div class="mpst ok"><b>غرفة: '+esc(NET.code)+'</b><span>اللاعبون ('+AR_NUM(netPlayers().length)+'):</span><ul class="plist">'+list+'</ul>'+
      '<span>'+(isHost()?'أنت منشئ الجولة: اضغط «ابدأ الجولة» ليدخل الجميع.':'انتظر منشئ الغرفة ثم اضغط «ابدأ الجولة».')+'</span></div>'+
      '<div class="btns"><button class="btn" id="mpGo" type="button">ابدأ الجولة</button><button class="btn alt" id="mpLeave" type="button">مغادرة الغرفة</button></div>';
  }
  return '<div class="mpst ok"><b>متصل بخدمة اللعب الجماعي</b><span>اكتب اسمك ورمز غرفة يتفق عليه أصدقاؤك (حروف إنجليزية أو أرقام)، ثم انضموا.</span></div>'+
    '<div class="mpf"><input id="mpName" maxlength="14" placeholder="اسمك" value="'+esc(S.name||'')+'"><input id="mpCode" maxlength="20" placeholder="رمز الغرفة مثل: home1" dir="ltr"></div>'+
    '<div class="btns"><button class="btn" id="mpJoin" type="button">انضم إلى الغرفة</button><button class="btn alt" id="mpGo" type="button">العب منفردًا</button></div>';
}
function refreshMP(){var m=$('mp');if(!m)return;m.innerHTML=mpHTML();bindMP();}
function bindMP(){
  var j=$('mpJoin'),l=$('mpLeave'),g=$('mpGo');
  if(g)g.addEventListener('click',startGame);
  if(j)j.addEventListener('click',mpJoin);
  if(l)l.addEventListener('click',mpLeave);
}
function mpJoin(){
  var code=($('mpCode').value||'').toLowerCase().replace(/[^a-z0-9_.-]/g,'').replace(/^[^a-z0-9]+/,'').slice(0,20);
  if(!code){toast('اكتب رمز الغرفة بحروف إنجليزية أو أرقام',2400);return;}
  S.name=cleanName($('mpName').value);saveS();
  ROOMAPI.join('hh-'+code).then(function(r){
    NET.room=r;NET.code=code;NET.lastRnd=0;
    NET.unsub=r.onPeers(function(){if(game.state==='menu')refreshMP();},function(){});
    r.presence({v:1,n:S.name,st:'lobby'}).catch(function(){});
    refreshMP();
  }).catch(function(e){toast(window.LANMODE?'تعذّر الاتصال بالمضيف ('+((e&&e.message)||'خطأ')+'). تأكد أنه يستضيف الجولة وأنك على نفس نقطة الاتصال.':'تعذّر الانضمام إلى الغرفة. تأكد أن الرابط مشارك معك.',4200);});
}
function mpLeave(){
  var r=NET.room;NET.room=null;
  if(NET.unsub){try{NET.unsub();}catch(e){}NET.unsub=null;}
  if(r)r.leave().catch(function(){});
  clearNet();refreshMP();
}
function mpPrepare(){
  if(NET.room){
    var hp=hostPeer(),host=isHost(),cfg;
    if(host){cfg={diff:S.diff,seed:(Math.random()*4294967295)>>>0,rnd:Date.now()};}
    else{
      cfg=hp&&hp.presence.cfg;
      if(!cfg||cfg.rnd===NET.lastRnd){toast('بانتظار منشئ الغرفة ليبدأ الجولة',2500);return false;}
    }
    NET.cfg=cfg;NET.lastRnd=cfg.rnd;D=DIFF[cfg.diff]||DIFF.med;game.seed=cfg.seed;game.rnd=cfg.rnd;
    if(host)NET.room.presence({cfg:cfg,v:1,n:S.name||'لاعب',st:'lobby',rd:cfg.rnd}).catch(function(){});
    return true;
  }
  D=DIFF[S.diff]||DIFF.med;game.seed=(Math.random()*4294967295)>>>0;game.rnd=0;
  return true;
}
