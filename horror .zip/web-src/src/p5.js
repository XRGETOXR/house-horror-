
/* ---------- audio ---------- */
var AC=null, master=null, noiseBuf=null;
var Snd={
  init:function(){
    if(AC){if(AC.state==='suspended')AC.resume();return;}
    try{
      AC=new (window.AudioContext||window.webkitAudioContext)();
      master=AC.createGain();master.gain.value=S.vol;master.connect(AC.destination);
      noiseBuf=AC.createBuffer(1,AC.sampleRate,AC.sampleRate);
      var d=noiseBuf.getChannelData(0);for(var i=0;i<d.length;i++)d[i]=Math.random()*2-1;
      [48,50.5,73].forEach(function(f,i){
        var o=AC.createOscillator(),g=AC.createGain();o.type=i===2?'triangle':'sine';o.frequency.value=f;g.gain.value=0.035;
        o.connect(g);g.connect(master);o.start();
        var l=AC.createOscillator(),lg=AC.createGain();l.frequency.value=0.07+i*0.03;lg.gain.value=0.02;l.connect(lg);lg.connect(g.gain);l.start();
      });
    }catch(e){AC=null;}
  },
  tone:function(type,f0,f1,vol,dur){
    if(!AC)return;var t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();
    o.type=type;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+dur);
    g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(Math.max(0.0002,vol),t+0.012);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
    o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+0.05);
  },
  noise:function(vol,dur,freq){
    if(!AC)return;var t=AC.currentTime,s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();
    s.buffer=noiseBuf;f.type='lowpass';f.frequency.value=freq;
    g.gain.setValueAtTime(Math.max(0.0002,vol),t);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
    s.connect(f);f.connect(g);g.connect(master);s.start(t);s.stop(t+dur+0.05);
  },
  beat:function(v){Snd.tone('sine',62,30,v,0.2);setTimeout(function(){Snd.tone('sine',54,28,v*0.8,0.18);},170);},
  gstep:function(d){var v=Math.max(0.05,0.75*(1-d/40));Snd.tone('sine',52,22,v,0.45);Snd.noise(v*0.5,0.35,180);},
  hstep:function(d){Snd.noise(Math.max(0.02,0.18*(1-d/14)),0.09,900);},
  sting:function(){Snd.tone('sawtooth',420,70,0.22,0.9);Snd.tone('square',233,60,0.1,0.9);},
  swing:function(){Snd.noise(0.35,0.4,1400);},
  groan:function(){Snd.tone('sawtooth',90,45,0.18,1.2);},
  chime:function(){Snd.tone('sine',880,880,0.16,0.5);setTimeout(function(){Snd.tone('sine',1320,1320,0.12,0.6);},120);},
  hit:function(){Snd.noise(0.9,0.6,500);Snd.tone('sine',90,25,0.9,0.7);},
  bang:function(){Snd.noise(0.5,0.5,600);Snd.tone('sine',70,30,0.5,0.4);},
  creak:function(v){Snd.tone('sawtooth',150,85,v,0.45);},
  door:function(){Snd.tone('sawtooth',70,40,0.2,1.2);Snd.noise(0.2,0.8,300);}
};

/* ---------- UI helpers ---------- */
var AR=['٠','١','٢','٣'];
var toastTimer=0;
function toast(msg,ms){
  var el=$('toast');el.textContent=msg;el.style.opacity=1;
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.style.opacity=0;},ms||2200);
}
function showScreen(html){var s=$('scr');panel.innerHTML=html;s.hidden=false;s.style.display='flex';s.style.background='';s.style.alignItems='';}
function hideScreen(){var s=$('scr');s.hidden=true;s.style.display='none';}
function fmtTime(t){var m=Math.floor(t/60),s=Math.floor(t%60);return AR_NUM(m)+':'+(s<10?AR_NUM(0):'')+AR_NUM(s);}
function AR_NUM(n){return String(n).replace(/\d/g,function(d){return '٠١٢٣٤٥٦٧٨٩'.charAt(+d);});}

function menuHTML(){
  var seg=['easy','med','hard','none'].map(function(k){var d=DIFF[k];
    return '<button type="button" class="seg'+(S.diff===k?' on':'')+'" data-d="'+k+'"><b>'+d.name+'</b><small>'+AR_NUM(d.keys)+' مفتاحًا</small></button>';}).join('');
  return '<h1>بيت المطرقة</h1>'+
  '<p class="lead">أنت محبوس في بيت مهجور من طابقين. رجل ملطخ بالدم يحمل مطرقة بأشواك يجوب الغرف، وفي الممر الطويل عملاق بطيء قد يظهر وقد لا يظهر.</p>'+
  '<div class="segs" id="segs">'+seg+'</div><p id="dinfo">'+DIFF[S.diff].info+'</p>'+
  mpBadge()+
  '<div class="goal"><ol><li>ابحث عن المفاتيح المخبأة في الصناديق وتحت الدرج، في الطابقين.</li>'+
  '<li>اجمع السلاح والأدوات: المسدس في صندوق، والمطرقة في صندوق، والمفك داخل الخزنة (رمزها في ورقة بالمطبخ).</li><li>اذهب إلى قاعة الخروج، أصلح الباب الحديدي ثم افتحه بالمفاتيح.</li>'+
  '<li>اهرب قبل أن يجدك أحدهما.</li></ol></div>'+
  '<div class="ctl desk"><span><kbd>W A S D</kbd>حركة</span><span><kbd>الفأرة</kbd>نظر</span>'+
  '<span><kbd>Shift</kbd>جري</span><span><kbd>C</kbd>انحناء</span>'+
  '<span><kbd>E</kbd>بحث / اختباء</span><span><kbd>F</kbd>الكشاف</span>'+
  '<span><kbd>Q</kbd>إطلاق النار</span><span><kbd>M</kbd>الخريطة</span><span><kbd>P</kbd>إيقاف مؤقت</span></div>'+
  '<div class="btns"><button class="btn" id="go" type="button">ابدأ اللعبة</button><button class="btn alt" id="mpb" type="button">👥 اللعب الجماعي</button><button class="btn alt" id="setb" type="button">الإعدادات</button></div>'+
  '<p class="fine">لعبة رعب. يُفضّل استخدام سماعات.<br>تطوير: Asoma Okazi</p>';
}
function showMenu(){
  game.state='menu';showScreen(menuHTML());bindGo(startGame);
  var bs=document.querySelectorAll('#segs .seg');
  Array.prototype.forEach.call(bs,function(b){
    b.addEventListener('click',function(){
      S.diff=b.getAttribute('data-d');saveS();
      Array.prototype.forEach.call(bs,function(x){x.classList.toggle('on',x===b);});
      $('dinfo').textContent=DIFF[S.diff].info;
    });
  });
  $('setb').addEventListener('click',function(){showSettings('menu');});
  $('mpb').addEventListener('click',showMP);
  bindMP();if(NET.room)NET.room.presence({st:'lobby'}).catch(function(){});
}
function settingsHTML(){
  return '<h2>الإعدادات</h2><div class="form">'+
  '<label>جودة الرسوم<select id="sGfx"><option value="low">منخفضة (أسرع)</option><option value="med">متوسطة</option><option value="high">عالية (أوضح)</option></select></label>'+
  '<label>حساسية النظر<input type="range" id="sSens" min="0.4" max="2" step="0.1"></label>'+
  '<label>مستوى الصوت<input type="range" id="sVol" min="0" max="1" step="0.05"></label>'+
  '<label>السطوع<input type="range" id="sBri" min="0.6" max="1.8" step="0.1"></label></div>'+
  '<button class="btn" id="back" type="button">رجوع</button><p class="fine">تطوير: Asoma Okazi</p>';
}
function showSettings(from){
  showScreen(settingsHTML());
  $('sGfx').value=S.gfx;$('sSens').value=S.sens;$('sVol').value=S.vol;$('sBri').value=S.bright;
  $('sGfx').addEventListener('change',function(e){S.gfx=e.target.value;applyGfx();saveS();});
  $('sSens').addEventListener('input',function(e){S.sens=+e.target.value;saveS();});
  $('sVol').addEventListener('input',function(e){S.vol=+e.target.value;if(master)master.gain.value=S.vol;saveS();});
  $('sBri').addEventListener('input',function(e){S.bright=+e.target.value;applyGfx();saveS();});
  $('back').addEventListener('click',function(){if(from==='pause')showPause();else showMenu();});
  $('back').focus();
}
function bindGo(fn){var b=$('go');if(b){b.addEventListener('click',fn);b.focus();}var m=$('menub');if(m)m.addEventListener('click',toMenu);}

/* ---------- input ---------- */
var keys={}, touch={mx:0,mz:0,run:false,on:false}, dragging=false, lockOn=false, mapOn=false;
function look(dx,dy,s){s*=S.sens;P.yaw-=dx*s;P.pitch=Math.max(-1.45,Math.min(1.45,P.pitch-dy*s));}
function requestLock(){
  if(touch.on)return;
  try{var r=cv.requestPointerLock();if(r&&r.catch)r.catch(function(){});}catch(e){}
}
document.addEventListener('pointerlockchange',function(){
  var was=lockOn;lockOn=(document.pointerLockElement===cv);
  if(was&&!lockOn&&game.state==='play')pauseGame();
});
document.addEventListener('mousemove',function(e){
  if(game.state!=='play')return;
  if(lockOn||dragging)look(e.movementX||0,e.movementY||0,0.0022);
});
cv.addEventListener('mousedown',function(){if(game.state==='play'){if(lockOn)fire();else dragging=true;}});
window.addEventListener('mouseup',function(){dragging=false;});
window.addEventListener('keydown',function(e){
  if(game.state==='play'){
    if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].indexOf(e.code)>=0)e.preventDefault();
    if(e.repeat){keys[e.code]=true;return;}
    keys[e.code]=true;
    if(e.code==='KeyE')interact();
    else if(e.code==='KeyQ')fire();
    else if(e.code==='KeyF')toggleTorch();
    else if(e.code==='KeyC')toggleCrouch();
    else if(e.code==='KeyM')toggleMap();
    else if(e.code==='KeyP'||e.code==='Escape')pauseGame();
  }else if(game.state==='paused'&&e.code==='KeyP'){resumeGame();}
  else if(game.state==='spec'&&e.code==='KeyE')NET.spec++;
  else if(game.state==='cinema'&&(e.code==='Enter'||e.code==='Space'||e.code==='Escape'))skipCinema();
});
window.addEventListener('keyup',function(e){keys[e.code]=false;if(e.code==='Space')e.preventDefault();});
window.addEventListener('blur',function(){keys={};if(game.state==='play')pauseGame();});

function setTouchMode(){
  if(touch.on)return;touch.on=true;document.body.classList.add('touch');
  $('cross').hidden=false;
}
(function bindTouch(){
  var stick=$('stick'),knob=$('knob'),sid=null,cx=0,cy=0,lid=null,lx=0,ly=0;
  window.addEventListener('touchstart',setTouchMode,{passive:true});
  stick.addEventListener('touchstart',function(e){
    e.preventDefault();var t=e.changedTouches[0];sid=t.identifier;
    var r=stick.getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;mv(t);
  },{passive:false});
  function mv(t){
    var dx=t.clientX-cx,dy=t.clientY-cy,l=Math.hypot(dx,dy),m=52;
    if(l>m){dx*=m/l;dy*=m/l;}
    knob.style.transform='translate('+dx+'px,'+dy+'px)';touch.mx=dx/m;touch.mz=-dy/m;
  }
  stick.addEventListener('touchmove',function(e){
    e.preventDefault();for(var i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===sid)mv(e.changedTouches[i]);
  },{passive:false});
  function end(e){
    for(var i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===sid){sid=null;touch.mx=0;touch.mz=0;knob.style.transform='none';}
  }
  stick.addEventListener('touchend',end);stick.addEventListener('touchcancel',end);
  cv.addEventListener('touchstart',function(e){
    e.preventDefault();if(lid!==null)return;var t=e.changedTouches[0];lid=t.identifier;lx=t.clientX;ly=t.clientY;
  },{passive:false});
  cv.addEventListener('touchmove',function(e){
    e.preventDefault();
    for(var i=0;i<e.changedTouches.length;i++){var t=e.changedTouches[i];
      if(t.identifier===lid&&game.state==='play'){look(t.clientX-lx,t.clientY-ly,0.0055);lx=t.clientX;ly=t.clientY;}}
  },{passive:false});
  function lend(e){for(var i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===lid)lid=null;}
  cv.addEventListener('touchend',lend);cv.addEventListener('touchcancel',lend);
  function hold(id,on){
    var b=$(id);
    b.addEventListener('touchstart',function(e){e.preventDefault();touch.run=true;b.classList.add('on');},{passive:false});
    var off=function(e){touch.run=false;b.classList.remove('on');};
    b.addEventListener('touchend',off);b.addEventListener('touchcancel',off);
  }
  hold('bRun');
  function tap(id,fn){$(id).addEventListener('touchstart',function(e){e.preventDefault();if(game.state==='play')fn();},{passive:false});}
  tap('bUse',function(){interact();});tap('bCrouch',function(){toggleCrouch();});
  tap('bFire',function(){fire();});tap('bTorch',function(){toggleTorch();});tap('bMap',function(){toggleMap();});
})();

function toggleTorch(){P.torch=!P.torch;}
function toggleCrouch(){if(!P.hidden)P.crouch=!P.crouch;}
function toggleMap(){mapOn=!mapOn;$('mapwrap').style.display=mapOn?'block':'none';}
function pauseGame(){
  if(game.state!=='play')return;
  game.state='paused';dragging=false;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
  showPause();
}
function showPause(){
  showScreen('<h2>متوقف مؤقتًا</h2><p class="lead">الوحوش تنتظرك.</p><div class="btns"><button class="btn" id="go" type="button">متابعة</button><button class="btn alt" id="setb" type="button">الإعدادات</button><button class="btn alt" id="exb" type="button">خروج</button></div>');
  bindGo(resumeGame);
  $('setb').addEventListener('click',function(){showSettings('pause');});
  $('exb').addEventListener('click',exitGame);
}
function exitGame(){
  try{if(window.AndroidLan&&AndroidLan.exitApp){AndroidLan.exitApp();return;}}catch(e){}
  toMenu();
}
function resumeGame(){
  if(game.state!=='paused')return;
  hideScreen();game.state='play';game.last=performance.now();requestLock();
}

/* ---------- interaction ---------- */
function nearTarget(){
  if(P.hidden)return {type:'unhide',label:'الخروج من المخبأ'};
  var i,k,xt=extraTarget();if(xt)return xt;
  for(i=0;i<spots.length;i++){k=spots[i];if(!k.searched&&k.fl===P.fl&&Math.hypot(k.x-P.x,k.z-P.z)<(k.r||1.7))return {type:'spot',obj:k,label:k.label};}
  for(i=0;i<closets.length;i++){
    if(closets[i].fl===P.fl&&distBox(P.x,P.z,closets[i].box)<1.15)return {type:'hide',obj:closets[i],label:closets[i].kind==='crate'?'الاختباء في الصندوق':'الاختباء في الخزانة'};
  }
  if(P.fl===0&&exitBox&&exitBox.door&&distBox(P.x,P.z,exitBox)<2.2){
    return {type:'door',label:game.keys>=game.need?'فتح الباب الحديدي':'الباب مقفل — تحتاج '+AR_NUM(game.need)+' مفاتيح'};
  }
  return null;
}
function interact(){
  var t=nearTarget();if(!t||game.state!=='play')return;
  if(t.run){t.run();return;}
  if(t.type==='spot'){
    var sp=t.obj;markSearched(sp);game.lastSearchI=spots.indexOf(sp);game.lastSearchT=Date.now();
    if(sp.key){
      game.keys++;Snd.chime();
      toast('وجدت مفتاحًا ('+AR_NUM(game.keys)+'/'+AR_NUM(game.need)+')'+(game.keys>=game.need?' — اتبع السهم إلى الباب الحديدي':''),2600);
    }else if(sp.item){takeItem(sp);}else{Snd.creak(0.1);toast('لا شيء هنا',1200);}
  }else if(t.type==='hide'){
    var c=t.obj;game.stats.hides++;P.hidden=c;P.x=c.x;P.z=c.z;P.crouch=false;
    if(D.monsters&&H.state==='chase'&&H.fl===P.fl&&dist2(H,P)<18){H.state='hideCheck';H.closet=c;H.stateT=0;setGoal(H,c.exit.x,c.exit.z,c.fl);}
  }else if(t.type==='unhide'){
    var cl=P.hidden;P.hidden=null;P.x=cl.exit.x;P.z=cl.exit.z;pushOut(P,PR);
  }else if(t.type==='door'){
    if(game.keys>=game.need&&!game.doorOpen){
      openExit();toast('الباب مفتوح! اهرب!',2600);
    }else if(game.keys<game.need){toast('الباب مقفل. ما زال ينقصك '+AR_NUM(game.need-game.keys)+' من المفاتيح.',2200);Snd.bang();}
  }
}
function kill(by){
  if(game.state!=='play'&&game.state!=='pad')return;
  closePad(false);
  game.state='dead';game.deadT=0;game.killer=by;game.msgShown=false;
  Snd.hit();$('hit').style.opacity=0.85;
  try{if(document.pointerLockElement)document.exitPointerLock();}catch(e){}
}

$('menuBtn').addEventListener('click',function(){if(game.state==='play')pauseGame();});
