#!/usr/bin/env python3
"""Build the game. Edit ONLY the files in web-src/src/, then run:  python3 build.py

Outputs:
  ../app/src/main/assets/   the site the Android app loads (index.html, css/, js/, lib/)
  ../../house-hammer.html   optional single-file web version for claude.ai (pass --no-web to skip)
"""
import os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'src')
ASSETS = os.path.join(HERE, '..', 'app', 'src', 'main', 'assets')
WEB_OUT = os.path.join(HERE, '..', '..', 'house-hammer.html')

# Game modules, in load order (they share one scope inside the first module's IIFE).
MODULES = ['p2.js', 'p3.js', 'p3b.js', 'p4.js', 'p5.js', 'p6.js', 'p7.js',
           'p8.js', 'p9a.js', 'p9b.js', 'p9c.js']


def read(name):
    with open(os.path.join(SRC, name), encoding='utf8') as f:
        return f.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf8') as f:
        f.write(text)


def main():
    page = read('page.html')
    m = re.search(r'<style>(.*?)</style>', page, re.S)
    css = m.group(1).strip() + '\n'
    rest = page[:m.start()] + page[m.end():]
    title = re.search(r'<title>.*?</title>', rest, re.S).group(0)
    body = rest.replace(title, '').strip() + '\n'
    lan = read('lan.js')
    game = ''.join(read(n) for n in MODULES).rstrip() + '\n})();\n'

    # 1. Android site (loaded by MainActivity from file:///android_asset/index.html)
    index = ('<!doctype html>\n<html lang="ar" dir="rtl"><head><meta charset="utf-8">'
             '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
             + title + '<link rel="stylesheet" href="css/style.css"></head>\n<body>\n' + body +
             '<script src="lib/three.min.js"></script>\n'
             '<script src="js/lan.js"></script>\n'
             '<script src="js/game.js"></script>\n</body></html>\n')
    write(os.path.join(ASSETS, 'index.html'), index)
    write(os.path.join(ASSETS, 'css', 'style.css'), css)
    write(os.path.join(ASSETS, 'js', 'lan.js'), lan)
    write(os.path.join(ASSETS, 'js', 'game.js'), game)
    print('android assets written to', os.path.normpath(ASSETS))

    # 2. Single-file web version (three.js from the CDN) for claude.ai
    if '--no-web' not in sys.argv:
        web = ('<!doctype html>\n<html lang="ar" dir="rtl"><head><meta charset="utf-8">'
               '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
               + title + '<style>' + css + '</style></head>\n<body>\n' + body +
               '<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>\n'
               '<script>\n' + lan + '</script>\n<script>\n' + game + '</script>\n</body></html>\n')
        write(WEB_OUT, web)
        print('web file written to', os.path.normpath(WEB_OUT))


if __name__ == '__main__':
    main()
