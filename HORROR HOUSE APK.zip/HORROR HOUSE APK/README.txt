HORROR HOUSE Android project

This project wraps the supplied HTML game in an Android WebView.
The game uses Three.js and Google Fonts from online CDNs, so an internet connection is required when playing.

To build on GitHub:
1. Create a GitHub repository.
2. Upload the CONTENTS of this folder (including the hidden .github folder) to the repository's main branch.
3. Open the Actions tab and select Build HORROR HOUSE APK.
4. Run workflow if it has not started automatically.
5. When the run is green, download the HORROR-HOUSE-APK artifact, extract the ZIP, and install app-debug.apk.

Package: com.asoma.horrorhouse
App label: HORROR HOUSE
