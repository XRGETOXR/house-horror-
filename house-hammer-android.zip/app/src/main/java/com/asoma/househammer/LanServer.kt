package com.asoma.househammer

import java.io.BufferedInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.ConcurrentHashMap

/**
 * Minimal WebSocket relay for LAN play (no external libraries).
 * Each client sends {"t":"pres","p":{...}} and receives the full list of peers:
 * {"t":"peers","you":"p001","list":[{"peer":"p001","p":{...}}, ...]}
 */
class LanServer(private val port: Int = 8765) {

    private class Client(val id: String, val out: OutputStream) {
        @Volatile var pres: String = "{}"
    }

    private val clients = ConcurrentHashMap<String, Client>()
    private val idLock = Any()
    private var counter = 0
    private var server: ServerSocket? = null

    @Synchronized
    fun start(): Boolean {
        if (server != null) return true
        return try {
            val ss = ServerSocket(port)
            server = ss
            Thread {
                while (true) {
                    val s = try { ss.accept() } catch (e: Exception) { break }
                    Thread { handle(s) }.apply { isDaemon = true }.start()
                }
            }.apply { isDaemon = true }.start()
            true
        } catch (e: Exception) {
            false
        }
    }

    @Synchronized
    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        server = null
        clients.values.forEach { c -> try { c.out.close() } catch (_: Exception) {} }
        clients.clear()
    }

    private fun handle(s: Socket) {
        var id: String? = null
        try {
            s.tcpNoDelay = true
            val inp = BufferedInputStream(s.getInputStream())
            val out = s.getOutputStream()
            val headers = readHeaders(inp)
            val key = headers["sec-websocket-key"] ?: return
            val digest = MessageDigest.getInstance("SHA-1")
                .digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray(Charsets.UTF_8))
            val accept = Base64.getEncoder().encodeToString(digest)
            out.write(
                ("HTTP/1.1 101 Switching Protocols\r\n" +
                    "Upgrade: websocket\r\nConnection: Upgrade\r\n" +
                    "Sec-WebSocket-Accept: $accept\r\n\r\n").toByteArray(Charsets.UTF_8)
            )
            out.flush()

            val newId = synchronized(idLock) { counter++; "p" + String.format("%03d", counter) }
            id = newId
            val client = Client(newId, out)
            clients[newId] = client
            send(client, "{\"t\":\"hello\",\"you\":\"$newId\"}")
            broadcast()

            while (true) {
                val text = readText(inp) ?: break
                if (text.startsWith("{\"t\":\"pres\"")) {
                    val i = text.indexOf("\"p\":")
                    if (i > 0 && text.endsWith("}")) {
                        client.pres = text.substring(i + 4, text.length - 1)
                        broadcast()
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            id?.let { clients.remove(it) }
            try { s.close() } catch (_: Exception) {}
            broadcast()
        }
    }

    private fun broadcast() {
        val list = clients.values.sortedBy { it.id }
        val entries = list.joinToString(",") { "{\"peer\":\"${it.id}\",\"p\":${it.pres}}" }
        list.forEach { c ->
            send(c, "{\"t\":\"peers\",\"you\":\"${c.id}\",\"list\":[$entries]}")
        }
    }

    private fun send(c: Client, text: String) {
        try {
            val payload = text.toByteArray(Charsets.UTF_8)
            val header = java.io.ByteArrayOutputStream()
            header.write(0x81)
            val n = payload.size
            when {
                n < 126 -> header.write(n)
                n < 65536 -> {
                    header.write(126)
                    header.write(n shr 8); header.write(n and 0xFF)
                }
                else -> {
                    header.write(127)
                    for (i in 7 downTo 0) header.write((n.toLong() shr (8 * i)).toInt() and 0xFF)
                }
            }
            synchronized(c.out) {
                c.out.write(header.toByteArray())
                c.out.write(payload)
                c.out.flush()
            }
        } catch (_: Exception) {
        }
    }

    private fun readHeaders(inp: InputStream): Map<String, String> {
        val map = HashMap<String, String>()
        var first = true
        while (true) {
            val line = readLine(inp) ?: break
            if (line.isEmpty()) break
            if (first) { first = false; continue }
            val idx = line.indexOf(':')
            if (idx > 0) map[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
        }
        return map
    }

    private fun readLine(inp: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = inp.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun readExact(inp: InputStream, n: Int): ByteArray? {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = inp.read(buf, off, n - off)
            if (r < 0) return null
            off += r
        }
        return buf
    }

    /** Reads one text frame; returns null on close. Handles ping and masking. */
    private fun readText(inp: InputStream): String? {
        while (true) {
            val h = readExact(inp, 2) ?: return null
            val opcode = h[0].toInt() and 0x0F
            val masked = (h[1].toInt() and 0x80) != 0
            var len = (h[1].toInt() and 0x7F).toLong()
            if (len == 126L) {
                val e = readExact(inp, 2) ?: return null
                len = ((e[0].toInt() and 0xFF) shl 8 or (e[1].toInt() and 0xFF)).toLong()
            } else if (len == 127L) {
                val e = readExact(inp, 8) ?: return null
                len = 0L
                for (b in e) len = (len shl 8) or (b.toLong() and 0xFF)
            }
            val mask = if (masked) readExact(inp, 4) ?: return null else null
            if (len > 1_000_000L) return null
            val data = readExact(inp, len.toInt()) ?: return null
            if (mask != null) for (i in data.indices) data[i] = (data[i].toInt() xor mask[i % 4].toInt()).toByte()
            when (opcode) {
                0x8 -> return null            // close
                0x9 -> { /* ping: ignored, clients do not need pongs on LAN */ }
                0x1 -> return String(data, Charsets.UTF_8)
                else -> { /* binary or continuation: ignored */ }
            }
        }
    }

    companion object {
        /** IPv4 addresses of this phone (hotspot address is usually 192.168.43.1). */
        fun localIps(): String {
            val out = ArrayList<String>()
            try {
                NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                    if (!ni.isUp || ni.isLoopback) return@forEach
                    ni.inetAddresses.toList().forEach { a ->
                        if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) {
                            a.hostAddress?.let { out.add(it) }
                        }
                    }
                }
            } catch (_: Exception) {}
            return out.joinToString(", ")
        }
    }
}
