/* LAN adapter: active only inside the Android app (AndroidLan bridge present).
   Implements the small "room" API the game uses, over a WebSocket to the host phone. */
(function(){
  if(!window.AndroidLan)return;
  window.LANMODE=true;
  var PORT=8765, hostingInfo='';

  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}

  function open(host){
    return new Promise(function(resolve,reject){
      var me=null,mine={},peers=[],listeners=[],closedByUs=false,done=false,sock;
      var room={
        peers:function(){return peers.slice();},
        presence:function(p){
          mine=Object.assign({},mine,p);
          if(sock&&sock.readyState===1&&me)sock.send(JSON.stringify({t:'pres',p:mine}));
          return Promise.resolve();
        },
        onPeers:function(fn){
          listeners.push(fn);
          return function(){listeners=listeners.filter(function(f){return f!==fn;});};
        },
        leave:function(){closedByUs=true;try{sock.close();}catch(e){}if(hostingInfo){hostingInfo='';try{AndroidLan.stopHost();}catch(e){}}return Promise.resolve();},
        connected:function(){return !!sock&&sock.readyState===1;}
      };
      function notify(){listeners.slice().forEach(function(f){try{f();}catch(e){}});}
      try{sock=new WebSocket('ws://'+host+':'+PORT+'/');}catch(e){reject(e);return;}
      sock.onmessage=function(ev){
        var m;try{m=JSON.parse(ev.data);}catch(e){return;}
        if(m.t==='hello'){
          me=m.you;
          if(!done){done=true;resolve(room);}
          sock.send(JSON.stringify({t:'pres',p:mine}));
        }else if(m.t==='peers'){
          peers=(m.list||[]).map(function(x){
            return {peer:x.peer,kind:'viewer',guest:false,isMe:x.peer===me,sameTab:x.peer===me,by:null,updatedAt:Date.now(),presence:x.p||{}};
          });
          notify();
        }
      };
      sock.onerror=function(){if(!done){done=true;reject(new Error('connect'));}};
      sock.onclose=function(){
        if(!done){done=true;reject(new Error('closed'));return;}
        if(!closedByUs){peers=[];notify();}
      };
    });
  }

  var api={
    join:function(name){
      var host=String(name||'').replace(/^hh-/,'');
      if(!host||host==='self')host='127.0.0.1';
      return open(host);
    }
  };
  window.claude={use:function(n){return Promise.resolve(n==='room'?api:null);}};

  /* UI helpers used by the multiplayer screen */
  function games(){
    try{var a=JSON.parse(AndroidLan.games());return Array.isArray(a)?a:[];}catch(e){return [];}
  }
  function renderGames(){
    var list=games().filter(function(g){return /^[0-9.]+$/.test(g.ip);});
    if(!list.length)return '<p class="fine">لا توجد جولات على الشبكة الآن. اضغط «استضافة جولة هنا» على هاتف المضيف، أو تأكد أنك متصل بنفس نقطة الاتصال.</p>';
    return list.map(function(g){
      return '<div class="btns"><button class="btn" type="button" onclick="lanJoinIp(\''+g.ip+'\')">'+esc(g.name||'جولة')+' ('+g.ip+')</button></div>';
    }).join('');
  }
  window.lanJoinIp=function(ip){
    var c=document.getElementById('mpCode');if(c)c.value=ip;
    var j=document.getElementById('mpJoin');if(j)j.click();
  };
  window.lanHTML=function(){
    var ips='';try{ips=AndroidLan.ips();}catch(e){}
    return '<div class="mpst ok"><b>اللعب عبر نقطة الاتصال</b>'+
      '<span>أحد الهواتف يشغّل نقطة الاتصال ويضغط «استضافة جولة هنا». الباقون يتصلون بنقطة الاتصال، وتظهر الجولة عندهم في القائمة، فيضغطون عليها للانضمام.</span></div>'+
      '<div class="mpf"><input id="mpName" maxlength="14" placeholder="اسمك"><input id="mpCode" maxlength="40" placeholder="أو اكتب عنوان المضيف" dir="ltr"></div>'+
      '<div class="btns"><button class="btn alt" type="button" onclick="lanHostNow()">استضافة جولة هنا</button>'+
      '<button class="btn alt" id="mpJoin" type="button">انضم بالعنوان المكتوب</button></div>'+
      '<div id="lanList">'+renderGames()+'</div>'+
      '<p class="fine" dir="ltr">عنوان هذا الهاتف: '+esc(ips||'غير معروف')+'</p>';
  };
  window.lanRoomHint=function(){
    return hostingInfo?'<p class="fine" dir="ltr">أنت المضيف. تظهر جولتك للهواتف المتصلة بنقطة الاتصال تلقائيًا (منفذ '+PORT+').</p>':'';
  };
  window.lanHostNow=function(){
    var nm=document.getElementById('mpName');var name='جولة '+((nm&&nm.value)||'لاعب');
    var ok=false;try{ok=AndroidLan.startHost(name);}catch(e){}
    if(!ok){var c=document.getElementById('mpCode');if(c)c.placeholder='تعذّر تشغيل الخادم على هذا الهاتف';return;}
    var ips='';try{ips=AndroidLan.ips();}catch(e){}
    hostingInfo=ips||'127.0.0.1';
    var code=document.getElementById('mpCode');if(code)code.value='127.0.0.1';
    var j=document.getElementById('mpJoin');if(j)j.click();
  };
  /* refresh the list of games while the screen is open */
  setInterval(function(){
    var el=document.getElementById('lanList');
    if(el)el.innerHTML=renderGames();
  },1500);
})();
