/* LAN adapter: active only inside the Android app (AndroidLan bridge present).
   Implements the small "room" API the game uses, over a WebSocket to the host phone,
   and shows the list of games found on the local network. */
(function(){
  if(!window.AndroidLan)return;
  window.LANMODE=true;
  var PORT=8765, hostingInfo='';

  var st=document.createElement('style');
  st.textContent=
    '.lan{display:grid;gap:12px;text-align:start}'+
    '.lan-head{display:flex;gap:12px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 14px}'+
    '.lan-dot{width:12px;height:12px;border-radius:50%;background:#46ff82;box-shadow:0 0 12px #46ff82;flex:none;animation:lanPulse 1.6s ease-in-out infinite}'+
    '.lan-head b{display:block;font-size:17px}.lan-head small{display:block;color:var(--muted);font-size:13px;line-height:1.6}'+
    '.lan h3{margin:6px 0 0;font-family:var(--display);font-weight:400;font-size:22px;color:var(--ink)}'+
    '.lan-list{display:grid;gap:8px}'+
    '.lan-game{display:flex;justify-content:space-between;align-items:center;gap:10px;width:100%;text-align:start;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:12px 14px;color:var(--ink);font-family:var(--body);font-size:17px;cursor:pointer}'+
    '.lan-game:hover,.lan-game:focus-visible{border-color:var(--blood);outline:none;background:var(--blood-d)}'+
    '.lan-game small{color:var(--muted);font-size:13px;direction:ltr}'+
    '.lan-empty{color:var(--muted);font-size:15px;border:1px dashed var(--line);border-radius:10px;padding:14px;margin:0;line-height:1.7}'+
    '.lan-actions{display:flex;justify-content:center}'+
    '.lan-manual{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:10px 14px}'+
    '.lan-manual summary{cursor:pointer;color:var(--muted)}'+
    '.lan-manual .mpf{margin-top:10px}'+
    '.lan-name input{width:100%;font-family:var(--body);font-size:16px;color:var(--ink);background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px;text-align:center}'+
    '@keyframes lanPulse{50%{opacity:.35}}';
  document.head.appendChild(st);

  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}

  function open(host){
    return new Promise(function(resolve,reject){
      var me=null,mine={},peers=[],listeners=[],closedByUs=false,done=false,sock;
      var room={
        peers:function(){return peers.slice();},
        presence:function(p){
          mine=Object.assign({},mine,p);
          if(sock&&sock.readyState===1&&me)sock.send(JSON.stringify({t:'pres',p:mine}));
          return Promise.resolve();
        },
        onPeers:function(fn){
          listeners.push(fn);
          return function(){listeners=listeners.filter(function(f){return f!==fn;});};
        },
        leave:function(){
          closedByUs=true;
          try{sock.close();}catch(e){}
          if(hostingInfo){hostingInfo='';try{AndroidLan.stopHost();}catch(e){}}
          return Promise.resolve();
        },
        connected:function(){return !!sock&&sock.readyState===1;}
      };
      function notify(){listeners.slice().forEach(function(f){try{f();}catch(e){}});}
      var timer=setTimeout(function(){
        if(!done){done=true;try{sock.close();}catch(e){}reject(new Error('timeout'));}
      },6000);
      try{sock=new WebSocket('ws://'+host+':'+PORT+'/');}catch(e){clearTimeout(timer);reject(e);return;}
      sock.onmessage=function(ev){
        var m;try{m=JSON.parse(ev.data);}catch(e){return;}
        if(m.t==='hello'){
          me=m.you;
          if(!done){done=true;clearTimeout(timer);resolve(room);}
          sock.send(JSON.stringify({t:'pres',p:mine}));
        }else if(m.t==='peers'){
          peers=(m.list||[]).map(function(x){
            return {peer:x.peer,kind:'viewer',guest:false,isMe:x.peer===me,sameTab:x.peer===me,by:null,updatedAt:Date.now(),presence:x.p||{}};
          });
          notify();
        }
      };
      sock.onerror=function(){if(!done){done=true;clearTimeout(timer);reject(new Error('connect'));}};
      sock.onclose=function(){
        if(!done){done=true;clearTimeout(timer);reject(new Error('closed'));return;}
        if(!closedByUs){peers=[];notify();}
      };
    });
  }

  var api={
    join:function(name){
      var host=String(name||'').replace(/^hh-/,'');
      if(!host||host==='self')host='127.0.0.1';
      return open(host).catch(function(){
        return new Promise(function(r){setTimeout(r,700);}).then(function(){return open(host);});
      });
    }
  };
  window.claude={use:function(n){return Promise.resolve(n==='room'?api:null);}};

  /* ---------- multiplayer screen ---------- */
  function games(){
    try{var a=JSON.parse(AndroidLan.games());return Array.isArray(a)?a:[];}catch(e){return [];}
  }
  function renderGames(){
    var list=games().filter(function(g){return /^[0-9.]+$/.test(g.ip);});
    if(!list.length)return '<p class="lan-empty">لا توجد جولات الآن. تأكد أن المضيف فتح الجولة، وأنك متصل بنفس نقطة الاتصال.</p>';
    return list.map(function(g){
      return '<button class="lan-game" type="button" onclick="lanJoinIp(\''+g.ip+'\')"><span>'+esc(g.name||'جولة')+'</span><small>'+g.ip+'</small></button>';
    }).join('');
  }
  window.lanJoinIp=function(ip){
    var c=document.getElementById('mpCode');if(c)c.value=ip;
    var j=document.getElementById('mpJoin');if(j)j.click();
  };
  window.lanHTML=function(){
    var ips='';try{ips=AndroidLan.ips();}catch(e){}
    return '<div class="lan">'+
      '<div class="lan-head"><span class="lan-dot"></span><div><b>اللعب عبر نقطة الاتصال</b>'+
      '<small>المضيف يشغّل نقطة الاتصال ويضغط «استضافة جولة هنا». الباقون يتصلون بها، وتظهر الجولة في القائمة.</small></div></div>'+
      '<div class="lan-name"><input id="mpName" maxlength="14" placeholder="اسمك"></div>'+
      '<h3>الجولات القريبة</h3>'+
      '<div id="lanList" class="lan-list">'+renderGames()+'</div>'+
      '<div class="lan-actions"><button class="btn" type="button" onclick="lanHostNow()">استضافة جولة هنا</button></div>'+
      '<details class="lan-manual"><summary>الانضمام بعنوان يدويًا</summary>'+
      '<div class="mpf"><input id="mpCode" maxlength="40" placeholder="مثل 192.168.43.1" dir="ltr"><button class="btn alt" id="mpJoin" type="button">انضم</button></div></details>'+
      '<p class="fine" dir="ltr">عنوان هذا الهاتف: '+esc(ips||'غير معروف')+'</p>'+
      '</div>';
  };
  window.lanRoomHint=function(){
    return hostingInfo?'<p class="fine" dir="ltr">أنت المضيف. تظهر جولتك تلقائيًا للهواتف المتصلة بنقطة الاتصال (منفذ '+PORT+').</p>':'';
  };
  window.lanHostNow=function(){
    var nm=document.getElementById('mpName');var name='جولة '+((nm&&nm.value)||'لاعب');
    var ok=false;try{ok=AndroidLan.startHost(name);}catch(e){}
    if(!ok){alertLine('تعذّر تشغيل الخادم على هذا الهاتف. أغلق التطبيق وافتحه من جديد.');return;}
    var ips='';try{ips=AndroidLan.ips();}catch(e){}
    hostingInfo=ips||'127.0.0.1';
    var code=document.getElementById('mpCode');if(code)code.value='127.0.0.1';
    var j=document.getElementById('mpJoin');if(j)j.click();
  };
  function alertLine(msg){
    var el=document.getElementById('lanList');if(el)el.innerHTML='<p class="lan-empty">'+esc(msg)+'</p>';
  }
  /* refresh the list of games while the screen is open (re-render only when it changed) */
  var lastList='';
  setInterval(function(){
    var el=document.getElementById('lanList');
    if(!el)return;
    var h=renderGames();
    if(h!==lastList){lastList=h;el.innerHTML=h;}
  },1500);
})();
