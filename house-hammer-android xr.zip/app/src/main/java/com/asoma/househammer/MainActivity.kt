package com.asoma.househammer

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private val lan = LanServer(8765)
    private lateinit var web: WebView

    /** Exposed to JavaScript as window.AndroidLan */
    inner class Bridge {
        @JavascriptInterface
        fun startServer(): Boolean = lan.start()

        @JavascriptInterface
        fun ips(): String = LanServer.localIps()

        /** Start hosting a game and announce it on the local network. */
        @JavascriptInterface
        fun startHost(name: String): Boolean {
            val ok = lan.start()
            if (ok) LanDiscovery.startAnnounce(name)
            return ok
        }

        /** Closes the app completely (exit button). */
        @JavascriptInterface
        fun exitApp() {
            runOnUiThread {
                LanDiscovery.stopAll()
                lan.stop()
                finish()
            }
        }

        @JavascriptInterface
        fun stopHost() {
            LanDiscovery.stopAnnounce()
            lan.stop()
        }

        /** Games heard on the network, as a JSON array. */
        @JavascriptInterface
        fun games(): String = LanDiscovery.gamesJson()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "AndroidLan")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
        LanDiscovery.startListening()
    }

    override fun onDestroy() {
        LanDiscovery.stopAll()
        lan.stop()
        super.onDestroy()
    }
}
