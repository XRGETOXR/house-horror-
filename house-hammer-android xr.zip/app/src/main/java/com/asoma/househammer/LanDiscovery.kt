package com.asoma.househammer

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * Game discovery on the local network (like a LAN server browser).
 * The host broadcasts "HH1|<name>" every second on UDP port 8766.
 * Every phone listens and keeps the list of games it has heard recently.
 */
object LanDiscovery {
    const val PORT = 8766
    private const val MAGIC = "HH1|"

    private val seen = ConcurrentHashMap<String, Pair<String, Long>>() // ip -> (name, lastSeen)
    @Volatile private var listenSock: DatagramSocket? = null
    @Volatile private var announceName: String? = null
    @Volatile private var announcing = false

    @Synchronized
    fun startListening() {
        if (listenSock != null) return
        try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            s.broadcast = true
            s.bind(InetSocketAddress(PORT))
            listenSock = s
            Thread {
                val buf = ByteArray(512)
                while (true) {
                    val p = DatagramPacket(buf, buf.size)
                    try { s.receive(p) } catch (_: Exception) { break }
                    val msg = String(p.data, 0, p.length, Charsets.UTF_8)
                    if (!msg.startsWith(MAGIC)) continue
                    val name = msg.substring(MAGIC.length).take(40)
                    val ip = p.address?.hostAddress ?: continue
                    seen[ip] = Pair(name, System.currentTimeMillis())
                }
            }.apply { isDaemon = true }.start()
        } catch (_: Exception) {
            listenSock = null
        }
    }

    @Synchronized
    fun startAnnounce(name: String) {
        val clean = name.replace("\"", "").replace("\\", "").take(40)
        announceName = clean
        if (announcing) return
        announcing = true
        Thread {
            try {
                val s = DatagramSocket()
                s.broadcast = true
                val target = InetAddress.getByName("255.255.255.255")
                while (true) {
                    val n = announceName ?: break
                    val data = (MAGIC + n).toByteArray(Charsets.UTF_8)
                    try { s.send(DatagramPacket(data, data.size, target, PORT)) } catch (_: Exception) {}
                    Thread.sleep(1000)
                }
                s.close()
            } catch (_: Exception) {
            } finally {
                announcing = false
            }
        }.apply { isDaemon = true }.start()
    }

    fun stopAnnounce() {
        announceName = null
    }

    /** JSON array of games heard in the last 4 seconds, excluding this phone's own announcements. */
    fun gamesJson(): String {
        val own = LanServer.localIps().split(", ").toSet()
        val now = System.currentTimeMillis()
        val items = seen.entries
            .filter { now - it.value.second < 4000 && it.key !in own }
            .sortedBy { it.key }
            .map { "{\"ip\":\"${it.key}\",\"name\":\"${it.value.first.replace("\"", "")}\"}" }
        return "[" + items.joinToString(",") + "]"
    }

    @Synchronized
    fun stopAll() {
        announceName = null
        try { listenSock?.close() } catch (_: Exception) {}
        listenSock = null
    }
}
