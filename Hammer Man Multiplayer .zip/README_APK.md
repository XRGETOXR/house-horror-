# تحويل لعبة «Hammer Man Multiplayer» إلى APK عبر GitHub

تم تجهيز هذا المشروع بالملفات اللازمة لبناء ملف **Android APK** تلقائياً عبر **GitHub Actions** دون الحاجة لتثبيت Android Studio على جهازك.

## الملفات المضافة
- `capacitor.config.json` — إعدادات حزمة الأندرويد (`com.hammerhouse.game`).
- `.github/workflows/build-apk.yml` — سير عمل تلقائي يبني اللعبة ويُخرج ملف `app-debug.apk`.

## خطوات استخراج ملف APK من GitHub
1. **حمّل ملفات المشروع** (ZIP) من المحرر ثم فك الضغط عنها.
2. **أنشئ مستودعاً جديداً (Repository) على GitHub** وارفع جميع الملفات إليه (تأكّد من وجود مجلد `.github/workflows/build-apk.yml`).
   > ملاحظة: إذا رفعت الملفات عبر واجهة الويب أو عبر Git، احرص على ألا يُحذف المجلد المخفي `.github`.
3. بعد رفع الملفات إلى فرع `main` (أو `master`):
   - افتح تبويب **Actions** في صفحتك على GitHub.
   - ستجد مهمة باسم **Build Android APK** تعمل تلقائياً (أو اضغط **Run workflow** لتشغيلها يدوياً).
   - انتظر 3–5 دقائق حتى تكتمل بعلامة خضراء.
4. انزل إلى قسم **Artifacts** في أسفل صفحة المهمة وحمّل ملف **`hammer-house-apk`** (بداخله `app-debug.apk`) وثبّته على هاتفك الأندرويد.
