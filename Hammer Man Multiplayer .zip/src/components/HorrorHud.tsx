import { RefObject, useEffect, useRef, useState } from 'react';
import { formatChatTime, getHousePreset, toArabicDigits } from '../game/constants';
import { ChatMessage, HudState } from '../game/types';
import { VoiceChatState } from '../game/voiceChat';
import { HeartbeatBeatEvent } from '../hooks/useDynamicHeartbeat';

interface HorrorHudProps {
  hud: HudState;
  isTouch: boolean;
  isFullscreen: boolean;
  heartbeatPulseRef: RefObject<HeartbeatBeatEvent | null>;
  chatMessages: ChatMessage[];
  chatOpen: boolean;
  unreadChat: number;
  onToggleChat: (open: boolean) => void;
  onSendChat: (text: string) => void;
  voiceState: VoiceChatState;
  onToggleVoice: () => void;
  onInteract: () => void;
  onDrop: () => void;
  onFire: () => void;
  onToggleCrouch: () => void;
  onToggleTorch: () => void;
  onToggleMap: () => void;
  onOpenJournal: () => void;
  onPause: () => void;
  onToggleFullscreen: () => void;
  onCycleSpectate: () => void;
  onExitSpectate: () => void;
  onTouchMove: (mx: number, mz: number) => void;
  onTouchRun: (running: boolean) => void;
  onTouchLook: (dx: number, dy: number) => void;
  onSkipCinema: () => void;
}

const PEER_COLORS = ['#5de2ff', '#ffd584', '#8effb8', '#ffa6c4'];

const SWEAT_DROPS = [
  { side: 'left', offset: '1.8%', w: 6, h: 11, delay: '0s', baseDur: 3.1, threshold: 0.12 },
  { side: 'right', offset: '2.1%', w: 7, h: 13, delay: '0.6s', baseDur: 2.8, threshold: 0.12 },
  { side: 'left', offset: '4.6%', w: 5, h: 10, delay: '1.3s', baseDur: 3.4, threshold: 0.28 },
  { side: 'right', offset: '5.2%', w: 6, h: 12, delay: '1.9s', baseDur: 3.0, threshold: 0.28 },
  { side: 'left', offset: '2.9%', w: 8, h: 15, delay: '0.9s', baseDur: 2.5, threshold: 0.46 },
  { side: 'right', offset: '3.4%', w: 8, h: 14, delay: '2.2s', baseDur: 2.6, threshold: 0.46 },
  { side: 'left', offset: '6.8%', w: 5, h: 9, delay: '1.6s', baseDur: 3.2, threshold: 0.65 },
  { side: 'right', offset: '6.9%', w: 5, h: 10, delay: '0.3s', baseDur: 3.1, threshold: 0.65 },
  { side: 'left', offset: '1.2%', w: 7, h: 14, delay: '2.4s', baseDur: 2.3, threshold: 0.8 },
  { side: 'right', offset: '1.4%', w: 7, h: 14, delay: '1.1s', baseDur: 2.4, threshold: 0.8 },
] as const;

interface HeartbeatVfxOverlayProps {
  threat: number;
  dangerOpacity: number;
  active: boolean;
  pulseRef: RefObject<HeartbeatBeatEvent | null>;
}

function HeartbeatVfxOverlay({
  threat,
  dangerOpacity,
  active,
  pulseRef,
}: HeartbeatVfxOverlayProps) {
  const vignetteRef = useRef<HTMLDivElement | null>(null);
  const edgeRef = useRef<HTMLDivElement | null>(null);
  const ringRef = useRef<HTMLDivElement | null>(null);

  const threatRef = useRef(threat);
  const dangerRef = useRef(dangerOpacity);
  const activeRef = useRef(active);

  threatRef.current = threat;
  dangerRef.current = dangerOpacity;
  activeRef.current = active;

  useEffect(() => {
    let rafId = 0;
    let smoothLevel = 0;
    let fallbackBeatAt = 0;

    const reducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;

    const tick = (now: number) => {
      const t = activeRef.current ? Math.max(0, Math.min(1, threatRef.current)) : 0;
      smoothLevel += (t - smoothLevel) * 0.14;

      let pulse = 0;
      if (activeRef.current && smoothLevel > 0.04 && !reducedMotion) {
        const bpm = 54 + Math.pow(smoothLevel, 1.05) * 130;
        const beatMs = Math.max(326, 60000 / bpm);

        const ev = pulseRef.current;
        let beatStart = ev ? ev.at : 0;
        let beatTension = ev ? ev.tension : smoothLevel;

        // If no recent audio beat event (e.g. AudioContext suspended before first click), run local BPM clock
        if (!beatStart || now - beatStart > beatMs * 1.45) {
          if (!fallbackBeatAt || now - fallbackBeatAt >= beatMs) {
            fallbackBeatAt = now;
          }
          beatStart = fallbackBeatAt;
          beatTension = smoothLevel;
        }

        const dtMs = Math.max(0, now - beatStart);
        const dubDelayMs = (0.2 - beatTension * 0.1) * 1000;

        const lub =
          dtMs < 260
            ? dtMs < 34
              ? dtMs / 34
              : Math.exp(-(dtMs - 34) / 68)
            : 0;

        const dt2 = dtMs - dubDelayMs;
        const dub =
          dt2 >= 0 && dt2 < 240
            ? (dt2 < 26 ? dt2 / 26 : Math.exp(-(dt2 - 26) / 74)) *
              (0.72 + beatTension * 0.24)
            : 0;

        pulse = Math.min(1, Math.max(lub, dub));
      }

      const baseDanger = Math.max(dangerRef.current * 0.34, smoothLevel * 0.26);
      const vOpacity = Math.min(
        0.92,
        baseDanger + pulse * (0.18 + Math.pow(smoothLevel, 0.85) * 0.62)
      );
      const edgeOpacity = Math.min(
        0.95,
        smoothLevel * 0.18 + pulse * (0.16 + smoothLevel * 0.72)
      );
      const ringOpacity =
        smoothLevel > 0.25
          ? Math.min(0.62, pulse * ((smoothLevel - 0.25) / 0.75) * 0.62)
          : 0;

      if (vignetteRef.current) {
        const squeezeScale = reducedMotion
          ? 1
          : 1.06 - pulse * (0.02 + smoothLevel * 0.048);
        vignetteRef.current.style.opacity = vOpacity.toFixed(3);
        vignetteRef.current.style.transform = `scale(${squeezeScale.toFixed(4)})`;
      }

      if (edgeRef.current) {
        edgeRef.current.style.opacity = edgeOpacity.toFixed(3);
        const spread = Math.round(10 + pulse * (14 + smoothLevel * 22));
        const blur = Math.round(46 + smoothLevel * 44 + pulse * 62);
        edgeRef.current.style.boxShadow = `inset 0 0 ${blur}px ${spread}px rgba(155, 8, 8, 0.9)`;
      }

      if (ringRef.current) {
        const waveScale = reducedMotion
          ? 1
          : 1 + pulse * (0.015 + smoothLevel * 0.032);
        ringRef.current.style.opacity = ringOpacity.toFixed(3);
        ringRef.current.style.transform = `scale(${waveScale.toFixed(4)})`;
      }

      rafId = window.requestAnimationFrame(tick);
    };

    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, [pulseRef]);

  return (
    <>
      <div
        ref={vignetteRef}
        className="fixed inset-0 pointer-events-none z-6 will-change-transform"
        style={{
          opacity: 0,
          background:
            'radial-gradient(ellipse at center, transparent 34%, rgba(125,0,0,0.68) 76%, rgba(45,0,0,0.96) 100%)',
        }}
      />
      <div
        ref={edgeRef}
        className="fixed inset-0 pointer-events-none z-6"
        style={{
          opacity: 0,
          background:
            'radial-gradient(circle at 12% 16%, rgba(150,8,8,0.22), transparent 34%), radial-gradient(circle at 88% 18%, rgba(150,8,8,0.22), transparent 34%), radial-gradient(circle at 14% 86%, rgba(150,8,8,0.24), transparent 36%), radial-gradient(circle at 86% 84%, rgba(150,8,8,0.24), transparent 36%)',
        }}
      />
      <div
        ref={ringRef}
        className="fixed inset-2 sm:inset-4 rounded-2xl pointer-events-none z-6 border-[3px] border-[#b31212]/45 will-change-transform"
        style={{
          opacity: 0,
          boxShadow: '0 0 28px rgba(179, 18, 18, 0.35)',
        }}
      />
    </>
  );
}

export function HorrorHud({
  hud,
  isTouch,
  isFullscreen,
  heartbeatPulseRef,
  chatMessages,
  chatOpen,
  unreadChat,
  onToggleChat,
  onSendChat,
  voiceState,
  onToggleVoice,
  onInteract,
  onDrop,
  onFire,
  onToggleCrouch,
  onToggleTorch,
  onToggleMap,
  onOpenJournal,
  onPause,
  onToggleFullscreen,
  onCycleSpectate,
  onExitSpectate,
  onTouchMove,
  onTouchRun,
  onTouchLook,
  onSkipCinema,
}: HorrorHudProps) {
  const mapCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const stickRef = useRef<HTMLDivElement | null>(null);
  const knobRef = useRef<HTMLDivElement | null>(null);
  const lookZoneRef = useRef<HTMLDivElement | null>(null);
  const chatInputRef = useRef<HTMLInputElement | null>(null);
  const chatListRef = useRef<HTMLDivElement | null>(null);
  const [chatDraft, setChatDraft] = useState('');
  const [touchSprint, setTouchSprint] = useState(false);

  const showPlayHud = hud.state === 'play';

  useEffect(() => {
    if (!showPlayHud || hud.crouch) {
      setTouchSprint(false);
      onTouchRun(false);
    }
  }, [showPlayHud, hud.crouch, onTouchRun]);

  useEffect(() => {
    if (chatOpen) {
      const id = window.setTimeout(() => chatInputRef.current?.focus(), 20);
      return () => window.clearTimeout(id);
    }
    return undefined;
  }, [chatOpen]);

  useEffect(() => {
    if (chatListRef.current) {
      chatListRef.current.scrollTop = chatListRef.current.scrollHeight;
    }
  }, [chatMessages.length, chatOpen]);

  // Draw hand-drawn parchment map when unlocked & open
  useEffect(() => {
    if (!hud.hasMap || !hud.mapOpen || !mapCanvasRef.current) return;
    const c = mapCanvasRef.current;
    const g = c.getContext('2d');
    if (!g) return;
    const Z = 5;
    const preset = getHousePreset(hud.houseTheme);
    const list = hud.floor ? preset.rooms1 : preset.rooms0;
    const st = preset.stairBounds;

    g.clearRect(0, 0, 300, 290);
    // Warm aged parchment background
    const paperGrad = g.createRadialGradient(150, 145, 35, 150, 145, 200);
    paperGrad.addColorStop(0, '#e8dab8');
    paperGrad.addColorStop(1, '#ccb78c');
    g.fillStyle = paperGrad;
    g.fillRect(0, 0, 300, 290);

    // Subtle hand-sketched paper creases
    g.strokeStyle = 'rgba(92, 62, 34, 0.14)';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(150, 0);
    g.lineTo(148, 290);
    g.moveTo(0, 145);
    g.lineTo(300, 147);
    g.stroke();

    // Hand-inked room outlines & labels
    list.forEach((r) => {
      const rx = r.x1 * Z + 0.5;
      const rz = r.z1 * Z + 0.5;
      const rw = (r.x2 - r.x1) * Z;
      const rh = (r.z2 - r.z1) * Z;

      g.fillStyle = 'rgba(130, 96, 54, 0.08)';
      g.fillRect(rx, rz, rw, rh);

      g.strokeStyle = 'rgba(42, 26, 15, 0.85)';
      g.lineWidth = 1.4;
      g.strokeRect(rx, rz, rw, rh);

      // Slight sketchy double corner tick
      g.strokeStyle = 'rgba(42, 26, 15, 0.35)';
      g.lineWidth = 0.8;
      g.strokeRect(rx + 2, rz + 2, rw - 4, rh - 4);

      g.fillStyle = '#2a1a0f';
      g.font = 'bold 9px Tajawal, sans-serif';
      g.textAlign = 'center';
      g.fillText(r.name, r.cx * Z, r.cz * Z + 3);
    });

    // Main hallway / gallery
    g.fillStyle = 'rgba(105, 76, 42, 0.12)';
    g.fillRect(0.5, 16 * Z + 0.5, 60 * Z, 8 * Z);
    g.strokeStyle = 'rgba(42, 26, 15, 0.85)';
    g.lineWidth = 1.4;
    g.strokeRect(0.5, 16 * Z + 0.5, 60 * Z, 8 * Z);
    g.fillStyle = '#3b2415';
    g.font = 'bold 9px Tajawal, sans-serif';
    g.textAlign = 'center';
    g.fillText(hud.floor ? 'الصالة العليا' : 'الممر الطويل', 38 * Z, 20.5 * Z);

    // Stairs (hand-hatched steps)
    const sx = st.x1 * Z;
    const sz = st.z1 * Z;
    const sw = (st.x2 - st.x1) * Z;
    const sh = (st.z2 - st.z1) * Z;
    g.fillStyle = 'rgba(168, 118, 42, 0.35)';
    g.fillRect(sx, sz, sw, sh);
    g.strokeStyle = '#4a2e14';
    g.lineWidth = 1;
    g.strokeRect(sx, sz, sw, sh);
    for (let yStep = sz + 4; yStep < sz + sh; yStep += 5) {
      g.beginPath();
      g.moveTo(sx, yStep);
      g.lineTo(sx + sw, yStep);
      g.stroke();
    }
    g.fillStyle = '#5e2310';
    g.font = 'bold 8.5px Tajawal, sans-serif';
    g.fillText('الدرج', ((st.x1 + st.x2) / 2) * Z, st.z1 * Z - 3);

    // Exit door mark in red ink on ground floor
    if (!hud.floor) {
      g.fillStyle = '#9e1914';
      g.fillRect(58.8 * Z, (32 - 1.5) * Z, 5, 3 * Z);
      g.strokeStyle = '#9e1914';
      g.lineWidth = 1.5;
      g.beginPath();
      g.arc(58 * Z, 32 * Z, 9, 0, Math.PI * 2);
      g.stroke();
      g.font = 'bold 8.5px Tajawal, sans-serif';
      g.fillText('البوابة', 54.5 * Z, 29 * Z);
    }

    // Ink floor caption
    g.fillStyle = '#2a1a0f';
    g.font = 'bold 10px Tajawal, sans-serif';
    g.textAlign = 'start';
    g.fillText(hud.floor ? 'الطابق الثاني' : 'الطابق الأرضي', 6, 12);

    // Hand-drawn crimson player arrow
    g.save();
    g.translate(hud.playerX * Z, hud.playerZ * Z);
    g.rotate(-hud.playerYaw + Math.PI);
    g.fillStyle = '#b31b15';
    g.strokeStyle = '#2a1a0f';
    g.lineWidth = 1;
    g.beginPath();
    g.moveTo(0, -7.5);
    g.lineTo(5, 5.5);
    g.lineTo(-5, 5.5);
    g.closePath();
    g.fill();
    g.stroke();
    g.restore();

    // Draw live multiplayer teammates & fallen corpses on same floor
    hud.mpPeers.forEach((p) => {
      if (p.escaped || p.fl !== hud.floor) return;
      const col = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
      if (!p.alive) {
        g.strokeStyle = '#a61712';
        g.lineWidth = 2.2;
        g.beginPath();
        g.moveTo(p.x * Z - 5, p.z * Z - 5);
        g.lineTo(p.x * Z + 5, p.z * Z + 5);
        g.moveTo(p.x * Z + 5, p.z * Z - 5);
        g.lineTo(p.x * Z - 5, p.z * Z + 5);
        g.stroke();

        g.fillStyle = '#7a120e';
        g.font = 'bold 9px Tajawal, sans-serif';
        g.textAlign = 'center';
        g.fillText(`${p.name} (جثة)`, p.x * Z, p.z * Z - 8);
        return;
      }

      g.save();
      g.translate(p.x * Z, p.z * Z);
      g.rotate(-p.yaw + Math.PI);
      g.fillStyle = col;
      g.strokeStyle = '#2a1a0f';
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(0, -6.5);
      g.lineTo(4.5, 4.5);
      g.lineTo(-4.5, 4.5);
      g.closePath();
      g.fill();
      g.stroke();
      g.restore();

      g.fillStyle = '#2a1a0f';
      g.font = 'bold 9px Tajawal, sans-serif';
      g.textAlign = 'center';
      g.fillText(p.name, p.x * Z, p.z * Z - 9);
    });
  }, [hud.hasMap, hud.mapOpen, hud.houseTheme, hud.floor, hud.playerX, hud.playerZ, hud.playerYaw, hud.mpPeers]);

  // Bind virtual joystick & touch look reliably whenever Play HUD mounts
  useEffect(() => {
    if (!showPlayHud || !isTouch) {
      onTouchMove(0, 0);
      return;
    }
    const stick = stickRef.current;
    const knob = knobRef.current;
    const lookZone = lookZoneRef.current;
    if (!stick || !knob || !lookZone) return;

    let sid: number | null = null;
    let cx = 0;
    let cy = 0;
    let lid: number | null = null;
    let lx = 0;
    let ly = 0;

    const mv = (clientX: number, clientY: number) => {
      let dx = clientX - cx;
      let dy = clientY - cy;
      const l = Math.hypot(dx, dy);
      const m = 42;
      if (l > m) {
        dx *= m / l;
        dy *= m / l;
      }
      knob.style.transform = `translate(${dx}px,${dy}px)`;
      onTouchMove(dx / m, -dy / m);
    };

    const resetStick = () => {
      sid = null;
      onTouchMove(0, 0);
      knob.style.transform = 'none';
    };

    const onStickStart = (e: TouchEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (sid !== null) return;
      const t = e.changedTouches[0];
      sid = t.identifier;
      const r = stick.getBoundingClientRect();
      cx = r.left + r.width / 2;
      cy = r.top + r.height / 2;
      mv(t.clientX, t.clientY);
    };

    const onLookStart = (e: TouchEvent) => {
      e.preventDefault();
      if (lid !== null) return;
      const t = e.changedTouches[0];
      lid = t.identifier;
      lx = t.clientX;
      ly = t.clientY;
    };

    const onWindowTouchMove = (e: TouchEvent) => {
      let handled = false;
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (sid !== null && t.identifier === sid) {
          mv(t.clientX, t.clientY);
          handled = true;
        } else if (lid !== null && t.identifier === lid) {
          onTouchLook(t.clientX - lx, t.clientY - ly);
          lx = t.clientX;
          ly = t.clientY;
          handled = true;
        }
      }
      if (handled) e.preventDefault();
    };

    const onWindowTouchEnd = (e: TouchEvent) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        const t = e.changedTouches[i];
        if (sid !== null && t.identifier === sid) {
          resetStick();
        }
        if (lid !== null && t.identifier === lid) {
          lid = null;
        }
      }
    };

    // Mouse-drag fallback if user forces Touch Mode on desktop
    let mouseStickDown = false;
    const onStickMouseDown = (e: MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      mouseStickDown = true;
      const r = stick.getBoundingClientRect();
      cx = r.left + r.width / 2;
      cy = r.top + r.height / 2;
      mv(e.clientX, e.clientY);
    };
    const onWindowMouseMove = (e: MouseEvent) => {
      if (!mouseStickDown) return;
      mv(e.clientX, e.clientY);
    };
    const onWindowMouseUp = () => {
      if (!mouseStickDown) return;
      mouseStickDown = false;
      resetStick();
    };

    stick.addEventListener('touchstart', onStickStart, { passive: false });
    stick.addEventListener('mousedown', onStickMouseDown);
    lookZone.addEventListener('touchstart', onLookStart, { passive: false });
    window.addEventListener('touchmove', onWindowTouchMove, { passive: false });
    window.addEventListener('touchend', onWindowTouchEnd);
    window.addEventListener('touchcancel', onWindowTouchEnd);
    window.addEventListener('mousemove', onWindowMouseMove);
    window.addEventListener('mouseup', onWindowMouseUp);

    return () => {
      resetStick();
      stick.removeEventListener('touchstart', onStickStart);
      stick.removeEventListener('mousedown', onStickMouseDown);
      lookZone.removeEventListener('touchstart', onLookStart);
      window.removeEventListener('touchmove', onWindowTouchMove);
      window.removeEventListener('touchend', onWindowTouchEnd);
      window.removeEventListener('touchcancel', onWindowTouchEnd);
      window.removeEventListener('mousemove', onWindowMouseMove);
      window.removeEventListener('mouseup', onWindowMouseUp);
    };
  }, [showPlayHud, isTouch, onTouchLook, onTouchMove]);

  const fatigueLevel = hud.exhausted ? 1 : Math.max(0, (0.44 - hud.stamina) / 0.44);
  const panicLevel =
    hud.stalkerState === 'chase'
      ? Math.max(0.65, hud.threat)
      : Math.max(0, (hud.threat - 0.5) / 0.5);
  const sweatLevel =
    hud.state === 'play' || hud.state === 'pad'
      ? Math.max(fatigueLevel, panicLevel)
      : 0;

  return (
    <>
      {/* Visual Atmosphere Layers */}
      <div
        className="fixed inset-0 pointer-events-none z-5"
        style={{
          background:
            'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.72) 100%)',
        }}
      />
      <HeartbeatVfxOverlay
        threat={hud.threat}
        dangerOpacity={hud.dangerOpacity}
        active={hud.state === 'play' || hud.state === 'pad'}
        pulseRef={heartbeatPulseRef}
      />
      {sweatLevel > 0.1 && (
        <div
          className="fixed inset-0 pointer-events-none z-7 overflow-hidden"
          style={{ opacity: Math.min(0.85, 0.25 + sweatLevel * 0.6) }}
        >
          {SWEAT_DROPS.map((d, idx) => {
            if (sweatLevel < d.threshold) return null;
            const dur = Math.max(1.25, d.baseDur - sweatLevel * 1.15);
            return (
              <div
                key={idx}
                className="sweat-drop fixed top-0"
                style={{
                  [d.side]: d.offset,
                  width: `${d.w}px`,
                  height: `${d.h}px`,
                  animationDuration: `${dur.toFixed(2)}s`,
                  animationDelay: d.delay,
                }}
              />
            );
          })}
        </div>
      )}
      {hud.hidden && hud.hiddenKind !== 'bed' && (
        <div
          className="fixed inset-0 pointer-events-none z-7 border-[10px] sm:border-[18px] border-[#130c08]"
          style={{
            background:
              'repeating-linear-gradient(180deg, rgba(6,3,2,0.92) 0 18px, rgba(0,0,0,0.08) 18px 26px)',
            boxShadow: 'inset 0 0 160px 72px rgba(0,0,0,0.94)',
          }}
        />
      )}
      {hud.hidden && hud.hiddenKind === 'bed' && (
        <div
          className="fixed inset-0 pointer-events-none z-7"
          style={{
            background:
              'linear-gradient(180deg, rgba(4,2,2,0.88) 0%, rgba(0,0,0,0.05) 36%, rgba(0,0,0,0.05) 70%, rgba(4,2,2,0.9) 100%)',
            boxShadow: 'inset 0 0 120px 44px rgba(0,0,0,0.88)',
          }}
        />
      )}
      {hud.hitFlash > 0 && (
        <div
          className="fixed inset-0 pointer-events-none z-8 bg-[#7a0000]"
          style={{ opacity: hud.hitFlash }}
        />
      )}
      {hud.lidOpacity > 0 && (
        <div
          className="fixed inset-0 pointer-events-none z-9 bg-black"
          style={{ opacity: hud.lidOpacity }}
        />
      )}

      {/* Cinema Bars & Captions */}
      {hud.cinemaBars && (
        <>
          <div className="fixed inset-x-0 top-0 h-[11vh] bg-black z-15 pointer-events-none transition-all duration-700" />
          <div className="fixed inset-x-0 bottom-0 h-[11vh] bg-black z-15 pointer-events-none transition-all duration-700" />
          {hud.cinemaFlash > 0 && (
            <div
              className="fixed inset-0 bg-white z-16 pointer-events-none"
              style={{ opacity: hud.cinemaFlash }}
            />
          )}
          {hud.cinemaCaption && (
            <div
              className={`fixed inset-x-0 text-center font-display z-17 pointer-events-none px-4 ${
                hud.cinemaBig
                  ? 'top-[36%] text-[clamp(56px,13vw,130px)] text-[#d3261d] [text-shadow:0_0_40px_rgba(211,38,29,0.7)]'
                  : 'bottom-[15vh] text-[clamp(28px,6vw,58px)] text-[#ebe3d6] [text-shadow:0_4px_24px_#000]'
              }`}
            >
              {hud.cinemaCaption}
            </div>
          )}
          {hud.state === 'cinema' && (
            <button
              type="button"
              onClick={onSkipCinema}
              className="fixed right-4 bottom-4 z-20 px-4 py-1.5 rounded-md bg-[rgba(14,10,9,0.9)] border border-[rgba(235,227,214,0.2)] text-sm text-[#ebe3d6] cursor-pointer hover:bg-white/10"
            >
              تخطي ⏭
            </button>
          )}
        </>
      )}

      {/* Spectating Overlay (LAN / Multiplayer after falling — corpse waits to be revived) */}
      {hud.state === 'spec' && (
        <div className="fixed inset-x-0 top-2.5 z-20 flex flex-col items-center gap-1 px-3 pointer-events-none" dir="rtl">
          <div className="pointer-events-auto bg-[rgba(12,8,7,0.9)] border border-[#e2b34a]/45 rounded-md px-3 py-1.5 flex items-center gap-2.5 text-xs text-[#ebe3d6] flex-wrap justify-center">
            <span>
              تتابع:{' '}
              <strong className="text-[#e2b34a]">{hud.mpSpectatingName || 'اللاعب الأول'}</strong>
            </span>
            {hud.mpPeers.filter((p) => p.alive && !p.escaped).length > 1 && (
              <button
                type="button"
                onClick={onCycleSpectate}
                className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 border border-white/20 text-[11px] cursor-pointer"
              >
                تبديل (E)
              </button>
            )}
            <button
              type="button"
              onClick={onExitSpectate}
              className="px-2 py-0.5 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[11px] cursor-pointer"
            >
              القائمة
            </button>
          </div>
          <div className="bg-[rgba(40,10,8,0.88)] border border-[#b3201a]/50 rounded px-2.5 py-0.5 text-[10px] text-[#ffd2cc]">
            جثتك في مكانها — يمكن لزميلك الاقتراب وإنعاشك خلال ٥ ثوانٍ
          </div>
        </div>
      )}

      {/* Active Play HUD */}
      {showPlayHud && (
        <div className="fixed inset-0 pointer-events-none z-10 flex flex-col justify-between p-2 sm:p-3">
          {/* Top Row */}
          <div className="flex items-start justify-between gap-1.5">
            {/* Top-Right in RTL: Day/Room/Locks (+ Compact Status under it on Touch so bottom-right buttons stay completely unobstructed) */}
            <div className="flex flex-col items-start gap-1.5 max-w-[46vw] sm:max-w-[340px]">
              <div
                className={`w-full bg-[rgba(10,6,6,0.78)] rounded-md px-2 py-1 text-[10px] sm:text-xs space-y-0.5 border ${
                  hud.livesLeft <= 2
                    ? 'border-[#b3201a] shadow-[0_0_12px_rgba(179,32,26,0.35)]'
                    : 'border-[rgba(235,227,214,0.14)]'
                }`}
              >
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span
                    className={`font-display text-xs sm:text-sm leading-none ${
                      hud.livesLeft <= 2 ? 'text-[#ff4d43]' : 'text-[#e2b34a]'
                    }`}
                  >
                    يوم {toArabicDigits(Math.min(hud.maxDays, hud.maxDays - hud.livesLeft + 1))}/{toArabicDigits(hud.maxDays)}
                  </span>
                  <div
                    className="flex items-center gap-0.5"
                    aria-label={`الأيام المتبقية ${hud.livesLeft} من ${hud.maxDays}`}
                  >
                    {Array.from({ length: hud.maxDays }).map((_, idx) => {
                      const lostCount = Math.max(0, hud.maxDays - hud.livesLeft);
                      const isLost = idx < lostCount;
                      const isCurrent = idx === lostCount && hud.livesLeft > 0;
                      return (
                        <span
                          key={idx}
                          className={`w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-[2px] border ${
                            isLost
                              ? 'bg-[#2a0707] border-[#7a1410] opacity-55'
                              : isCurrent
                                ? hud.livesLeft === 1
                                  ? 'bg-[#ff4d43] border-[#ff8078]'
                                  : 'bg-[#e2b34a] border-[#ffe39b]'
                                : 'bg-white/20 border-white/30'
                          }`}
                        />
                      );
                    })}
                  </div>
                  <span className="text-[10px] text-[#c5b9aa] truncate max-w-[88px] sm:max-w-[140px]">
                    · {hud.roomName}
                  </span>
                </div>

                <div className="flex items-center gap-1 text-[9px] sm:text-[10px] text-[#a09384]">
                  <span className={hud.locks.plankBroken ? 'text-[#6fbf73]' : ''}>
                    {hud.locks.plankBroken ? '✓ لوح' : '— لوح'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className={hud.locks.wireCut ? 'text-[#6fbf73]' : ''}>
                    {hud.locks.wireCut ? '✓ سلك' : '— سلك'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className={hud.locks.panelOpened ? 'text-[#6fbf73]' : ''}>
                    {hud.locks.panelOpened ? '✓ غطاء' : '— غطاء'}
                  </span>
                </div>

                {hud.mpRoomCode && (
                  <div className="pt-0.5 border-t border-white/10 flex items-center gap-1.5 flex-wrap text-[9px] sm:text-[10px]">
                    <span className="text-[#e2b34a] font-mono-num font-bold">
                      {hud.mpRoomCode}
                    </span>
                    {hud.mpPeers.map((p) => {
                      const col = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
                      const st = !p.alive
                        ? 'سقط'
                        : p.escaped
                          ? 'هرب'
                          : p.hiddenIdx >= 0
                            ? 'مختبئ'
                            : p.fl
                              ? 'ط٢'
                              : 'ط١';
                      return (
                        <span
                          key={p.id}
                          className="inline-flex items-center gap-1 text-[#ebe3d6]"
                        >
                          <span
                            className="w-1.5 h-1.5 rounded-sm shrink-0"
                            style={{ backgroundColor: col }}
                          />
                          <span className="max-w-[50px] truncate">{p.name}</span>
                          <span className={!p.alive ? 'text-[#ff7364] font-bold' : 'text-[#a09384]'}>
                            ({st})
                          </span>
                        </span>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Compact Status & Stamina card on Touch (stacked neatly below Day card) */}
              {isTouch && (
                <div
                  className={`bg-[rgba(10,6,6,0.78)] border rounded-md px-2 py-1 space-y-0.5 min-w-[118px] max-w-full transition-colors ${
                    hud.hidden
                      ? 'border-[#45b877]/70 shadow-[0_0_12px_rgba(69,184,119,0.28)]'
                      : 'border-[rgba(235,227,214,0.14)]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1.5 text-[9px]">
                    <span
                      className={`font-bold ${
                        hud.hidden
                          ? 'text-[#7ef2ae]'
                          : hud.crouch
                            ? 'text-[#e2b34a]'
                            : 'text-[#cfc3b4]'
                      }`}
                    >
                      {hud.hidden ? 'مختبئ (hidden)' : hud.crouch ? 'منحنٍ' : 'ظاهر'}
                    </span>
                    <span className="font-bold text-[#e2b34a] truncate max-w-[78px]">
                      {hud.heldLabel}
                    </span>
                  </div>
                  {hud.hasGun && (
                    <div className="text-[9px] text-[#ebe3d6] font-mono-num">
                      رصاص: {toArabicDigits(hud.ammo)}
                    </div>
                  )}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[9px] text-[#a09384]">
                      {hud.crouch ? 'منحنٍ' : 'طاقة'}
                    </span>
                    <div className="flex-1 h-1.5 bg-white/12 rounded overflow-hidden">
                      <div
                        className={`h-full origin-right transition-transform duration-75 ${
                          hud.exhausted ? 'bg-[#c9502f]' : 'bg-[#ebe3d6]'
                        }`}
                        style={{ transform: `scaleX(${hud.stamina.toFixed(3)})` }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Center Alerts: Hidden Status / Exit Arrow / Stun Timer / Chase Warning */}
            <div className="hidden sm:flex flex-col items-center gap-1">
              {hud.hidden && (
                <div className="bg-[rgba(12,26,18,0.9)] border border-[#45b877]/65 rounded-md px-2.5 py-1 text-center shadow-[0_0_16px_rgba(32,120,72,0.35)]">
                  <div className="text-xs font-bold text-[#7ef2ae] flex items-center justify-center gap-1.5">
                    <span>
                      مختبئ ·{' '}
                      {hud.hiddenKind === 'bed'
                        ? 'تحت السرير'
                        : hud.hiddenKind === 'crate'
                          ? 'داخل الصندوق'
                          : 'داخل الخزانة'}
                    </span>
                    <span className="font-mono-num text-[9px] text-[#45b877]">(hidden)</span>
                  </div>
                </div>
              )}

              {hud.exitArrowAngle !== null && (
                <div className="bg-[rgba(12,8,7,0.82)] border border-[rgba(70,255,130,0.4)] rounded px-2 py-0.5 text-xs text-[#46ff82] flex items-center gap-1.5">
                  <span
                    className="inline-block font-bold text-sm leading-none"
                    style={{ transform: `rotate(${hud.exitArrowAngle.toFixed(3)}rad)` }}
                  >
                    ↑
                  </span>
                  <span>{hud.exitArrowText}</span>
                </div>
              )}

              {hud.stalkerStunLeft > 0 && (
                <div className="bg-[rgba(12,8,7,0.86)] border border-[#e2b34a]/45 rounded px-2 py-0.5 text-xs text-[#e2b34a] font-bold font-mono-num">
                  مُغمى: {toArabicDigits(hud.stalkerStunLeft)} ث
                </div>
              )}

              {hud.stalkerState === 'chase' && hud.stalkerStunLeft <= 0 && (
                <div className="font-display text-xl text-[#ff5a4d] [text-shadow:0_2px_8px_#000]">
                  يطاردك!
                </div>
              )}
            </div>

            {/* Top-Left in RTL: Keys, Diary Notes, Fullscreen & Pause (+ Touch-only Map & MP Voice/Chat neatly stacked below without overlap) */}
            <div
              className="flex flex-col items-end gap-1.5 shrink-0"
              onTouchStart={(e) => e.stopPropagation()}
            >
              <div className="flex items-center gap-1 pointer-events-auto flex-nowrap">
                <div className="bg-[rgba(10,6,6,0.78)] border border-[rgba(235,227,214,0.14)] rounded-md px-1.5 sm:px-2 py-1 text-[10px] sm:text-xs flex items-center gap-1 whitespace-nowrap">
                  <div className="flex items-center gap-0.5 sm:gap-1">
                    <span className="text-[#e2b34a] font-bold">مفاتيح</span>
                    <span className="font-mono-num font-bold text-[#ebe3d6]">
                      {toArabicDigits(hud.keys)}/{toArabicDigits(hud.needKeys)}
                    </span>
                  </div>
                  <span aria-hidden="true" className="text-white/25">
                    ·
                  </span>
                  <button
                    type="button"
                    onClick={onOpenJournal}
                    className={`flex items-center gap-0.5 sm:gap-1 cursor-pointer transition-colors ${
                      hud.notesRead.length > 0 ? 'text-[#e6d7b8] hover:text-[#e2b34a]' : 'text-[#a09384]'
                    }`}
                    title="مذكرات (N)"
                  >
                    <span className="font-bold">مذكرات</span>
                    <span className="font-mono-num font-bold">
                      {toArabicDigits(hud.notesRead.length)}/{toArabicDigits(hud.totalNotes)}
                    </span>
                  </button>
                  {hud.codeKnown && !hud.safeOpen && (
                    <>
                      <span aria-hidden="true" className="text-white/25">
                        ·
                      </span>
                      <span className="text-[#e2b34a] font-mono-num font-bold">
                        {toArabicDigits(hud.safeCode)}
                      </span>
                    </>
                  )}
                </div>

                {!isTouch && hud.hasMap && (
                  <button
                    type="button"
                    onClick={onToggleMap}
                    title="الخريطة المرسومة يدوياً (M)"
                    className={`min-h-[34px] px-2 py-1 rounded-md border text-xs font-bold cursor-pointer transition-colors ${
                      hud.mapOpen
                        ? 'bg-[#3b2814] border-[#e2b34a] text-[#e2b34a]'
                        : 'bg-[rgba(28,19,11,0.88)] border-[#d2aa5a]/55 text-[#f2e2c4] hover:border-[#e2b34a]'
                    }`}
                  >
                    خريطة
                  </button>
                )}

                <button
                  type="button"
                  onClick={onToggleFullscreen}
                  aria-label={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
                  title={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-md bg-[rgba(10,6,6,0.82)] border border-white/18 text-xs text-[#ebe3d6] hover:bg-white/10 cursor-pointer flex items-center justify-center shrink-0"
                >
                  ⛶
                </button>
                <button
                  type="button"
                  onClick={onPause}
                  aria-label="إيقاف مؤقت"
                  title="إيقاف مؤقت (P)"
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-md bg-[rgba(10,6,6,0.82)] border border-white/18 text-xs text-[#ebe3d6] hover:bg-white/10 cursor-pointer flex items-center justify-center shrink-0"
                >
                  ⏸
                </button>
              </div>

              {/* Touch secondary top-left row: Hand-drawn Map + MP Voice & Chat buttons (never overlapping top bar!) */}
              {isTouch && (hud.hasMap || hud.mpRoomCode) && (
                <div className="flex flex-col items-end gap-1.5 pointer-events-none">
                  <div className="pointer-events-auto flex items-center gap-1.5 flex-wrap justify-end">
                    {hud.hasMap && (
                      <button
                        type="button"
                        onClick={onToggleMap}
                        className={`min-h-[30px] px-2.5 py-1 rounded-md border text-[10px] font-bold cursor-pointer transition-colors shadow-[0_2px_10px_rgba(0,0,0,0.5)] ${
                          hud.mapOpen
                            ? 'bg-[#3b2814] border-[#e2b34a] text-[#e2b34a]'
                            : 'bg-[rgba(28,19,11,0.88)] border-[#d2aa5a]/55 text-[#f2e2c4]'
                        }`}
                      >
                        خريطة
                      </button>
                    )}

                    {hud.mpRoomCode && (
                      <>
                        <button
                          type="button"
                          onClick={() => onToggleVoice()}
                          className={`min-h-[30px] px-2 py-1 rounded-md border text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-[0_2px_10px_rgba(0,0,0,0.5)] ${
                            !voiceState.enabled
                              ? 'bg-[rgba(12,8,7,0.84)] border-white/20 text-[#ebe3d6]'
                              : voiceState.muted
                                ? 'bg-[rgba(48,16,12,0.9)] border-[#d35b4c] text-[#ffd4cc]'
                                : voiceState.speaking
                                  ? 'bg-[rgba(16,46,28,0.92)] border-[#5ee396] text-[#9effc3]'
                                  : 'bg-[rgba(14,34,22,0.9)] border-[#45b877] text-[#8ef5b8]'
                          }`}
                        >
                          <span>{voiceState.enabled && voiceState.muted ? '🔇' : '🎙'}</span>
                          <span>
                            {!voiceState.enabled
                              ? 'صوت'
                              : voiceState.muted
                                ? 'مكتوم'
                                : 'صوت شغّال'}
                          </span>
                          {voiceState.enabled &&
                            !voiceState.muted &&
                            (voiceState.activePeers.length > 0 ||
                              hud.mpPeers.some((p) => p.voiceActive)) && (
                              <span className="w-1.5 h-1.5 rounded-full bg-[#6ef7a5] animate-pulse" />
                            )}
                        </button>

                        <button
                          type="button"
                          onClick={() => onToggleChat(!chatOpen)}
                          className={`min-h-[30px] px-2 py-1 rounded-md border text-[10px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-[0_2px_10px_rgba(0,0,0,0.5)] ${
                            chatOpen
                              ? 'bg-[#3b2814] border-[#e2b34a] text-[#ffe6aa]'
                              : 'bg-[rgba(12,8,7,0.84)] border-white/20 text-[#e2b34a]'
                          }`}
                        >
                          <span>💬</span>
                          <span>دردشة</span>
                          {unreadChat > 0 && !chatOpen && (
                            <span className="px-1 rounded bg-[#b3201a] text-white font-mono-num text-[9px]">
                              {toArabicDigits(unreadChat)}
                            </span>
                          )}
                        </button>
                      </>
                    )}
                  </div>

                  {hud.mpRoomCode && voiceState.error && (
                    <div className="pointer-events-auto bg-[rgba(48,10,8,0.92)] border border-[#b3201a] rounded px-2 py-0.5 text-[9.5px] text-[#ffd4cc] max-w-[210px]">
                      {voiceState.error}
                    </div>
                  )}

                  {hud.mpRoomCode && (chatOpen || chatMessages.length > 0) && (
                    <div className="pointer-events-auto w-[min(210px,48vw)] bg-[rgba(10,7,6,0.84)] border border-[rgba(235,227,214,0.16)] rounded-md p-1.5 space-y-1 shadow-[0_4px_16px_rgba(0,0,0,0.6)]">
                      <div
                        ref={chatListRef}
                        className={`overflow-y-auto space-y-0.5 text-[10px] pe-1 ${
                          chatOpen ? 'max-h-24' : 'max-h-11'
                        }`}
                      >
                        {(chatOpen ? chatMessages : chatMessages.slice(-2)).map((m) => {
                          const col = PEER_COLORS[Math.abs(m.colorIndex) % PEER_COLORS.length];
                          const timeLabel = formatChatTime(m.ts);
                          if (m.system) {
                            return (
                              <div
                                key={m.id}
                                className="flex items-start justify-between gap-1.5 px-1.5 py-0.5 rounded-e bg-[#2a1d10]/80 border-s-2 border-[#e2b34a] text-[#ffd685] leading-snug"
                              >
                                <span className="text-[9px] font-medium break-words">
                                  <span className="text-[#e2b34a] font-bold me-1">النظام:</span>
                                  {m.text}
                                </span>
                                {timeLabel && (
                                  <span dir="ltr" className="font-mono-num text-[8px] text-[#c7a96b]/85 shrink-0">
                                    {timeLabel}
                                  </span>
                                )}
                              </div>
                            );
                          }
                          return (
                            <div key={m.id} className="flex items-baseline justify-between gap-1.5 leading-snug">
                              <div className="min-w-0 break-words">
                                <span className="font-bold me-1" style={{ color: col }}>
                                  {m.senderName}:
                                </span>
                                <span className="text-[#ebe3d6]">{m.text}</span>
                              </div>
                              {timeLabel && (
                                <span dir="ltr" className="font-mono-num text-[8px] text-[#8d8174] shrink-0">
                                  {timeLabel}
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>

                      {chatOpen && (
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            const clean = chatDraft.trim();
                            if (clean) {
                              onSendChat(clean);
                              setChatDraft('');
                            }
                            onToggleChat(false);
                          }}
                          className="flex gap-1 pt-0.5"
                        >
                          <input
                            ref={chatInputRef}
                            type="text"
                            maxLength={160}
                            value={chatDraft}
                            onChange={(e) => setChatDraft(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Escape') {
                                e.preventDefault();
                                onToggleChat(false);
                              }
                            }}
                            placeholder="رسالة..."
                            className="flex-1 min-w-0 px-1.5 py-0.5 rounded bg-black/65 border border-[#e2b34a]/40 text-[10px] text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                          />
                          <button
                            type="submit"
                            className="px-2 py-0.5 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[10px] font-bold text-[#ebe3d6] cursor-pointer"
                          >
                            إرسال
                          </button>
                        </form>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Mobile compact status alert strip (upper-center, never overlapping corner bars) */}
          {isTouch &&
            (hud.hidden ||
              hud.exitArrowAngle !== null ||
              hud.stalkerStunLeft > 0 ||
              (hud.stalkerState === 'chase' && hud.stalkerStunLeft <= 0)) && (
              <div className="fixed left-1/2 top-11 -translate-x-1/2 z-11 flex flex-col items-center gap-0.5 pointer-events-none">
                {hud.hidden && (
                  <div className="bg-[rgba(12,26,18,0.9)] border border-[#45b877]/65 rounded px-2 py-0.5 text-[10px] font-bold text-[#7ef2ae] whitespace-nowrap">
                    مختبئ ·{' '}
                    {hud.hiddenKind === 'bed'
                      ? 'تحت السرير'
                      : hud.hiddenKind === 'crate'
                        ? 'داخل الصندوق'
                        : 'داخل الخزانة'}
                  </div>
                )}
                {hud.exitArrowAngle !== null && (
                  <div className="bg-[rgba(12,8,7,0.84)] border border-[rgba(70,255,130,0.4)] rounded px-2 py-0.5 text-[10px] text-[#46ff82] flex items-center gap-1 whitespace-nowrap">
                    <span
                      className="inline-block font-bold leading-none"
                      style={{ transform: `rotate(${hud.exitArrowAngle.toFixed(3)}rad)` }}
                    >
                      ↑
                    </span>
                    <span>{hud.exitArrowText}</span>
                  </div>
                )}
                {hud.stalkerStunLeft > 0 && (
                  <div className="bg-[rgba(12,8,7,0.88)] border border-[#e2b34a]/45 rounded px-2 py-0.5 text-[10px] text-[#e2b34a] font-bold font-mono-num">
                    مُغمى: {toArabicDigits(hud.stalkerStunLeft)} ث
                  </div>
                )}
                {hud.stalkerState === 'chase' && hud.stalkerStunLeft <= 0 && (
                  <div className="font-display text-base text-[#ff5a4d] [text-shadow:0_2px_8px_#000]">
                    يطاردك!
                  </div>
                )}
              </div>
            )}

          {/* Desktop Bottom Row: Status, Held Item + Stamina */}
          {!isTouch && (
            <div className="flex items-end justify-between gap-2">
              <div
                className={`bg-[rgba(10,6,6,0.78)] border rounded-md px-2 py-1 space-y-0.5 min-w-[152px] transition-colors ${
                  hud.hidden
                    ? 'border-[#45b877]/70 shadow-[0_0_12px_rgba(69,184,119,0.28)]'
                    : 'border-[rgba(235,227,214,0.14)]'
                }`}
              >
                <div className="flex items-center justify-between gap-1.5 text-[10px] border-b border-white/10 pb-0.5">
                  <span className="text-[#a09384]">الحالة:</span>
                  <span
                    className={`font-bold ${
                      hud.hidden
                        ? 'text-[#7ef2ae]'
                        : hud.crouch
                          ? 'text-[#e2b34a]'
                          : 'text-[#cfc3b4]'
                    }`}
                  >
                    {hud.hidden ? 'مختبئ (hidden)' : hud.crouch ? 'منحنٍ' : 'ظاهر'}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-1.5 text-xs">
                  <span className="text-[#a09384]">بيدك:</span>
                  <span className="font-bold text-[#e2b34a] truncate max-w-[96px]">
                    {hud.heldLabel}
                  </span>
                </div>
                {hud.hasGun && (
                  <div className="text-[10px] text-[#ebe3d6] font-mono-num">
                    رصاص: {toArabicDigits(hud.ammo)}
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-[#a09384]">
                    {hud.crouch ? 'منحنٍ' : 'طاقة'}
                  </span>
                  <div className="flex-1 h-1.5 bg-white/12 rounded overflow-hidden">
                    <div
                      className={`h-full origin-right transition-transform duration-75 ${
                        hud.exhausted ? 'bg-[#c9502f]' : 'bg-[#ebe3d6]'
                      }`}
                      style={{ transform: `scaleX(${hud.stamina.toFixed(3)})` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Center Crosshair, Prompt, Bear Trap Struggle, Revive Channel, and Toast */}
      {showPlayHud && (
        <>
          <div className="fixed left-1/2 top-1/2 w-1.5 h-1.5 -ml-[3px] -mt-[3px] rounded-full bg-[rgba(235,227,214,0.58)] pointer-events-none z-11" />

          {hud.trappedTimer > 0 && (
            <div className="fixed left-1/2 bottom-[108px] sm:bottom-[120px] -translate-x-1/2 z-12 pointer-events-none bg-[rgba(94,13,10,0.9)] border border-[#b3201a] rounded-md px-3 py-1.5 text-center space-y-1 min-w-[195px]">
              <div className="text-xs font-bold text-white">
                {isTouch
                  ? 'عالِق بالفخ! اضغط تفاعل باستمرار'
                  : 'عالِق بالفخ! اضغط E باستمرار'}
              </div>
              <div className="h-1.5 bg-black/50 rounded overflow-hidden">
                <div
                  className="h-full bg-[#e2b34a]"
                  style={{ width: `${Math.min(100, Math.max(10, (1 - hud.trappedTimer / 3.2) * 100))}%` }}
                />
              </div>
            </div>
          )}

          {hud.revivingTargetName && (
            <div className="fixed left-1/2 bottom-[108px] sm:bottom-[120px] -translate-x-1/2 z-12 pointer-events-none bg-[rgba(26,11,7,0.92)] border border-[#e2b34a]/70 rounded-md px-3 py-1.5 text-center space-y-1 min-w-[210px] shadow-[0_0_20px_rgba(0,0,0,0.65)]">
              <div className="text-xs font-bold text-[#ffe6aa] flex items-center justify-between gap-2">
                <span>إنعاش {hud.revivingTargetName}...</span>
                <span className="font-mono-num text-[#e2b34a]">
                  {toArabicDigits(Math.ceil(hud.revivingTimeLeft))} ث
                </span>
              </div>
              <div className="h-2 bg-black/60 rounded overflow-hidden border border-white/15">
                <div
                  className="h-full bg-gradient-to-l from-[#e2b34a] to-[#6fbf73] transition-[width] duration-75"
                  style={{ width: `${Math.min(100, Math.max(4, hud.revivingProgress * 100))}%` }}
                />
              </div>
              <div className="text-[10px] font-bold text-[#ff7364]">
                الصوت يجذب الوحش إليكما!
              </div>
            </div>
          )}

          {hud.prompt && (
            <div className="fixed left-1/2 bottom-[64px] sm:bottom-[74px] -translate-x-1/2 z-12 pointer-events-none bg-[rgba(12,8,7,0.88)] border border-[rgba(235,227,214,0.18)] rounded px-2.5 py-1 text-[11px] sm:text-xs text-[#ebe3d6] whitespace-nowrap max-w-[90vw] truncate">
              {!isTouch && (
                <b className="inline-block min-w-[20px] px-1 me-1.5 border border-[#ebe3d6] rounded text-center text-[10px]">
                  E
                </b>
              )}
              <span>{hud.prompt}</span>
            </div>
          )}

          {hud.toast && (
            <div className="fixed left-1/2 top-[22%] sm:top-[16%] -translate-x-1/2 z-12 pointer-events-none font-display text-sm sm:text-lg text-center text-[#ebe3d6] [text-shadow:0_2px_10px_#000] max-w-[84vw]">
              {hud.toast}
            </div>
          )}
        </>
      )}

      {/* Bottom-Center Drop Button (Desktop & Touch — cleanly centered between left & right controls) */}
      {showPlayHud && hud.heldItem && !hud.hidden && (
        <div
          className="fixed left-1/2 bottom-3 -translate-x-1/2 z-14 pointer-events-auto"
          dir="rtl"
          onTouchStart={(e) => e.stopPropagation()}
        >
          <button
            type="button"
            onTouchStart={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onDrop();
            }}
            onClick={(e) => {
              e.stopPropagation();
              onDrop();
            }}
            className="min-h-[36px] max-w-[34vw] sm:max-w-none px-3 py-1.5 rounded-full bg-[rgba(14,10,8,0.88)] hover:bg-[rgba(34,24,14,0.94)] border border-[#e2b34a]/80 shadow-[0_4px_16px_rgba(0,0,0,0.65)] text-[10.5px] sm:text-xs font-bold text-[#ffe6aa] flex items-center gap-1.5 cursor-pointer active:scale-95 transition-transform"
          >
            {!isTouch && (
              <kbd className="px-1 border border-[#e2b34a]/50 rounded text-[10px] text-[#ebe3d6] shrink-0">
                G
              </kbd>
            )}
            <span className="truncate">رمي · {hud.heldLabel}</span>
          </button>
        </div>
      )}

      {/* In-Game Multiplayer Corner Controls for Desktop OR Spectate Mode */}
      {hud.mpRoomCode &&
        ((hud.state === 'play' && !isTouch) || hud.state === 'spec') && (
          <div
            className="fixed z-22 bottom-3 left-3 flex flex-col-reverse items-start gap-1.5 pointer-events-none"
            dir="rtl"
            onTouchStart={(e) => e.stopPropagation()}
          >
            {/* Corner Buttons Row */}
            <div className="pointer-events-auto flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => onToggleVoice()}
                title={
                  !voiceState.enabled
                    ? 'تفعيل الدردشة الصوتية'
                    : voiceState.muted
                      ? 'إلغاء كتم المايك'
                      : 'كتم المايك'
                }
                className={`min-h-[32px] px-2.5 py-1 rounded-md border text-[10px] sm:text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-[0_3px_12px_rgba(0,0,0,0.55)] ${
                  !voiceState.enabled
                    ? 'bg-[rgba(12,8,7,0.84)] border-white/20 text-[#ebe3d6] hover:border-[#e2b34a]/60'
                    : voiceState.muted
                      ? 'bg-[rgba(48,16,12,0.9)] border-[#d35b4c] text-[#ffd4cc]'
                      : voiceState.speaking
                        ? 'bg-[rgba(16,46,28,0.92)] border-[#5ee396] text-[#9effc3] shadow-[0_0_12px_rgba(94,227,150,0.4)]'
                        : 'bg-[rgba(14,34,22,0.9)] border-[#45b877] text-[#8ef5b8]'
                }`}
              >
                <span>{voiceState.enabled && voiceState.muted ? '🔇' : '🎙'}</span>
                <span>
                  {!voiceState.enabled
                    ? 'صوت'
                    : voiceState.muted
                      ? 'مكتوم'
                      : 'صوت شغّال'}
                </span>
                {voiceState.enabled &&
                  !voiceState.muted &&
                  (voiceState.activePeers.length > 0 ||
                    hud.mpPeers.some((p) => p.voiceActive)) && (
                    <span className="w-1.5 h-1.5 rounded-full bg-[#6ef7a5] animate-pulse" />
                  )}
              </button>

              <button
                type="button"
                onClick={() => onToggleChat(!chatOpen)}
                title="فتح/إغلاق الدردشة (T)"
                className={`min-h-[32px] px-2.5 py-1 rounded-md border text-[10px] sm:text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-[0_3px_12px_rgba(0,0,0,0.55)] ${
                  chatOpen
                    ? 'bg-[#3b2814] border-[#e2b34a] text-[#ffe6aa]'
                    : 'bg-[rgba(12,8,7,0.84)] border-white/20 text-[#e2b34a] hover:border-[#e2b34a]/60'
                }`}
              >
                <span>💬</span>
                <span>دردشة</span>
                {!isTouch && !chatOpen && (
                  <kbd className="px-1 border border-white/20 rounded text-[9px] text-[#c5b9aa]">
                    T
                  </kbd>
                )}
                {unreadChat > 0 && !chatOpen && (
                  <span className="px-1 rounded bg-[#b3201a] text-white font-mono-num text-[9px]">
                    {toArabicDigits(unreadChat)}
                  </span>
                )}
              </button>
            </div>

            {voiceState.error && (
              <div className="pointer-events-auto bg-[rgba(48,10,8,0.92)] border border-[#b3201a] rounded px-2 py-0.5 text-[9.5px] text-[#ffd4cc] max-w-[230px]">
                {voiceState.error}
              </div>
            )}

            {(chatOpen || chatMessages.length > 0) && (
              <div className="pointer-events-auto w-[min(232px,62vw)] bg-[rgba(10,7,6,0.82)] border border-[rgba(235,227,214,0.16)] rounded-md p-1.5 space-y-1 shadow-[0_4px_16px_rgba(0,0,0,0.6)]">
                <div
                  ref={chatListRef}
                  className={`overflow-y-auto space-y-0.5 text-[10px] pe-1 ${
                    chatOpen ? 'max-h-28' : 'max-h-12'
                  }`}
                >
                  {(chatOpen ? chatMessages : chatMessages.slice(-2)).map((m) => {
                    const col = PEER_COLORS[Math.abs(m.colorIndex) % PEER_COLORS.length];
                    const timeLabel = formatChatTime(m.ts);
                    if (m.system) {
                      return (
                        <div
                          key={m.id}
                          className="flex items-start justify-between gap-1.5 px-1.5 py-0.5 rounded-e bg-[#2a1d10]/80 border-s-2 border-[#e2b34a] text-[#ffd685] leading-snug"
                        >
                          <span className="text-[9px] font-medium break-words">
                            <span className="text-[#e2b34a] font-bold me-1">النظام:</span>
                            {m.text}
                          </span>
                          {timeLabel && (
                            <span dir="ltr" className="font-mono-num text-[8px] text-[#c7a96b]/85 shrink-0">
                              {timeLabel}
                            </span>
                          )}
                        </div>
                      );
                    }
                    return (
                      <div key={m.id} className="flex items-baseline justify-between gap-1.5 leading-snug">
                        <div className="min-w-0 break-words">
                          <span className="font-bold me-1" style={{ color: col }}>
                            {m.senderName}:
                          </span>
                          <span className="text-[#ebe3d6]">{m.text}</span>
                        </div>
                        {timeLabel && (
                          <span dir="ltr" className="font-mono-num text-[8px] text-[#8d8174] shrink-0">
                            {timeLabel}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                {chatOpen && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const clean = chatDraft.trim();
                      if (clean) {
                        onSendChat(clean);
                        setChatDraft('');
                      }
                      onToggleChat(false);
                    }}
                    className="flex gap-1 pt-0.5"
                  >
                    <input
                      ref={chatInputRef}
                      type="text"
                      maxLength={160}
                      value={chatDraft}
                      onChange={(e) => setChatDraft(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Escape') {
                          e.preventDefault();
                          onToggleChat(false);
                        }
                      }}
                      placeholder="رسالة..."
                      className="flex-1 min-w-0 px-1.5 py-0.5 rounded bg-black/65 border border-[#e2b34a]/40 text-[10px] text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                    />
                    <button
                      type="submit"
                      className="px-2 py-0.5 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[10px] font-bold text-[#ebe3d6] cursor-pointer"
                    >
                      إرسال
                    </button>
                  </form>
                )}
              </div>
            )}
          </div>
        )}

      {/* Hand-Drawn House Map Overlay (centered high so corner HUD & touch buttons never overlap) */}
      {showPlayHud && hud.hasMap && hud.mapOpen && (
        <div
          className="fixed top-14 sm:top-16 left-1/2 -translate-x-1/2 z-24 bg-[#dfd0b0] border-2 border-[#593c22] rounded-lg p-1.5 shadow-[0_10px_28px_rgba(0,0,0,0.85)] pointer-events-auto"
          onTouchStart={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between gap-2 px-1 pb-1">
            <span className="text-[10px] sm:text-[11px] font-bold text-[#332012]">
              خريطة البيت المرسومة يدوياً
            </span>
            <button
              type="button"
              onClick={onToggleMap}
              aria-label="إغلاق الخريطة"
              className="px-1.5 py-0.5 rounded bg-[#593c22]/15 hover:bg-[#593c22]/25 text-[10px] font-bold text-[#332012] cursor-pointer"
            >
              ✕
            </button>
          </div>
          <canvas
            ref={mapCanvasRef}
            width={300}
            height={290}
            className="w-[min(238px,62vw)] h-auto block rounded border border-[#593c22]/40"
          />
          <small className="block text-[#4e341d] mt-1 px-0.5 text-[9.5px] font-medium">
            {isTouch ? 'اضغط «خريطة» للإغلاق · النقطة الحمراء موقعك' : 'اضغط M أو «خريطة» للإغلاق'}
          </small>
        </div>
      )}

      {/* Touch Controls for Mobile/Tablet (Compact, evenly spaced, zero overlaps) */}
      {showPlayHud && isTouch && (
        <div className="fixed inset-0 z-13 pointer-events-none">
          {/* Right-side Look Zone */}
          <div
            ref={lookZoneRef}
            className="absolute inset-y-0 left-[36%] right-0 pointer-events-auto touch-none"
          />

          {/* Compact Virtual Stick (Bottom Left) */}
          <div
            ref={stickRef}
            className="absolute left-3 bottom-3 w-[98px] h-[98px] sm:w-[108px] sm:h-[108px] rounded-full bg-white/10 border border-[rgba(235,227,214,0.28)] pointer-events-auto touch-none shadow-[0_0_18px_rgba(0,0,0,0.45)]"
          >
            <span className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] text-white/35 pointer-events-none">
              ▲
            </span>
            <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[9px] text-white/35 pointer-events-none">
              ▼
            </span>
            <div
              ref={knobRef}
              className="absolute left-1/2 top-1/2 w-[42px] h-[42px] -ml-[21px] -mt-[21px] rounded-full bg-[rgba(235,227,214,0.42)] border border-white/50 shadow-md pointer-events-none"
            />
          </div>

          {/* Compact Action Buttons (Bottom Right — tidy spacing, never collides with status or center Drop) */}
          <div
            className="absolute right-3 bottom-3 grid grid-cols-2 gap-2 pointer-events-auto"
            onTouchStart={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                const next = !touchSprint;
                setTouchSprint(next);
                onTouchRun(next);
              }}
              onClick={() => {
                const next = !touchSprint;
                setTouchSprint(next);
                onTouchRun(next);
              }}
              className={`w-[46px] h-[40px] rounded-full bg-[rgba(12,8,7,0.82)] border text-[10px] font-bold ${
                touchSprint ? 'border-[#e2b34a] text-[#e2b34a]' : 'border-white/22 text-[#ebe3d6]'
              }`}
            >
              جري
            </button>
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onToggleCrouch();
              }}
              className={`w-[46px] h-[40px] rounded-full bg-[rgba(12,8,7,0.82)] border text-[10px] font-bold ${
                hud.crouch ? 'border-[#e2b34a] text-[#e2b34a]' : 'border-white/22 text-[#ebe3d6]'
              }`}
            >
              انحناء
            </button>
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onToggleTorch();
              }}
              className={`h-[40px] rounded-full bg-[rgba(12,8,7,0.82)] border text-[10px] font-bold ${
                hud.heldItem === 'gun' ? 'w-[46px]' : 'col-span-2 w-full'
              } ${
                !hud.hasTorch
                  ? 'border-white/12 text-[#85796c]'
                  : hud.torch
                    ? 'border-[#e2b34a] text-[#e2b34a] shadow-[0_0_10px_rgba(226,179,74,0.3)]'
                    : 'border-white/22 text-[#ebe3d6]'
              }`}
            >
              {hud.hasTorch ? 'كشاف' : 'بلا كشاف'}
            </button>
            {hud.heldItem === 'gun' && (
              <button
                type="button"
                onTouchStart={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onFire();
                }}
                className="w-[46px] h-[40px] rounded-full bg-[#5e0d0a] border border-[#b3201a] text-[10px] font-bold text-[#ebe3d6]"
              >
                إطلاق
              </button>
            )}
            <button
              type="button"
              onTouchStart={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onInteract();
              }}
              className="col-span-2 w-14 h-14 justify-self-center rounded-full bg-[#5e0d0a] border-2 border-[#b3201a] text-xs font-bold text-[#ebe3d6] shadow-lg active:scale-95"
            >
              تفاعل
            </button>
          </div>
        </div>
      )}
    </>
  );
}
