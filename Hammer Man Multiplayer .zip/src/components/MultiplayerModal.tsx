import { useEffect, useRef, useState } from 'react';
import {
  getAndroidLanGames,
  getAndroidLanIps,
  hasAndroidLanBridge,
} from '../game/androidLan';
import { DIFFICULTIES, formatChatTime, toArabicDigits } from '../game/constants';
import {
  ChatMessage,
  DifficultyKey,
  HouseTheme,
  MultiplayerRoomSnapshot,
  PublicRoomSummary,
} from '../game/types';
import { VoiceChatState } from '../game/voiceChat';

interface LanInfoResponse {
  port: number;
  addresses: string[];
  urls: string[];
}

interface DiscoveredServer extends PublicRoomSummary {
  serverUrl?: string;
}

interface MultiplayerModalProps {
  room: MultiplayerRoomSnapshot | null;
  rooms: PublicRoomSummary[];
  selfId: string | null;
  errorMsg: string | null;
  difficulty: DifficultyKey;
  houseTheme: HouseTheme;
  chatMessages: ChatMessage[];
  voiceState: VoiceChatState;
  onToggleVoice: () => void;
  onStopVoice: () => void;
  onSendChat: (text: string) => void;
  onRefreshRooms: () => void;
  onCreateRoom: (name: string, diff: DifficultyKey, serverName?: string) => void;
  onJoinRoom: (code: string, name: string) => void;
  onSetServerUrl: (url: string | null) => void;
  onCreateLanInvite: (name: string, diff: DifficultyKey) => Promise<string>;
  onAcceptLanReply: (replyCode: string) => Promise<void>;
  onJoinLanInvite: (inviteCode: string, name: string) => Promise<string>;
  onChangeDiff: (diff: DifficultyKey) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
  onClose: () => void;
}

const PEER_COLORS = ['#38a3cc', '#e09132', '#45b877', '#d15a82'];
const DIFF_KEYS: DifficultyKey[] = ['practice', 'easy', 'med', 'hard', 'nightmare'];
const HOTSPOT_GATEWAY_URLS = [
  'http://192.168.43.1:3000',
  'http://192.168.49.1:3000',
  'http://192.168.137.1:3000',
  'http://172.20.10.1:3000',
];

function loadSavedName(): string {
  try {
    return localStorage.getItem('hh_name_v2') || '';
  } catch {
    return '';
  }
}

function loadSavedServerUrl(): string {
  try {
    return localStorage.getItem('hh_lan_url_v1') || '';
  } catch {
    return '';
  }
}

export function MultiplayerModal({
  room,
  rooms,
  selfId,
  errorMsg,
  difficulty,
  houseTheme,
  chatMessages,
  voiceState,
  onToggleVoice,
  onStopVoice,
  onSendChat,
  onRefreshRooms,
  onCreateRoom,
  onJoinRoom,
  onSetServerUrl,
  onCreateLanInvite,
  onAcceptLanReply,
  onJoinLanInvite,
  onChangeDiff,
  onStartGame,
  onLeaveRoom,
  onClose,
}: MultiplayerModalProps) {
  const isOfflineFile = typeof window !== 'undefined' && window.location.protocol === 'file:';
  const [name, setName] = useState<string>(loadSavedName);
  const [serverNameInput, setServerNameInput] = useState('');
  // CS-style two main choices: Host Server ("افتح سيرفر") vs Find Server ("أوجد سيرفر")
  const [lanTab, setLanTab] = useState<'create' | 'browse'>('create');

  // Discovered servers from current origin + probed hotspot gateways
  const [httpRooms, setHttpRooms] = useState<DiscoveredServer[]>([]);
  const [scanningLan, setScanningLan] = useState(false);
  const [showHotspotTools, setShowHotspotTools] = useState(false);
  const [hotspotRole, setHotspotRole] = useState<'host' | 'guest'>('host');
  const [serverIp, setServerIp] = useState<string>(loadSavedServerUrl);
  const [lanUrls, setLanUrls] = useState<string[]>([]);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Offline P2P WebRTC state (inside collapsible Hotspot tools when no server is running)
  const [hostInviteCode, setHostInviteCode] = useState('');
  const [hostReplyInput, setHostReplyInput] = useState('');
  const [guestInviteInput, setGuestInviteInput] = useState('');
  const [guestReplyCode, setGuestReplyCode] = useState('');
  const [lanBusy, setLanBusy] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [showExtraInvite, setShowExtraInvite] = useState(false);

  // Lobby Chat state
  const [chatText, setChatText] = useState('');
  const chatScrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages.length]);

  useEffect(() => {
    if (serverIp.trim()) {
      onSetServerUrl(serverIp.trim());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const probeAllServers = async (probeGateways = false) => {
    const found: DiscoveredServer[] = [];
    const seenCodes = new Set<string>();

    const tryEndpoint = async (baseUrl: string, serverUrl?: string) => {
      const ctrl = new AbortController();
      const tId = window.setTimeout(() => ctrl.abort(), 1400);
      try {
        const res = await fetch(`${baseUrl}/api/rooms`, { signal: ctrl.signal });
        if (!res.ok) return;
        const data = (await res.json()) as { rooms?: PublicRoomSummary[] };
        if (data && Array.isArray(data.rooms)) {
          for (const r of data.rooms) {
            if (!seenCodes.has(`${r.code}:${serverUrl || ''}`)) {
              seenCodes.add(`${r.code}:${serverUrl || ''}`);
              found.push({ ...r, serverUrl });
            }
          }
        }
      } catch {
        // Ignore unreachable gateway
      } finally {
        window.clearTimeout(tId);
      }
    };

    const tasks: Promise<void>[] = [];
    if (!isOfflineFile) {
      tasks.push(tryEndpoint(''));
    }
    if (hasAndroidLanBridge()) {
      for (const ag of getAndroidLanGames()) {
        if (!seenCodes.has(ag.code)) {
          seenCodes.add(ag.code);
          found.push(ag);
        }
      }
    }
    const cleanSavedIp = serverIp.trim();
    if (cleanSavedIp) {
      const normalized = /^https?:\/\//i.test(cleanSavedIp)
        ? cleanSavedIp.replace(/\/+$/, '')
        : `http://${cleanSavedIp.includes(':') ? cleanSavedIp : `${cleanSavedIp}:3000`}`;
      tasks.push(tryEndpoint(normalized, normalized));
    }
    if (probeGateways || isOfflineFile) {
      for (const gw of HOTSPOT_GATEWAY_URLS) {
        tasks.push(tryEndpoint(gw, gw));
      }
    }

    await Promise.all(tasks);
    setHttpRooms(found);
  };

  useEffect(() => {
    if (room) return undefined;
    let active = true;

    const load = () => {
      if (!active) return;
      void probeAllServers(lanTab === 'browse');
    };

    load();
    const timer = window.setInterval(load, hasAndroidLanBridge() ? 1500 : 2600);

    if (hasAndroidLanBridge()) {
      const ips = getAndroidLanIps();
      if (ips) {
        setLanUrls(ips.split(/[,\s]+/).filter(Boolean));
      }
    } else if (!isOfflineFile) {
      fetch('/api/lan-info')
        .then((res) => (res.ok ? res.json() : null))
        .then((data: LanInfoResponse | null) => {
          if (active && data && Array.isArray(data.urls)) {
            setLanUrls(data.urls);
          }
        })
        .catch(() => {});
    }

    return () => {
      active = false;
      window.clearInterval(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room, lanTab, isOfflineFile, serverIp]);

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = chatText.trim();
    if (!clean) return;
    onSendChat(clean);
    setChatText('');
  };

  const isHost = Boolean(room && selfId && room.hostId === selfId);
  const isLanRoom = room?.code === 'LAN';

  // Merge WebSocket live rooms + HTTP/Hotspot discovered rooms
  const visibleServers: DiscoveredServer[] = (() => {
    const map = new Map<string, DiscoveredServer>();
    for (const r of rooms) {
      map.set(r.code, r);
    }
    for (const r of httpRooms) {
      if (!map.has(r.code)) {
        map.set(r.code, r);
      }
    }
    return Array.from(map.values()).sort((a, b) => b.createdAt - a.createdAt);
  })();

  const saveName = (val: string) => {
    setName(val);
    try {
      localStorage.setItem('hh_name_v2', val);
    } catch {
      // ignore
    }
  };

  const applyCustomIp = (val: string) => {
    setServerIp(val);
    try {
      localStorage.setItem('hh_lan_url_v1', val);
    } catch {
      // ignore
    }
    onSetServerUrl(val.trim() || null);
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey((prev) => (prev === key ? null : prev)), 1800);
  };

  const shareText = (title: string, text: string, key: string) => {
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      navigator.share({ title, text }).catch(() => copyText(text, key));
    } else {
      copyText(text, key);
    }
  };

  const handleCreateServer = () => {
    setLocalError(null);
    const cleanPlayer = name.trim() || 'لاعب ١';
    const customSrv = serverNameInput.trim();
    onCreateRoom(cleanPlayer, difficulty, customSrv || undefined);
  };

  const handleJoinListedServer = (srv: DiscoveredServer) => {
    setLocalError(null);
    if (srv.serverUrl) {
      onSetServerUrl(srv.serverUrl);
    }
    onJoinRoom(srv.code, name.trim() || 'لاعب ٢');
  };

  const handleRefreshScan = async () => {
    setScanningLan(true);
    onRefreshRooms();
    await probeAllServers(true);
    setScanningLan(false);
  };

  const handleGenerateInvite = async () => {
    setLocalError(null);
    setLanBusy(true);
    try {
      const code = await onCreateLanInvite(name.trim() || 'لاعب ١', difficulty);
      setHostInviteCode(code);
      setHostReplyInput('');
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'تعذر تجهيز رابط نقطة الاتصال');
    } finally {
      setLanBusy(false);
    }
  };

  const handleAcceptReply = async () => {
    const clean = hostReplyInput.trim();
    if (!clean) return;
    setLocalError(null);
    setLanBusy(true);
    try {
      await onAcceptLanReply(clean);
      setHostReplyInput('');
      setHostInviteCode('');
      setShowExtraInvite(false);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'بيانات الرد غير صالحة');
    } finally {
      setLanBusy(false);
    }
  };

  const handleGuestGenerateReply = async () => {
    const clean = guestInviteInput.trim();
    if (!clean) return;
    setLocalError(null);
    setLanBusy(true);
    try {
      const reply = await onJoinLanInvite(clean, name.trim() || 'لاعب ٢');
      setGuestReplyCode(reply);
    } catch (err) {
      setLocalError(err instanceof Error ? err.message : 'بيانات الدعوة غير صالحة');
    } finally {
      setLanBusy(false);
    }
  };

  const activeError = localError || errorMsg;
  const activeHostName =
    room?.hostName ||
    room?.peers.find((p) => p.id === room.hostId)?.name ||
    'صاحب السيرفر';
  const activeServerTitle =
    room?.serverName || (isLanRoom ? `سيرفر ${activeHostName}` : `سيرفر ${activeHostName}`);
  const activeThemeName =
    (room?.world?.houseTheme || houseTheme) === 'classic' ? 'البيت التقليدي' : 'القصر القديم';

  return (
    <div
      className="fixed inset-0 z-30 flex items-center justify-center p-2.5 sm:p-4 bg-[rgba(2,1,1,0.9)] overflow-y-auto"
      dir="rtl"
    >
      <div className="w-full max-w-[460px] bg-[rgba(14,10,9,0.97)] border border-[rgba(235,227,214,0.2)] rounded-xl p-3.5 sm:p-4 space-y-3 text-[#ebe3d6]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-2">
          <div>
            <h2 className="font-display text-xl sm:text-2xl text-[#e2b34a] leading-none">
              اللعب الجماعي (LAN)
            </h2>
            <p className="text-[10px] sm:text-[11px] text-[#a09384] mt-0.5">
              {room
                ? 'غرفة الانتظار · دردشة نصية وصوتية مع فريقك'
                : 'افتح سيرفراً أو أوجد سيرفر صديقك للدخول معاً بدون رمز'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-2.5 py-1 rounded border border-white/20 text-[11px] text-[#c5b9aa] hover:bg-white/10 cursor-pointer whitespace-nowrap shrink-0"
          >
            إغلاق
          </button>
        </div>

        {activeError && (
          <div className="bg-[#4b0e0b] border border-[#b3201a] text-[#ffdad6] text-[11px] rounded-md px-2.5 py-1.5 text-center">
            {activeError}
          </div>
        )}

        {!room ? (
          <div className="space-y-3">
            {/* Player Name */}
            <div className="space-y-1">
              <label className="block text-[11px] text-[#c5b9aa]" htmlFor="mp-name-input">
                اسمك في اللعب
              </label>
              <input
                id="mp-name-input"
                type="text"
                maxLength={14}
                value={name}
                onChange={(e) => saveName(e.target.value)}
                placeholder="اكتب اسمك هنا..."
                className="w-full px-2.5 py-1.5 rounded-md bg-black/50 border border-white/20 text-xs sm:text-sm text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
              />
            </div>

            {/* CS-Style Primary Two Options: افتح سيرفر vs أوجد سيرفر */}
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-lg bg-black/55 border border-white/10">
              <button
                type="button"
                onClick={() => {
                  setLocalError(null);
                  setLanTab('create');
                }}
                className={`py-2 px-2 rounded-md text-xs sm:text-sm font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  lanTab === 'create'
                    ? 'bg-[#5e0d0a] text-[#ebe3d6] border border-[#b3201a] shadow-[0_0_12px_rgba(179,32,26,0.35)]'
                    : 'text-[#a09384] hover:text-[#ebe3d6]'
                }`}
              >
                افتح سيرفر
              </button>
              <button
                type="button"
                onClick={() => {
                  setLocalError(null);
                  setLanTab('browse');
                  void handleRefreshScan();
                }}
                className={`py-2 px-2 rounded-md text-xs sm:text-sm font-bold transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-1.5 ${
                  lanTab === 'browse'
                    ? 'bg-[#5e0d0a] text-[#ebe3d6] border border-[#b3201a] shadow-[0_0_12px_rgba(179,32,26,0.35)]'
                    : 'text-[#a09384] hover:text-[#ebe3d6]'
                }`}
              >
                <span>أوجد سيرفر</span>
                {visibleServers.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded bg-[#e2b34a] text-[#1a0d08] font-mono-num text-[10px]">
                    {toArabicDigits(visibleServers.length)}
                  </span>
                )}
              </button>
            </div>

            {lanTab === 'create' ? (
              <div className="bg-black/40 border border-white/10 rounded-lg p-3 space-y-2.5">
                <div className="space-y-1">
                  <label className="block text-[10px] text-[#c5b9aa]" htmlFor="mp-srv-name">
                    اسم السيرفر (يظهر لأصدقائك في «أوجد سيرفر»)
                  </label>
                  <input
                    id="mp-srv-name"
                    type="text"
                    maxLength={24}
                    value={serverNameInput}
                    onChange={(e) => setServerNameInput(e.target.value)}
                    placeholder={`سيرفر ${name.trim() || 'لاعب'}`}
                    className="w-full px-2.5 py-1.5 rounded bg-black/60 border border-white/15 text-xs text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-[#a09384] bg-black/35 px-2.5 py-1.5 rounded border border-white/10">
                  <span>الماب المختارة:</span>
                  <span className="text-[#e2b34a] font-bold">
                    {activeThemeName} · {DIFFICULTIES[difficulty].name}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleCreateServer}
                  className="w-full py-2.5 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] font-display text-lg sm:text-xl text-[#ebe3d6] cursor-pointer transition-colors"
                >
                  افتح السيرفر وانتظر اللاعبين
                </button>
              </div>
            ) : (
              <div className="bg-black/40 border border-white/10 rounded-lg p-2.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#e2b34a]">
                    السيرفرات المتاحة ({toArabicDigits(visibleServers.length)})
                  </span>
                  <button
                    type="button"
                    disabled={scanningLan}
                    onClick={() => void handleRefreshScan()}
                    className="px-2.5 py-0.5 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#ebe3d6] cursor-pointer disabled:opacity-50"
                  >
                    {scanningLan ? 'جاري البحث...' : 'تحديث القائمة'}
                  </button>
                </div>

                {visibleServers.length === 0 ? (
                  <div className="text-[11px] text-[#a09384] text-center py-5 px-3 bg-black/30 rounded border border-white/5 space-y-1">
                    <div>لا توجد سيرفرات مفتوحة حالياً.</div>
                    <div className="text-[10px] text-[#8a7d6f]">
                      عندما يفتح صديقك السيرفر (أو يبدأ اللعب) سيظهر اسمه هنا فوراً للدخول معه.
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-52 overflow-y-auto pe-0.5">
                    {visibleServers.map((srv) => {
                      const isFull = srv.playerCount >= srv.maxPlayers;
                      const mapName = srv.houseTheme === 'classic' ? 'البيت التقليدي' : 'القصر القديم';
                      return (
                        <div
                          key={`${srv.code}:${srv.serverUrl || ''}`}
                          className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-md bg-black/55 border border-white/12 hover:border-[#e2b34a]/50 transition-colors"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-[#ebe3d6] truncate">
                              {srv.serverName}
                            </div>
                            <div className="text-[10px] text-[#a09384] truncate">
                              بواسطة: <span className="text-[#e2b34a]">{srv.hostName}</span>
                              {' · '}
                              {mapName}
                              {' · '}
                              <span className="font-mono-num">
                                {toArabicDigits(srv.playerCount)}/{toArabicDigits(srv.maxPlayers)}
                              </span>
                            </div>
                            <div
                              className={`text-[9.5px] font-bold mt-0.5 ${
                                srv.phase === 'playing' ? 'text-[#7ef2ae]' : 'text-[#c5b9aa]'
                              }`}
                            >
                              {srv.phase === 'playing'
                                ? '● داخل الماب الآن — اضغط لدخول اللعب معه'
                                : '○ في غرفة الانتظار'}
                            </div>
                          </div>
                          <button
                            type="button"
                            disabled={isFull}
                            onClick={() => handleJoinListedServer(srv)}
                            className="px-3 py-1.5 rounded bg-[#2c1512] hover:bg-[#5e0d0a] disabled:opacity-45 border border-[#e2b34a]/50 text-[11px] font-bold text-[#e2b34a] hover:text-white cursor-pointer whitespace-nowrap shrink-0"
                          >
                            {isFull ? 'ممتلئ' : srv.phase === 'playing' ? 'دخول الماب' : 'دخول'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* Collapsible Hotspot / Direct Wi-Fi Tools */}
            <div className="pt-0.5">
              <button
                type="button"
                onClick={() => setShowHotspotTools((v) => !v)}
                className="text-[10px] text-[#a09384] hover:text-[#e2b34a] underline cursor-pointer"
              >
                {showHotspotTools
                  ? 'إخفاء خيارات نقطة الاتصال (Hotspot)'
                  : 'نقطة اتصال هاتف / عنوان الشبكة المحلية (Hotspot)'}
              </button>

              {showHotspotTools && (
                <div className="mt-2 space-y-2 bg-black/45 border border-white/10 rounded-lg p-2.5">
                  {lanUrls.length > 0 && (
                    <div className="space-y-1">
                      <div className="text-[10px] text-[#e2b34a] font-bold">
                        أعطِ هذا الرابط لصديقك المتصل بنفس نقطة الاتصال (Wi-Fi / Hotspot):
                      </div>
                      {lanUrls.map((url) => (
                        <div key={url} className="flex items-center justify-between gap-2">
                          <span dir="ltr" className="font-mono text-[10px] text-[#ebe3d6] truncate">
                            {url}
                          </span>
                          <button
                            type="button"
                            onClick={() => copyText(url, url)}
                            className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#ebe3d6] cursor-pointer whitespace-nowrap shrink-0"
                          >
                            {copiedKey === url ? 'تم ✓' : 'نسخ'}
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="space-y-1">
                    <div className="text-[10px] text-[#c5b9aa]">
                      عنوان خادم نقطة الاتصال (IP المضيف إذا لم يظهر تلقائياً):
                    </div>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        dir="ltr"
                        value={serverIp}
                        onChange={(e) => applyCustomIp(e.target.value)}
                        placeholder="192.168.43.1:3000"
                        className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[10px] text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                      />
                      {serverIp && (
                        <button
                          type="button"
                          onClick={() => applyCustomIp('')}
                          className="px-2 py-1 rounded bg-white/10 text-[10px] text-[#c5b9aa] cursor-pointer"
                        >
                          افتراضي
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Direct Offline P2P fallback when no Node server is reachable (APK offline mode) */}
                  <div className="pt-1.5 border-t border-white/10 space-y-2">
                    <div className="text-[10px] text-[#c5b9aa] font-bold">
                      ربط مباشر بدون خادم (للنسخة المحمولة أوفلاين):
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setLocalError(null);
                          setHotspotRole('host');
                        }}
                        className={`py-1 px-2 rounded text-[10px] font-bold border cursor-pointer ${
                          hotspotRole === 'host'
                            ? 'bg-[#2a221d] border-[#e2b34a] text-[#e2b34a]'
                            : 'bg-black/40 border-white/15 text-[#c5b9aa]'
                        }`}
                      >
                        المضيف
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setLocalError(null);
                          setHotspotRole('guest');
                        }}
                        className={`py-1 px-2 rounded text-[10px] font-bold border cursor-pointer ${
                          hotspotRole === 'guest'
                            ? 'bg-[#2a221d] border-[#e2b34a] text-[#e2b34a]'
                            : 'bg-black/40 border-white/15 text-[#c5b9aa]'
                        }`}
                      >
                        المنضم
                      </button>
                    </div>

                    {hotspotRole === 'host' ? (
                      <div className="space-y-1.5">
                        <button
                          type="button"
                          disabled={lanBusy}
                          onClick={handleGenerateInvite}
                          className="w-full py-1.5 rounded bg-[#5e0d0a] hover:bg-[#7d130f] disabled:opacity-50 border border-[#b3201a] text-xs font-bold text-[#ebe3d6] cursor-pointer"
                        >
                          {lanBusy ? 'جاري التجهيز...' : '١. إنشاء دعوة نقطة اتصال'}
                        </button>
                        {hostInviteCode && (
                          <div className="flex gap-1.5">
                            <input
                              readOnly
                              dir="ltr"
                              value={hostInviteCode}
                              onFocus={(e) => e.currentTarget.select()}
                              className="flex-1 px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px]"
                            />
                            <button
                              type="button"
                              onClick={() => shareText('دعوة LAN', hostInviteCode, 'invite')}
                              className="px-2 py-1 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[10px] text-[#e2b34a] cursor-pointer"
                            >
                              {copiedKey === 'invite' ? '✓' : 'مشاركة'}
                            </button>
                          </div>
                        )}
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            dir="ltr"
                            value={hostReplyInput}
                            onChange={(e) => setHostReplyInput(e.target.value)}
                            placeholder="٢. ألصق رد المنضم..."
                            className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[10px]"
                          />
                          <button
                            type="button"
                            disabled={lanBusy || !hostReplyInput.trim()}
                            onClick={handleAcceptReply}
                            className="px-2.5 py-1 rounded bg-[#2a221d] border border-[#e2b34a]/50 text-[10px] font-bold text-[#e2b34a] cursor-pointer"
                          >
                            اتصال
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        <input
                          type="text"
                          dir="ltr"
                          value={guestInviteInput}
                          onChange={(e) => setGuestInviteInput(e.target.value)}
                          placeholder="١. ألصق دعوة المضيف..."
                          className="w-full px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[10px]"
                        />
                        <button
                          type="button"
                          disabled={lanBusy || !guestInviteInput.trim()}
                          onClick={handleGuestGenerateReply}
                          className="w-full py-1.5 rounded bg-[#5e0d0a] hover:bg-[#7d130f] disabled:opacity-45 border border-[#b3201a] text-xs font-bold text-[#ebe3d6] cursor-pointer"
                        >
                          {lanBusy ? 'جاري الرد...' : '٢. تجهيز رد الدخول'}
                        </button>
                        {guestReplyCode && (
                          <div className="flex gap-1.5">
                            <input
                              readOnly
                              dir="ltr"
                              value={guestReplyCode}
                              onFocus={(e) => e.currentTarget.select()}
                              className="flex-1 px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px]"
                            />
                            <button
                              type="button"
                              onClick={() => shareText('رد LAN', guestReplyCode, 'reply')}
                              className="px-2 py-1 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[10px] text-[#e2b34a] cursor-pointer"
                            >
                              {copiedKey === 'reply' ? '✓' : 'مشاركة'}
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-2.5">
            {/* Server Waiting Banner */}
            <div className="bg-black/50 border border-[#e2b34a]/35 rounded-lg p-2.5 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="text-sm font-bold text-[#e2b34a] truncate">
                  {activeServerTitle}
                </div>
                <div className="text-[10px] text-[#c5b9aa] mt-0.5 truncate">
                  صاحب السيرفر: <span className="font-bold text-[#ebe3d6]">{activeHostName}</span>
                  {' · '}
                  <span>{activeThemeName}</span>
                </div>
              </div>
              {isLanRoom && isHost ? (
                <button
                  type="button"
                  onClick={() => setShowExtraInvite((v) => !v)}
                  className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/15 border border-white/20 text-[10px] text-[#ebe3d6] cursor-pointer whitespace-nowrap shrink-0"
                >
                  {showExtraInvite ? 'إغلاق' : '+ دعوة لاعب'}
                </button>
              ) : null}
            </div>

            {isLanRoom && isHost && showExtraInvite && (
              <div className="bg-black/45 border border-white/15 rounded-lg p-2.5 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-[#e2b34a]">إضافة لاعب آخر</span>
                  <button
                    type="button"
                    disabled={lanBusy}
                    onClick={handleGenerateInvite}
                    className="px-2 py-0.5 rounded bg-[#5e0d0a] border border-[#b3201a] text-[10px] text-[#ebe3d6] cursor-pointer"
                  >
                    {lanBusy ? 'جاري الإنشاء...' : 'توليد دعوة'}
                  </button>
                </div>
                {hostInviteCode && (
                  <div className="flex gap-1.5">
                    <input
                      readOnly
                      dir="ltr"
                      value={hostInviteCode}
                      onFocus={(e) => e.currentTarget.select()}
                      className="flex-1 px-2 py-1 rounded bg-black/70 border border-white/10 font-mono text-[10px]"
                    />
                    <button
                      type="button"
                      onClick={() => copyText(hostInviteCode, 'extraInvite')}
                      className="px-2 py-1 rounded bg-white/10 text-[10px] cursor-pointer"
                    >
                      {copiedKey === 'extraInvite' ? '✓' : 'نسخ'}
                    </button>
                  </div>
                )}
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    dir="ltr"
                    value={hostReplyInput}
                    onChange={(e) => setHostReplyInput(e.target.value)}
                    placeholder="ألصق رد اللاعب..."
                    className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 font-mono text-[10px]"
                  />
                  <button
                    type="button"
                    disabled={lanBusy || !hostReplyInput.trim()}
                    onClick={handleAcceptReply}
                    className="px-2.5 py-1 rounded bg-[#2a221d] border border-[#e2b34a]/50 text-[10px] text-[#e2b34a] cursor-pointer"
                  >
                    تأكيد
                  </button>
                </div>
              </div>
            )}

            {/* Connected Players List */}
            <div className="space-y-1">
              <div className="text-[11px] text-[#c5b9aa] font-bold">
                اللاعبون في السيرفر ({toArabicDigits(room.peers.length)}/٤)
              </div>
              <div className="space-y-1 max-h-28 overflow-y-auto">
                {room.peers.map((p) => {
                  const color = PEER_COLORS[Math.abs(p.colorIndex) % PEER_COLORS.length];
                  const isYou = p.id === selfId;
                  const isRoomHost = p.id === room.hostId;
                  const peerVoiceOn = isYou
                    ? voiceState.enabled && !voiceState.muted
                    : Boolean(p.voiceActive || voiceState.activePeers.includes(p.id));
                  return (
                    <div
                      key={p.id}
                      className="flex items-center justify-between px-2.5 py-1.5 rounded-md bg-white/5 border border-white/10 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className="w-2.5 h-2.5 rounded-sm shrink-0 border border-white/40"
                          style={{ backgroundColor: color }}
                        />
                        <span className="font-bold text-[#ebe3d6] truncate">{p.name}</span>
                        {isYou && (
                          <span className="text-[9.5px] px-1 py-0.5 rounded bg-white/10 text-[#c5b9aa]">
                            أنت
                          </span>
                        )}
                        {isRoomHost && (
                          <span className="text-[9.5px] px-1 py-0.5 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/40 text-[#e2b34a]">
                            صاحب السيرفر
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {peerVoiceOn && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#183b27] border border-[#45b877]/50 text-[#7ef2ae]">
                            🎙 صوت
                          </span>
                        )}
                        <span className="text-[10px] text-[#45b877]">متصل</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Difficulty Selection (Host controls it) */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] text-[#c5b9aa]">
                <span>مستوى الصعوبة:</span>
                <span className="text-[#e2b34a] font-bold">{DIFFICULTIES[room.diff].name}</span>
              </div>
              {isHost && (
                <div className="grid grid-cols-5 gap-1">
                  {DIFF_KEYS.map((k) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => onChangeDiff(k)}
                      className={`py-1 rounded text-[10px] border cursor-pointer ${
                        room.diff === k
                          ? 'bg-[#5e0d0a] border-[#b3201a] text-white font-bold'
                          : 'bg-black/40 border-white/15 text-[#c5b9aa] hover:border-white/30'
                      }`}
                    >
                      {DIFFICULTIES[k].name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Voice Chat Bar in Lobby */}
            <div className="bg-black/45 border border-white/10 rounded-lg p-2 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-[11px] font-bold">
                  <span className="text-[#e2b34a]">الدردشة الصوتية (Voice Chat)</span>
                  {voiceState.enabled && !voiceState.muted && (
                    <span
                      className={`w-2 h-2 rounded-full ${
                        voiceState.speaking ? 'bg-[#6dff9b] animate-pulse' : 'bg-[#45b877]'
                      }`}
                    />
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={onToggleVoice}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold border cursor-pointer transition-colors ${
                      !voiceState.enabled
                        ? 'bg-[#1f2923] border-[#45b877]/50 text-[#7ef2ae] hover:bg-[#273a2f]'
                        : voiceState.muted
                          ? 'bg-[#3d2312] border-[#e2b34a]/50 text-[#ffd584]'
                          : 'bg-[#17422a] border-[#6dff9b] text-[#9affbe]'
                    }`}
                  >
                    {!voiceState.enabled
                      ? '🎙 تشغيل المايك'
                      : voiceState.muted
                        ? '🔇 مكتوم (اضغط للتحدث)'
                        : '🎙 المايك مفتوح'}
                  </button>
                  {voiceState.enabled && (
                    <button
                      type="button"
                      onClick={onStopVoice}
                      className="px-2 py-1 rounded bg-white/10 hover:bg-white/15 text-[10px] text-[#c5b9aa] cursor-pointer"
                    >
                      إيقاف
                    </button>
                  )}
                </div>
              </div>
              {voiceState.error && (
                <div className="text-[10px] text-[#ff8b80]">{voiceState.error}</div>
              )}
            </div>

            {/* Lobby Text Chat */}
            <div className="bg-black/45 border border-white/10 rounded-lg p-2 space-y-1.5">
              <div className="text-[10px] text-[#a09384] font-bold">دردشة السيرفر</div>
              <div
                ref={chatScrollRef}
                className="h-24 overflow-y-auto space-y-1.5 text-[11px] pe-1"
              >
                {chatMessages.length === 0 ? (
                  <div className="text-[#a09384]/70 text-center py-5">
                    تحدّث مع أصدقائك قبل بدء اللعب...
                  </div>
                ) : (
                  chatMessages.map((m) => {
                    const color = PEER_COLORS[Math.abs(m.colorIndex) % PEER_COLORS.length];
                    const timeLabel = formatChatTime(m.ts);
                    if (m.system) {
                      return (
                        <div
                          key={m.id}
                          className="flex items-start justify-between gap-2 px-2 py-1 rounded-e bg-[#2a1d10]/85 border-s-2 border-[#e2b34a] text-[#ffd685] leading-snug"
                        >
                          <div className="min-w-0 break-words">
                            <span className="inline-block px-1 py-0.2 me-1.5 rounded bg-[#e2b34a]/20 border border-[#e2b34a]/45 text-[9px] font-bold text-[#e2b34a]">
                              النظام
                            </span>
                            <span className="text-[10.5px] font-medium text-[#ffdf9e]">
                              {m.text}
                            </span>
                          </div>
                          {timeLabel && (
                            <span
                              dir="ltr"
                              className="font-mono-num text-[9px] text-[#c7a96b]/85 shrink-0 pt-0.5"
                            >
                              {timeLabel}
                            </span>
                          )}
                        </div>
                      );
                    }
                    return (
                      <div
                        key={m.id}
                        className="flex items-baseline justify-between gap-2 px-1 py-0.5 rounded bg-white/[0.03] leading-snug"
                      >
                        <div className="min-w-0 break-words">
                          <span className="font-bold me-1.5" style={{ color }}>
                            {m.senderName}:
                          </span>
                          <span className="text-[#ebe3d6]">{m.text}</span>
                        </div>
                        {timeLabel && (
                          <span
                            dir="ltr"
                            className="font-mono-num text-[9px] text-[#8d8174] shrink-0"
                          >
                            {timeLabel}
                          </span>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
              <form onSubmit={handleChatSubmit} className="flex gap-1.5">
                <input
                  type="text"
                  maxLength={160}
                  value={chatText}
                  onChange={(e) => setChatText(e.target.value)}
                  placeholder="اكتب رسالة..."
                  className="flex-1 px-2 py-1 rounded bg-black/60 border border-white/15 text-[11px] text-[#ebe3d6] focus:outline-none focus:border-[#e2b34a]"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 rounded bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] text-[11px] font-bold text-[#ebe3d6] cursor-pointer"
                >
                  إرسال
                </button>
              </form>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1.5 pt-0.5">
              {isHost ? (
                <button
                  type="button"
                  onClick={onStartGame}
                  className="flex-1 py-2 rounded-md bg-[#5e0d0a] hover:bg-[#7d130f] border border-[#b3201a] font-display text-lg sm:text-xl text-[#ebe3d6] cursor-pointer"
                >
                  ابدأ اللعب الجماعي
                </button>
              ) : (
                <div className="flex-1 py-2 text-center text-[11px] text-[#e2b34a] bg-black/40 border border-[#e2b34a]/25 rounded-md">
                  في انتظار {activeHostName} لبدء اللعب...
                </div>
              )}
              <button
                type="button"
                onClick={() => {
                  onStopVoice();
                  setHostInviteCode('');
                  setGuestReplyCode('');
                  onLeaveRoom();
                }}
                className="px-3 py-2 rounded-md border border-white/20 text-[11px] text-[#c5b9aa] hover:bg-white/10 cursor-pointer"
              >
                مغادرة
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
