import {
  ChatMessage,
  DifficultyKey,
  HouseTheme,
  MultiplayerPeer,
  MultiplayerRoomSnapshot,
  PublicRoomSummary,
  RoomWorldSnapshot,
} from './types';

export interface AndroidLanBridge {
  startHost: (name: string) => boolean;
  stopHost: () => void;
  games: () => string;
  ips: () => string;
}

declare global {
  interface Window {
    AndroidLan?: AndroidLanBridge;
  }
}

export const ANDROID_LAN_PORT = 8765;

export function hasAndroidLanBridge(): boolean {
  return typeof window !== 'undefined' && Boolean(window.AndroidLan);
}

export function getAndroidLanIps(): string {
  if (!hasAndroidLanBridge()) return '';
  try {
    return String(window.AndroidLan?.ips() || '');
  } catch {
    return '';
  }
}

export function getAndroidLanGames(): PublicRoomSummary[] {
  if (!hasAndroidLanBridge()) return [];
  try {
    const raw = window.AndroidLan?.games();
    const list = JSON.parse(raw || '[]');
    if (!Array.isArray(list)) return [];
    const out: PublicRoomSummary[] = [];
    for (const item of list) {
      const ip = String(item?.ip || '').trim();
      if (!/^[0-9.]+$/.test(ip)) continue;
      const srvName = String(item?.name || 'سيرفر نقطة الاتصال').trim();
      out.push({
        code: `ALAN:${ip}`,
        serverName: srvName,
        hostName: srvName,
        diff: 'med',
        houseTheme: 'manor',
        phase: 'lobby',
        playerCount: 1,
        maxPlayers: 4,
        createdAt: Date.now(),
      });
    }
    return out;
  } catch {
    return [];
  }
}

interface AndroidLanPresence {
  role?: 'host' | 'guest';
  name?: string;
  peerState?: Partial<MultiplayerPeer>;
  voiceActive?: boolean;
  room?: MultiplayerRoomSnapshot;
  monsters?: unknown;
  events?: Array<{ id: string; fromId: string; event: Record<string, unknown> }>;
  chats?: ChatMessage[];
  signals?: Array<{ id: string; fromId: string; toId: string; signal: unknown }>;
}

interface AndroidLanManagerCallbacks {
  onOpen: () => void;
  onPacket: (pkt: Record<string, unknown>) => void;
  onError: (msg: string) => void;
  onClose: () => void;
}

function createInitialWorld(
  diff: DifficultyKey,
  houseTheme: HouseTheme,
  roundId = 1
): RoomWorldSnapshot {
  return {
    roundId,
    diff,
    houseTheme,
    safeCode: 1000 + Math.floor(Math.random() * 9000),
    keySeed: Math.floor(Math.random() * 900000) + 1000,
    giantRoll: Math.random(),
    searchedSpots: [],
    plankBroken: false,
    wireCut: false,
    panelOpened: false,
    safeOpen: false,
    doorOpen: false,
    takenTorches: [],
  };
}

function makeDefaultPeer(id: string, name: string, colorIndex: number): MultiplayerPeer {
  return {
    id,
    name: name.slice(0, 14) || 'لاعب',
    colorIndex,
    x: 9,
    y: 0,
    z: 9,
    yaw: 0,
    fl: 0,
    crouch: false,
    torch: false,
    hiddenIdx: -1,
    heldItem: null,
    alive: true,
    escaped: false,
    day: 1,
    speed: 0,
    voiceActive: false,
  };
}

export class AndroidLanManager {
  private cbs: AndroidLanManagerCallbacks;
  private sock: WebSocket | null = null;
  private hosting = false;
  private closedByUs = false;
  private selfId: string | null = null;
  private playerName = 'لاعب';
  private serverName = 'سيرفر';
  private room: MultiplayerRoomSnapshot | null = null;

  private myPresence: AndroidLanPresence = {};
  private outEvents: Array<{ id: string; fromId: string; event: Record<string, unknown>; ts: number }> = [];
  private outChats: Array<{ msg: ChatMessage; ts: number }> = [];
  private outSignals: Array<{ id: string; fromId: string; toId: string; signal: unknown; ts: number }> = [];

  private seenEventIds = new Set<string>();
  private seenChatIds = new Set<string>();
  private seenSignalIds = new Set<string>();
  private joinedNotified = false;
  private lastPhase: 'lobby' | 'playing' = 'lobby';
  private seq = 0;

  constructor(cbs: AndroidLanManagerCallbacks) {
    this.cbs = cbs;
  }

  public get active(): boolean {
    return Boolean(this.sock && (this.sock.readyState === WebSocket.OPEN || this.sock.readyState === WebSocket.CONNECTING));
  }

  public get isHosting(): boolean {
    return this.hosting;
  }

  private nextId(prefix: string): string {
    this.seq += 1;
    return `${this.selfId || 'p'}-${prefix}-${Date.now()}-${this.seq}`;
  }

  private pushPresence(): void {
    if (!this.sock || this.sock.readyState !== WebSocket.OPEN || !this.selfId) return;
    const now = Date.now();
    this.outEvents = this.outEvents.filter((e) => now - e.ts < 8000).slice(-14);
    this.outChats = this.outChats.filter((c) => now - c.ts < 12000).slice(-16);
    this.outSignals = this.outSignals.filter((s) => now - s.ts < 8000).slice(-16);

    const payload: AndroidLanPresence = {
      ...this.myPresence,
      events: this.outEvents.map(({ id, fromId, event }) => ({ id, fromId, event })),
      chats: this.outChats.map((c) => c.msg),
      signals: this.outSignals.map(({ id, fromId, toId, signal }) => ({
        id,
        fromId,
        toId,
        signal,
      })),
    };
    if (this.hosting && this.room) {
      payload.room = this.room;
    }
    try {
      this.sock.send(JSON.stringify({ t: 'pres', p: payload }));
    } catch {
      // ignore
    }
  }

  public startHosting(
    playerName: string,
    diff: DifficultyKey,
    serverName?: string,
    houseTheme: HouseTheme = 'manor'
  ): void {
    this.close();
    if (!hasAndroidLanBridge()) {
      this.cbs.onError('واجهة AndroidLan غير متوفرة');
      return;
    }

    this.playerName = playerName.trim().slice(0, 14) || 'لاعب ١';
    this.serverName = (serverName || `سيرفر ${this.playerName}`).trim().slice(0, 26);

    let ok = false;
    try {
      ok = Boolean(window.AndroidLan?.startHost(this.serverName));
    } catch {
      ok = false;
    }
    if (!ok) {
      this.cbs.onError('تعذّر تشغيل خادم نقطة الاتصال على هذا الهاتف');
      return;
    }

    this.hosting = true;
    this.connectSocket('127.0.0.1', () => {
      if (!this.selfId) return;
      const hostPeer = makeDefaultPeer(this.selfId, this.playerName, 0);
      this.room = {
        code: 'LAN',
        serverName: this.serverName,
        hostName: this.playerName,
        hostId: this.selfId,
        phase: 'lobby',
        diff,
        world: createInitialWorld(diff, houseTheme, 1),
        peers: [hostPeer],
        messages: [],
      };
      this.myPresence = {
        role: 'host',
        name: this.playerName,
        peerState: hostPeer,
        room: this.room,
      };
      this.joinedNotified = true;
      this.lastPhase = 'lobby';
      this.cbs.onPacket({
        type: 'room:joined',
        selfId: this.selfId,
        room: this.cloneRoom(),
      });
      this.pushPresence();
    });
  }

  public joinIp(ip: string, playerName: string): void {
    this.close();
    this.hosting = false;
    this.playerName = playerName.trim().slice(0, 14) || 'لاعب ٢';
    const cleanIp = ip.replace(/^ALAN:/, '').trim();
    this.connectSocket(cleanIp, () => {
      this.myPresence = {
        role: 'guest',
        name: this.playerName,
        peerState: makeDefaultPeer(this.selfId || 'guest', this.playerName, 1),
      };
      this.pushPresence();
    });
  }

  private connectSocket(host: string, onHello: () => void): void {
    this.closedByUs = false;
    this.joinedNotified = false;
    this.seenEventIds.clear();
    this.seenChatIds.clear();
    this.seenSignalIds.clear();

    let sock: WebSocket;
    try {
      sock = new WebSocket(`ws://${host}:${ANDROID_LAN_PORT}/`);
    } catch {
      this.cbs.onError('تعذر الاتصال بنقطة الاتصال');
      return;
    }
    this.sock = sock;

    sock.onmessage = (ev) => {
      let msg: { t?: string; you?: string; list?: Array<{ peer: string; p?: AndroidLanPresence }> };
      try {
        msg = JSON.parse(String(ev.data)) as typeof msg;
      } catch {
        return;
      }

      if (msg.t === 'hello') {
        this.selfId = String(msg.you || '');
        this.cbs.onOpen();
        onHello();
      } else if (msg.t === 'peers') {
        const list = Array.isArray(msg.list) ? msg.list : [];
        if (this.hosting) {
          this.handleHostPeersUpdate(list);
        } else {
          this.handleGuestPeersUpdate(list);
        }
      }
    };

    sock.onerror = () => {
      this.cbs.onError('فشل الاتصال بسيرفر نقطة الاتصال');
    };

    sock.onclose = () => {
      if (!this.closedByUs) {
        this.room = null;
        this.cbs.onClose();
      }
    };
  }

  private cloneRoom(): MultiplayerRoomSnapshot | null {
    if (!this.room) return null;
    return {
      ...this.room,
      world: { ...this.room.world, searchedSpots: [...this.room.world.searchedSpots] },
      peers: this.room.peers.map((p) => ({ ...p })),
      messages: this.room.messages ? [...this.room.messages] : [],
    };
  }

  private applyWorldEventToRoom(ev: Record<string, unknown>): void {
    if (!this.room) return;
    const w = this.room.world;
    const kind = String(ev.kind || '');
    if (kind === 'spot' && typeof ev.index === 'number') {
      if (!w.searchedSpots.includes(ev.index)) w.searchedSpots.push(ev.index);
    } else if (kind === 'lock') {
      const lock = String(ev.lock || '');
      if (lock === 'plankBroken') w.plankBroken = true;
      else if (lock === 'wireCut') w.wireCut = true;
      else if (lock === 'panelOpened') w.panelOpened = true;
    } else if (kind === 'safe') {
      w.safeOpen = true;
    } else if (kind === 'door') {
      w.doorOpen = true;
    } else if (kind === 'torchPickup' && typeof ev.index === 'number') {
      if (!w.takenTorches) w.takenTorches = [];
      if (!w.takenTorches.includes(ev.index)) w.takenTorches.push(ev.index);
    }
  }

  private handleHostPeersUpdate(
    list: Array<{ peer: string; p?: AndroidLanPresence }>
  ): void {
    if (!this.room || !this.selfId) return;

    const existingMap = new Map(this.room.peers.map((p) => [p.id, p]));
    const nextPeers: MultiplayerPeer[] = [];
    let dirtyRoom = false;

    const usedColors = new Set<number>();
    const selfExisting = existingMap.get(this.selfId) || makeDefaultPeer(this.selfId, this.playerName, 0);
    nextPeers.push(selfExisting);
    usedColors.add(selfExisting.colorIndex);

    for (const item of list) {
      const pid = String(item.peer || '');
      if (!pid || pid === this.selfId) continue;
      const pData = item.p || {};
      let peer = existingMap.get(pid);
      if (!peer) {
        let color = 1;
        while (usedColors.has(color) && color < 16) color++;
        peer = makeDefaultPeer(pid, pData.name || 'لاعب', color);
        dirtyRoom = true;
      }
      usedColors.add(peer.colorIndex);
      if (pData.peerState) {
        Object.assign(peer, pData.peerState, {
          id: pid,
          colorIndex: peer.colorIndex,
        });
      }
      if (typeof pData.voiceActive === 'boolean') {
        peer.voiceActive = pData.voiceActive;
      }
      nextPeers.push(peer);
      this.cbs.onPacket({ type: 'peer:state', peer: { ...peer } });

      // Process guest world events
      if (Array.isArray(pData.events)) {
        for (const evWrap of pData.events) {
          if (!evWrap?.id || this.seenEventIds.has(evWrap.id)) continue;
          this.seenEventIds.add(evWrap.id);
          this.applyWorldEventToRoom(evWrap.event);
          this.outEvents.push({
            id: evWrap.id,
            fromId: pid,
            event: evWrap.event,
            ts: Date.now(),
          });
          this.cbs.onPacket({
            type: 'world:event',
            fromId: pid,
            event: evWrap.event,
            world: { ...this.room.world },
          });
          dirtyRoom = true;
        }
      }

      // Process guest chat messages
      if (Array.isArray(pData.chats)) {
        for (const chatMsg of pData.chats) {
          if (!chatMsg?.id || this.seenChatIds.has(chatMsg.id)) continue;
          this.seenChatIds.add(chatMsg.id);
          const stamped: ChatMessage = {
            ...chatMsg,
            senderId: pid,
            senderName: peer.name,
            colorIndex: peer.colorIndex,
          };
          if (!this.room.messages) this.room.messages = [];
          this.room.messages.push(stamped);
          if (this.room.messages.length > 60) {
            this.room.messages.splice(0, this.room.messages.length - 60);
          }
          this.outChats.push({ msg: stamped, ts: Date.now() });
          this.cbs.onPacket({ type: 'chat:message', message: stamped });
          dirtyRoom = true;
        }
      }

      // Process guest WebRTC voice signals
      if (Array.isArray(pData.signals)) {
        for (const sig of pData.signals) {
          if (!sig?.id || this.seenSignalIds.has(sig.id)) continue;
          this.seenSignalIds.add(sig.id);
          if (sig.toId === this.selfId) {
            this.cbs.onPacket({
              type: 'voice:signal',
              fromId: pid,
              signal: sig.signal,
            });
          } else if (sig.toId) {
            this.outSignals.push({
              id: sig.id,
              fromId: pid,
              toId: sig.toId,
              signal: sig.signal,
              ts: Date.now(),
            });
            dirtyRoom = true;
          }
        }
      }
    }

    if (nextPeers.length !== this.room.peers.length) {
      dirtyRoom = true;
    }
    this.room.peers = nextPeers;

    if (dirtyRoom) {
      this.cbs.onPacket({ type: 'room:update', room: this.cloneRoom() });
      this.pushPresence();
    }
  }

  private handleGuestPeersUpdate(
    list: Array<{ peer: string; p?: AndroidLanPresence }>
  ): void {
    if (!this.selfId) return;
    const hostEntry = list.find((item) => item.p?.role === 'host' && item.p?.room);
    if (!hostEntry || !hostEntry.p?.room) return;

    const hostData = hostEntry.p;
    const remoteRoom = hostData.room!;
    this.room = remoteRoom;

    if (!this.joinedNotified) {
      this.joinedNotified = true;
      this.lastPhase = remoteRoom.phase;
      this.cbs.onPacket({
        type: 'room:joined',
        selfId: this.selfId,
        room: this.cloneRoom(),
      });
      if (remoteRoom.phase === 'playing') {
        this.cbs.onPacket({ type: 'game:started', room: this.cloneRoom() });
      }
    } else {
      if (remoteRoom.phase === 'playing' && this.lastPhase !== 'playing') {
        this.lastPhase = 'playing';
        this.cbs.onPacket({ type: 'game:started', room: this.cloneRoom() });
      } else {
        this.lastPhase = remoteRoom.phase;
        this.cbs.onPacket({ type: 'room:update', room: this.cloneRoom() });
      }
    }

    for (const peer of remoteRoom.peers) {
      if (peer.id !== this.selfId) {
        this.cbs.onPacket({ type: 'peer:state', peer });
      }
    }

    if (hostData.monsters) {
      this.cbs.onPacket({ type: 'monsters:state', data: hostData.monsters });
    }

    if (Array.isArray(hostData.events)) {
      for (const evWrap of hostData.events) {
        if (!evWrap?.id || this.seenEventIds.has(evWrap.id)) continue;
        this.seenEventIds.add(evWrap.id);
        if (evWrap.fromId !== this.selfId) {
          this.cbs.onPacket({
            type: 'world:event',
            fromId: evWrap.fromId,
            event: evWrap.event,
            world: remoteRoom.world,
          });
        }
      }
    }

    if (Array.isArray(hostData.chats)) {
      for (const chatMsg of hostData.chats) {
        if (!chatMsg?.id || this.seenChatIds.has(chatMsg.id)) continue;
        this.seenChatIds.add(chatMsg.id);
        this.cbs.onPacket({ type: 'chat:message', message: chatMsg });
      }
    }

    if (Array.isArray(hostData.signals)) {
      for (const sig of hostData.signals) {
        if (!sig?.id || this.seenSignalIds.has(sig.id)) continue;
        this.seenSignalIds.add(sig.id);
        if (sig.toId === this.selfId) {
          this.cbs.onPacket({
            type: 'voice:signal',
            fromId: sig.fromId,
            signal: sig.signal,
          });
        }
      }
    }
  }

  public sendClientMessage(msg: Record<string, unknown>): void {
    const type = String(msg.type || '');
    if (type === 'room:diff' && this.hosting && this.room) {
      const diff = msg.diff as DifficultyKey;
      this.room.diff = diff;
      this.room.world.diff = diff;
      this.cbs.onPacket({ type: 'room:update', room: this.cloneRoom() });
      this.pushPresence();
      return;
    }

    if (type === 'game:start' && this.hosting && this.room) {
      const diff = (msg.diff as DifficultyKey) || this.room.diff;
      const theme = (msg.houseTheme as HouseTheme) || this.room.world.houseTheme || 'manor';
      this.room.diff = diff;
      this.room.phase = 'playing';
      this.room.world = createInitialWorld(diff, theme, this.room.world.roundId + 1);
      this.lastPhase = 'playing';
      const snap = this.cloneRoom();
      this.cbs.onPacket({ type: 'game:started', room: snap });
      this.pushPresence();
      return;
    }

    if (type === 'player:state') {
      const rest = { ...msg };
      delete rest.type;
      this.myPresence.peerState = {
        ...(this.myPresence.peerState || {}),
        ...(rest as Partial<MultiplayerPeer>),
      };
      if (this.hosting && this.room && this.selfId) {
        const selfPeer = this.room.peers.find((p) => p.id === this.selfId);
        if (selfPeer) Object.assign(selfPeer, rest);
      }
      this.pushPresence();
      return;
    }

    if (type === 'monsters:state' && this.hosting) {
      this.myPresence.monsters = msg.data;
      this.pushPresence();
      return;
    }

    if (type === 'world:event' && this.selfId) {
      const ev = (msg.event || {}) as Record<string, unknown>;
      const id = this.nextId('ev');
      this.seenEventIds.add(id);
      this.outEvents.push({ id, fromId: this.selfId, event: ev, ts: Date.now() });
      if (this.hosting && this.room) {
        this.applyWorldEventToRoom(ev);
      }
      this.pushPresence();
      return;
    }

    if (type === 'chat:send' && this.selfId) {
      const text = String(msg.text || '').trim().slice(0, 160);
      if (!text) return;
      const selfPeer = this.room?.peers.find((p) => p.id === this.selfId);
      const chatMsg: ChatMessage = {
        id: this.nextId('chat'),
        senderId: this.selfId,
        senderName: selfPeer?.name || this.playerName,
        colorIndex: selfPeer?.colorIndex || 0,
        text,
        ts: Date.now(),
      };
      this.seenChatIds.add(chatMsg.id);
      this.outChats.push({ msg: chatMsg, ts: Date.now() });
      if (this.hosting && this.room) {
        if (!this.room.messages) this.room.messages = [];
        this.room.messages.push(chatMsg);
        this.cbs.onPacket({ type: 'chat:message', message: chatMsg });
      }
      this.pushPresence();
      return;
    }

    if (type === 'voice:state' && this.selfId) {
      const active = Boolean(msg.active);
      this.myPresence.voiceActive = active;
      if (this.hosting && this.room) {
        const selfPeer = this.room.peers.find((p) => p.id === this.selfId);
        if (selfPeer) selfPeer.voiceActive = active;
        this.cbs.onPacket({ type: 'room:update', room: this.cloneRoom() });
      }
      this.pushPresence();
      return;
    }

    if (type === 'voice:signal' && this.selfId) {
      const toId = String(msg.toId || '');
      if (!toId) return;
      const id = this.nextId('sig');
      this.seenSignalIds.add(id);
      this.outSignals.push({
        id,
        fromId: this.selfId,
        toId,
        signal: msg.signal,
        ts: Date.now(),
      });
      this.pushPresence();
    }
  }

  public close(): void {
    this.closedByUs = true;
    if (this.sock) {
      try {
        this.sock.close();
      } catch {
        // ignore
      }
      this.sock = null;
    }
    if (this.hosting) {
      this.hosting = false;
      try {
        window.AndroidLan?.stopHost();
      } catch {
        // ignore
      }
    }
    this.room = null;
    this.selfId = null;
  }
}
