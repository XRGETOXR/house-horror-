export interface VoiceChatState {
  enabled: boolean;
  muted: boolean;
  speaking: boolean;
  activePeers: string[];
  error: string | null;
}

interface VoicePeerConn {
  pc: RTCPeerConnection;
  audio: HTMLAudioElement;
  makingOffer: boolean;
  ignoreOffer: boolean;
  senderAttached: boolean;
  remoteHasStream: boolean;
}

interface SignalPayload {
  sdp?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
}

export class VoiceChatManager {
  private selfId: string | null = null;
  private peerIds: string[] = [];
  private localStream: MediaStream | null = null;
  private peers = new Map<string, VoicePeerConn>();
  private enabled = false;
  private muted = false;
  private speaking = false;
  private error: string | null = null;
  private volume = 0.85;
  private sendSignal: (toId: string, signal: unknown) => void;
  private sendState: (active: boolean) => void;
  private onChange: (st: VoiceChatState) => void;

  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private meterTimer = 0;

  constructor(
    sendSignal: (toId: string, signal: unknown) => void,
    sendState: (active: boolean) => void,
    onChange: (st: VoiceChatState) => void
  ) {
    this.sendSignal = sendSignal;
    this.sendState = sendState;
    this.onChange = onChange;
  }

  public getState(): VoiceChatState {
    const activePeers: string[] = [];
    this.peers.forEach((rec, pid) => {
      if (rec.remoteHasStream) activePeers.push(pid);
    });
    return {
      enabled: this.enabled,
      muted: this.muted,
      speaking: this.speaking,
      activePeers,
      error: this.error,
    };
  }

  private emit(): void {
    this.onChange(this.getState());
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    this.peers.forEach((rec) => {
      rec.audio.volume = this.volume;
    });
  }

  public syncRoomPeers(selfId: string | null, peerIds: string[]): void {
    this.selfId = selfId;
    this.peerIds = peerIds.filter((id) => id && id !== selfId);

    // Remove departed peers
    for (const [pid, rec] of this.peers.entries()) {
      if (!this.peerIds.includes(pid)) {
        this.cleanupPeer(pid, rec);
      }
    }

    // If local mic is enabled, ensure connections exist with all current peers
    if (this.enabled && this.localStream) {
      for (const pid of this.peerIds) {
        const rec = this.ensurePeer(pid);
        this.attachLocalTrack(rec);
      }
    }
    this.emit();
  }

  public async toggleVoice(): Promise<void> {
    if (!this.enabled) {
      await this.enable();
    } else {
      this.setMuted(!this.muted);
    }
  }

  public async enable(): Promise<void> {
    if (this.enabled && this.localStream) {
      this.setMuted(false);
      return;
    }
    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      typeof navigator.mediaDevices.getUserMedia !== 'function'
    ) {
      this.error = 'المتصفح لا يدعم الميكروفون أو يحتاج اتصالاً آمناً';
      this.emit();
      return;
    }
    if (typeof RTCPeerConnection === 'undefined') {
      this.error = 'المتصفح لا يدعم المكالمات الصوتية (WebRTC)';
      this.emit();
      return;
    }

    this.error = null;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: false,
      });
      this.localStream = stream;
      this.enabled = true;
      this.muted = false;
      stream.getAudioTracks().forEach((t) => {
        t.enabled = true;
      });
      this.startMicMeter(stream);
      this.sendState(true);

      for (const pid of this.peerIds) {
        const rec = this.ensurePeer(pid);
        this.attachLocalTrack(rec);
      }
      this.emit();
    } catch {
      this.error = 'يرجى السماح بصلاحية الميكروفون للدردشة الصوتية';
      this.enabled = false;
      this.emit();
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.localStream) {
      this.localStream.getAudioTracks().forEach((t) => {
        t.enabled = !muted;
      });
    }
    if (muted) {
      this.speaking = false;
    }
    if (this.enabled) {
      this.sendState(!muted);
    }
    this.emit();
  }

  public stop(): void {
    const wasEnabled = this.enabled;
    this.enabled = false;
    this.muted = false;
    this.speaking = false;
    this.error = null;
    this.stopMicMeter();

    if (this.localStream) {
      this.localStream.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {
          // ignore
        }
      });
      this.localStream = null;
    }

    for (const [pid, rec] of this.peers.entries()) {
      this.cleanupPeer(pid, rec);
    }
    this.peers.clear();

    if (wasEnabled) {
      this.sendState(false);
    }
    this.emit();
  }

  private isPolite(peerId: string): boolean {
    if (!this.selfId) return true;
    return this.selfId > peerId;
  }

  private ensurePeer(peerId: string): VoicePeerConn {
    const existing = this.peers.get(peerId);
    if (existing) return existing;

    const isFileProto = typeof window !== 'undefined' && window.location.protocol === 'file:';
    const pc = new RTCPeerConnection({
      iceServers: isFileProto ? [] : [{ urls: 'stun:stun.l.google.com:19302' }],
    });

    const audio = document.createElement('audio');
    audio.autoplay = true;
    audio.setAttribute('playsinline', 'true');
    audio.volume = this.volume;

    const rec: VoicePeerConn = {
      pc,
      audio,
      makingOffer: false,
      ignoreOffer: false,
      senderAttached: false,
      remoteHasStream: false,
    };
    this.peers.set(peerId, rec);

    pc.onicecandidate = (ev) => {
      if (ev.candidate) {
        this.sendSignal(peerId, { candidate: ev.candidate.toJSON() });
      }
    };

    pc.onnegotiationneeded = async () => {
      try {
        rec.makingOffer = true;
        await pc.setLocalDescription();
        if (pc.localDescription) {
          this.sendSignal(peerId, { sdp: pc.localDescription });
        }
      } catch {
        // ignore transient negotiation errors
      } finally {
        rec.makingOffer = false;
      }
    };

    pc.ontrack = (ev) => {
      const [remoteStream] = ev.streams;
      if (remoteStream) {
        audio.srcObject = remoteStream;
      } else {
        const fallbackStream = new MediaStream([ev.track]);
        audio.srcObject = fallbackStream;
      }
      audio.play().catch(() => {});
      rec.remoteHasStream = true;
      this.emit();
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
        rec.remoteHasStream = false;
        this.emit();
      }
    };

    return rec;
  }

  private attachLocalTrack(rec: VoicePeerConn): void {
    if (!this.localStream || rec.senderAttached) return;
    const track = this.localStream.getAudioTracks()[0];
    if (!track) return;
    rec.senderAttached = true;
    rec.pc.addTrack(track, this.localStream);
  }

  public async handleSignal(fromId: string, rawSignal: unknown): Promise<void> {
    if (!fromId || fromId === this.selfId || typeof RTCPeerConnection === 'undefined') return;
    const signal = rawSignal as SignalPayload | null;
    if (!signal) return;

    const rec = this.ensurePeer(fromId);
    if (this.enabled && this.localStream) {
      this.attachLocalTrack(rec);
    }

    const pc = rec.pc;
    const polite = this.isPolite(fromId);

    try {
      if (signal.sdp) {
        const desc = new RTCSessionDescription(signal.sdp);
        const offerCollision =
          desc.type === 'offer' && (rec.makingOffer || pc.signalingState !== 'stable');
        rec.ignoreOffer = !polite && offerCollision;
        if (rec.ignoreOffer) return;

        await pc.setRemoteDescription(desc);
        if (desc.type === 'offer') {
          await pc.setLocalDescription();
          if (pc.localDescription) {
            this.sendSignal(fromId, { sdp: pc.localDescription });
          }
        }
      } else if (signal.candidate) {
        try {
          await pc.addIceCandidate(signal.candidate);
        } catch (err) {
          if (!rec.ignoreOffer) {
            throw err;
          }
        }
      }
    } catch {
      // ignore malformed or stale signaling packets
    }
  }

  private cleanupPeer(peerId: string, rec: VoicePeerConn): void {
    try {
      rec.pc.close();
    } catch {
      // ignore
    }
    try {
      rec.audio.pause();
      rec.audio.srcObject = null;
      rec.audio.remove();
    } catch {
      // ignore
    }
    this.peers.delete(peerId);
  }

  private startMicMeter(stream: MediaStream): void {
    this.stopMicMeter();
    try {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      const src = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      src.connect(analyser);
      this.audioCtx = ctx;
      this.analyser = analyser;

      const data = new Uint8Array(analyser.frequencyBinCount);
      this.meterTimer = window.setInterval(() => {
        if (!this.analyser || !this.enabled || this.muted) {
          if (this.speaking) {
            this.speaking = false;
            this.emit();
          }
          return;
        }
        this.analyser.getByteFrequencyData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) sum += data[i];
        const avg = sum / data.length;
        const nowSpeaking = avg > 14;
        if (nowSpeaking !== this.speaking) {
          this.speaking = nowSpeaking;
          this.emit();
        }
      }, 180);
    } catch {
      // ignore AudioContext meter fallback
    }
  }

  private stopMicMeter(): void {
    if (this.meterTimer) {
      window.clearInterval(this.meterTimer);
      this.meterTimer = 0;
    }
    if (this.audioCtx) {
      try {
        void this.audioCtx.close();
      } catch {
        // ignore
      }
      this.audioCtx = null;
      this.analyser = null;
    }
  }
}
