import type * as THREE from 'three';

export type GameState =
  | 'menu'
  | 'day'
  | 'wake'
  | 'play'
  | 'pad'
  | 'note'
  | 'paused'
  | 'dead'
  | 'spec'
  | 'cinema'
  | 'win';

export type DifficultyKey = 'practice' | 'easy' | 'med' | 'hard' | 'nightmare';

export type GfxQuality = 'low' | 'med' | 'high';

export type HouseTheme = 'manor' | 'classic';

export type TouchMode = 'auto' | 'on' | 'off';

export type HeldItemType =
  | 'hammer'
  | 'screwdriver'
  | 'cutters'
  | 'gun'
  | 'vase'
  | null;

export interface GameSettings {
  gfx: GfxQuality;
  sens: number;
  vol: number;
  bright: number;
  diff: DifficultyKey;
  houseTheme: HouseTheme;
  touchMode: TouchMode;
}

export interface RoomDef {
  id: string;
  name: string;
  x1: number;
  z1: number;
  x2: number;
  z2: number;
  cx: number;
  cz: number;
  fl: 0 | 1;
}

export interface Box2D {
  x1: number;
  x2: number;
  z1: number;
  z2: number;
  door?: boolean;
}

export interface HideSpot {
  x: number;
  z: number;
  w: number;
  d: number;
  box: Box2D;
  exit: { x: number; z: number };
  room: string;
  kind: 'closet' | 'crate' | 'bed';
  eye: number;
  fl: 0 | 1;
  peekSlits: boolean;
}

export interface SearchSpot {
  fl: 0 | 1;
  x: number;
  z: number;
  label: string;
  obj: THREE.Group;
  mat: THREE.MeshStandardMaterial;
  col: number;
  searched: boolean;
  key: boolean;
  item: 'gun' | 'ham' | 'cutters' | 'ammo' | null;
  n?: number;
  special: boolean;
  hide: boolean;
  r: number;
  furnitureKind?: 'crate' | 'drawer' | 'cabinet' | 'shelf' | 'dresser' | 'vanity';
  nearDoor?: boolean;
}

export interface DroppedProp {
  id: number;
  kind: Exclude<HeldItemType, null>;
  fl: 0 | 1;
  x: number;
  y: number;
  z: number;
  vy: number;
  mesh: THREE.Group;
  label: string;
  active: boolean;
}

export interface BearTrap {
  id: number;
  fl: 0 | 1;
  x: number;
  z: number;
  mesh: THREE.Group;
  jawL: THREE.Mesh;
  jawR: THREE.Mesh;
  armed: boolean;
}

export interface CreakBoard {
  fl: 0 | 1;
  x: number;
  z: number;
  w: number;
  d: number;
  cooldown: number;
}

export interface DoorDef {
  fl: 0 | 1;
  ax: 'x' | 'z';
  fixed: number;
  c: number;
  piv: THREE.Group;
  handleGroup: THREE.Group;
  box: Box2D;
  ang: number;
  target: number;
  side: number;
  solid: boolean;
  cx: number;
  cz: number;
  handleAnim: number;
  handleMode: 'open' | 'rattle';
  doorRattle: number;
  jamTimer: number;
  jamCooldown: number;
}

export interface DiaryNoteWorldItem {
  id: string;
  title: string;
  fl: 0 | 1;
  x: number;
  z: number;
  mesh: THREE.Group;
  glow: THREE.Sprite;
  read: boolean;
}

export interface HandMapWorldItem {
  fl: 0 | 1;
  x: number;
  z: number;
  mesh: THREE.Group;
  sheet: THREE.Group;
  glow: THREE.Sprite;
  found: boolean;
}

export interface TorchPickupWorldItem {
  index: number;
  ownerRole: 'host' | 'guest';
  fl: 0 | 1;
  x: number;
  y: number;
  z: number;
  mesh: THREE.Group;
  glow: THREE.Sprite;
  taken: boolean;
}

export interface ExitLocks {
  plankBroken: boolean;
  wireCut: boolean;
  panelOpened: boolean;
  keysUsed: boolean;
}

export interface MultiplayerPeer {
  id: string;
  name: string;
  colorIndex: number;
  x: number;
  y: number;
  z: number;
  yaw: number;
  fl: 0 | 1;
  crouch: boolean;
  torch: boolean;
  hiddenIdx: number;
  heldItem: HeldItemType;
  alive: boolean;
  escaped: boolean;
  day: number;
  speed: number;
  voiceActive?: boolean;
}

export interface RoomWorldSnapshot {
  roundId: number;
  diff: DifficultyKey;
  houseTheme?: HouseTheme;
  safeCode: number;
  keySeed: number;
  giantRoll: number;
  searchedSpots: number[];
  plankBroken: boolean;
  wireCut: boolean;
  panelOpened: boolean;
  safeOpen: boolean;
  doorOpen: boolean;
  takenTorches?: number[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  colorIndex: number;
  text: string;
  ts: number;
  system?: boolean;
}

export interface PublicRoomSummary {
  code: string;
  serverName: string;
  hostName: string;
  diff: DifficultyKey;
  houseTheme?: HouseTheme;
  phase: 'lobby' | 'playing';
  playerCount: number;
  maxPlayers: number;
  createdAt: number;
}

export interface MultiplayerRoomSnapshot {
  code: string;
  serverName?: string;
  hostName?: string;
  hostId: string;
  phase: 'lobby' | 'playing';
  diff: DifficultyKey;
  world: RoomWorldSnapshot;
  peers: MultiplayerPeer[];
  messages?: ChatMessage[];
}

export interface HudState {
  state: GameState;
  houseTheme: HouseTheme;
  day: number;
  maxDays: number;
  livesLeft: number;
  roomName: string;
  floor: 0 | 1;
  keys: number;
  needKeys: number;
  ammo: number;
  hasGun: boolean;
  heldItem: HeldItemType;
  heldLabel: string;
  codeKnown: boolean;
  safeCode: number;
  safeOpen: boolean;
  locks: ExitLocks;
  doorOpen: boolean;
  stamina: number;
  exhausted: boolean;
  crouch: boolean;
  hasTorch: boolean;
  torch: boolean;
  hidden: boolean;
  hiddenKind: 'closet' | 'crate' | 'bed' | null;
  trappedTimer: number;
  trapProgress: number;
  stalkerState: 'patrol' | 'investigate' | 'chase' | 'hideCheck' | 'stunned';
  stalkerStunLeft: number;
  threat: number;
  prompt: string;
  toast: string;
  toastId: number;
  exitArrowAngle: number | null;
  exitArrowText: string;
  mapOpen: boolean;
  hasMap: boolean;
  notesRead: string[];
  activeNoteId: string | null;
  totalNotes: number;
  mpConnected: boolean;
  mpRoomCode: string | null;
  mpIsHost: boolean;
  mpPeers: MultiplayerPeer[];
  mpSpectatingName: string | null;
  revivingTargetName: string | null;
  revivingTimeLeft: number;
  revivingProgress: number;
  playerX: number;
  playerZ: number;
  playerYaw: number;
  timeSeconds: number;
  hidesCount: number;
  chasesCount: number;
  trapsTriggered: number;
  killer: 'hammer' | 'giant' | 'closet' | 'trap' | null;
  dayPhase: 'start' | 'death' | 'final';
  dayCross: boolean;
  daySub: string;
  cinemaCaption: string;
  cinemaBig: boolean;
  cinemaFlash: number;
  cinemaBars: boolean;
  lidOpacity: number;
  hitFlash: number;
  dangerOpacity: number;
}
