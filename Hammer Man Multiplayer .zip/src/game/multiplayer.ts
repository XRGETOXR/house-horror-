import {
  AndroidLanManager,
  getAndroidLanGames,
  hasAndroidLanBridge,
} from './androidLan';
import { LanRtcManager } from './lanRtc';
import {
  ChatMessage,
  DifficultyKey,
  HouseTheme,
  MultiplayerPeer,
  MultiplayerRoomSnapshot,
  PublicRoomSummary,
  RoomWorldSnapshot,
} from './types';

export interface MonsterNetPayload {
  h: [number, number, 0 | 1, number, number, number, number, number, number, number, number];
  g: [number, number, number, number, number, number, number, number];
}

export interface MultiplayerCallbacks {
  onRoomsList?: (rooms: PublicRoomSummary[]) => void;
  onRoomChange: (room: MultiplayerRoomSnapshot | null, selfId: string | null) => void;
  onGameStarted: (room: MultiplayerRoomSnapshot) => void;
  onPeerState: (peer: MultiplayerPeer) => void;
  onMonstersState: (data: MonsterNetPayload) => void;
  onWorldEvent: (
    fromId: string,
    event: Record<string, unknown>,
    world: RoomWorldSnapshot
  ) => void;
  onChatMessage: (message: ChatMessage) => void;
  onVoiceSignal?: (fromId: string, signal: unknown) => void;
  onError: (msg: string) => void;
}

function normalizeWsUrl(raw: string | null): string | null {
  const trimmed = (raw || '').trim();
  if (!trimmed) return null;

  let withProto = trimmed;
  if (/^https?:\/\//i.test(withProto)) {
    withProto = withProto.replace(/^http/i, 'ws');
  } else if (!/^wss?:\/\//i.test(withProto)) {
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    withProto = `${proto}//${withProto}`;
  }

  try {
    const u = new URL(withProto);
    if (!u.port && !trimmed.includes(':') && u.protocol === 'ws:') {
      u.port = '3000';
    }
    if (!u.pathname || u.pathname === '/') {
      u.pathname = '/ws';
    }
    return u.toString();
  } catch {
    return null;
  }
}

export class MultiplayerClient {
  private ws: WebSocket | null = null;
  private lan: LanRtcManager;
  private androidLan: AndroidLanManager;
  private customWsUrl: string | null = null;
  private cbs: MultiplayerCallbacks;
  public selfId: string | null = null;
  public room: MultiplayerRoomSnapshot | null = null;
  public connected = false;
  private pendingAction: (() => void) | null = null;

  constructor(cbs: MultiplayerCallbacks) {
    this.cbs = cbs;
    this.lan = new LanRtcManager({
      onOpen: () => {
        this.connected = true;
      },
      onPacket: (pkt) => {
        this.handleIncomingPacket(pkt);
      },
      onError: (msg) => {
        this.cbs.onError(msg);
      },
      onClose: () => {
        this.connected = false;
        this.room = null;
        this.cbs.onRoomChange(null, this.selfId);
      },
    });
    this.androidLan = new AndroidLanManager({
      onOpen: () => {
        this.connected = true;
      },
      onPacket: (pkt) => {
        this.handleIncomingPacket(pkt);
      },
      onError: (msg) => {
        this.cbs.onError(msg);
      },
      onClose: () => {
        this.connected = false;
        this.room = null;
        this.cbs.onRoomChange(null, this.selfId);
      },
    });
  }

  public get isHost(): boolean {
    return Boolean(this.room && this.selfId && this.room.hostId === this.selfId);
  }

  public get isLanDirect(): boolean {
    return this.lan.active || this.androidLan.active;
  }

  public setCustomServerUrl(rawUrl: string | null): void {
    this.customWsUrl = normalizeWsUrl(rawUrl);
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
      this.connected = false;
    }
  }

  private handleIncomingPacket(msg: Record<string, unknown>): void {
    const type = String(msg.type || '');
    if (type === 'rooms:list') {
      const list = Array.isArray(msg.rooms) ? (msg.rooms as PublicRoomSummary[]) : [];
      this.cbs.onRoomsList?.(list);
    } else if (type === 'room:joined') {
      this.selfId = String(msg.selfId || '');
      this.room = msg.room as MultiplayerRoomSnapshot;
      this.cbs.onRoomChange(this.room, this.selfId);
    } else if (type === 'room:update') {
      this.room = msg.room as MultiplayerRoomSnapshot;
      this.cbs.onRoomChange(this.room, this.selfId);
    } else if (type === 'room:left') {
      this.room = null;
      this.cbs.onRoomChange(null, this.selfId);
    } else if (type === 'room:error') {
      this.cbs.onError(String(msg.message || 'تعذر الاتصال بالسيرفر'));
    } else if (type === 'game:started') {
      this.room = msg.room as MultiplayerRoomSnapshot;
      this.cbs.onRoomChange(this.room, this.selfId);
      this.cbs.onGameStarted(this.room);
    } else if (type === 'peer:state') {
      const peer = msg.peer as MultiplayerPeer;
      if (this.room) {
        const idx = this.room.peers.findIndex((p) => p.id === peer.id);
        if (idx >= 0) this.room.peers[idx] = peer;
        else this.room.peers.push(peer);
      }
      this.cbs.onPeerState(peer);
    } else if (type === 'monsters:state') {
      this.cbs.onMonstersState(msg.data as MonsterNetPayload);
    } else if (type === 'world:event') {
      const world = msg.world as RoomWorldSnapshot;
      if (this.room && world) this.room.world = world;
      this.cbs.onWorldEvent(
        String(msg.fromId || ''),
        (msg.event || {}) as Record<string, unknown>,
        world
      );
    } else if (type === 'chat:message') {
      const chatMsg = msg.message as ChatMessage;
      if (chatMsg && chatMsg.id) {
        if (this.room) {
          if (!this.room.messages) this.room.messages = [];
          if (!this.room.messages.some((m) => m.id === chatMsg.id)) {
            this.room.messages.push(chatMsg);
            if (this.room.messages.length > 60) {
              this.room.messages.splice(0, this.room.messages.length - 60);
            }
          }
        }
        this.cbs.onChatMessage(chatMsg);
      }
    } else if (type === 'voice:signal') {
      this.cbs.onVoiceSignal?.(String(msg.fromId || ''), msg.signal);
    }
  }

  private ensureSocket(onOpenAction?: () => void, silentIfLocalFile = false): void {
    if (this.lan.active) {
      this.lan.close();
    }
    if (this.androidLan.active) {
      this.androidLan.close();
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      onOpenAction?.();
      return;
    }
    this.pendingAction = onOpenAction || null;
    if (this.ws && this.ws.readyState === WebSocket.CONNECTING) {
      return;
    }

    if (window.location.protocol === 'file:' && !this.customWsUrl) {
      if (!silentIfLocalFile) {
        this.cbs.onError(
          'في النسخة المحمولة، استخدم تبويب «بدون نت (نقطة اتصال)» أو أدخل عنوان IP للخادم المحلي'
        );
      }
      return;
    }

    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = this.customWsUrl || `${proto}//${window.location.host}/ws`;
    let ws: WebSocket;
    try {
      ws = new WebSocket(url);
    } catch {
      this.cbs.onError('عنوان الخادم غير صالح');
      return;
    }
    this.ws = ws;

    ws.onopen = () => {
      this.connected = true;
      const act = this.pendingAction;
      this.pendingAction = null;
      act?.();
    };

    ws.onmessage = (ev) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(ev.data)) as Record<string, unknown>;
      } catch {
        return;
      }
      this.handleIncomingPacket(msg);
    };

    ws.onerror = () => {
      this.cbs.onError(
        this.customWsUrl
          ? `فشل الاتصال بخادم نقطة الاتصال (${this.customWsUrl})`
          : 'فشل الاتصال بخادم اللعب الجماعي'
      );
    };

    ws.onclose = () => {
      this.connected = false;
      this.ws = null;
    };
  }

  private send(payload: Record<string, unknown>): void {
    if (this.androidLan.active) {
      this.androidLan.sendClientMessage(payload);
      return;
    }
    if (this.lan.active) {
      this.lan.sendClientMessage(payload);
      return;
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  public refreshRooms(silent = false): void {
    if (this.lan.active || this.androidLan.active) return;
    if (hasAndroidLanBridge()) {
      this.cbs.onRoomsList?.(getAndroidLanGames());
      if (window.location.protocol === 'file:' && !this.customWsUrl) {
        return;
      }
    }
    if (window.location.protocol === 'file:' && !this.customWsUrl && silent) {
      return;
    }
    this.ensureSocket(() => {
      this.send({ type: 'rooms:list' });
    }, silent);
  }

  public createRoom(
    name: string,
    diff: DifficultyKey,
    serverName?: string,
    houseTheme: HouseTheme = 'manor'
  ): void {
    if (hasAndroidLanBridge() && !this.customWsUrl) {
      this.androidLan.startHosting(name, diff, serverName, houseTheme);
      return;
    }
    this.ensureSocket(() => {
      this.send({ type: 'room:create', name, diff, serverName, houseTheme });
    });
  }

  public joinRoom(code: string, name: string): void {
    if (code.startsWith('ALAN:') || (hasAndroidLanBridge() && /^[0-9.]+$/.test(code.trim()))) {
      this.androidLan.joinIp(code, name);
      return;
    }
    this.ensureSocket(() => {
      this.send({ type: 'room:join', code, name });
    });
  }

  public async createLanInvite(name: string, diff: DifficultyKey): Promise<string> {
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
    return this.lan.createHostOffer(name, diff);
  }

  public async acceptLanReply(replyCode: string): Promise<void> {
    return this.lan.acceptGuestAnswer(replyCode);
  }

  public async joinLanInvite(inviteCode: string, name: string): Promise<string> {
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
    return this.lan.joinWithHostOffer(inviteCode, name);
  }

  public setDifficulty(diff: DifficultyKey): void {
    if (!this.isHost) return;
    this.send({ type: 'room:diff', diff });
  }

  public startGame(diff: DifficultyKey, houseTheme: HouseTheme = 'manor'): void {
    if (!this.isHost) return;
    this.send({ type: 'game:start', diff, houseTheme });
  }

  public leaveRoom(): void {
    if (this.androidLan.active) {
      this.androidLan.close();
    } else if (this.lan.active) {
      this.lan.sendClientMessage({ type: 'room:leave' });
      this.lan.close();
    } else if (this.room) {
      this.send({ type: 'room:leave' });
    }
    this.room = null;
    this.connected = false;
    this.cbs.onRoomChange(null, this.selfId);
  }

  public sendPlayerState(st: Record<string, unknown>): void {
    if (!this.room) return;
    this.send({ type: 'player:state', ...st });
  }

  public sendMonstersState(data: MonsterNetPayload): void {
    if (!this.room || !this.isHost) return;
    this.send({ type: 'monsters:state', data });
  }

  public sendWorldEvent(event: Record<string, unknown>): void {
    if (!this.room) return;
    this.send({ type: 'world:event', event });
  }

  public sendChat(text: string): void {
    if (!this.room) return;
    const clean = text.trim().slice(0, 160);
    if (!clean) return;
    this.send({ type: 'chat:send', text: clean });
  }

  public sendVoiceState(active: boolean): void {
    if (!this.room) return;
    this.send({ type: 'voice:state', active });
  }

  public sendVoiceSignal(toId: string, signal: unknown): void {
    if (!this.room || !toId) return;
    this.send({ type: 'voice:signal', toId, signal });
  }

  public dispose(): void {
    this.androidLan.close();
    this.lan.close();
    try {
      this.ws?.close();
    } catch {
      // ignore
    }
    this.ws = null;
    this.room = null;
    this.connected = false;
  }
}
