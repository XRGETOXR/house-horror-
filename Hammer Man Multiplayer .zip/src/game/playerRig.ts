import * as THREE from 'three';
import { HeldItemType } from './types';

export interface PlayerSurvivorRig {
  group: THREE.Group;
  bodyGroup: THREE.Group;
  head: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  beamMesh: THREE.Mesh;
  torchGlow: THREE.Sprite;
  muzzleFlash: THREE.Sprite;
  auraGlow: THREE.Sprite;
  trimColor: number;
  toolMeshes: Record<Exclude<HeldItemType, null>, THREE.Group>;
  nameSprite: THREE.Sprite;
  nameText: string;
  walkPhase: number;
  idlePhase: number;
  recoilTimer: number;
}

const JACKET_PALETTES = [
  { jacket: 0x2b7a9b, trim: 0x8be4ff, pack: 0x46392c, hair: 0x1e1510, eye: 0x2a4d69 }, // Teal survivor
  { jacket: 0xc27a2c, trim: 0xffd584, pack: 0x3b2f26, hair: 0x2f1d12, eye: 0x4a3520 }, // Amber survivor
  { jacket: 0x388c5d, trim: 0x8effb8, pack: 0x363628, hair: 0x171413, eye: 0x254b38 }, // Emerald survivor
  { jacket: 0x9b4260, trim: 0xffa6c4, pack: 0x352930, hair: 0x3b1f1c, eye: 0x422a3d }, // Crimson-plum survivor
];

function createNameTagTexture(name: string, status = ''): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 384;
  canvas.height = 96;
  const g = canvas.getContext('2d')!;
  g.clearRect(0, 0, 384, 96);

  const isDowned =
    status.includes('سقط') || status.includes('جثة') || status.includes('إنعاش');
  g.fillStyle = isDowned ? 'rgba(42, 8, 6, 0.92)' : 'rgba(10, 8, 8, 0.86)';
  g.strokeStyle = isDowned ? 'rgba(255, 96, 74, 0.95)' : 'rgba(139, 228, 255, 0.85)';
  g.lineWidth = 3;
  g.beginPath();
  g.roundRect(24, 16, 336, 64, 12);
  g.fill();
  g.stroke();

  g.textAlign = 'center';
  g.textBaseline = 'middle';
  g.fillStyle = '#f4efe6';
  g.font = 'bold 30px Tajawal, sans-serif';
  const label = status ? `${name} · ${status}` : name;
  g.fillText(label, 192, 49);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createSurvivorRig(
  name: string,
  colorIndex: number,
  skinTex: THREE.Texture,
  glowTex: THREE.Texture
): PlayerSurvivorRig {
  const palette = JACKET_PALETTES[Math.abs(colorIndex) % JACKET_PALETTES.length];
  const group = new THREE.Group();
  const bodyGroup = new THREE.Group();
  group.add(bodyGroup);

  const mk = (
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    x: number,
    y: number,
    z: number
  ): THREE.Mesh => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    return m;
  };

  const jacketMat = new THREE.MeshStandardMaterial({
    color: palette.jacket,
    roughness: 0.76,
    metalness: 0.06,
  });
  const trimMat = new THREE.MeshStandardMaterial({
    color: palette.trim,
    emissive: palette.trim,
    emissiveIntensity: 0.25,
    roughness: 0.45,
  });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0x242833, roughness: 0.88 });
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x151210, roughness: 0.86 });
  const packMat = new THREE.MeshStandardMaterial({ color: palette.pack, roughness: 0.84 });
  const skinMat = new THREE.MeshStandardMaterial({ map: skinTex, roughness: 0.68 });
  const hairMat = new THREE.MeshStandardMaterial({ color: palette.hair, roughness: 0.9 });
  const eyeWhite = new THREE.MeshBasicMaterial({ color: 0xf4f4f0 });
  const eyeIris = new THREE.MeshBasicMaterial({ color: palette.eye });
  const eyePupil = new THREE.MeshBasicMaterial({ color: 0x0e1014 });
  const lipMat = new THREE.MeshStandardMaterial({ color: 0x8b5b52, roughness: 0.72 });

  // ---------- Organic Sculpted Torso, Shoulders & Survival Backpack ----------
  // Tapered anatomically contoured jacket torso (elliptical cylinder)
  const chest = mk(new THREE.CylinderGeometry(0.205, 0.162, 0.56, 16), jacketMat, 0, 1.13, 0);
  chest.scale.set(1.12, 1, 0.72);
  bodyGroup.add(chest);

  // Rounded trapezius / collar mantle + high coat collar
  const shoulders = mk(new THREE.CylinderGeometry(0.115, 0.205, 0.14, 14), jacketMat, 0, 1.42, 0);
  shoulders.scale.set(1.12, 1, 0.74);
  bodyGroup.add(shoulders);
  const collar = mk(
    new THREE.CylinderGeometry(0.102, 0.112, 0.08, 14, 1, true),
    jacketMat,
    0,
    1.46,
    -0.01
  );
  bodyGroup.add(collar);

  // Rounded shoulder caps so arms meet torso naturally
  [-1, 1].forEach((sx) => {
    const cap = mk(new THREE.SphereGeometry(0.095, 12, 10), jacketMat, sx * 0.23, 1.35, 0);
    cap.scale.set(1, 0.95, 0.88);
    bodyGroup.add(cap);
  });

  // High-visibility chest ring & front zipper strip
  const chestBand = mk(new THREE.CylinderGeometry(0.202, 0.194, 0.045, 16), trimMat, 0, 1.32, 0);
  chestBand.scale.set(1.13, 1, 0.74);
  bodyGroup.add(chestBand);
  bodyGroup.add(mk(new THREE.CapsuleGeometry(0.016, 0.42, 4, 8), trimMat, 0, 1.13, 0.145));

  // Rounded waist belt + brass buckle + side utility pouch
  const belt = mk(new THREE.CylinderGeometry(0.17, 0.172, 0.065, 16), bootMat, 0, 0.86, 0);
  belt.scale.set(1.12, 1, 0.74);
  bodyGroup.add(belt);
  bodyGroup.add(mk(new THREE.CylinderGeometry(0.036, 0.036, 0.055, 10), trimMat, 0, 0.86, 0.132));
  const pouch = mk(new THREE.CapsuleGeometry(0.042, 0.05, 4, 8), packMat, -0.2, 0.84, 0.03);
  bodyGroup.add(pouch);

  // Sculpted Survival Backpack (-Z back) with rounded top & bedroll
  const packMain = mk(new THREE.CylinderGeometry(0.145, 0.155, 0.38, 12), packMat, 0, 1.15, -0.18);
  packMain.scale.set(1.08, 1, 0.65);
  bodyGroup.add(packMain);
  const packDome = mk(new THREE.SphereGeometry(0.145, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.5), packMat, 0, 1.34, -0.18);
  packDome.scale.set(1.08, 0.65, 0.65);
  bodyGroup.add(packDome);
  const bedroll = mk(new THREE.CylinderGeometry(0.055, 0.055, 0.34, 10), trimMat, 0, 1.43, -0.19);
  bedroll.rotation.z = Math.PI / 2;
  bodyGroup.add(bedroll);
  // Curved shoulder straps
  [-0.1, 0.1].forEach((sx) => {
    const strap = mk(new THREE.CapsuleGeometry(0.022, 0.34, 4, 8), bootMat, sx, 1.19, 0.0);
    strap.scale.set(1.1, 1, 4.6);
    bodyGroup.add(strap);
  });

  // ---------- Sculpted Human Head & Face (facing +Z, zero square blocks) ----------
  const neck = mk(new THREE.CylinderGeometry(0.06, 0.072, 0.15, 12), skinMat, 0, 1.49, 0.01);
  bodyGroup.add(neck);

  const head = new THREE.Group();
  head.position.set(0, 1.63, 0.015);

  // Smooth anatomical cranium + slightly tapered jaw
  const cranium = mk(new THREE.SphereGeometry(0.144, 18, 14), skinMat, 0, 0.02, 0);
  cranium.scale.set(0.92, 1.1, 0.98);
  head.add(cranium);

  const jaw = mk(new THREE.SphereGeometry(0.105, 14, 10), skinMat, 0, -0.055, 0.032);
  jaw.scale.set(0.92, 0.96, 0.98);
  head.add(jaw);

  // Ears
  [-1, 1].forEach((sx) => {
    const ear = mk(new THREE.SphereGeometry(0.032, 8, 8), skinMat, sx * 0.132, 0.0, -0.01);
    ear.scale.set(0.45, 1.0, 0.78);
    head.add(ear);
  });

  // Sculpted nose & lips
  const nose = mk(new THREE.CapsuleGeometry(0.016, 0.035, 4, 8), skinMat, 0, 0.005, 0.138);
  nose.rotation.x = -0.35;
  head.add(nose);
  const mouth = mk(new THREE.CapsuleGeometry(0.009, 0.042, 4, 8), lipMat, 0, -0.068, 0.128);
  mouth.rotation.z = Math.PI / 2;
  head.add(mouth);

  // Natural layered eyes (sclera, iris, pupil, curved brow)
  [-0.05, 0.05].forEach((ex) => {
    const sclera = mk(new THREE.SphereGeometry(0.025, 10, 8), eyeWhite, ex, 0.032, 0.122);
    sclera.scale.set(1.15, 0.85, 0.55);
    head.add(sclera);

    const iris = mk(new THREE.SphereGeometry(0.014, 8, 8), eyeIris, ex, 0.032, 0.133);
    iris.scale.set(1, 1, 0.45);
    head.add(iris);

    const pupil = mk(new THREE.SphereGeometry(0.008, 8, 8), eyePupil, ex, 0.032, 0.137);
    pupil.scale.set(1, 1, 0.45);
    head.add(pupil);

    const brow = mk(new THREE.CapsuleGeometry(0.008, 0.044, 4, 6), hairMat, ex, 0.066, 0.124);
    brow.rotation.z = Math.PI / 2 + (ex < 0 ? -0.1 : 0.1);
    head.add(brow);
  });

  // Rounded hair cap + back hair taper (natural organic crown)
  const hairTop = mk(
    new THREE.SphereGeometry(0.149, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.58),
    hairMat,
    0,
    0.032,
    -0.012
  );
  hairTop.scale.set(0.94, 1.06, 1.02);
  hairTop.rotation.x = -0.22;
  head.add(hairTop);
  const hairBack = mk(new THREE.SphereGeometry(0.128, 14, 10), hairMat, 0, -0.01, -0.042);
  hairBack.scale.set(0.98, 1.08, 0.86);
  head.add(hairBack);

  bodyGroup.add(head);

  // ---------- Articulated Sculpted Arms & Hands ----------
  const buildArmBase = (armGroup: THREE.Group) => {
    const upper = mk(new THREE.CylinderGeometry(0.066, 0.056, 0.25, 12), jacketMat, 0, -0.125, 0);
    armGroup.add(upper);
    armGroup.add(mk(new THREE.SphereGeometry(0.055, 10, 8), jacketMat, 0, -0.25, 0));
    const fore = mk(new THREE.CylinderGeometry(0.054, 0.044, 0.22, 12), jacketMat, 0, -0.36, 0.015);
    fore.rotation.x = -0.12;
    armGroup.add(fore);
    const cuff = mk(new THREE.CylinderGeometry(0.048, 0.048, 0.03, 12), bootMat, 0, -0.46, 0.028);
    cuff.rotation.x = -0.12;
    armGroup.add(cuff);
    const palm = mk(new THREE.SphereGeometry(0.048, 10, 8), skinMat, 0, -0.51, 0.04);
    palm.scale.set(0.85, 1.15, 0.74);
    armGroup.add(palm);
  };

  // Left Arm + Cylindrical Flashlight & Volumetric Light Cone
  const armL = new THREE.Group();
  armL.position.set(0.275, 1.35, 0);
  buildArmBase(armL);

  const flashBody = new THREE.Group();
  flashBody.position.set(0, -0.51, 0.14);
  const fCyl = mk(
    new THREE.CylinderGeometry(0.034, 0.028, 0.23, 12),
    new THREE.MeshStandardMaterial({ color: 0x333842, metalness: 0.72, roughness: 0.34 }),
    0,
    0,
    0
  );
  fCyl.rotation.x = Math.PI / 2;
  flashBody.add(fCyl);
  const lens = mk(
    new THREE.CylinderGeometry(0.04, 0.034, 0.03, 12),
    new THREE.MeshBasicMaterial({ color: 0xfff2be }),
    0,
    0,
    0.125
  );
  lens.rotation.x = Math.PI / 2;
  flashBody.add(lens);

  const beamGeo = new THREE.ConeGeometry(0.65, 3.2, 14, 1, true);
  beamGeo.translate(0, -1.6, 0);
  beamGeo.rotateX(-Math.PI / 2);
  const beamMat = new THREE.MeshBasicMaterial({
    color: 0xffe8b0,
    transparent: true,
    opacity: 0.18,
    side: THREE.DoubleSide,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const beamMesh = new THREE.Mesh(beamGeo, beamMat);
  beamMesh.position.set(0, 0, 0.14);
  flashBody.add(beamMesh);

  const torchGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTex,
      color: 0xffe6a3,
      transparent: true,
      opacity: 0.88,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  torchGlow.scale.set(0.7, 0.7, 1);
  torchGlow.position.set(0, 0, 0.16);
  flashBody.add(torchGlow);
  armL.add(flashBody);
  armL.rotation.x = -0.95;
  bodyGroup.add(armL);

  // Right Arm + Held Item Meshes
  const armR = new THREE.Group();
  armR.position.set(-0.275, 1.35, 0);
  buildArmBase(armR);

  const handAnchor = new THREE.Group();
  handAnchor.position.set(0, -0.51, 0.12);
  armR.add(handAnchor);

  const metalM = new THREE.MeshStandardMaterial({ color: 0x383d46, roughness: 0.3, metalness: 0.85 });
  const woodM = new THREE.MeshStandardMaterial({ color: 0x624026, roughness: 0.85 });
  const redM = new THREE.MeshStandardMaterial({ color: 0xb82e24, roughness: 0.5 });
  const ceramicM = new THREE.MeshStandardMaterial({ color: 0xd0bfa8, roughness: 0.35 });

  const hammerG = new THREE.Group();
  const hShaft = mk(new THREE.CylinderGeometry(0.022, 0.022, 0.42, 8), woodM, 0, 0.16, 0.04);
  hShaft.rotation.x = 0.45;
  hammerG.add(hShaft);
  hammerG.add(mk(new THREE.BoxGeometry(0.08, 0.09, 0.2), metalM, 0, 0.34, 0.12));

  const cuttersG = new THREE.Group();
  cuttersG.add(mk(new THREE.CylinderGeometry(0.014, 0.014, 0.24, 8), redM, 0.025, 0, 0.08).rotateX(Math.PI / 2));
  cuttersG.add(mk(new THREE.CylinderGeometry(0.014, 0.014, 0.24, 8), redM, -0.025, 0, 0.08).rotateX(Math.PI / 2));
  cuttersG.add(mk(new THREE.BoxGeometry(0.07, 0.04, 0.12), metalM, 0, 0, 0.22));

  const screwG = new THREE.Group();
  const sh1 = mk(new THREE.CylinderGeometry(0.022, 0.02, 0.16, 8), redM, 0, 0, 0.04);
  sh1.rotation.x = Math.PI / 2;
  const sh2 = mk(new THREE.CylinderGeometry(0.008, 0.008, 0.22, 8), metalM, 0, 0, 0.2);
  sh2.rotation.x = Math.PI / 2;
  screwG.add(sh1, sh2);

  const gunG = new THREE.Group();
  gunG.add(mk(new THREE.BoxGeometry(0.046, 0.056, 0.28), metalM, 0, 0.05, 0.1));
  gunG.add(mk(new THREE.BoxGeometry(0.044, 0.13, 0.056), woodM, 0, -0.02, 0.02));
  const muzzleFlash = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTex,
      color: 0xffd166,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  muzzleFlash.scale.set(0.62, 0.62, 1);
  muzzleFlash.position.set(0, 0.055, 0.27);
  muzzleFlash.visible = false;
  gunG.add(muzzleFlash);

  const vaseG = new THREE.Group();
  vaseG.add(mk(new THREE.CylinderGeometry(0.095, 0.07, 0.28, 14), ceramicM, 0, 0.08, 0.12));

  const toolMeshes: Record<Exclude<HeldItemType, null>, THREE.Group> = {
    hammer: hammerG,
    cutters: cuttersG,
    screwdriver: screwG,
    gun: gunG,
    vase: vaseG,
  };
  Object.values(toolMeshes).forEach((tm) => {
    tm.visible = false;
    handAnchor.add(tm);
  });
  bodyGroup.add(armR);

  // ---------- Articulated Sculpted Legs & Hiking Boots ----------
  const buildLeg = (sx: number): THREE.Group => {
    const leg = new THREE.Group();
    leg.position.set(sx * 0.115, 0.84, 0);

    // Thigh + knee + tapered calf
    const thigh = mk(new THREE.CylinderGeometry(0.09, 0.074, 0.38, 12), pantsMat, 0, -0.19, 0);
    leg.add(thigh);
    leg.add(mk(new THREE.SphereGeometry(0.072, 10, 8), pantsMat, 0, -0.38, 0.005));
    const calf = mk(new THREE.CylinderGeometry(0.07, 0.054, 0.34, 12), pantsMat, 0, -0.55, 0);
    leg.add(calf);

    // Ankle cuff + sculpted capsule boot
    leg.add(mk(new THREE.CylinderGeometry(0.06, 0.064, 0.11, 10), bootMat, 0, -0.71, 0));
    const foot = mk(new THREE.CapsuleGeometry(0.062, 0.13, 6, 10), bootMat, 0, -0.78, 0.05);
    foot.rotation.x = Math.PI / 2;
    foot.scale.set(1.06, 1, 0.82);
    leg.add(foot);

    return leg;
  };

  const legL = buildLeg(1);
  const legR = buildLeg(-1);
  bodyGroup.add(legL, legR);

  // Soft teammate silhouette aura so player is visible down dim hallways
  const auraGlow = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTex,
      color: palette.trim,
      transparent: true,
      opacity: 0.24,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
  );
  auraGlow.scale.set(1.45, 2.15, 1);
  auraGlow.position.set(0, 1.15, 0);
  group.add(auraGlow);

  // Crisp floating Arabic Nameplate above head
  const nameSprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: createNameTagTexture(name),
      transparent: true,
      depthTest: true,
    })
  );
  nameSprite.scale.set(1.65, 0.42, 1);
  nameSprite.position.set(0, 2.15, 0);
  group.add(nameSprite);

  group.traverse((obj) => {
    if (
      obj instanceof THREE.Mesh &&
      obj !== beamMesh &&
      !(obj.material instanceof THREE.MeshBasicMaterial)
    ) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });
  beamMesh.castShadow = false;
  beamMesh.receiveShadow = false;

  return {
    group,
    bodyGroup,
    head,
    armL,
    armR,
    legL,
    legR,
    beamMesh,
    torchGlow,
    muzzleFlash,
    auraGlow,
    trimColor: palette.trim,
    toolMeshes,
    nameSprite,
    nameText: name,
    walkPhase: 0,
    idlePhase: Math.random() * Math.PI * 2,
    recoilTimer: 0,
  };
}

export function triggerSurvivorGunshot(rig: PlayerSurvivorRig): void {
  rig.recoilTimer = 0.24;
  rig.muzzleFlash.visible = true;
  (rig.muzzleFlash.material as THREE.SpriteMaterial).opacity = 0.98;
  rig.muzzleFlash.scale.set(0.68, 0.68, 1);
}

export function getSurvivorMuzzleWorldPos(
  rig: PlayerSurvivorRig,
  out: THREE.Vector3
): THREE.Vector3 {
  rig.group.updateMatrixWorld(true);
  return rig.muzzleFlash.getWorldPosition(out);
}

export function updateSurvivorNameTag(
  rig: PlayerSurvivorRig,
  name: string,
  status = ''
): void {
  const key = `${name}|${status}`;
  if (rig.nameText === key) return;
  rig.nameText = key;
  const mat = rig.nameSprite.material as THREE.SpriteMaterial;
  mat.map?.dispose();
  mat.map = createNameTagTexture(name, status);
  mat.needsUpdate = true;
}

export function animateSurvivorRig(
  rig: PlayerSurvivorRig,
  dt: number,
  speed: number,
  crouch: boolean,
  torchOn: boolean,
  heldItem: HeldItemType,
  alive: boolean
): void {
  rig.beamMesh.visible = torchOn && alive;
  rig.torchGlow.visible = torchOn && alive;

  (Object.keys(rig.toolMeshes) as Exclude<HeldItemType, null>[]).forEach((k) => {
    rig.toolMeshes[k].visible = alive && heldItem === k;
  });

  if (!alive) {
    rig.bodyGroup.rotation.x = -Math.PI / 2;
    rig.bodyGroup.position.y = 0.28;
    rig.armL.rotation.x = -0.35;
    rig.armR.rotation.x = 0.25;
    rig.legL.rotation.x = 0.12;
    rig.legR.rotation.x = -0.08;
    rig.head.rotation.y = 0.18;
    rig.nameSprite.position.y = 1.15;

    const auraMat = rig.auraGlow.material as THREE.SpriteMaterial;
    auraMat.color.setHex(0xff5238);
    auraMat.opacity = 0.34 + 0.22 * (0.5 + 0.5 * Math.sin(performance.now() * 0.005));
    rig.auraGlow.scale.set(2.1, 1.4, 1);
    rig.auraGlow.position.set(0, 0.4, 0);
    return;
  }

  const auraMat = rig.auraGlow.material as THREE.SpriteMaterial;
  auraMat.color.setHex(rig.trimColor);
  auraMat.opacity = 0.24;
  rig.auraGlow.scale.set(1.45, 2.15, 1);
  rig.auraGlow.position.set(0, 1.15, 0);

  rig.idlePhase += dt * 2.1;
  const breathe = Math.sin(rig.idlePhase) * 0.015;

  rig.bodyGroup.rotation.x = crouch ? 0.24 : 0;
  rig.bodyGroup.position.y +=
    ((crouch ? -0.35 : 0) + breathe - rig.bodyGroup.position.y) * Math.min(1, dt * 10);
  rig.nameSprite.position.y = crouch ? 1.78 : 2.15;

  if (speed > 0.15) {
    rig.walkPhase += dt * Math.min(12, speed * 2.5);
  }
  const swing = speed > 0.15 ? Math.sin(rig.walkPhase) * Math.min(0.85, speed * 0.22) : 0;

  rig.recoilTimer = Math.max(0, rig.recoilTimer - dt);
  if (rig.recoilTimer > 0.11 && alive) {
    const kFlash = (rig.recoilTimer - 0.11) / 0.13;
    rig.muzzleFlash.visible = true;
    const sc = 0.42 + kFlash * 0.38;
    rig.muzzleFlash.scale.set(sc, sc, 1);
    (rig.muzzleFlash.material as THREE.SpriteMaterial).opacity = Math.min(1, kFlash * 1.15);
  } else {
    rig.muzzleFlash.visible = false;
  }

  rig.legL.rotation.x = swing;
  rig.legR.rotation.x = -swing;
  rig.armL.rotation.x = -0.92 + swing * 0.15;
  const recoilKick = rig.recoilTimer > 0 ? (rig.recoilTimer / 0.24) * 0.62 : 0;
  rig.armR.rotation.x =
    (heldItem ? -0.65 + swing * 0.2 : -swing * 0.55 + breathe * 1.4) - recoilKick;
  rig.head.rotation.y =
    speed > 0.15
      ? Math.sin(rig.walkPhase * 0.25) * 0.05
      : Math.sin(rig.idlePhase * 0.45) * 0.08;
}
